# Windows/WSL 脚本执行（本技能入口补充）

本技能正文见 SKILL.md。以下是新增的支持文件：

- **`references/powershell-curl-and-python.md`** — 在 Windows PowerShell 5.1 下跑
  网络/抓取脚本的实测坑与可复制模板。包含：
  1. `curl` 是 `Invoke-WebRequest` 别名 → 永远写 `curl.exe`
  2. 别用 heredoc 往 `python -c` 塞代码 → `write_file` 成 `.py` 再跑
  3. 解释器固定用 `uv run --no-project --python 3.14 python script.py`
     （绕开 Store 存根 与 `python314.dll conflicts`）
  4. `&` 调用运算符触发前台/后台误判 → 用 `uv run`
  5. GitHub 搜索 API 限流 + 改名仓库返 422 假"权限"错误 → `git clone --depth 1` 本地检索，
     `curl.exe -D -` 追 301 找新仓库名

遇到 PowerShell 里 curl/python 行为异常时，先读这个文件。
