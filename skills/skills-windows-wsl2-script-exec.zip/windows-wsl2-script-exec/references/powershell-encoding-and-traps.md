# PowerShell 5.1 编码与零散陷阱（原独立技能 windows-wsl-execution，2026-10 并入）

早期版本（引号地狱 / & 后台判定 / -replace 操作数 / 47624 只读 / VBS 编码 / terminal.shell 全崩时走 MCP 通道）。主 SKILL.md 已覆盖更高版本，本文件留作补充与佐证。

# Windows + WSL2 命令执行

用户环境：Windows 11 + WSL2（Ubuntu 24.04，用户 `hermes`，sudo 免密，Python 3.12.3 + Pillow，无 numpy）。工作区 `D:\Hermes文件库` = WSL `/mnt/d/Hermes文件库`。

## 硬规则（用户明确要求）
1. **命令执行优先用 WSL2**：`wsl -d Ubuntu-24.04 -- <cmd>`。
2. **写脚本文件也走 WSL**（wsl 内 python 写 / `bash heredoc`），别用 PowerShell 的 here-string/Out-File 写程序文件（BOM/引号坑）。
3. Windows 专用操作（GUI/启动器/注册表/Hermes CLI/需读取 `LOCALAPPDATA` 的脚本）例外，用 PowerShell。

## 核心陷阱 1：PowerShell 内嵌 Python 引号地狱 ⚠️ 最常见浪费
`curl.exe ... | python -c "import sys,json; [print(f\"{h['x']}\") for h in ...]"` 在 PowerShell 里几乎必炸（引号转义/单双引号混用）。**不要内联 `python -c`。**
正确做法（贯穿会话验证有效的模式）：
1. 用 PowerShell here-string 把 Python 写成文件（无 BOM）：
```powershell
$content = @'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
...正常 Python,用单引号双引号都行...
'@
[System.IO.File]::WriteAllText("D:\Hermes文件库\job.py", $content, [System.Text.UTF8Encoding]::new($false))
```
2. 执行：Windows Python 用 Start-Process，WSL 用 `wsl -d Ubuntu-24.04 -- python3 /mnt/d/Hermes文件库/job.py`。
3. `wsl -- bash -c '...'` 内外层引号嵌套同样会炸——把逻辑写进 .py 用 `... python3 file.py`，别包 bash -c。

## 核心陷阱 2：`& 调用运算符` 触发后台判定
`terminal` 工具看到命令里有 `&`（如 `& "C:\...\python.exe" -u x.py`）会报 `Foreground command uses '&' backgrounding`。**改用 `Start-Process`。**

## 核心陷阱 4：PowerShell 表达式里的隐式参数/只读变量

- **`-replace` 只能有 2 个操作数**：`$h -replace 'pat', '$1' + "x" + $y` 会报
  `The -ireplace operator allows only two elements to follow it, not 4`。
  → 先把替换串拼成一个变量，或写进双引号插值：`$h -replace '(pat)', "`$1`n$extra"`
  （注意 `$1` 在双引号里要转义成 `` `$1 ``，否则 PowerShell 会当自己的变量展开）。
- **`$pid` 是只读自动变量**，`foreach ($pid in 1,2,3)` 报
  `无法覆盖变量 PID，因为该变量为只读`。→ 循环变量换名 `$procid`。
- **中文路径/参数必须完整加引号**：`... "D:\Hermes文件库\每日科技日报\" | Select-Object Name`
  会报 `字符串缺少终止符`（结尾 `\"` 被当转义）。→ 用 `search_files` 工具替代管道内联路径，
  或把路径存进变量再用，别在长管道里裸写中文路径。
- **长内联命令整体被 `Invoke-Expression` 重解析**：工具会把命令包进
  `try { Invoke-Expression '...' }`，里面的引号/中文容易二次解析出错。命令一长
  （>3 个管道、含中文路径、含嵌套引号）就**写成 .ps1/.py 文件再跑**，别硬撑内联。

## 核心陷阱 5：`subprocess` 里调不到 shell 别名
## 核心陷阱 5：`subprocess` 里调不到 shell 别名

Python `subprocess.run(['python3.14', ...])` 报 `FileNotFoundError [WinError 2]`——
`python3.14` 是 PowerShell 的 shell 别名，**不是真的可执行文件名**，`subprocess` 不走 shell 解析。
→ 传完整路径：`C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`。
（同理 `python`/`py` 在 subprocess 里也不可靠。）

## 救命通道：所有 shell 类工具一起崩时

若 `terminal` / `read_file` / `write_file` / `search_files` 同时报
`Unknown HERMES_SHELL_TYPE='wsl -d ubuntu-24.04 -- bash -lc' on Windows`
（config 的 `terminal.shell` 被写成了一条 wsl 命令 —— 合法值只有 `auto|pwsh|powershell|bash`）：

- **`wsl ...` 永远不能写进 `terminal.shell`**。要跑 Linux 就在命令里显式 `wsl -d Ubuntu-24.04 -- bash -lc "..."`。
- 连 `read_file`/`write_file` 都挂了会让人以为没救了 —— 实际 **MCP 通道还活着**：
  `mcp__windows_mcp__FileSystem`（mode=read/write/list）与 `mcp__windows_mcp__PowerShell`
  经 `tool_call` 调用，可完成整条"写 .py → 跑 → 读回"链路。
- 修配置：`hermes config set terminal.shell auto`（CLI 本身不依赖 shell，能跑）。但**进程内缓存不会刷新**，
  必须彻底退出桌面端重开；本会话内继续干活就走上面的 MCP 通道，最后一次性告知用户重启。
- MCP 通道的两个小坑：`FileSystem` 必须给 `mode`（`read`/`write`/`list`），没有 `max_bytes` 参数；
  超长中文内容要分段写再脚本合并，别一次塞几万字。

## 核心陷阱 6：`write_file` 的落盘编码会被下游解释器决定成败 ⚠️

`write_file` 写 .py/.md/.json/.vbs 等文本**不保证是你以为的编码**。对大多数消费方（Python、
markdown）无所谓，但**对按 ANSI 代码页读文件的解释器是致命的**：WSH 读 `.vbs`、PS 5.1 读
`.ps1`、`.bat`，都是按系统 GBK 读。

实测案例（2026-09-21）：`write_file` 写出的 `.vbs` 落成 **UTF-16LE**，里面硬编码了中文用户名
路径 `C:\Users\王子涵\...` → WSH 解读码 → 开机弹 `80070003 系统找不到指定的路径`。

**规则**：
- 写完 `.vbs` / `.ps1` / `.bat` 后，**必须回读验证编码**：
  `([System.IO.File]::ReadAllBytes($p))[0..1]` → `FF FE`=UTF-16LE、`EF BB BF`=UTF-8-BOM。
- **更稳的做法是不依赖编码**：让这类脚本**一个中文字都不带**，路径从 `%LOCALAPPDATA%` /
  `%APPDATA%` 运行时拼。纯 ASCII 文件三种编码下都不会读错。
- 含中文的 `.vbs` 别只改编码（下次被任何工具重存立刻复发）→ 去中文。体检脚本见
  `windows-maintenance` 技能的 `scripts/check_vbs_encoding.py`。
- 反过来：`read_file` 遇到 UTF-16 文件会**判为 binary 读不出来**（file_size 有值但 content 为空）
  —— 这本身就是"文件编码异常"的信号，别当文件损坏。

## 核心陷阱 3：定时任务/无控制台时 Python 输出编码
任务计划环境无控制台，Python `print(emoji/中文)` 用 GBK 会崩。**设 `$env:PYTHONUTF8="1"`**（PEP 540 强制 UTF-8）。

## 捕获 Python 输出（任务跑脚本要看结果）
```powershell
$env:PYTHONUTF8="1"
Start-Process -FilePath "C:\Users\王子涵\AppData\Local\Python\bin\python.exe" `
  -ArgumentList "-u","D:\Hermes文件库\job.py" -NoNewWindow -Wait `
  -RedirectStandardOutput "D:\Hermes文件库\out.txt" -RedirectStandardError "D:\Hermes文件库\err.txt"
Get-Content "D:\Hermes文件库\out.txt" -Encoding UTF8   # 强制 UTF8 读，否则中文乱码
```
`-u`（无缓冲）让卡死时日志能定位。

## 路径 / 环境事实
- Windows Python 实际路径：`C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`（`python`/`py` 别名失效）。注：`AppData\Local\Python\bin\python.exe` 可能不存在，某些脚本用 python3.14.exe。
- WSL 里访问 Windows 盘：`/mnt/c/...`、`/mnt/d/...`；反过来 Windows 路径 `D:\...` 在 WSL 内要转 `/mnt/d/...`。
- `curl`（PowerShell 里是 `Invoke-WebRequest` 别名）≠ `curl.exe`。要 curl 语法必须 `curl.exe`。
- WSL 默认分发不是你想要的时：`wsl -d Ubuntu-24.04 --` 显式指定。
- WSL 里 Python 缺 numpy 等第三方包：别装，用 Pillow 自带 API（`ImageChops.difference().getbbox()` 替代 numpy 找内容边界）。

## 用户强烈偏好
- 命令给 WSL 就别退回 PowerShell（用户会纠正："不是说让你用 WSL 吗"）。一条命令也要 WSL。
- 失败排查时：先看是不是 `&`/引号/编码。**引号/编码是 90% 的根因**，别反复试错同一写法。
