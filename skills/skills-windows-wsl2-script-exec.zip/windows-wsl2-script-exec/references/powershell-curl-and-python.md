# PowerShell 下跑网络/抓取脚本的实测坑与模板

本文件记录在 Windows 11 + PowerShell 5.1 环境里跑研究/抓取类脚本时反复踩的坑。

## 1. `curl` 是别名，不是 curl

PowerShell 的 `curl` 指向 `Invoke-WebRequest`，不认 curl 的参数：

```
Invoke-Expression : 无法绑定参数"Headers"。无法将"System.String"类型的
"Accept: application/vnd.github+json"值转换为"System.Collections.IDictionary"类型。

Invoke-Expression : 无法处理命令，因为一个或多个强制参数丢失: Uri。
```

**永远写 `curl.exe`**（`wget` → `wget.exe` 同理）。它才是真 curl，`-s` / `-o` / `-H "K: v"` 都正常。

```powershell
curl.exe -s "https://api.github.com/repos/OWNER/REPO" -o out.json
curl.exe -s -D - -o NUL "https://example.com" | Select-String -Pattern "location|HTTP/"
```

`-D -` 打印响应头、`-o NUL` 丢弃正文 —— 这是**追 301 重定向**最快的方式（见第 4 节）。

## 2. 别用 PowerShell heredoc 往 `python -c` 塞代码

```powershell
# 坏的
uv run python -c @'
print("=== ", f)
'@
# SyntaxError: invalid syntax   ← 引号被 PowerShell 吃掉，看起来像 Python 的错
```

错误信息会伪装成 Python 语法错误，浪费轮次。**正确做法：`write_file` 成 `.py` 文件再运行**，
需要参数就用 `sys.argv` / 环境变量，不要往命令行里拼代码。

### 2.1 经 `wsl -- bash -lc "..."` 传内联 Python：`$` 和 `[]` 一起炸

把 Python 塞进 `wsl ... bash -lc "python3 -c \"...\""` 时，PS 的兼容层会把
Python 语法当 PS 语法解析。实测两类假错：

```
# 下标 d[1] 被当成 PS 的数组/属性语法
“,”后面缺少表达式。
属性或类型文本末尾缺少 ]。
# 正则 r"^([A-Za-z]...)" 里的引号被 PS 提前吃掉
字符串缺少终止符: '。
```

**症状特征：报错全是 PowerShell 解析器的话术（`Unexpected token` / `缺少右“)”`），
行号指向你的 Python 代码 —— 这不是 Python 的错，是源码根本没传到 Python。**

**规则：`wsl ... bash -lc` 里出现的 Python 一旦含 `[` `]` `$` 正则引号，一律改写 `.py` 文件：**

```bash
# ✅ 先落盘，再执行
wsl -d Ubuntu-24.04 -- python3 /mnt/d/某目录/dbg.py
```

同理，`wsl -d Ubuntu-24.04 -- bash -lc "... <<'PY' ... PY"` 的 heredoc 形式
会让 PS 报 `已指定 command 参数` / `ParameterSpecifiedAlready` —— **heredoc 一律不要走 wsl 内联**。

## 3. 解释器：显式指定版本

`python` / `python3` 在部分 Windows 上只是 Microsoft Store 存根：

```
Python was not found; run without arguments to install from the Microsoft Store...
exit_code: 9009
```

`uv` 的托管解释器可能与系统 Python 冲突：

```
ImportError: Module use of python314.dll conflicts with this version of Python.
```

**固定用这个组合**，两个问题一起解决：

```powershell
uv run --no-project --python 3.14 python script.py
```

- `--python 3.14` 显式选版本，绕开 dll 冲突
- `--no-project` 避免在用户目录留下 project 环境

先 `uv python list` 看有哪些真实解释器，别假设 `python` 可用。

## 4. `&` 调用运算符会触发误判

```powershell
& "$env:LOCALAPPDATA\Python\pythoncore-3.14-64\python.exe" script.py
# 被拒：Foreground command uses '&' backgrounding.
```

前台命令检测器把 `&` 调用当成后台化。用 `uv run ...` 或直接相对路径调用。

## 5. 仓库改名 = 301，搜索 API 会静默失败

未认证的 GitHub 搜索 API 限流很紧，报：

```
API rate limit exceeded for <ip>. (But here's the good news: Authenticated requests
get a higher rate limit...)
```

而且**仓库改名后**，`search/code` 会返回 `422 Validation Failed`：

```json
{"message":"Validation Failed","errors":[{"message":"The listed users and repositories
cannot be searched either because the resources do not exist or you do not have
permission to view them.","field":"q"}]}
```

这个 422 看起来像"权限问题"，实际是**仓库已改名**。用 `-D -` 看 301 的 Location 找新地址：

```powershell
curl.exe -s -D - -o NUL "https://api.github.com/repos/OLD/NAME" | Select-String -Pattern "location"
```

**结论：要读某个仓库的源码，直接 `git clone --depth 1` 再本地 grep，别跟搜索 API 搏斗。**
`raw.githubusercontent.com` 不受搜索 API 限流影响，适合单文件快取：

```powershell
curl.exe -s "https://raw.githubusercontent.com/OWNER/REPO/main/path/to/file.go" -o file.go
```

## 可复制模板：本地检索一个仓库

```powershell
git clone --depth 1 https://github.com/OWNER/REPO.git repo-src
# 然后用 search_files 在 repo-src 下按 pattern 检索（比 grep 快且结果结构化）
# 用完删掉：Remove-Item -Recurse -Force repo-src
```

`--depth 1` 只取最新快照，大仓库也能秒级完成（2500+ 文件的 Go 仓库实测没问题）。
读完记得清理，别把克隆留在用户目录。
