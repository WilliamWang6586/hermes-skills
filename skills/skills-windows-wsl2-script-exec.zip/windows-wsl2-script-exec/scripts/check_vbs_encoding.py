# -*- coding: utf-8 -*-
"""检查/修复启动文件夹与 gateway-service 下 .vbs 的编码为纯 ASCII。

背景：WSH 对 UTF-16LE 或含中文的 .vbs 会解码错乱 -> 开机报 80070003
「系统找不到指定的路径」。规则：.vbs 一律纯 ASCII + 路径用 %LOCALAPPDATA% 拼。

用法:
    python3.14 check_vbs_encoding.py              # 检查默认路径
    python3.14 check_vbs_encoding.py <vbs> [...]   # 检查指定文件

退出码: 0=全部OK  1=有问题（含中文需手工改，或仍是 UTF-16）
"""
import os
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

DEFAULT_TARGETS = [
    os.path.expandvars(r"%LOCALAPPDATA%\Hermes Agent CN Desktop\data\hermes-home\gateway-service\Hermes_Gateway.vbs"),
    os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Hermes_Gateway.vbs"),
    os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Hermes_GatewayGuard.vbs"),
]


def inspect(path):
    """返回 (源编码, 非ASCII字符列表, 是否已改为ASCII)。"""
    raw = open(path, "rb").read()
    if raw[:2] == b"\xff\xfe":
        text, src = raw.decode("utf-16-le"), "UTF-16LE"
    elif raw[:3] == b"\xef\xbb\xbf":
        text, src = raw.decode("utf-8-sig"), "UTF-8-BOM"
    else:
        text, src = raw.decode("utf-8", errors="replace"), "UTF-8"

    bad = [(i, c) for i, c in enumerate(text) if ord(c) > 127 and c not in "\r\n"]

    # 纯 ASCII 且无 BOM -> 无需动
    if not bad and raw[:2] != b"\xff\xfe" and raw[:3] != b"\xef\xbb\xbf":
        return src, bad, False

    # 含中文：不能自动转（转了会丢字符），交给人工改写
    if bad:
        return src, bad, False

    # 无中文但编码不对（UTF-16/BOM）-> 安全转成 ASCII + CRLF
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")
    open(path, "wb").write(text.encode("ascii"))
    return src, bad, True


def main():
    targets = sys.argv[1:] or DEFAULT_TARGETS
    fails = 0
    print("=" * 70)
    for p in targets:
        if not os.path.exists(p):
            print(f"[跳过] 不存在: {p}")
            continue
        src, bad, fixed = inspect(p)
        cur = open(p, "rb").read()
        is_utf16 = cur[:2] == b"\xff\xfe"
        if bad:
            status = f"❌ 含 {len(bad)} 个非ASCII字符（须手工改写成纯ASCII）"
            fails += 1
        elif is_utf16:
            status = "❌ 仍是 UTF-16"
            fails += 1
        else:
            status = "✅ ASCII-OK" + ("（已自动转换）" if fixed else "")
        print(f"\n{os.path.basename(p)}\n  原编码={src}  {status}")
        for i, c in bad[:5]:
            print(f"    pos {i}: {c!r} U+{ord(c):04X}")
        if bad:
            print("    → 改用 %LOCALAPPDATA% 拼路径，去掉中文硬编码")
    print("\n" + "=" * 70)
    print("[OK] 全部通过" if fails == 0 else f"[FAIL] {fails} 个文件有问题")
    return 1 if fails else 0


if __name__ == "__main__":
    assert inspect.__doc__, "self-check"
    sys.exit(main())
