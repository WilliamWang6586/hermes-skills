---
name: windows-wsl2-script-exec
description: >-
  HOW to write and run scripts on this Windows 11 + WSL2 host (user 王子涵)
  without hitting PowerShell↔WSL quoting/BOM failures. Use whenever a task needs
  a Python/script executed on the Windows machine — the naive inline forms
  (`python -c`, `wsl bash -c '...'`, PS here-strings with Chinese, `&` in the
  command) blow up. Covers the reliable write-file + run-in-WSL pattern.
version: "1.3"
updated_at: "2026-10-20"
---

# Windows + WSL2 脚本执行模式（用户：王子涵）

本机 Windows PowerShell 5.1 + WSL2（Ubuntu 24.04，用户 hermes）。大量报错是**引号嵌套 + Python 无 BOM 中文乱码 + `&` 被当后台**造成的。下面是被验证可靠的固定做法。

## ⭐ 什么时候值得走 WSL，什么时候别（别滥用）

用户 2026-10-20 问过「是不是所有命令都能走 WSL，WSL 对 AI agent 是不是更好用」。
**答：不是。默认走 PowerShell 更快，WSL 只在缺 Linux 工具时才值。** 别为了"显得专业"往 WSL 里塞。

| 值得走 WSL | 别走 WSL |
|---|---|
| 跑 Linux 项目（pip/apt 装的依赖） | 操作 `D:\Hermes文件库` 里的文件（`/mnt/d` 跨文件系统慢很多倍） |
| `apt install` Linux 专属工具 | Hermes 自身脚本（`.ps1`、`hermes` CLI）—— WSL 里跑不了 |
| 复杂 `grep`/`sed`/awk 管道 | 批量遍历几十万小文件（`/mnt/d` 遍历是灾难） |
| `#!/bin/bash` 脚本、Docker/systemd | 注册表、Windows 服务、Office COM、AutoCAD COM |

**判断口诀**：命令里出现 `.ps1` / `hermes` / `Get-` / `D:\` → PowerShell 直接跑；
出现 `apt` / `bash` / `/mnt/d` / `chmod` → 套 `wsl -d Ubuntu-24.04 -- bash -lc "..."`。
路径换算：`D:\Hermes文件库` ↔ `/mnt/d/Hermes文件库`。

## 铁律（用户明确要求）
- 命令执行**优先走 WSL2**：`wsl -d Ubuntu-24.04 -- <cmd>`

  ⚠️ **这条是自觉遵守，不是环境强制。** 本机 `config.yaml` 里**没有** `terminal.shell` 键
  （只有工具白名单里的 `- terminal`），所以 Hermes 的 `terminal` 工具默认仍由 **PowerShell 5.1** 执行；
  WSL 只是靠你在每条命令外层套 `wsl -d ...` 进去。
  **每会话开头做一次确认**（一条命令，别猜）：
  ```powershell
  wsl -d Ubuntu-24.04 -- bash -lc "echo WSL_OK; whoami; ls /mnt/d/Hermes文件库 | head -3"
  ```
  输出 `WSL_OK / hermes / ...` = WSL 可用，之后所有命令照本节套壳执行。
  想让 terminal 工具原生走 WSL 只有一条路（全局行为变更，**先问用户**）：
  `hermes config set terminal.shell "wsl -d Ubuntu-24.04 -- bash -lc"`。
  改完后所有 Windows 专用命令（AutoCAD COM、启动器、注册表）得反过来套 `powershell.exe -Command "..."`。
  **别把"记忆里写了走 WSL"当成已配置** —— 用户 2026-10-20 明确问过"为什么老走 PowerShell"，
  根因就是记忆只是提示词上下文，`config.yaml` 从未落这个键。

  **2026-10-20 已实际写入**：`hermes config set terminal.shell "wsl -d Ubuntu-24.04 -- bash -lc"`
  → config.yaml 已确认落盘（`terminal:` / `  shell: wsl -d Ubuntu-24.04 -- bash -lc`）。

  ⚠️ **改完不要在「改配置的那个会话」里验证，要开新会话**。`terminal.shell` 是**会话启动时读一次**：
  当前会话中途改完立刻跑 `uname -s` 会看到 `MSYS_NT-10.0-...` 或 PowerShell 输出，**这不是配置失败**。
  验活就一句：`uname -s` → `Linux` 才算生效。
  若**新会话**里仍不切换，才说明该版本运行时不认 `terminal.shell` 键 —— runtime 是 PyInstaller 打包的
  `hermes-agent-cn-runtime-win32-x64.exe`（MZ 头，源码嵌二进制，`strings` 里只有模块名如
  `tools.terminal_tool` 没有配置键文本），**只能实跑验证，别靠翻二进制猜**。

  ✅ **2026-10-20 已实跑定性（别再重复验证了）**：配置值确实落盘（`hermes config get terminal.shell`
  返回 `wsl -d Ubuntu-24.04 -- bash -lc`，环境里也有 `HERMES_SHELL_TYPE` = 同一串），但 `/new` 开新会话后
  `uname -s` **仍是 `MSYS_NT-10.0-26200`**。即 **0.19.0-cn.7 运行时不吃这个键**，写整条命令行无效。
  - **别再去翻 `_internal` 找源码**：`hermes_cli/` 只剩 `web_dist`，`tools/` 只剩 `__init__.py`+`computer_use`，
    `terminal_tool.py` 已编译进 exe，`search_files` 搜 `HERMES_SHELL_TYPE` 必定 0 命中——实测浪费 8 轮。
  - **结论用法**：需要 WSL 就在每条命令外层套 `wsl -d Ubuntu-24.04 -- bash -lc "..."`（实测通，返 `Linux`/`hermes`）。
  - 想把无效配置清掉：`hermes config unset terminal.shell`，免得以后误以为"已配好"。

  🔴 **2026-10-20 二次实测修正：这个值不是「无害无效」，而是会把所有 shell 类工具打死。**
  写 `terminal.shell: wsl -d Ubuntu-24.04 -- bash -lc` 落盘后（重启过 Hermes、也开过新会话），
  **`terminal` / `read_file` / `search_files` / `write_file` / `patch` 全部在初始化阶段崩溃**：
  ```
  RuntimeError: Unknown HERMES_SHELL_TYPE='wsl -d Ubuntu-24.04 -- bash -lc' on Windows.
  Supported values: 'auto', 'pwsh', 'powershell', 'bash'
  ```
  - 致命性：连 `hermes config set terminal.shell auto` 都跑不了（它本身要走 terminal 工具），
     `read_file` 也读不了 config.yaml → **agent 自己无法自修，只能让用户手改**。
  - 用户改环境变量 `HERMES_SHELL_TYPE=auto` **没用**：报错里那串值是 runtime 从 `config.yaml` 读的，
    不是进程环境变量。
  - 正确处置（给用户的指令要最省事）：让用户在 **Hermes 外部**的 PowerShell 里
    `notepad "$env:LOCALAPPDATA\Hermes Agent CN Desktop\data\hermes-home\config.yaml"`，
    把 `terminal.shell` 整行删掉或改成 `auto`，然后完全退出重开。
  - **规则：`terminal.shell` 只许 `auto|pwsh|powershell|bash`，永远别写 `wsl ...`。**
    要 Linux 就每条命令套 `wsl -d Ubuntu-24.04 -- bash -lc "..."`（本来就是可靠做法）。

  🩹 **修好之后工具仍不恢复 = 进程内缓存，必须重启 app（2026-10-20 实测完整闭环）**：
  把 config 改回 `shell: auto` 后，`terminal` **立刻就能读**（报错信息里会带
  `Supported values: 'auto'|'pwsh'|'powershell'|'bash'`），但**当前进不去的进程仍持有旧值**。
  - 实测：配置文件已是 `shell: auto`（bin 读取第 330 行确认）、`HERMES_SHELL_TYPE` 环境变量已是空，
    `terminal` 却照旧报 `Unknown HERMES_SHELL_TYPE='wsl ...'` → **缓存，不是配置**。处置：**彻底退出桌面端（含托盘图标）再重开**，开新会话不够。
  - ⚠️ **`patch` / `write_file` 会被安全策略硬拒**（"Refusing to write to Hermes config file"），
    `read_file` / `search_files` 也因走同一个 shell 解析层一起崩 → **别跟 config 文件较劲**。
  - ✅ **救命通道 = MCP 的 `mcp__windows_mcp__FileSystem`（read/write）和
    `mcp__windows_mcp__PowerShell`（command）**，它们不经过 Hermes 的 shell 层，实测可用：
    ```
    tool_call mcp__windows_mcp__PowerShell  {"command": "Select-String -Path '<config.yaml>' -Pattern 'shell'"}
    ```
    ⚠️ 这类 MCP 命令里**别 `Select-String` 扫整个 hermes-home 目录**（会命中 sessions/*.json 里的
    超长 system prompt，本次返回 82 万字符直接爆上下文）。只钉单个文件，或加 `-Include` 后排除 `sessions`。
  - **给用户的指令只要两句**：「把 `terminal.shell` 改成 `auto`（或删掉该行）」+「彻底退出重开」。别让他去研究环境变量。

  🚑 **全部 shell 工具瘫痪时的只读取证路径**（本次实测可用，别干等用户）：
  `browser_navigate` + `browser_console` 能读本地文件，即使 terminal 全崩：
  ```
  browser_navigate  file:///C:/Users/%E7%8E%8B%E5%AD%90%E6%B6%B5/AppData/Local/Hermes%20Agent%20CN%20Desktop/data/hermes-home/config.yaml
  browser_console   document.body.innerText            → 直接拿到 yaml 全文（含 terminal.shell 实锤）
  ```
  - 目录列表也能看：`browser_navigate file:///D:/.../memory/` 会渲染成索引表。
  - ⚠️ 单个 md/yaml 文件导航后 `snapshot` 可能是空的 → **再用 `browser_console` 读 `document.body.innerText`**。
  - ⚠️ 不要用 `fetch()` 批量抓 file://（`Failed to fetch`，跨源被拦）；**一次一个文件 `browser_navigate` 最稳**。
  - 路径里的中文/空格必须 percent-encode。

  🧪 **bash.exe 顶替法：实测无效，已回滚（2026-10-20 当天验证完就撤销了，别再试）**：
  Hermes 通过 `HERMES_GIT_BASH_PATH = ...\hermes\git\bin\bash.exe` 写死路径，把它换成
  `C:\Windows\System32\bash.exe`（WSL 启动器）后，**直接调该 exe 确实进 Linux**
  （`bash.exe -c "uname -s"` → `Linux / hermes / /mnt/d/...`），
  但 Hermes 的 `terminal` 工具**照旧跑 PowerShell**，一点没变。
  **真因**：这台机器上 `terminal` 工具根本不用 bash —— 看 `$PID` 的父进程 `CommandLine` 是
  `powershell.exe -NoP -NonI -Exec Bypass ...`。改 bash.exe 等于改了条没人走的路。
  → 已 `Copy-Item bash.exe.bak bash.exe` 完整回滚，`bash.exe` 恢复 47008 字节原版。
  **教训（通用）**：动任何"默认 shell"之前，先一条命令确认当前到底是谁：
  ```powershell
  (Get-CimInstance Win32_Process -Filter "ProcessId=$PID").CommandLine
  ```
  不看这一步就改文件，纯属白忙。
  ```powershell
  $gb="C:\Users\王子涵\AppData\Local\hermes\git\bin"
  Copy-Item "$gb\bash.exe" "$gb\bash.exe.bak" -Force                # ① 备份必须是第一步
  Remove-Item "$gb\bash.exe" -Force
  Copy-Item "C:\Windows\System32\bash.exe" "$gb\bash.exe" -Force    # ② WSL 启动器顶替
  ```
  实测 `$gb\bash.exe -c "uname -s; whoami; pwd"` → `Linux / hermes / /mnt/d/Hermes文件库`，**顶替生效**。
  - 回滚一条：`Copy-Item "$gb\bash.exe.bak" "$gb\bash.exe" -Force`（本次已执行，`.bak` 已删）
  - ⚠️ **风险**：Hermes gateway、各脚本、`git` 全依赖 Git Bash 的 `usr\bin`；换 WSL 后路径语义变了
    （`D:\` → `/mnt/d/`），**大概率连带坏一批工具**。属改系统底层，升级 Hermes 可能被覆盖。
  - ⚠️ **验证到哪一步要认清**：本文只验证了「直接调该 exe 进 Linux」。**"新会话里 terminal 工具跟着变"
    与 "git/gateway 回归" 都没验**。下结论前必须：开新会话 `uname -s` + `git --version` +
    `python3 --version` + gateway 健康检查，四项过了才能说"成功"。
  - **默认建议**：偶尔用 Linux 就别改全局，每条命令套 `wsl -d Ubuntu-24.04 -- bash -lc "..."`。

  🔎 **怎么一眼认出实际 shell**（用户曾发截图问"到底是不是 WSL"）：
  `uname -s` 返 `MSYS_NT-10.0-26200` = Git for Windows 的 MSYS，**不是 Linux 内核**；
  ⚠️ **但这台机器的 PowerShell 里也有 `uname.exe`（Git 的）**，所以在 PS 里敲 `uname -s` 一样返
  `MSYS_NT-...`——**光看这行分不清是 bash 还是 PowerShell**。要定性就看父进程：
  `(Get-CimInstance Win32_Process -Filter "ProcessId=$PID").CommandLine` → 出现 `powershell.exe` 就是 PS。
  `cat /etc/os-release` 报 `找不到路径"D:\etc\os-release"` = PowerShell 把 `/etc/` 当成了 `D:\etc\`；
  输出带 `Path` 表头 = PowerShell 对象格式化，不是 bash 纯文本。

  `wsl -d Ubuntu-24.04 -- bash -lc "..."` 在**纯 ASCII 命令**下是可靠的（实测 `echo/ls/grep/env` 全通）；
  含中文/引号/多命令的复杂串仍按下面「三个必炸的写法」走文件模式。
- **写脚本文件也走 WSL**，不直接用 PS 的 `here-string` 重定向、`Out-File`（PS5.1 默认无 BOM 会中文乱码 + 引号坑）
- Windows 专用操作（GUI / 启动器 / 注册表 / Hermes CLI / 读 LOCALAPPDATA 的脚本）才用 PowerShell
- Windows Python 实际路径：`C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`（`python` 失效=Store 别名 exit 9009；**`py` 可用**：WindowsApps\py.exe → 默认 3.14.6，`py script.py` 是最短可靠调用，2026-10 实测大量脚本跑通，别再绕开它）。
  **用 `Get-Command python3.14` 拿路径、`py -0p` 列已装解释器，别硬编码**——实测 `Get-Command` 返回的是 shim
  `C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`（与 `Programs\Python\...` 不同），
  硬编码过的旧路径可能已不存在。WSL 内用 `python3`（`/mnt/d/...` 路径）。VS Code `code` CLI 也在（打开文件夹教学场景可直接用）。
- **`python -c "..."` 在这台机器会报 `Python was not found; ... Microsoft Store`** →
  不是没装 Python，是 `python` 别名失效。直接用 `python3.14` 的绝对路径

## 三个必炸的写法（避开）
1. `python -c "..."` / `python -c '...'` 内联 → 引号/转义地狱，还被安全审批卡。
2. `wsl ... bash -c '...'` 含中文/嵌套双引号 → wsl.exe 自己再引号一次，bash 收到断串（`syntax error near unexpected token '('`）。**任何含引号、含 `(`、含中文、多命令的 WSL 调用都不要走 `bash -c` 字符串**。
3. 命令里用 `&` 调用（`& "path\prog.exe"`）→ 被 Hermes 当成"后台启动"拒绝（`Foreground command uses '&' backgrounding`）。

## 可靠模式（每次照做）

**A. 写脚本文件**（PS 里用 here-string → `[System.IO.File]::WriteAllText` 无 BOM）：
```powershell
$content = @'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
print("中文")
'@
[System.IO.File]::WriteAllText("D:\Hermes文件库\script.py", $content, [System.Text.UTF8Encoding]::new($false))
```
（`[System.Text.UTF8Encoding]::new($false)` = UTF-8 **无 BOM**，PS 自带 `-Encoding UTF8` 会带 BOM 导致 Python 首行 `#!` 报错。）

**B. 用 WSL 跑脚本**（脚本内路径写 `/mnt/d/...`，不是 `D:\`）：
```
wsl -d Ubuntu-24.04 -- python3 /mnt/d/Hermes文件库/script.py
```

**C. 需要 Windows Python 且要捕获输出**：用 `Start-Process -Wait -RedirectStandardOutput/-RedirectStandardError`（不要用 `&`）：
```powershell
$env:PYTHONUTF8="1"
Start-Process -FilePath "C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe" -ArgumentList "D:\文件\script.py" -NoNewWindow -Wait -RedirectStandardOutput "D:\文件\out.txt" -RedirectStandardError "D:\文件\err.txt"
Get-Content "D:\文件\out.txt" -Encoding UTF8
```

## 已存在的 .py 文件要改一行？用 patch 工具，绝不用 PowerShell 读写改写
`(Get-Content x.py -Raw) -replace '旧','新' | Set-Content x.py` 是**必炸**写法：PS5.1 的 `Get-Content`
按 ANSI/GBK 解码无 BOM 的 UTF-8 → 中文全变 `鍏ュ厷鐢宠涔?` 乱码 → `Set-Content -Encoding UTF8`
再把乱码以 UTF-8 存回去 → **中文不可逆损坏**（实测：一个 gen_docx.py 被这行命令写坏，
首行注释变成 `"""鍏ュ厷鐢宠涔?鈫?鎵撳嵃瀵圭収绋匡紙Word + PDF锛夈€?`，Python 报
`SyntaxError: unterminated triple-quoted string literal`）。

**规则：改 .py/.md/.json 里的内容只用 `patch` 工具（replace 模式）或 `write_file` 整体重写。**
PowerShell 只用来「跑」脚本，不用来「读写」脚本内容。

## write_file 写的中文 .py 会带 BOM？跑之前剥掉
Hermes 的 `write_file` 在 Windows 上可能给 .py 写 UTF-8 **带 BOM**，Python 3 不会因 BOM 报错
（BOM 在首行被吞），但 lint / 某些工具会报 `invalid non-printable character U+FEFF (line 1, column 1)`。
剥 BOM 的一行（幂等，可无脑跑）：
```powershell
$p='D:\path\script.py'; $b=[System.IO.File]::ReadAllBytes($p)
if($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF){ [System.IO.File]::WriteAllBytes($p, $b[3..($b.Length-1)]); 'BOM stripped' }
```
（注意 `$LASTEXITCODE` 残留会让这条命令显示 exit 1，看输出文字判断，别当失败。）

## .vbs（WSH/开机自启）必须存成**纯 ASCII**，路径用环境变量拼
**实测炸点**：`write_file` 写 `Hermes_Gateway.vbs` 落盘成 **UTF-16LE**，且脚本里硬编码了中文用户名路径
`C:\Users\王子涵\...` → WSH 解码脚本时路径变乱码 → 开机弹
「Windows Script Host / 行 24 / 系统找不到指定的路径 / **80070003**」。
（注意：报错行号指向 `sh.CurrentDirectory = ...`，容易误判成"目录不存在"，真因是**脚本编码**。）

**规则**：启动文件夹与 gateway-service 下的 .vbs 一律
1. **纯 ASCII**（一个中文字都不带）；
2. 路径**运行时拼接**：`sh.Environment("PROCESS").Item("LOCALAPPDATA") & "\Hermes Agent CN Desktop\data\..."`
   —— 不写 `%USERPROFILE%` 硬编码、更不写中文用户名；
3. 开头加存在性检查，路径变了就 `WScript.Quit 1` 静默退出，别弹框。

**验证方式**（别只看文件在不在，要看退出码）：
```powershell
$p = Start-Process -FilePath "cscript.exe" -ArgumentList "//nologo","`"$vbs`"" -Wait -PassThru -WindowStyle Hidden
$p.ExitCode   # 0 = 无语法/运行时错误；非0 = 有问题
```
批量检查编码用 `scripts/check_vbs_encoding.py`（转 ASCII + 报非 ASCII 字符位置）。
⚠️ 含 `WScript.Sleep 180000` 的自检脚本用 `-Wait` 会**卡满 3 分钟**（属设计行为，别当故障）。

## ⭐ 要跑多个脚本？用 Python 编排，别用 PowerShell 编排
**本会话最大教训**：写了 3 个 PowerShell 编排脚本（`.ps1` 里带中文标签、中文变量、中文路径），
**全部在解析阶段就炸**：`.ps1` 落盘为 UTF-8 无 BOM → PowerShell 按 GBK 读 → 中文字面量变
`姝ｆ枃`/`鎶ュ悕琛?` → `Unexpected token` / `The string is missing the terminator`。

**根因**：`windows-wsl2-script-exec` 早已警告过 `Get-Content/Set-Content` 读写中文，
但**同一个坑对 `.ps1` 文件本身同样成立**——PS 读脚本时也是按 ANSI/GBK 解码。

**规则：一旦编排逻辑里带中文（标签、路径、变量值），优先转成 Python 写。**

> ⚠️ **但如果产物必须是 `.ps1`（例如要交给别的 agent 复现的安装脚本），别急着改写 Python
> ——真正的修法是给 `.ps1` 存 UTF-8 BOM**（见下节）。本节说的"转 Python"是最省事的选择，
> 不是唯一出路。

### ⭐ `.ps1` 带中文的正确修法：UTF-8 **BOM**（不是改写）

`write_file` 落盘的 UTF-8 **无 BOM**，PS5.1 按 GBK 解码 → 中文字符串被撕裂 →
报**假语法错误**：`表达式或语句中包含意外的标记"}"`，且**行号指向中文字符串所在的那一行**
（本机实测：报错行 22 / 61，两行都恰好含中文注释）。

**辨识法**：报错行附近有中文 + `Get-Content` 读出来是乱码 → **是编码问题，别再找语法**。
补 BOM：

```powershell
$p = "install-skills.ps1"
$t = [System.IO.File]::ReadAllText($p, [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText($p, $t, [System.Text.UTF8Encoding]::new($true))  # $true = 写 BOM
# 复验：首 3 字节必须是 239,187,191
"BOM: $(([System.IO.File]::ReadAllBytes($p))[0..2] -join ',')"
```

⚠️ **`patch` 改过 `.ps1` 后 BOM 可能丢失 → 每次 patch 完都要复验一次。**
（注意方向相反的两个坑：`.py` 要**无** BOM，`.ps1` 含中文要**有** BOM，见上文 4 节。）

**交付 `.ps1` 前的三道验证**（语法通过 ≠ 逻辑正确，**必须实跑关键函数**）：

```powershell
$e=$null;$t=$null
[System.Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$e) | Out-Null
if($e){ $e|ForEach-Object{"行$($_.Extent.StartLineNumber): $($_.Message)"} } else { "语法OK" }
```
1. 语法（上面这段）
2. 编码（BOM 三字节）
3. **关键函数抽出来单独实跑** —— 本会话正是靠实跑才发现 `curl` 缺 `-L` 把 301 重定向的
   有效仓库误判为不存在（会静默跳过安装）。只做语法检查的话，这个 bug 会直接交付出去。

**另外：PowerShell 函数名别用 `Test-*` 前缀**（保留动词，与 `Test-Path` 冲突），
用 `Assert-RepoExists` 这类自定义动词。

```python
# ✅ 编排写在 Python 里，零编码坑
import os, subprocess
MEM = r"D:\Hermes文件库\记忆外置库"          # 中文路径在 Python 里完全没问题
PY  = r"C:\Users\王子涵\AppData\Local\Python\bin\python.exe"
env = dict(os.environ, PYTHONUTF8="1")
for f in ["a.py", "b.py", "c.py"]:
    r = subprocess.run([PY, "-u", os.path.join(MEM, f)],
                       capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env=env)
    print(f"===== {f} exit={r.returncode} =====")
    print("\n".join("  " + l for l in r.stdout.strip().splitlines()[-6:]))
    if r.returncode:
        print("  ERR: " + r.stderr.strip().splitlines()[-1][:200])
```

随后只留一条 PowerShell 命令把**这个编排脚本**跑起来（全部是 ASCII）：
```powershell
$env:PYTHONUTF8="1"
Start-Process -FilePath $py -ArgumentList @("-u","D:\...\_all.py") -NoNewWindow -Wait `
  -RedirectStandardOutput "$env:TEMP\o.txt" -RedirectStandardError "$env:TEMP\e.txt"
Get-Content "$env:TEMP\o.txt" -Encoding UTF8
```

**判定法**：如果一段 PowerShell 里出现了**任何一个中文字面量**，就改成 Python。
`Start-Process` 的 `-ArgumentList @("-u", $带中文路径)` 这一层是安全的
（PS 只是把字符串原样传给进程），**不安全的是 PS 自己解析脚本内容**。

## ⭐ 给 input() 程序喂自动化输入：管道会带 BOM 前缀，重定向文件才干净

测试「读 input() 的脚本」时，**PS 管道 `"a`nb" | py x.py` 会把 BOM（`\ufeff`）粘进第一行**——
实测 `float("19.9")` 收到 `'\ufeff19.9'` 报 `ValueError: could not convert string to float`，
看着像脚本 bug，其实是**测试环境问题**（真人敲键盘不会有 BOM）。

**可靠做法**：写一个无 BOM 的 UTF-8 输入文件，用 `cmd /c` 重定向：

```powershell
[IO.File]::WriteAllText("D:\path\in.txt", "19.9`n3`n100", (New-Object System.Text.UTF8Encoding($false)))
cmd /c "py script.py < D:\path\in.txt"
Remove-Item D:\path\in.txt
```

判断输入相关报错真伪：`ValueError` 信息里带 `\ufeff` / `\x00` 之类的转义 = 喂入污染，不是脚本错。

### 在 MCP `windows_mcp__PowerShell` 里喂输入：只能用 `cmd /c`，且别用 `&` 捕获

2026-10-24 实测（该通道的 PS 方言比本机 PS5.1 更窄），三种写法对照：

| 写法 | 结果 |
|---|---|
| `cmd /c "py x.py < in.txt"` | ✅ 可用（推荐） |
| `& py x.py < in.txt` | ❌ `The '<' operator is reserved for future use.` |
| `$out = & py x.py < in.txt 2>&1` | ❌ 同上（重定向不支持，跟 `&` 无关） |

所以 MCP 里跑交互程序就两行：写无 BOM 输入文件 → `cmd /c "py x.py < _in.txt"`，
输出直接在返回里，**不需要重定向到文件再读**。

### 把多行内容写进文件：`@'...'@` here-string 一次写，别用数组 join

用 `'a','b' | Join-String` 或 `-join "`n"` 拼长文本时，反引号转义和引号嵌套会连炸两轮。
直接 here-string 最稳（PS5.1 支持，MCP 通道也支持）：

```powershell
$c = @'
第一行
第二行含 "双引号" 和 '单引号' 都安全
'@
[IO.File]::WriteAllText($p, $c, (New-Object System.Text.UTF8Encoding($false)))
```

⚠️ 但**内容是 Python 代码且含大量引号/f-string 时**，走 `write_file` 工具或 MCP `FileSystem` 写，
别塞 here-string —— 一旦需要写 `'` 或 `@'` 结尾符就完蛋。

## ⭐ Dashboard 起不来 / 端口被占：先查 Windows 端口排除表，别急着改配置

Hermes CN Desktop 的 dashboard 固定从 **9120** 起试 `9120/9121/9122`。若整段被 Windows 占掉，
进程在打印 `HERMES_DASHBOARD_READY` 之前就 `exit 1`，桌面端报
`Failed to start the dashboard after 3 attempt(s) ... exited before ready`。

**根因**：WSL2/Hyper-V 的 winnat 动态预留 TCP 端口段，命中就 `bind()` → `WinError 10013`
（"以一种访问权限不允许的方式做了一个访问套接字的尝试"）。**不是配置错、不是插件错。**

```powershell
netsh interface ipv4 show excludedportrange protocol=tcp   # 看 9120-9122 是否落在某段里
```
落在里面 → 管理员释放（会短暂影响 WSL/容器网络）：
```powershell
net stop winnat; net start winnat
```
复验：排除表里那段消失 → 手动 `dashboard --host 127.0.0.1 --port 9120 --no-open` 看到
`HERMES_DASHBOARD_READY port=9120` 即成功；`Invoke-WebRequest http://127.0.0.1:9120/` 返 200。
`/api/health` 返 **401 是认证门，不是故障**。

**两条别踩的**：
1. 复发时**先查排除表再决定**，别一看见 startup failed 就重启 winnat。
2. 换端口**不是根治**：排除段是动态的，今天空的 9310 明天也可能被占。
3. `--skip-build` 会去找 `<版本目录>\hermes_cli\web_dist`，实际产物在 `_internal\hermes_cli\web_dist`
   → 报 "no web dist found"。手动起 dashboard 时**别加** `--skip-build`。

## 脚本 assert 阈值别写死
自检脚本里的 `assert han > 3000` 这类**校验阈值**，在稿件被正常精简后会误报失败
（实测：字数从 3630 合理压到 2948，脚本报 AssertionError，看着像内容坏了）。
阈值留出正常波动余量（如按目标字数的 85% 设），并让报错信息说清是"阈值"还是"内容异常"。

## 文件被 Word/Excel 占用 → PermissionError: [Errno 13]
生成 .docx/.xlsx 时若用户正开着那个文件，`doc.save()` 直接
`PermissionError: [Errno 13] Permission denied`。
不要重试、不要让用户关 Word 才能继续——**换个输出文件名**（`_打印稿.docx` / `_v2.docx`），
一次成型。交付时明确告诉用户「旧的哪份已作废、抄写/使用只用新文件」。

## Windows Python 打印中文乱码？
控制台按 GBK 解码无 BOM 的 UTF-8 会乱码（如 `w\u0000s\u0000l` 前缀、`�hKm0R`）——**这不代表文件/内容错**。用 `-Encoding UTF8` 读回文件、或用 `Start-Process` 重定向到文件再读，就正常。

## PowerShell 语法坑（零散但会卡住）

1. **`-replace` 第 2 参数不能拼接**：`-replace 'a', '$1' + "x"` 报 `allows only two elements`。
   改用双引号插值：`-replace 'a', "`$1`nx"`。
2. **命令里的 `&` 被 Hermes 判为 backgrounding 拒绝** → **首选：根本别用 `&`**。
   `&` 只在调用**带引号 / 含空格的路径**时才需要；`curl.exe -s -o NUL -w "%{http_code}" https://x`、
   `git ls-remote ...` 这类**裸命令名直接写就正常**（2026-10-10 实测通过）。只有路径带引号那种才包 `cmd /c "..."`。
3. **`bash -lc '...'` 单引号内的 `$r` 仍会被 PS 展开** → 复杂 bash 一律写 `.sh` 文件再跑。
4. **`wsl` 传 Windows 路径给 python3 会拼错** → 必须转 `/mnt/c/...`、`/mnt/d/...` 格式，不能直接传 `C:\...`。
5. **PS5.1 读 UTF-8 中文模板乱码**（GBK 解码）→ 用 `read_file` 工具或 WSL `cat` 读，别信 PS 显示。
6. ⭐ **`$var` 紧跟 `:` → PS 当成 scope/drive 语法，直接报错**（2026-10-10 实测）：
   `变量引用无效。':' 后面的变量名称字符无效。请考虑使用 ${} 分隔名称`。
   最阴的是**中文会被吃进变量名**——`"第$_次: HTTP $code"` 里 PS 把 `$_次` 当变量名，`:` 紧随其后 → 报错，
   症状看着像"中文路径/中文变量"问题，其实是**冒号语法**。
   **修法（按推荐度）**：①`-f` 格式化最稳：`Write-Host ("第{0}次: HTTP {1}"  -f $_, $code)`
   ②花括号分隔 `${code}` ③变量后加一个空格。**任何「变量 + 冒号」的插值都套这条。**

## ⭐ 中文路径连「可执行文件」都过不去 → 测试一律搬到 ASCII 目录

**实测**：`& "D:\Hermes文件库\c_projects\minesweeper.exe"` 报
`无法将"D:\Hermes鏂囦欢搴揬c_projects\minesweeper.exe"项识别为 cmdlet...`
—— PS 把**命令行里的中文路径**按 GBK 解码，路径直接烂掉。不只是 `.ps1` 文件内容，
**传给 cmdlet 的中文路径实参同样会烂**。

**规则：凡是「编译 → 反复跑 → 读输出」的循环（编译型语言、待测二进制、批量测试），
全部在 `C:\Users\Public\<工程名>\` 下做**，完事再 `Copy-Item` 回 `D:\Hermes文件库\...`：

```powershell
New-Item -ItemType Directory -Force -Path C:\Users\Public\proj | Out-Null
Copy-Item "D:\Hermes文件库\proj\a.exe" C:\Users\Public\proj\ -Force
# 在 ASCII 路径下反复编译/测试/读输出, 零编码坑
```
`gcc` 本身编译时路径带中文**没问题**（`gcc -o "D:\Hermes文件库\...\a.exe" "D:\...\a.c"` 实测可用），
烂的是 **PS 的 cmdlet / 调用运算符解析路径**。所以：编译可以留在原地，**跑和读挪到 ASCII 目录**。

## ⭐ PS 的 `cd` 不跨调用持久 → 每条命令都用绝对路径
`cd D:\xxx; <cmd>` 在下一轮 terminal 调用里**回到默认 cwd**（实测：`cd` 后紧跟的
`[System.IO.File]::ReadAllText("相对名")` 报 `未能找到文件 "D:\Hermes文件库\相对名"`）。
**每条命令里所有路径写绝对路径**，或用 `-Workdir` 参数，别指望 `cd` 记住。
（`$env:` 变量是持久化的，只有 cwd 不是。）

## 读被重定向的输出：先判 UTF-16 还是 UTF-8
`cmd | Out-File` / `>` 重定向在 PS5.1 里会写成 **UTF-16LE**（`read_file` 报
`Binary file - cannot display as text`）。别猜编码，直接按字节探测再转 UTF-8：
```powershell
$b = [System.IO.File]::ReadAllBytes("C:/path/out.txt")
$enc = if ($b.Length -ge 2 -and $b[0] -eq 0xFF -and $b[1] -eq 0xFE) { [System.Text.Encoding]::Unicode }
       elseif ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) { [System.Text.Encoding]::UTF8 }
       else { [System.Text.Encoding]::UTF8 }
[System.IO.File]::WriteAllText("C:/path/out.utf8.txt", $enc.GetString($b), [System.Text.UTF8Encoding]::new($false))
```
然后用 `read_file` 读 `out.utf8.txt`（工具按 UTF-8 读，正常）。
**更省事的首选：整个测试用 Python `subprocess` 驱动，`encoding="utf-8"` 显式指定，跳过所有 PS 重定向。**

## ⭐ 被测程序若自己调 `system("cls")`，管道输入会静默丢光
写 C/C++ 控制台程序的自动化测试时，**清屏别用 `system("cls")`**：输入被重定向（管道/文件）时
`system()` 会起子进程并干扰 stdin，之后 `fgets` 立刻读到 EOF → 程序"只跑完菜单就退出"，
输出看着正常但后面的命令全没执行（实测 `out1.txt` 只有 10 行菜单）。
改 **ANSI 转义** `printf("\033[2J\033[H")`，只影响显示不碰 stdin。
配合检测：`GetConsoleMode` 失败 或 `!isatty(fileno(stdin))` → 关掉 ANSI + 关掉倍速延时，
测试跑得又快又干净。

## ⭐ 写测试脚本时：断言错法会让「程序没 bug」变成「测试全红」

自建测试驱动时最贵的坑是**测试自身有 bug，却看着像被测程序坏了**。实测两类：

1. **重复出现的行取第一个匹配 → 断言永远读到初始值。**
   游戏每回合重印一次 `已翻开: N/71`。`re.search(r"已翻开: (\d+)/", out)` 拿的是
   **第一块**（`0`），于是"首翻后应展开"100% 失败；而真相是末块 `28/71`，程序完全正常。
   **修法**：`re.findall(...)` 取 `max()` 或 `[-1]`。**任何"会随迭代变化的状态行"都用 findall。**
   同理：程序 `q` 退出后**不再重绘**，所以"最后一块棋盘"在 `split("已翻开: ")[-2]`，不是 `[-1]`。

2. **对随机结果写死断言。**
   `check("踩雷" in out)` 在随机布雷下必然偶发失败（那一局恰好没踩雷），
   `check("胜利" in out)` 同样。**断言"两种出口都出现过"要用 N 局统计，不能压单局。**
   需要确定性 → 给被测程序加 `--seed N` 固定随机种子（顺带让 bug 可复现），
   再用「同种子跑一局读出内部状态 → 同种子重开并规避 → 断言必须成功」的两阶段法，
   这样"胜利判定"这种原本靠运气的逻辑就能被**严格**验证。

3. **解析定宽文本要按列宽切，别用正则逐字符枚举。**
   棋盘每格固定 2 字符（`" #"` / `" ."` / `" 1"`）。用 `findall(r"[1-8]", body)` 枚举会
   **把 `.` 也数成一列** → 列号全错 → 拿错格子。先 `re.sub(r"\x1b\[[0-9;]*m","",body)` 去色，
   再 `[s[i:i+2] for i in range(0,len(s),2)]` 定宽切格。

**排查手法**：断言红了先怀疑**断言**，别先改程序。打印出实际匹配到的原始内容
（`repr()` 看转义和 `\r`）再判断——本次 90% 的"失败"都是解析/断言写错，
真正的程序 bug 只有「洪泛展开重复入栈导致堆损坏」一个，它是靠
`rc=3221226356`(=0xC0000374 堆损坏) 这个**独立信号**才被抓出来的，不是靠断言。

## 相关工具 API 备忘

**截图/图片 → 自己「看」**（本会话：要读用户发的扫雷截图里的 16×16 棋盘）：
`vision_analyze` 在本机走的是**辅助模型**，输出可能被 summarize/截断，不可靠地拿空间布局。
可靠做法：`browser_navigate` 打开 `file:///C:/...` 图片，再 `browser_vision` 提问
（本地图片路径里的中文用户名要 percent-encode，如 `C:/Users/%E7%8E%8B%E5%AD%90%E6%B6%B5/...`）。
⚠️ 即使这样，OCR 出的网格仍会**个别格错位**——所以设计自检：
带「相邻数字 vs 旗数」一致性约束的任务（扫雷/数独/棋盘类），把读到的网格丢给求解器，
求解器第一件事就是报矛盾点（`数字1 周围已有2旗` = 读错了），**矛盾处标出来别硬答**。

**Scrapling**（`D:\Hermes文件库\开源项目部署\Scrapling\.venv`）：
- playwright 在 `[fetchers]` extra 组里，**不是** 独立的 `playwright` extra
- `Response` 对象**没有** `title` / `css_first` 属性，用 `response.css("...").get()`

## ⭐⭐ 提权写系统文件（hosts 等）：`-Verb RunAs -File` 会静默失败并清空文件

**2026-10-16 实测两次把 `C:\Windows\System32\drivers\etc\hosts` 写成 0 字节**，全程无报错：

```powershell
# ❌ 这两个写法都会「看着成功、其实没写」
Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','D:\Hermes文件库\x.ps1' -Wait
#    → PS5.1 把含中文的路径实参按 GBK 吞掉 → 脚本没跑（你以为跑了）
#    且脚本内 here-string @'...'@ 经该路径传参可能整体为空
#    → Set-Content -Value $null 写出 0 字节，原文件内容直接丢失
```

**症状辨识**：`Get-Item <系统文件> | Select LastWriteTime,Length` → **LastWriteTime 变了但 Length=0**。
这是「提权脚本没真正执行 + here-string 为空」的组合，不是权限问题。

**可靠写法：内容落一个纯 ASCII 文件，再用 `cmd /c copy /Y` 提权覆盖。**

```powershell
# 1) 用 write_file 把目标内容写到纯 ASCII 路径（不带中文！）
#    C:\Windows\Temp\hosts_default.txt
# 2) 提权 copy 覆盖
Start-Process cmd -Verb RunAs -ArgumentList '/c','copy','/Y','C:\Windows\Temp\hosts_default.txt','C:\Windows\System32\drivers\etc\hosts' -Wait
Start-Sleep -Seconds 1
# 3) 必须验证非 0，别只看没报错
Get-Item C:\Windows\System32\drivers\etc\hosts | Select-Object LastWriteTime,Length
```

**三条铁律**：
1. **改系统文件前先备份**（`copy hosts hosts.bak`），改完**必须 `Length` 校验非 0**——0 字节且无报错是本坑的签名。
2. **提权脚本一律放纯 ASCII 路径**（`C:\Windows\Temp\`、`C:\Users\Public\`），**绝不放在带中文的路径下用 `-File` 调**。
3. **提权脚本内不要用 here-string 传大段内容**——内容改成独立文件 + `copy`/`Move-Item`，比在脚本里拼字符串稳得多。

> Windows 默认 hosts（803 字节、纯注释无 IP 行）已存 `C:\Windows\Temp\hosts_default.txt`，
> 被清空时可直接 copy 回去。

## ⭐ `Test-NetConnection` 返回 True ≠ 端口能用（网络分诊别用它判活）
本机实测：`Test-NetConnection github.com -Port 443` 返回 **True**，但 `curl https://github.com/` 是
**000 / 15.6s / exit 35**（TLS 被 reset）——防火墙对 SYN 放行、对 ClientHello 阻断。
**TCP 层探测在这台机器/这个网络上完全不可信。** 判网络可用性一律用
`curl.exe -s -o NUL -w "%{http_code}" --max-time 10 <url>`，看**是否拿到 HTTP 码**。
（附带后果：`Test-NetConnection ... -InformationLevel Quiet` 返回 False 会让命令 `exit_code=1`，
Hermes 会误报 "terminal failed" —— 看输出文字判断，别当失败。）

## 校验
脚本跑完后，用 `read_file`（或 Python 按 UTF-8 读）确认内容，别信 PS 控制台的乱码显示。

## 关键词
WSL / PowerShell / 引号 / BOM / Start-Process / python3.14 / here-string / /mnt/d / 中文乱码 / -replace / cmd /c / Scrapling / browser_vision / 截图识别 / 网格辨读 / ASCII 路径 / 定宽解析 / 断言假失败 / .ps1 假语法错误 / UTF-8 BOM 补写 / curl -L / 301 重定向 / 交付前实测 / 变量紧跟冒号 / 变量引用无效 / scope 语法 / -f 格式化 / 裸命令名免 `&` / hosts 清空 / RunAs 提权 / 0 字节写入 / Test-NetConnection 假通 / SNI 阻断 / curl 判活 / terminal.shell 不生效 / HERMES_SHELL_TYPE / 全部shell工具瘫痪 / Unknown HERMES_SHELL_TYPE / browser_console 读本地文件 / 别翻 _internal 找源码 / bash.exe 顶替 / HERMES_GIT_BASH_PATH / 顶替无效已回滚 / 父进程判 shell / WSL 值不值得走 / 改回auto仍不恢复 / 进程内缓存重启app / patch拒写config / mcp windows_mcp FileSystem / windows_mcp PowerShell 救援 / Dashboard 启动失败 / WinError 10013 / excludedportrange / winnat

## 相关技能
- 写 C/C++ 命令行程序并测它 → `c-native-cli-programs`（含 `templates/test_cli_driver.py` 测试驱动模板）
- **重装/迁移 WSL、装 Ubuntu、配用户与工具链** → `references/wsl2-install-and-history.md`（原 `wsl2-setup` 技能，含管理员提权、`install --root` 跳过交互、`/mnt/d` 中文路径 pip -e 失败等坑）
- **早期 PowerShell 陷阱合集**（引号地狱、`&` 后台判定、`-replace` 操作数、`$pid` 只读、VBS 编码、`terminal.shell` 全崩时走 MCP `windows_mcp` 通道救援） → `references/powershell-encoding-and-traps.md`（原 `windows-wsl-execution` 技能）
