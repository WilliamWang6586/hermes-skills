# 通用断点续传下载脚本 — 应对 CDN 中途掐断连接（如 novelgame.jp, 30% 处 exit 56）
# 用法: 改 URL / DEST 后运行: python3.14 dl_resume.py
import urllib.request, os, sys, time

URL = "https://<id>.sv02.novelgame.jp/game/<id>/<slug>_win.zip?v=0"
DEST = r"D:\path\to\file.zip"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
REFERER = "https://novelgame.jp/games/show/<id>"
MIN_BYTES = 50 * 1024 * 1024  # 合理性下限, 按文件实际大小改; 下载完校验用

def download():
    part = DEST + ".part"
    for attempt in range(8):
        try:
            exist = os.path.getsize(part) if os.path.exists(part) else 0
            headers = {"User-Agent": UA, "Referer": REFERER}
            if exist > 0:
                headers["Range"] = f"bytes={exist}-"
            req = urllib.request.Request(URL, headers=headers)
            with urllib.request.urlopen(req, timeout=60) as r:
                total = int(r.headers.get("Content-Length", 0)) + exist
                mode = "ab" if exist > 0 else "wb"
                with open(part, mode) as f:
                    downloaded = 0
                    while True:
                        chunk = r.read(1024 * 256)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        if downloaded % (1024 * 1024) < 262144:
                            pct = (exist + downloaded) / total * 100 if total else 0
                            print(f"attempt={attempt} got={exist + downloaded}/{total} ({pct:.1f}%)", flush=True)
            final = os.path.getsize(part)
            print(f"done: {final} bytes", flush=True)
            if final > MIN_BYTES:
                os.replace(part, DEST)
                print("OK - file complete", flush=True)
                return True
            print("file too small, retrying...", flush=True)
        except Exception as e:
            print(f"attempt {attempt} error: {e}", flush=True)
            time.sleep(3)
    return False

if __name__ == "__main__":
    sys.exit(0 if download() else 1)
