#!/usr/bin/env python3
"""Typora / Electron 类桌面软件「Activation Hook 注入」破解的端到端验证。

用法：
    python verify_electron_crack.py                      # 用默认路径
    python verify_electron_crack.py "D:\\Typora"         # 指定安装目录

退出码 0 = 全部通过（破解真实生效）；1 = 有失败项。

设计原则：
  * 不依赖截图（多进程 Electron 应用截图不可靠）
  * 断言 5 类：文件布局 / 注入内容(含对照组) / Fuses 字节 / 注册表 / 运行时日志
  * 第 5 类（日志）是唯一硬标准：出现 renewLicense 且其后无 onUnfillLicense
"""
import os
import re
import subprocess
import sys
from pathlib import Path

TY = Path(sys.argv[1] if len(sys.argv) > 1 else r"D:\Typora")
RES = TY / "resources"
REG_KEY = r"HKCU\Software\Typora"      # 其他软件改这里
LICENSE_VAL = "RHJlYW1OeWE=#0#1/1/2059"  # 其他软件改这里
LOG = Path(os.environ.get("APPDATA", "")) / "Typora" / "typora.log"

_ok = True


def chk(label, cond, detail=""):
    global _ok
    if not cond:
        _ok = False
    print(f"  {'OK  ' if cond else 'FAIL'} {label}" + (f"  ({detail})" if detail else ""))


# ---------- 1. 文件布局 ----------
print("=== 1. 文件布局 ===")
chk("app.asar 已移走(→.bak)", not (RES / "app.asar").exists() and (RES / "app.asar.bak").exists())
chk("resources/app/ 已解包", (RES / "app" / "launch.dist.js").exists())
chk("resources/app.bak/ 原始备份", (RES / "app.bak" / "launch.dist.js").exists())
chk("exe 原版备份存在", (TY / "Typora.exe.bak").exists())

# ---------- 2. 注入内容（含对照组）----------
print("\n=== 2. 注入内容 ===")
inj_p, orig_p = RES / "app" / "launch.dist.js", RES / "app.bak" / "launch.dist.js"
if inj_p.exists() and orig_p.exists():
    inj = inj_p.read_text(encoding="utf-8", errors="replace")
    orig = orig_p.read_text(encoding="utf-8", errors="replace")
    for k in ["Hook破解开始", "publicDecrypt", "api/client/", "restoreSLicense",
              "protocol.handle", "setTimeout"]:
        chk(f"注入版含 {k}", k in inj)
    # 对照组：原版必须干净，否则说明改错了文件
    chk("原版未被注入（对照组）", "Hook破解开始" not in orig,
        f"{len(orig)} 字符 vs 注入版 {len(inj)}")
else:
    chk("launch.dist.js 双侧可读", False, "注入版或原版缺失")

# ---------- 3. Fuses 字节差异 ----------
print("\n=== 3. Fuses 改动 ===")
exe, bak = TY / "Typora.exe", TY / "Typora.exe.bak"
if exe.exists() and bak.exists():
    a, b = bak.read_bytes(), exe.read_bytes()
    chk("exe 大小不变", len(a) == len(b), f"{len(a):,}B")
    diffs = [i for i in range(len(a)) if a[i] != b[i]]
    chk("恰好 1 字节差异（OnlyLoadAppFromAsar）", len(diffs) == 1,
        f"offset 0x{diffs[0]:x}: {a[diffs[0]]:02x}->{b[diffs[0]]:02x}" if diffs else "无差异")
else:
    chk("exe 与原版备份均在", False)

# ---------- 4. 注册表授权 ----------
print("\n=== 4. 注册表授权 ===")
r = subprocess.run(["reg", "query", REG_KEY, "/s"],
                   capture_output=True, text=True, errors="replace")
out = r.stdout
chk("SLicense 已写入", LICENSE_VAL in out)
m = re.search(r"IDate\s+REG_SZ\s+(\S+)", out)
chk("IDate 已写入", bool(m), m.group(1) if m else "")

# ---------- 5. 运行时日志（唯一硬标准）----------
print("\n=== 5. 运行时证据（日志）===")
if LOG.exists():
    lines = LOG.read_text(encoding="utf-8", errors="replace").splitlines()
    renew = [l for l in lines if "renewLicense" in l]
    chk("有 renewLicense 成功记录（Hook 生效）", bool(renew),
        renew[-1].strip()[:100] if renew else "无")
    if renew:
        # 按时间戳切分：该次续期之后不应再出现 onUnfillLicense
        ts = " ".join(renew[-1].split()[1:3])           # 2026/9/14 19:41:32
        after = [l for l in lines
                 if "onUnfillLicense" in l and " ".join(l.split()[1:3]) >= ts]
        chk("激活后无 onUnfillLicense", not after,
            f"renew时间={ts}, 之后Unfill次数={len(after)}")
else:
    chk("日志文件存在", False, str(LOG))

print("\n" + "=" * 50)
print("✅ 端到端验证全部通过 —— 破解真实生效" if _ok else "❌ 存在失败项，见上")
sys.exit(0 if _ok else 1)
