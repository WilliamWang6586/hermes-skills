---
name: download-and-verify
description: 找游戏/软件的可靠下载源并验证下载文件安全性。触发词：下载XX游戏/软件、找稳定可靠的下载源、扫描有没有病毒/有毒、官方下载、要破解版、装到D盘。覆盖 novelgame.jp 官方免费游戏挖掘、商业软件破解方案调研（先交信息表再动手）、GitHub 逆向仓库搜索、Electron 桌面软件授权绕过层级模型、官方中文站 CDN 取原包、大文件断点续传、SHA-256+ZIP审计+Defender扫描+运行时行为验证四重检查。
version: "1.2.0"
updated_at: "2026-09-14"
---

# Download & Verify — 可靠下载源 + 安全验证

## 触发场景

用户要求「下载XX游戏/软件」「找稳定可靠的下载源」「扫描其中是否有病毒」。

## 核心流程

> ⚠️ **用户说「要破解版」时，第一动作是交信息调研表，不是开下载。**
> 用户原话：「先给我信息我看看」—— 要的是**方案盘点 + 版本取舍 + 风险声明**，拍板后才动手。
> 直接开始下载/试破解 = 走错第一步。调研表模板见 `references/commercial-software-crack.md` 第五节。

1. **确认游戏真实身份**：中文译名 → Bing 精确搜索（用内置浏览器，curl 会被反爬）→ 找到日文原名 / 官方平台。小众日系游戏常见于 novelgame.jp（ノベルゲームコレクション，作者官方免费发布，无需登录）。
2. **只认一手官方源**：novelgame.jp（作者上传）、Steam、DLsite 官方页。抖音/B站评论区网盘、盗版站 = 高风险，明确告知用户不用。
3. **下载**：大文件用 Python urllib 断点续传脚本（scripts/dl_resume.py），别信单次 curl。
4. **四重验证**（见下）：
   - SHA-256 哈希
   - ZIP 条目审计
   - Windows Defender 全目录扫描
   - 试运行行为检查（进程存活 + 无外网连接）
5. **交付报告**：游戏信息表（原名/作者/时长/结局/分级）+ 官方链接 + 扫描结果 + 文件位置 + 语言提醒（官方版常为日文原版，民间汉化非官方源）。

## novelgame.jp 下载细节（实测 2026-08-27）

- 作品页: `novelgame.jp/games/show/<id>`；页面有「ブラウザでプレイ」（浏览器直玩，无需下载）和「PC（Windows）版をDL」。
- `/games/download/win/<id>` 是 **R-15 确认页**（HTML，不是文件）——「ダウンロードする」按钮的 href 才是真实 CDN 链接。用 `browser_console` eval 读 href，别猜 URL：
  ```js
  [...document.querySelectorAll('a')].filter(a=>a.textContent.includes('ダウンロードする')).map(a=>a.href)
  ```
- 真实链接格式: `https://<id>.sv02.novelgame.jp/game/<id>/<slug>_win.zip?v=0`
- 游戏体 = TyranoScript/NW.js 打包，标准结构：`<slug>.exe`(≈80MB) + `nw.pak` + `icudtl.dat` + libEGL/libGLESv2/d3dcompiler_47/ffmpegsumo DLL + `readme.txt`（TyranoScript 官方引擎说明）+ 日文说明 txt（**Shift-JIS 编码**，用 `open(...,'rb').read().decode('shift_jis')` 读，直接 read_file 是乱码）。
- 作者信息在说明 txt 和页面「作者のゲーム」区块；同作者系列作品可顺带发现。

## 商业软件/付费软件（含「破解版」需求）

用户说「要破解版」时**不要直接开始下载**——先交付「信息调研表」让用户拍板（用户明确偏好：先给信息再动手）。调研表四要素：

1. **官方当前版本号**（官网常被校园网阻断 → 从 GitHub API / changelog 镜像取）
2. **可用方案盘点表**：方案名 | 仓库 | 适配版本 | 平台 | 评价。⚠️ 必须标注平台字段——逆向仓库里 macOS 方案（DYLD 注入、Mach-O ad-hoc 重签、`~/Library` 授权文件）**在 Windows 上完全不可用**，混进表格会误导用户
3. **版本剪刀差**：最新官方版往往**没有**公开补丁（补丁滞后 1-2 个版本），明确告知「只能搞到 X 版破解」让用户选
4. **来源风险声明**：官网打不开时只能用国内镜像/第三方软件站，需用户接受"源非官方"前提，后面用四重验证兜底

**Windows 侧 Typora/Electron 类桌面软件的切入点（实测修正）**：改 `resources/app.asar` 内的 JS 是**理论上**更干净，但 ⚠️ **asar 里是 V8 字节码 + 明文源码混排，直接改字符串常量「改得进去、语义未必生效」**。

**授权绕过有 5 个层级**，打错层级 = 完全无效且**无任何报错**（状态栏只是继续显示「未激活」）：
① 渲染进程 UI 标志（`File.option.hasLicense`）② 续期分支（`renewLicense`）③ 注册表（`HKCU\Software\<厂商>`）④ 主进程 RSA 验签 ⑤ Electron 加载方式（Fuses）。
**判定补丁是否打对的唯一硬标准 = 回日志看 `onUnfillLicense` 是否消失 / `trailRemains` 是否变化**，不是看文件改没改成功。
Windows 版 Typora 实测可行的是 **Activation Hook 注入**（hook `crypto.publicDecrypt` 绕验签 + 拦截 `api/client/*` + 屏蔽 530 秒二次校验 + 改 Fuses），仓库 `HTryone/-typora-patcher`，只对作者验证过的版本（1.13.7/1.14.6）有效。
完整机制、五条死路对照表、诊断命令见 `references/commercial-software-crack.md` 第七节。

**官方原版包优先走官方中文站 CDN**（比第三方软件站强得多，拿到的是签名原包）：
`https://downloads.typoraio.cn/windows/typora-setup-x64[-<版本>].exe`——带版本号可下历史版本。
验证方式：`Get-AuthenticodeSignature` → `Status=Valid`，`Signer=Qiyun (Shanghai) Technology Co., Ltd.`。
（用户是吉林大学校园网：`typora.io`/`download.typora.io` 被阻断，但 `downloads.typoraio.cn` 通。）

## 下载坑

- CDN 连接在大约 30% 处被服务器掐断：curl exit 56 `schannel: server closed abruptly (missing close_notify)`，本地留下不完整文件。
- `curl -C -` 断点续传再失败 exit 35（SSL）——别死磕 curl，换 Python。
- ✅ 解法：Python urllib 带 `Range: bytes=<已有>-` 写 `.part` 文件，循环重试（8次，间隔3s），完成后校验大小 ≈ Content-Length 再 `os.replace` 成正式文件。见 scripts/dl_resume.py（改 URL/DEST 即可复用）。

## 四重验证命令（PowerShell）

```powershell
# 1. 哈希
Get-FileHash <file> -Algorithm SHA256

# 2. ZIP 条目审计（对照游戏结构找异常文件）
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead(<zip>); $zip.Entries | Select FullName, Length; $zip.Dispose()

# 3. Defender 扫描（解压后扫目录）
& "C:\Program Files\Windows Defender\MpCmdRun.exe" -Scan -ScanType 3 -File <解压目录>
# 输出 "found no threats" + 退出码 0 = 干净

# 4. 运行时行为检查
$p = Start-Process -FilePath <exe> -PassThru; Start-Sleep 12
Get-Process -Id $p.Id   # 存活+内存合理
Get-NetTCPConnection -OwningProcess $p.Id | Where-Object { $_.State -eq 'Established' -and $_.RemoteAddress -notmatch '^(127\.|0\.0\.0\.0)' }  # 应无输出
Stop-Process -Id $p.Id -Force
```

## Pitfalls

- NW.js 打包游戏的 exe **无数字签名/版本信息 = 正常**（免费游戏签名要花钱），不是风险信号；风险信号是 ZIP 里有异常文件（.scr、vbs、多出的 exe、加密壳）。
- 搜索引擎 curl 直抓被反爬（Bing 返回空、B站 API 返回非 JSON/-412）→ 一律用内置 `browser_navigate`。⚠️ Bing 还可能返回**完全无关的脏缓存结果**（查技术词却返回百度经验银行类内容）——别信第一页，换 API 源。
- **`raw.githubusercontent.com` 常被校园网阻断（000），但 `api.github.com` 通**。用它取源码/README，不要爬 raw 域：
  ```python
  # contents 接口返回 base64，支持指定分支
  d = json.loads(curl(f"https://api.github.com/repos/{repo}/contents/{path}?ref={branch}"))
  content = base64.b64decode(d["content"]).decode("utf-8", errors="replace")
  # 列全树：/git/trees/{branch}?recursive=1  →  每个 x["path"] 是关键
  ```
  先查 `default_branch`（新版仓库多为 `main`，但老仓库仍是 `master`，猜错直接 404）。
- **GitHub API 响应带 UTF-8 BOM** → `json.load(sys.stdin)` 报 `Unexpected UTF-8 BOM`。管道给 Python 时用 `.lstrip('\ufeff')` 或 `decode('utf-8-sig')`。
- ⚠️ PowerShell 里 `python3.14 -c "…json…"` 的引号嵌套极易崩（BOM/中文/转义三重坑）→ 调研脚本一律 `write_file` 成 `.py` 再跑。
- 下载完成后务必校验大小与服务端 Content-Length 一致，被掐断的下载不会报错，只会在解压/运行时露馅。
- Python 别名失效时用全路径 `C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`。
- R-15/成人向内容如实告知用户分级，不评判、不隐瞒。

### 通用坑（本轮实测新增）

- ⚠️ **打了补丁「成功」≠ 生效**。文件写入成功、字节校验通过、大小一致，全都可能只是「改在了一个用不上的分支上」。**必须回到程序日志/状态栏验证行为变化**，否则是在自我欺骗。本项目就栽在这里。
- ⚠️ **多进程 GUI 应用（Electron：Typora 一启动就是 5 个进程）不要用截图验证后台窗口**——`SetForegroundWindow` 抓到哪个窗口是随机的；用户同时在玩游戏时截到的很可能是无关画面，白费一轮。**优先用日志 + 注册表 + 进程状态做程序化验证**。
- ⚠️ **CDN 常不支持 HTTP HEAD**（`curl -I` 返回空，误判成「文件不存在」）。探测文件是否存在用 **Range GET**：`curl.exe -s -r 0-0 -D - -o NUL <url>` → `206 + Content-Range: bytes 0-0/<总长>` = 存在。**别用「版本号不在 changelog 里」推断文件不存在，实测才知道。**
- ⚠️ **拉 GitHub 小仓库别用 `git clone`**——校园网 git 直连 443 常超时（20s+ `Could not connect`），而 `api.github.com` 通。用 `contents` 接口逐个取文件，6 个文件的仓库也能轻松拉全。
- ⚠️ **Windows 改注册表别用 `reg.exe delete ... /f`**——参数解析会把 `/f` 当成值写进去，制造新的脏数据。用 PowerShell 原生 cmdlet：`Set-ItemProperty -Path "HKCU:\..." -Name X -Value "" -Type String`。
- **NSIS 安装器**（`/S` 静默）：`/D=<路径>` 必须是**最后一个参数且不带引号**，顺序错会被忽略装到默认目录。`-Wait` 可能一直不返回 → 直接查目标目录/进程判断成败，别干等。

- 除错时先用 `curl -o NUL -w "%{http_code}"` 批量探连通性——http 000 且 time≈timeout = 域名被阻断（换源），200 = 通（问题在解析不在网络）。

## 支持文件

- `scripts/dl_resume.py` — 带 Range 断点续传 + 重试 + 大小校验的通用下载脚本（改 URL/DEST 即用）。
- `scripts/verify_electron_crack.py` — Electron 桌面软件「Activation Hook 注入」破解的端到端验证（5 类断言：文件布局/注入内容含对照组/Fuses 字节/注册表/运行时日志；退出码 0=真生效）。改顶部 `TY`/`REG_KEY`/`LICENSE_VAL` 即可复用到其他 Electron 软件。
- `references/commercial-software-crack.md` — 商业桌面软件（Typora 等）破解方案盘点 + GitHub 逆向仓库速查表 + **第七节：Windows 授权机制逆向、五条死路对照表、Activation Hook 注入正确方案、诊断命令、7.5.1 成功验证方法、7.5.2 交互式脚本自动化（覆写 readlineSync.question）、7.5.3 给第三方脚本加回归测试**。
