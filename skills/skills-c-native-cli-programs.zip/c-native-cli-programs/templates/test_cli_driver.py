"""驱动命令行程序的测试模板 (Python, 零编码坑)

用法: 改 EXE / 各测试段, 然后
    $env:PYTHONUTF8="1"; uv run --no-project python test_driver.py

要点(踩过的坑都在下面注释里):
  - 断言红了先怀疑断言, 打印 repr() 看真实内容
  - 会迭代变化的状态行用 findall 取 last/max, 别用 search 取第一个
  - 别对随机结果写死断言; 需要确定性就给程序加 --seed, 用两阶段法
  - 解析定宽文本先剥 ANSI 色, 再按列宽切
  - 检查 returncode, 3221226356 (=0xC0000374) 是堆损坏
"""
import subprocess, sys, re

EXE = r"C:\Users\Public\proj\target.exe"   # ⚠ 二进制放 ASCII 路径, 别放中文路径


def run(lines, args=None, timeout=20):
    """把 lines 逐行喂给 stdin(CRLF 行尾), 返回 (stdout, returncode)。"""
    data = "".join(l + "\r\n" for l in lines)
    p = subprocess.run([EXE] + (args or []),
                       input=data.encode("utf-8"),
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       timeout=timeout)
    return p.stdout.decode("utf-8", "replace"), p.returncode


def strip_ansi(s):
    return re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", s)


def parse_grid(text, rows_hint=None):
    """从 ' N| a b c' 定宽棋盘里解出 {(row,col): 单元格字符串}。

    ⚠ 每格宽度必须按真实列宽切(常见 2 字符 " #"/" ."/" 1"/" F")。
      用 findall(r"[1-8]", body) 逐字符枚举会漏掉 '.' 导致列号整体错位。
    """
    grid = {}
    for ln in text.split("\n"):
        ln = ln.replace("\r", "")
        if "|" not in ln:
            continue
        head, body = ln.split("|", 1)
        m = re.search(r"(\d+)\s*$", strip_ansi(head))
        if not m:
            continue
        row = int(m.group(1))
        body = strip_ansi(body)
        cells = [body[i:i + 2] for i in range(0, len(body), 2)]   # 定宽切!
        for col, c in enumerate(cells, start=1):
            grid[(row, col)] = c.strip()
    return grid


FAILS = []


def check(cond, msg):
    print(("  PASS  " if cond else "  FAIL  ") + msg)
    if not cond:
        FAILS.append(msg)


def main():
    print("=" * 60)
    print("测试: 基本流程")
    out, rc = run(["1", "", "q", ""])
    check(rc == 0, f"退出码 0 (实际 {rc})")
    # ⚠ rc == 3221226356 (0xC0000374) => 堆损坏, 优先查显式栈越界

    print("=" * 60)
    print("测试: 状态行断言要用 findall 取最后")
    out, rc = run(["1", "", "step", "step", "q", ""])
    # ✗ vals = re.search(r"count: (\d+)", out)   -> 永远拿到初始值, 假失败
    vals = [int(x) for x in re.findall(r"count: (\d+)", out)]   # ✓
    check(bool(vals) and max(vals) > 0, f"状态确实推进了 (max={max(vals) if vals else 0})")

    print("=" * 60)
    print("测试: 固定种子 + 两阶段法验证确定性逻辑")
    # 阶段1: 同种子跑一局, 读回内部状态(雷位/牌序)
    # out1, _ = run([...], args=["--seed", "12345"])
    # grid = parse_grid(out1.split("最终:")[-1])
    # secrets = [pos for pos, v in grid.items() if v == "*"]
    # 阶段2: 同种子重开, 规避 secrets, 断言"必然成功的结果"
    # out2, _ = run([...], args=["--seed", "12345"])
    # check("胜利" in out2, "规避后必得胜利")

    print("=" * 60)
    if FAILS:
        print(f"结果: {len(FAILS)} 项失败")
        for f in FAILS:
            print("  -", f)
        return 1
    print("结果: 全部测试通过 ✔")
    return 0


if __name__ == "__main__":
    sys.exit(main())
