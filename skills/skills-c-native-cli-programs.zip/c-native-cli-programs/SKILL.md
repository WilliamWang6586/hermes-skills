---
name: c-native-cli-programs
description: >-
  用 C/C++ 写单文件命令行程序（游戏、算法工具、小工具）并做可验证的自动化测试。
  当用户说「用 C 写个 X」「写个控制台程序/小游戏」「编译成 exe」时使用。
  覆盖：显式栈/队列的越界这类原生内存 bug 的识别与修法、便于测试的程序设计
  （--seed / 非交互检测 / 别用 system("cls")）、用 Python subprocess 驱动 exe 的测试模式。
  宿主环境的 PowerShell/中文路径坑见 windows-wsl2-script-exec 技能。
version: "1.0"
updated_at: "2026-09-25"
---

# C / 原生命令行程序设计（含可测性）

用户要「用 C 写个 XX」时，交付标准是**编译通过 + 真跑起来验证过**，不是写完代码就算。
本技能记录让 C 程序**能被自动化验证**的设计约定，以及原生内存 bug 的现场特征。

## 一、让程序天生可测（一开始就加，成本几分钟，省几小时）

1. **`--seed N` 固定随机种子**
   任何带随机的程序（洗牌、布雷、抽样）都加这个参数。好处：
   - bug 可复现（用户说"偶尔崩"时能定性）
   - 测试能构造确定性场景（见下文两阶段法）

   ```c
   unsigned int seed = (unsigned int)time(NULL);
   for (int i = 1; i < argc; i++)
       if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc)
           seed = (unsigned int)strtoul(argv[++i], NULL, 10);
   srand(seed);
   ```

2. **⛔ 清屏别用 `system("cls")`**
   输入被重定向（管道/文件/`subprocess`）时，`system()` 会起子进程并**干扰 stdin**，
   之后 `fgets` 立刻读到 EOF → 程序"只跑完菜单就退出"，输出正常但后续命令全没执行。
   （实测症状：喂 6 条命令，stdout 只有 10 行菜单。）

   ```c
   printf("\033[2J\033[H");   /* 清屏, 只动显示不碰 stdin */
   ```

3. **自动检测非交互模式，顺手关掉清屏和延时**
   ```c
   #ifdef _WIN32
       HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
       DWORD m;
       if (!GetConsoleMode(h, &m)) { g_ansi = 0; g_interactive = 0; }  /* 被重定向 */
       if (_isatty(_fileno(stdin)) == 0) g_interactive = 0;
   #endif
   ```
   测试模式下 `Sleep(900)` 之类的"让用户看清提示"延时全部跳过 → 测试快几十倍。

4. **`q` 退出前把终局状态打全**
   若程序正常流程是"循环顶部重绘"，那 `q` 之后**不会**再重绘。
   测试想读终局棋盘就会读错块。**退出/结束分支里显式打印一次最终状态。**

5. **用完 stdout 要 `fflush`**，尤其是提示后等输入时（`printf("\n> "); fflush(stdout);`）。

## 二、显式栈/队列的越界：最隐蔽也最致命

**现场特征**：进程以 `rc=3221226356`（= `0xC0000374`，Windows **堆损坏**）
或 Linux 下 `malloc(): corrupted top size` / `free(): invalid pointer` 崩溃，
**崩在看起来毫不相干的 `malloc`/`free`/`printf` 上**，且在**小盘**上更容易触发。

**根因模式**：用 `int stack[N]`-式的显式栈做 BFS/DFS/洪泛填充时，
**入栈只判断了业务状态（如 `is_open`），没有在"入栈那一刻"标记**，
于是同一个格子被多个邻居重复压栈 → `top` 超过容量 → `stack[top++]` 越界写入 → 堆损坏。

```c
/* ✗ 错：入栈时不标记, 同格被多次压栈, top 越界 */
for (邻居 nb) if (!nb->is_open && !nb->is_flag) stack[top++] = idx(nb);

/* ✓ 对：入栈即标记, 保证每格最多入栈一次, top 永不超 cap */
for (邻居 nb) {
    if (nb->is_open || nb->is_flag) continue;
    nb->is_open = 1;            /* 入栈即占位 */
    count++;                    /* 计数也在这里加, 别在出栈时加 */
    stack[top++] = idx(nb);
}
```

**要点**：
- **容量 `cap = rows*cols` 只有在"每格至多入栈一次"的前提下才成立**，别加大数组糊过去。
- 计数（`opened_count` 之类）跟着**入栈**加，别在出栈加 —— 否则重复入栈会重复计数。
- 起点也要走同一套"入栈即标记"逻辑，别在循环外单独 `is_open=1` 又让循环再处理一遍。

**定位手法**：判据不是断言，是**退出码**。测试里检查 `p.returncode`，
`3221226356` 直接指向堆损坏，比看日志快得多。再用最小规模（如 5×5）稳定复现。

## 三、用 Python `subprocess` 驱动被测程序

**不要用 PowerShell 写测试编排**（编码/引号坑，详见 `windows-wsl2-script-exec`）。
Python 显式指定编码，零坑：

```python
import subprocess
def run(lines, args=None, timeout=20):
    data = "".join(l + "\r\n" for l in lines)          # 给 stdin 的行尾用 \r\n
    p = subprocess.run([EXE] + (args or []), input=data.encode("utf-8"),
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       timeout=timeout)
    return p.stdout.decode("utf-8", "replace"), p.returncode
```

配合一个小 `check(cond, msg)` 收集失败项、最后统一汇报，比 assert 中断更实用
（一轮跑完所有用例，而不是第一个失败就停）。

**直接抄现成模板**：`templates/test_cli_driver.py` —— 含 `run()` / `strip_ansi()` /
`parse_grid()` 定宽解析 / `check()` 收集器 / 两阶段法骨架，坑都以注释标在原地。

### ⭐ 断言别写成假失败（最贵的坑）

1. **会随迭代变化的状态行 → `findall` 取最后一个，别 `search` 取第一个。**
   每回合重印的 `已翻开: N/71`，`search` 拿的是初始值 `0` → 断言假失败 100 次。
   `max(re.findall(...))` 或 `[-1]`。

2. **别对随机结果写死断言。** 断言"某种结局出现"要用 **N 局统计**，不能压单局。
   需要确定性就用 `--seed`，配**两阶段验证法**：
   > 同种子跑一局 → 从输出读回内部状态（雷位/牌序）→ 同种子重开并规避 →
   > 断言"必然成功的结果"。这样"胜利判定"这类靠运气的逻辑能被严格验证。

3. **解析定宽文本按列宽切，别用正则逐字符枚举。**
   棋盘每格 2 字符时，`findall(r"[1-8]", body)` 会把 `.` 也数成列 → 列号全错。
   先 `re.sub(r"\x1b\[[0-9;]*m", "", body)` 去 ANSI 色，再定宽切片：
   `[s[i:i+2] for i in range(0, len(s), 2)]`。

4. **断言红了先怀疑断言，别先改程序。** 打印实际匹配内容的 `repr()`（看转义和 `\r`）
   再判断。本次真实程序 bug 只有 1 个（堆损坏），其余 90% "失败"都是解析/断言写错。

### ⭐ 交互式程序（读键盘、自己清屏）：`subprocess` 测试**做不到**，别硬搭

`kbhit`/`getch` 轮询 + 自绘棋盘的**实时游戏**（贪吃蛇/俄罗斯方块/弹球）有个硬边界：
**它不读 stdin 行缓冲，只读键盘事件**。于是 Python `subprocess` 喂 stdin **一点用都没有**，
`kbhit_()` 永远返回 0 → 蛇按原方向直线撞墙，程序照跑，输出看着"正常"（实测贪吃蛇只走直线至死）。

**判据：程序若用 `kbhit`/`getch`（含自制 termios 版 `kbhit_`），就不要给它写 subprocess 测试。**
`templates/test_cli_driver.py` 那套（stdin 喂命令 + 解析输出）**只适用于「读一行命令 → 执行 → 回菜单」的
菜单式程序**（扫雷、计算器、文本工具）。**先看它怎么读输入，再决定测试策略。**

替代验证（按性价比排）：
1. **人类真跑** —— 交付说明里必须写清：在**真终端**跑（VSCode 里 `Ctrl+`` ` `` 终端 / PowerShell 窗口），
   ⛔ **不是** VSCode 的「Run Code 输出面板」——那个不接键盘输入，`kbhit` 永远读不到（用户必踩）。
2. **把纯逻辑抽出来测**：碰撞判定/方向取反/`step()` 这类不碰键盘的函数，加 `demo()` 自检，
   用 `#ifndef NOMAIN` 包住 `main` 后单独编译一个测试目标。
3. **脚本化输入**（成本高，非必要不做）：加 `--script 录制的按键序列` 参数，测试时才走它。
   （这是**测试专用**开关，别为了它把正常交互流程改坏。）

### ⚠️ 移动/增长类逻辑：`memmove` 用重叠安全的那个，别用 `memcpy`

蛇身/队列的"整段后移一格"（`从 [0..n-2] 搬到 [1..n-1]`）**区间重叠**，
`memcpy` 是 UB、`memmove` 才定义良好 —— 一行之差，且 `memmove` 不比 `memcpy` 慢到哪去。
同理：蛇尾那格**不算撞自己**（下一步它就走了），自撞检测循环写 `i < len - 1` 而不是 `i < len`，
否则贴着自己尾巴走会莫名判死。

## 四、编译与自检

- 开警告并当错误看：`gcc -O2 -Wall -Wextra -o out.exe src.c`（要求零警告）
- 交付前**必须真跑**：至少跑通一局完整流程 + 边界（非法输入、越界、空输入 EOF）
- 交付物：源码 + 可执行 + 测试脚本 + README（含编译命令、操作说明、已修 bug 记录）
- README 里记「踩过的坑」比记功能更有价值

## 五、Windows 上批量验证一堆小 .c 文件（练习题/答案集）

PowerShell 批量跑 `gcc` 编译 + 喂输入的套路，两个必踩的坑：

1. **`|` 管道喂 stdin 给 gcc 编译出的 exe 会卡死**（命令行 `-` 参数、管道、`<` 在 PowerShell 里都不稳）。
   可靠做法只有**写输入文件 + cmd 重定向**：
   ```powershell
   Set-Content $in -Value "7 2" -Encoding ASCII
   $c = (& gcc $src -o $exe -Wall -Wextra 2>&1)          # 2>&1 才能拿到警告
   $o = (& cmd /c "`"$exe`" < `"$in`"" 2>&1) -join "`n"  # 注意引号全包
   ```
2. **自测函数别拆成第二个 .c**。想着「`main` 用宏包住 + 另建 selftest.c 提供 main」→ 撞
   `multiple definition of 'main'`（`-D` 只对同一个编译单元有效，两个文件里 `#ifdef` 都成立）。
   懒办法：**同一个文件里写两个 main**，靠宏二选一：
   ```c
   #ifdef SELFTEST
   int main(void) { /* 断言自检 */ return 0; }
   #else
   int main(void) { /* 正常程序 */ return 0; }
   #endif
   ```
   `gcc x.c -DSELFTEST` 跑自检，不加宏就是干净提交版。

## 六、相关技能
- 宿主环境（PowerShell 引号/中文路径/BOM/重定向编码）→ `windows-wsl2-script-exec`
- 中文路径连 exe 调用都会烂 → 编译可留原地，**跑和读挪到 `C:\Users\Public\<proj>\`**

## 关键词
C / C++ / gcc / 命令行程序 / 小游戏 / 堆损坏 / 0xC0000374 / heap corruption /
栈越界 / flood fill / BFS / 显式栈 / --seed / subprocess 测试 / system("cls") /
可测性设计 / 断言假失败 / kbhit / getch / 实时游戏不可自动化测试 / memmove 重叠区间
