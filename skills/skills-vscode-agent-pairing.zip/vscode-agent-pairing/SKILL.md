---
name: vscode-agent-pairing
description: >-
  让 agent 把代码写进用户正在看的 VSCode 里（"打开 vscode 直接写代码，能让我在页面上看到"）。
  当用户要求「用 VSCode 写/改代码」「让我在编辑器里看到」「打开编辑器」「边写我边看」
  「在 VSCode 里跑一下」时使用。覆盖：定位 Code.exe、Start-Process 拉起窗口（PS 里 `&`
  会被当成后台符被拦）、`-r -g file:line` 定位到具体行、磁盘文件双向同步的心智模型、
  以及"必须用真终端跑交互式程序"这类交付前的提醒。适用于任何本地编辑器协作场景。
version: "1.0.0"
updated_at: "2026-09-27"
platforms: [windows, macos, linux]
---

# 在用户的 VSCode 里写代码（编辑器协作）

用户说「打开 vscode 直接写代码，让我在页面上看到」时，他要的是**共享一个编辑器**的体感。
实现方式不是 GUI 自动化，而是**磁盘文件 + 窗口唤起**——这个区别决定了整套做法。

## 心智模型（先说清楚，决定了所有命令）

```
我 write_file / patch  →  文件落到磁盘  →  VSCode 因文件变化自动刷新编辑器内容
用户保存              →  我用 read_file 读磁盘  →  拿到改后的最新代码
```

**不做 GUI 自动化**：不需要点击、不需要模拟键盘、不受窗口位置漂移影响。
用户保存后我读盘就是最新版，天然双向同步。失败率远低于 UIA 自动化。

## 标准流程

### 1. 定位 VSCode（不要假设在 PATH 里）

```powershell
Get-Command code -EA SilentlyContinue | Select-Object -ExpandProperty Source
Get-ChildItem "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe" -EA SilentlyContinue | Select-Object -ExpandProperty FullName
Get-ChildItem "C:\Program Files\Microsoft VS Code\Code.exe" -EA SilentlyContinue | Select-Object -ExpandProperty FullName
```

典型结果：`%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe`（用户级安装，PATH 里可能只有 `code.cmd`）。
**用 `Code.exe` 全路径，不要用 `code.cmd`**——`.cmd` 经 `Start-Process` 容易丢参数。

### 2. 拉起窗口并打开目标目录

```powershell
$code = "C:\Users\<user>\AppData\Local\Programs\Microsoft VS Code\Code.exe"
Start-Process -FilePath $code -ArgumentList @('-n', $dir)      # -n = 新窗口
Start-Sleep -Seconds 8                                          # 冷启动要等，别过早验证
Get-Process -Name Code -EA SilentlyContinue | Select-Object Id, MainWindowTitle
```

**验证真开起来了**：`MainWindowTitle` 非空且含目标目录名（如 `_vscode_test - Visual Studio Code`）。
标题为空的是后台 helper 进程，别拿它当证据。

### 3. 写文件后，让它自动弹出并跳到指定行

```powershell
# -r = 复用已有窗口；-g = 打开文件并定位到 file:line
Start-Process -FilePath $code -ArgumentList @('-r', '-g', 'D:\path\to\file.py:5')
```

验证：`MainWindowTitle` 变成 `file.py - 项目名 - Visual Studio Code`。

### 4. 交付前实测跑一次

写完代码别只报「已写好」。用真解释器跑一遍拿真实输出：

```powershell
python3.14 "D:\path\to\file.py"     # 本机 python 命令不存在，用 python3.14
gcc -Wall -Wextra -O2 x.c -o x.exe  # C 项目；有警告就顺手清掉
```

## Pitfalls

1. **PowerShell 前台命令里的 `&` 会被拦截**（本会话实测 3 次失败）：`& $code -n $dir`
   被判定为"使用了后台符"而拒绝执行。**改用 `Start-Process -FilePath ... -ArgumentList @(...)`**，
   参数用数组形式，不要拼成一个字符串。
2. **交互式程序必须用真终端跑**：`kbhit()`/`getchar()` 类程序在 VSCode 的「输出面板」
   （Run Code 之类的快捷运行）里**读不到键盘输入**，会看起来像卡死。
   必须让用户在 **VSCode 集成终端**（`` Ctrl+` ``）或独立 PowerShell 窗口里运行。
   这是**交付给用户前就该主动说明**的事，否则他试一次失败会以为代码有问题。
3. **`Start-Sleep` 别省**：VSCode 冷启动 8 秒左右，紧接着查进程/标题会拿到空值。
4. **不要用 `-n` 每次开新窗口**：批量改多个文件时用 `-r` 复用窗口，否则会堆一堆
   VSCode 窗口。首次拉起用 `-n`，后续定位用 `-r`。
5. **VSCode 侧改动我天然可见**：用户手改并保存后，直接 `read_file` 读盘就是最新内容，
   不需要任何"同步"动作。**不要为这个写机制**。
6. **扩展不是必须的**：不装 Python 扩展也能编辑/运行，只是没有语法高亮和补全。
   用户没要求就别主动装——真要装：
   `Start-Process $code -ArgumentList @('--install-extension','ms-python.python')`。

## 与用户的沟通要点

- **主动做一次端到端演示**（开窗 → 写文件 → 定位到行 → 跑出真实输出），
  再告诉用户"切窗口看"。只报"我可以做到"没有说服力。
- **明确说清不是 GUI 控制**：用户可能以为是"你替我操作编辑器"。要说明底层是
  磁盘文件 + 窗口唤起，所以不会误点、不会因窗口漂移出错。
- **给出「你说什么 → 我做什么」的对照表**，比讲原理有用：
  「在 VSCode 里开个项目写个 X」→ 建目录 + 写文件 + 自动弹出并定位；
  「第 20 行再改一下」→ patch 精确改，编辑器内容实时变。
