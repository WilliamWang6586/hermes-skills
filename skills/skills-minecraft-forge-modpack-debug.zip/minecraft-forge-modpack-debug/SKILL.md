---
name: minecraft-forge-modpack-debug
description: >-
  排查和修复 Minecraft Forge 整合包启动/加载崩溃。触发词：MC 崩溃、forge 崩溃、
  StackOverflowError、mixin 失败、Minecraft 打不开、整合包启动失败。
  覆盖：递归定位法（二分移 mod）、Forge 版本降级、HMCL 实例组装、自动启动测试、
  常见崩溃模式（ItemStack 递归 / Essential 双模块 / mixin 应用失败 / coremod 转换错误）。
version: "1.0"
updated_at: "2026-08-03"
platforms: [windows]
---

# Minecraft Forge 整合包崩溃排查

实战经验（2026-08，幸运方块樱花赛道整合包，1.20.1 Forge，耗时 2 小时 12 轮崩溃排查）。

## 触发场景

- 用户下载整合包（mrpack/懒人版）导入 HMCL 后启动崩溃
- 崩溃类型：StackOverflowError / MixinTransformerError / ResolutionException / Mod loading failed

## 核心工作流

### 1. 先建立自动启动测试（关键！省 10 倍时间）

不要每次让用户手动启动！写 `launch_mc.py`：
- 从版本 json 构建完整 java 命令（classpath 从 libraries 展开，处理 `${classpath}`/`-p` module path 变量）
- **坑**：json 的 jvm 参数自带 `-cp ${classpath}` 和 `-p ${module_path}`，必须展开 `${classpath}` 并**从 classpath 排除 module path 已有的 jar**（否则 "reads more than one module"）；路径比较要 normpath（module path 用 `/`，classpath 用 `\`）
- 假 accessToken + `--userType legacy` 可离线启动（单人游戏不需正版验证）
- 成功判定：`Sound engine started`（主菜单音频）；**注意** `Backend library: LWJGL`/`Reloading ResourceManager`/`Setting user:` 都太早（15-57 秒出现，mods 资源还没加载完）
- 崩溃判定：`Exception in thread` + 具体异常类型

### 2. 崩溃模式速查

| 症状 | 原因 | 修复 |
|------|------|------|
| `Module essential._1.forge._1 and Essential._1.forge._1 export package` | 两个 Essential jar（旧版+新版）同时存在 | 删旧版，留一个 |
| `Invalid paths argument: fmlcore/javafmllanguage/mclanguage/lowcodelanguage` | Forge 库缺（MinecraftLocator 硬编码扫描 libraries 路径） | 从 maven.minecraftforge.net 下载对应版本 jar |
| `ItemStack.m_41619_ ↔ m_41720_ 无限递归 (StackOverflowError)` | **Forge 47.4.4 的 field_to_method coremod bug**（重定向 item 字段访问到 getItem 后自递归） | **降级 Forge 到 47.3.33**（47.4.10 同样含 ItemStack 转换，但 47.3.33 验证可用） |
| `Mixin ... FAILED during APPLY / @Shadow field not located` | mod 版本与 MC 不匹配（如 GlitchCore 0.0.1.1） | 移出该 mod |
| `Mod XX requires YY (missing)` | 依赖 mod 被移除 | 加回或接受功能缺失（Forge 只警告不崩，除非 required） |
| `CustomSkinLoader SkinManagerPatch.requireModified 失败` | CSL 15.0.1 transformation 与 forge 不兼容 | 移除 CSL（皮肤补丁，玩法无关） |
| HMCL 每次启动自动"补装"旧 mod | 版本目录残留 `modrinth.index.json`（模板的），HMCL 执行 ModrinthCompletionTask | 删除版本目录的 modrinth.index.json + modpack.cfg |
| HMCL 用全局 gameDir（不隔离） | 版本目录缺 `.hmcl` 标记目录 | 从正常实例复制 `.hmcl` 目录 |

### 3. 定位"改了某方法但不知道谁改"的凶手

- **扫描 mixin 注解**：javap -v 找 `method=["m_XXXXX_"]`（注解格式是数组 `method=[...]`，不是 `method="..."`）
- **coremod 会绕过 mixin 扫描**：检查 mod jar 的 META-INF/coremods.json + `coremods/` 目录 js；**Forge 自己的 universal jar 也有 coremod**（libraries/net/minecraftforge/forge/*/forge-*-universal.jar 内的 coremods/field_to_method.js）
- **终极手段**：`-Dmixin.debug.verbose=true -Dmixin.debug.export=true` 看 mixin 应用记录/导出转换后类
- **大二分**：按文件名分批移出 mod（每批 60 个）→ 自动测试 → 递归消失即凶手在批次内 → 细分。**注意依赖缺失可能引入新崩溃混淆判定**

## HMCL 实例组装要点（从 mrpack 组装）

1. 解压 mrpack 的 `overrides/` 到版本目录（mods/config/saves/kubejs 全在 overrides）
2. 版本 json：**用已有可运行实例的 json 做模板**（比官方 json 好——官方 json 用 `inheritsFrom` 依赖原版版本，模板 json 是完整展开 117 库）
3. Forge 版本：整合包要求的版本，json 里所有 `版本号` 全局替换（name/path/url/version 字段）
4. 下载缺失 forge 库（fmlloader/fmlcore/javafmllanguage/mclanguage/lowcodelanguage/forge-universal）
5. 删模板残留：modrinth.index.json、modpack.cfg（否则 HMCL 每次启动自动补装模板 mod！）、旧 jar
6. 保留 `.hmcl` 目录（HMCL 独立游戏目录标记，删了 gameDir 变全局）

## 验证

- 自动启动到 `Sound engine started` 或稳定运行 150 秒
- 检查版本目录 crash-reports/ 无新文件
- 最终让用户用 HMCL 启动进世界确认

## 陷阱

- **PowerShell 通配符**：文件名含 `[万用皮肤补丁]` 时 Move-Item/Get-Item 必须用 `-LiteralPath`（`[` `]` 是通配符，路径匹配失败但命令"看似成功"）
- 内联 python -c 在 PowerShell 引号嵌套必炸 → 写 .py 文件执行
- 启动进程要 terminate，否则 jar 被占用无法移动
- 成功标志过早会误判：LWJGL 初始化 ≠ 主菜单

## HMCL 相关深坑（2026-08-03 实测）

### HMCL 启动参数与 json 不一致（用了旧 forge 版本）
症状：json 已改 47.3.33，但 HMCL 生成的 launch.bat 里 `--fml.forgeVersion 47.4.4`、module path 也是 47.4.4。
解决：**直接删除本地 47.4.4 的所有库目录**（libraries/net/minecraftforge/{fmlcore,fmlloader,fmlearlydisplay,javafmllanguage,mclanguage,lowcodelanguage,forge}/1.20.1-47.4.4/）→ HMCL 无库可用 → 只能走 json 的版本。
另外 json 的 `"jar"` 字段决定 `-Dminecraft.client.jar` 指向——从模板复制 json 时它指向旧实例路径，必须改成当前版本名。

### HMCL json 编码坑
- HMCL 生成/写入 json 可能是 **GBK 或带 BOM**；PowerShell `[System.IO.File]::WriteAllText` 默认写 **UTF-8 BOM**（json.load 报 "Unexpected UTF-8 BOM"）
- 修复：用 Python `json.load(open(path, encoding='utf-8-sig'))` 读（自动去 BOM）+ `json.dump(..., ensure_ascii=False)` 写回 UTF-8 无 BOM
- **最稳妥**：直接用可运行实例的模板 json 重新生成（读模板→改 id/jar→写回），避免手工改 json 的编码问题

### 修复有缺陷 mod jar（mixin 崩溃）而不删除
症状：`Mixin [xxx.mixins.json:client.MixinGuiGraphics] FAILED during APPLY / @Shadow field not located`
解法：**改 jar 内的 mixins.json**（Python zipfile 读全部条目→改 json 删掉坏 mixin 类→写新 jar 替换），保留 mod 本体满足依赖（如 GlitchCore 是 biomesoplenty 的依赖，不能删只能修）。改后注意验证 `"required": true` 的其他 mixin 仍能加载。
