---
name: document-generation
description: >-
  生成格式化文档（Word/PDF/HTML）给用户。中文文档最佳实践、Edge headless PDF 转换、
  批量文档提取与分析。当用户要求"生成一个文档""输出 Word/PDF""做一份规划/报告"时使用。
trigger:
  - 生成文档
  - 生成Word
  - 读书报告
  - 按模板写报告
  - 课程论文
  - 降AI率
  - 降AI味
  - 测AI率
  - 查AI率
  - AI率多少
  - AIGC检测
  - 这篇有没有AI味
  - 读后感
  - 生成PDF
  - 生成规划
  - 生成报告
  - 做一份规划
  - 出一份报告
  - 输出Word
  - 输出PDF
  - 导出文档
  - PPT转Word
  - 把PPT整理成Word
  - PPT转文档
  - 整理成word
  - 做一份讲义
  - 课程讲义
  - 按这个格式做一版
  - 按这个模板改一下
  - 照这个模板改
  - 按这个版式
  - 做成XX版本
  - 照这个格式填
  - 听写表
  - 词表
  - 词汇表
  - 四六级词汇
  - 单词表
  - 答题卡
  - 登记表
  - 照这个格式做一份
  - 按这个格式填上去
  - 做成XX版本
  - document generation
  - create document
  - generate report
---

# 文档生成技能

一站式生成格式化文档给用户。支持 Word (.docx)、PDF、HTML 三种格式，涵盖中文排版最佳实践。

## 格式选择决策

| 场景 | 推荐格式 | 工具 |
|------|---------|------|
| 用户要编辑/打印 | Word (.docx) | python-docx |
| 用户要 PDF | **Word COM 直转（首选）** | python-docx + pywin32 |
| 需要保留样式、表格、中文 | HTML → Edge PDF | 直接写 HTML + Edge headless |
| 用户两个都要 | 生成 docx + Word COM 转 PDF | python-docx + pywin32 |
| **PPT → Word 图文对照讲义** | Word (.docx) | python-pptx 读 / python-docx 写 → `references/pptx-to-docx-handout.md` |
| **PPT/课件 → 期末复习讲义**（"蒸馏/总结知识点/方便复习"） | Word (.docx) + PDF | 压缩重组 + 公式速查 + 自测题 → `references/pptx-to-exam-notes.md` |
| **照现有表格 PDF 的版式生成新版**（听写表/词表/答题卡/登记表） | 直接生成 PDF | PyMuPDF `find_tables()` 抠几何 + `insert_text()` 落字 → `references/pymupdf-table-pdf.md` |
| **按学校/老师模板写读书报告、课程论文**（含查重/降 AI 率、扫描版经典著作取原文） | Word (.docx) | 照模板抠字号 + 稿子写进生成脚本 → `references/reading-report-from-template.md` |

## ⭐ docx → PDF：用 Word COM，别用 Edge（实测快 10 倍）

`document-generation` 老版本推荐 Edge headless 渲染 HTML 转 PDF。**实测对比（本会话）**：
Edge 路线要手工拼 HTML、90s 级超时、还要处理页眉重复/`CLEAN_KEYS` 过滤一堆坑；
**Word COM 一行 `SaveAs2(FileFormat=17)` 直接转，秒级完成，保真度还更高**。

```python
# pip install pywin32   ← Python 3.14 有 wheel，可装（别信"3.14 装不上"的旧结论）
import shutil, os, win32com.client as wc
tmp  = os.path.join(os.environ["TEMP"], "t.docx")   # ① 先复制到纯 ASCII 路径
shutil.copy(SRC_CN_PATH, tmp)                        #   Word COM 对中文路径偶发失败
pdf  = os.path.join(os.environ["TEMP"], "t.pdf")
if os.path.exists(pdf): os.remove(pdf)

w = wc.Dispatch("Word.Application"); w.Visible = False
try:
    d = w.Documents.Open(tmp)
    d.SaveAs2(pdf, FileFormat=17)   # 17 = wdFormatPDF
    d.Close(0)
finally:
    w.Quit()                        # 必须 finally，否则残留 WINWORD.EXE 卡死后续调用
assert os.path.exists(pdf), "PDF 未生成"   # 没这个 assert 会静默成功
shutil.copy(pdf, DST_CN_PATH)
```

要点：
- **必须先在 Python 里 `shutil.copy` 到 ASCII 路径** —— Word COM 传中文路径会偶发失败
- **`w.Quit()` 放 `finally`** —— 残留 WINWORD.EXE 会让下次 COM 调用挂住
- **`assert os.path.exists(pdf)`** —— 这是唯一可信的成功判据（老坑：`exit_code` 不可信）
- 这条路径**完全绕过 Edge 的 90s 超时**，也就不用再做「删掉 Word 超时段」这类维护

## Edge headless 仍是必需场景

只有「**没有 Word**」或「**源本来就是 HTML**」时才用 Edge。详见
`references/edge-headless-pdf.md`。

## PPTX → Word 讲义

用户说「把这份 PPT 整理成 Word」「PPT 转文档」「做一份课程讲义」时，先探明结构再选形态。

**PPT 信息分三层，价值排序：演讲者备注 > 正文要点 > 图片**
- `slide.notes_slide.notes_text_frame.text` = 真正的讲稿正文，通常是最有价值的部分
- `shape.text_frame` = 碎片化短句（时间轴标签、人名、图注），不成段
- 先统计"多少页有备注"——这个比例直接决定文档形态（71页PPT里可能只有16页有备注）

**必须让用户在两条路线里选**（不要替用户默认，形态差异极大）：
- **图文对照版**：每页 = 页码标题 + 要点列表 + 原图 + 备注全文；页数多、零丢失、可对照原PPT
- **纯文本讲稿版**：不插图，便于打印背诵；页数少

**红线：只整理，不创作。** 没有备注的页面就用"要点列表"呈现原文，**绝不替课程/作者编写讲解内容**。交付时明确写出"没有替你编写讲解内容"。

**交付前必须实测验证**（用户明确要求过，见 Pitfalls #5）。完整实现见 `references/pptx-to-docx-handout.md`。

## 标准工作流：生成 Word + PDF 双格式

### 第一步：用 python-docx 生成 Word

```python
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()
# 设置默认字体
style = doc.styles['Normal']
style.font.name = '微软雅黑'
style.font.size = Pt(11)

# ... 添加内容 ...

doc.save('output.docx')
```

### 第二步：同时生成 HTML 版本（推荐）

不要直接用 Edge 渲染 .docx——会超时（见 pitfalls）。应该同时生成一份 HTML 或用 python-docx 读回内容写 HTML。

### 第三步：Edge headless HTML→PDF

```powershell
$edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
Start-Process -FilePath $edge -ArgumentList @(
    "--headless", "--disable-gpu",
    "--print-to-pdf=C:\path\to\output.pdf",
    "--no-pdf-header-footer",
    "C:\path\to\document.html"
) -Wait -NoNewWindow
```

> 详细参数和注意事项见 `references/edge-headless-pdf.md`

## 中文文档排版规范

### 字体
- 正文：微软雅黑 11pt
- 标题：微软雅黑加粗，h1=22pt, h2=16pt, h3=13pt
- 代码/英文：Consolas 或等宽字体

### 配色
- 主色：#1A56DB（深蓝，专业感）
- 强调色：#3B82F6（亮蓝）
- 警告色：#F59E0B（琥珀）
- 正文色：#333

### 间距
- 行距：1.25-1.5 倍
- 段后间距：4-6pt
- 列表缩进：24px

### HTML 页边距（影响 PDF 输出）
```css
@page { size: A4; margin: 20mm 18mm; }
```

## 提示框样式

### 信息提示（蓝底）
```css
.tip { background: #eff6ff; border-left: 4px solid #3B82F6; padding: 10px 16px; }
```

### 警告提示（黄底）
```css
.warn { background: #fef3c7; border-left: 4px solid #F59E0B; padding: 10px 16px; }
```

## 批量文档提取与分析

见 `references/batch-document-extraction.md`

## ⚠️ 「测一下这篇的 AI 率」——先读 `references/ai-rate-detection.md`

`scripts/ai_smell_check.py` 是写稿时的粗筛，**不能直接当"AI 率报告"用**：它的词表含
首先/最后/更/全面 这类政论文标配词，会把正常的读书报告判成"需改"。

实测结论（一篇 2558 字思政读书报告，真实判定 ≈10%）：
- **必须剔除四类误报**：序数用法（第一卷/第一次/第一书记）、比较级"更"、政论标配词、副标题破折号
- 真正有判别力的是**套话整句**（综上所述/意义重大/提供了根本遵循…），0 命中即安全
- 评分改用六项 100 分制（套话 25 + 句长标准差 25 + AI 词密度 20 + "我"密度 15 + 口语 10 + 承认局限 5），
  **不要用通用库的 `30+70×(1-密度/10)`**，它会给学术文本假高分
- 脚本只统计，`更/第一/最后/——` 必须人工看上下文再定性（`--verbose` 打印上下文）
- 报告口径：一句人话结论 → 指标表 → 可改可不改的几处

命令：`uv run --with python-docx python scripts/ai_rate.py 报告.docx --verbose`

## Pitfalls

1. **Edge 不能直接渲染 .docx**：会超时或卡住（fallback_task_provider 错误）。必须 HTML 中转。
2. **PowerShell 路径中的 &**：不要用 `& "path\to\msedge.exe"` 调用，终端工具会误判为后台进程。用 `Start-Process` 代替。
3. **PDF 路径不能有空格**：`--print-to-pdf=` 后直接跟完整路径。
4. **python-docx 字体设置**：设置 `style.font.name` 后，新段落继承该样式，但 run 级别的字体会覆盖。中文还必须同时设 eastAsia：
   ```python
   from docx.oxml.ns import qn
   style._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')   # 缺这行中文会掉回宋体
   ```
5. **⚠️ `doc.paragraphs` 不包含表格单元格文本** —— 写内容校验脚本时最常见的**假阴性**来源。本会话实测：PPT 来的"708/750"在表格里，校验器只扫 `paragraphs` 就报"内容缺失"，差点误判文档有缺陷。必须单独拼进来：
   ```python
   table_text = "\n".join(c.text for tb in doc.tables for row in tb.rows for c in row.cells)
   full = "\n".join(p.text for p in doc.paragraphs) + "\n" + table_text
   ```
   **通用教训**：校验器漏报比没有校验器更危险——它会让你以为测过了。校验报"缺失"时，先怀疑校验器的覆盖面，再怀疑产物。
6. **交付前必须实测验证**：用户明确要求过，不接受"status=passed / 生成成功"就报完成。至少做到：解包 `word/media` 数图片并核字节数、数 `inline_shapes`、核页标记数量、抽查多处关键词。有效校验脚本见 `references/pptx-to-docx-handout.md`。
7. **同名图片跨页复用**：PPT 里页眉 logo / 页脚横幅每页都出现，直接抽图会让 Word 体积翻几倍。按 blob 的 md5 去重，并按尺寸过滤装饰图（宽>12in 且高>3in 的横幅、<1in×1in 的小图标）。
8. **🔴 `insert_textbox()` 会静默丢文字（PyMuPDF 生成表格 PDF 时）**：文字放不进度量框时它返回**负数**，然后什么都不画、不报错，产物 PDF 表格线齐全但**文字层完全空白**，`get_text()` 返回 `''`。实测 14.63pt 行里 `fontsize=9.5` 返回 `-0.33` 就被丢弃（9pt 才 `+0.46` 通过）。**判据是返回值 `rc < 0`，必须判**；正解是改用 `insert_text()` + 显式基线（按绝对坐标落字，无"放不下"这种失败模式）。**并且渲染函数末尾必须重开产物断言文字层存在**，否则会交出 89 页空白表。详见 `references/pymupdf-table-pdf.md`。
9. **模板复刻先量再抄，别重新设计版式**：用户给现成表格 PDF 说"按这个格式做一版"时，用 `find_tables()` 抠出 `bbox`/行列数/行高/列宽照抄——用户认的就是那个观感。**能不能套用原行高必须先量分布**（本会话：四级释义 100% 单行 → 原样套；六级 63% 超长、最长 9 行 → 单行物理放不下，改行高自适应）。宁可行高不均，也不截断内容；分岔时把选择摆给用户。
10. **🔴 中文 PDF 里英文必须换比例字体（SimSun 是等宽 CJK 字体）**：用户报"每行内字之间间距不一样"时，根因通常是**中文宋体把每个 ASCII 字符都排成 0.5em**（实测 `i`=`m`=`W`=5.000pt），英文看着逐字撑开。正解：按 run 切分，**ASCII 走 Times，CJK 走宋体**。⚠️ 但 **IPA 音标必须留在宋体**（Times 无 IPA 字形，会渲染成一排点 `[··bju·s]`）。**验证要用数值**（字体声明 + 每字符宽度是否不等），**别信辅助视觉模型**——它本会话两次误判为等宽。详见 `references/pymupdf-table-pdf.md`。
11. **🔴 渲染路径上任何"保护性"上限都是静默截断**：本会话给表格行高设了 `min(n, 4)` 上限，结果**静默吃掉 38 条词义**（1.71%），产物表面完全正常，只有逐条回读比对才暴露；放开上限只多 1 页。同类：`insert_textbox` 的度量框（Pitfall #8）。**规则：上限要么不设，要么设了就必须用逐条回读把损失量出来。**
12. **词性标签跨词表不一致，必须归一化**：四级用 `a./ad.`、六级用 `adj./adv.`（`a.` 与 `ad.` 一字母之差极易混）。用户明确要求"adj 和 adv 一定要区分好"→ 统一成全称 `adj.`/`adv.`。同时源数据在词性前塞有噪音（义项序号、音标、`(pl ...)`、`adj·` 错字），**剥离有顺序要求**（斜杠必须先于音标剥，见 reference）。
13. **🔴 先验证输入源的「范围」，再验证产物的「正确性」**：本会话把力气全花在渲染细节上，逐条回读校验 **4539/4539 全 PASS** —— 但**比对的是错的范围**：把「六级净增表」当成了「六级全表」，成品只有 2219 词、比四级还少。**校验再严密也救不了范围错误的输入。** 用户是靠常识（六级不该比四级少）发现的。**规则：拿到外部词表/清单/数据源，先打印头几行 + 核对规模是否与官方口径相符（有没有表头？有没有字母分隔行？数量对不对？），再动手。产物规模反直觉时立刻停下查源，别急着解释。** 详见 `references/pymupdf-table-pdf.md` 第 5.1 步。
14. **🔴 去重必须按「词+释义」，不能只按词形** —— 同形异义词会被吞掉一个义项。本会话初版按 `word.lower()` 去重，**静默删掉了四级 72 个词的其中一个义项**（`bear` 熊/容忍、`box` 盒子/拳击、`can` 能/罐头、`light` 光/轻、`March` 三月/行军）。词表把同形异义**分开列**正是要保留两个义项。正解：去重键用 `(word, meaning)`，排序键用 `(词, 词)` 让同一词的多个义项相邻。**判据：源表头声明的词数 vs 你解析出的词数**——本会话源表写 `(共 4615 词)` 而我只有 4539，差的那 76 条就是这个 bug 的信号（对齐后 4614，仅差 1 条解析失败）。见 Pitfall #13：**源声明的规模就是你的校验基准**。
15. **补释义走「多源回退链」，并核对官方标记**：合并全表（8013）里 2600+ 派生词（`abbreviation`/`accessible`/`zoology`）在原大纲文件里**没有释义**。按优先级回退：大纲文件 → OALD8 → TOEFL → **ECDICT（`translation` 列，覆盖面最广）** → COCA。⚠️ ECDICT 的 `tag` 列可交叉验证词汇范围（实测 `cet4`=3849 / `cet6`=5407 / 合计 5805，与官方口径吻合），但**它的标记并不完整**（`cet4` 只标了 3849，而大纲是 4615），**所以 ECDICT 只能当释义源，不能当词表骨架**。补全流程 + 重音/英式拼写归一见 `references/pymupdf-table-pdf.md`。

## 相关技能

- `PDF全能工具箱`：PDF 合并/拆分/OCR/水印等处理
- `Word全能工具箱`：Word 格式转换/编辑/合并
- `ocr-and-documents`：从 PDF/扫描件提取文本
- `powerpoint`：PPT 生成

## 参考文件

- `references/edge-headless-pdf.md` — Edge headless HTML→PDF 完整指南
- `references/batch-document-extraction.md` — 批量文档提取方案（旧版，已被 `batch-extraction.md` 取代）
- `references/batch-extraction.md` — **混合格式文件夹批量提取**（原独立技能 `batch-document-extraction`）：
  三提取器矩阵（PyMuPDF / python-docx / olefile）、.doc 四种方案、纯图片 PDF 与损坏 PDF 判据、
  扁平命名代价、Windows+WSL2 编码取舍、完成后清点验证命令。
- `references/pptx-to-docx-handout.md` — **PPT → Word 图文对照讲义**完整实测流程（抽图去重/装饰图过滤/中文排版/讲稿分段/验证脚本/交付话术）
- `references/reading-report-from-template.md` — **按学校模板写读书报告/课程论文**：
  模板字号抠参数、扫描版经典著作取原文（PyMuPDF 而非 pdftotext；GBK-EUC-H 字形错字、印刷页码 = PDF 序 − N 且须先验证）、
  **封面落款被挤到第 2 页的真因是总占高超 780pt，加空行是赌博**、信息栏等长下划线、WPS COM `KWps.Application` 转 PDF 验版式、
  **二改场景（先写完稿、事后才拿到模板）**：从零重建 docx 而不是改样式、封面字段抠取要剔 U+3000 全角空格、
  长副标题会折行需降字号并渲染看图、模板里的说明性标题是占位符要自拟、
  降 AI 率四条实操（AI 高频词 0 命中 / 句长要抖 / 真实第一人称细节但绝不编造事迹 / 结语留疑问）→ 配套 `scripts/ai_smell_check.py`
- `references/pymupdf-table-pdf.md` — **用 PyMuPDF 照现有表格 PDF 生成新版** / `insert_text` vs `insert_textbox` 静默丢字 / **中英字体混排 + IPA 必须留宋体** / **词性标签 adj·adv 归一化与噪音剥离顺序** / 中文按宽度换行 / 行高该不该自适应、**上限即静默截断** / 权威词表镜像下载 + **先验全表还是增量表的识别信号** / 词表行解析正则 / **同形异义词去重必须按「词+释义」** / **多源回退补释义链（ECDICT 当源、不当骨架）** / 回读逐条比对验证与 SimSun 读不回的等价字形）
- `references/pptx-to-exam-notes.md` — **课件 → 期末复习讲义**（文字在文本框、公式在图片里 → 另存 PDF 逐页 `get_pixmap` 后 OCR 抄公式 / 大章节切块读 / ★▲标记 + 公式速查表 + 自测题形态 / 抽查页验证符号不乱码）
- `scripts/extract_all.py` — 开箱即用的批量提取脚本
- `references/variant-respin.md` — **用已交付成品派生另一套**（原 `document-variant-respin`）：
  脚本参数化 `P` dict → 替换表脚本 → 排序铁律（长串在前/占位符二段替换）→ 相邻字面量拼接导致漏替换 →
  成品级残留自检（PPT 递归 group、docx 表格单元格）+ `scripts/check_variant_residue.py` 门禁 →
  改动分寸（主标题隐喻/核心方向/起点故事必改，版式不动）→ `☐` 独立 run 坑。
- `references/manuscript-length-and-form-filling.md` — **按硬性篇幅反复精简/扩写 + 填 .docx 表格表单**
  （原 `manuscript-length-fitting`）：稿纸格数公式、查重白名单与边界碎片坑、加厚/末尾加厚、
  **绝不编造个人事迹**红线、单元格容量计算、`hRule=exact` + 表格后空 `<w:p>` 两个"2 页"根因、
  Word COM 验页数（pywin32 首选）+ `scripts/length_tools.py`、`scripts/docx_form_fit.py`。
- `references/rudang-shenqingshu.md` — 入党申请书专项（吉大格式硬性要求与结构骨架）。
- `scripts/check_variant_residue.py` / `scripts/length_tools.py` / `scripts/docx_form_fit.py` — 上述两个参考的配套脚本。
- `references/ai-rate-detection.md` — **测稿件 AI 率**（读书报告/课程论文/思政作业）：
  四类必剔误报（序数/"更"/政论词/副标题破折号）、套话整句清单、"人味"特征表、六项 100 分评分口径、
  报告形态（先结论后表格）、"测≠改"与原文件不动的约束 → 配套 `scripts/ai_rate.py`
- `scripts/ai_rate.py` — AI 率量化脚本（docx/txt 直吃，`--verbose` 打印需人工判性质的上下文）。
  `scripts/ai_smell_check.py` 是写稿粗筛，别拿它出报告。
- `scripts/table_pdf_builder.py` — **表格 PDF 生成骨架**（中英混排/音标留宋体/词性归一化/不设行高上限/文字层强制门/回读验证）。做听写表·词表·答题卡类任务时拷它改，别从零写。
