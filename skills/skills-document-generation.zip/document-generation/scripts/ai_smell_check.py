# -*- coding: utf-8 -*-
"""中文稿件 AI 味自检：字数 / 段长节奏 / AI 高频词 / 句长分布。
用法: python ai_smell_check.py 报告.docx [正文分隔标记，默认 参考文献]
无表格的文档直接可用；有表格时先把表格文本拼进来（见 SKILL.md Pitfall #5）。
"""
import re
import sys

import docx

AI_WORDS = ["此外", "综上所述", "值得注意的是", "不仅", "一方面", "另一方面", "彰显",
            "意义深远", "至关重要", "赋能", "标志着", "奠定了", "深刻地", "充分体现"]


def main(path, cut="参考文献"):
    d = docx.Document(path)
    paras = [p.text for p in d.paragraphs]
    body = "\n".join(paras).split(cut)[0]
    body = re.sub(r"\s", "", body)

    print(f"正文字符数: {len(body)}")
    lens = [len(re.sub(r"\s", "", t)) for t in paras if len(t) > 60]
    print(f"段落字数分布: {lens}")

    hits = {w: body.count(w) for w in AI_WORDS if body.count(w)}
    print(f"AI 高频词: {hits or '无'}")

    sents = [s for s in re.split(r"[。！？；]", body) if s.strip()]
    avg = sum(map(len, sents)) / max(len(sents), 1)
    short = sum(1 for s in sents if len(s) < 15)
    print(f"句数 {len(sents)} | 平均句长 {avg:.1f} | 短句(<15字) {short}")
    print(f"分号 {body.count('；')} | 破折号 {body.count('——')}")

    ok = not hits and short >= 5
    print("判定:", "通过" if ok else "需改（有 AI 高频词，或短句太少）")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], *(sys.argv[2:3])))
