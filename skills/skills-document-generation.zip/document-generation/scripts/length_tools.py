# -*- coding: utf-8 -*-
"""手写稿篇幅配平工具：字数/页数核算 + 重复片段检测（二合一）。

用法：改下面三个常量 → python3.14 length_tools.py
输出：总字符/页数/余量、各段字符数排行（定位该砍哪段）、≥8字的重复片段。

⚠️ Windows 上跑之前先剥 BOM；改本文件只用 patch/write_file，不要用 PowerShell 读写。
"""
import re
from collections import defaultdict

SRC = r"D:\Hermes文件库\入党申请书\入党申请书_王子涵.md"
CELLS = 360          # 每页格数（向用户确认，别猜）
TARGET = 9.5         # 目标页数
WIN = 8              # 判定重复的片段长度

# 首尾呼应 / 固定提法 / 政审必查信息 —— 这些重复属正常，不算问题
WHITELIST = (
    "申请加入中国共产党", "向党组织提出申请",
    "中国特色社会主义", "吉林大学交通学院",
    "习近平谈治国理政", "党的二十大报告",
    "此致", "敬礼",
)


def load(path):
    """读稿：去掉 markdown 标记行（# / > / ---），返回正文字符串列表。"""
    paras = []
    for ln in open(path, encoding="utf-8").read().splitlines():
        s = ln.strip()
        if not s or s.startswith((">", "#")) or set(s) <= set("-|: "):
            continue
        paras.append(s)
    return paras


def stats(paras):
    tot = sum(len(p) for p in paras)
    limit = CELLS * TARGET
    print(f"正文 {tot} 字符 | {CELLS} 格/页 × {TARGET} 页 = 上限 {limit:.0f}")
    print(f"当前 → {tot / CELLS:.2f} 页")
    d = tot - limit
    print(f"{'⚠️ 超出' if d > 0 else '✅ 余量'} {abs(d):.0f} 字符（{abs(d) / CELLS:.2f} 页）\n")
    print("各段字符数（最长者优先砍）：")
    for i, p in sorted(enumerate(paras, 1), key=lambda x: -len(x[1])):
        print(f"  {i:2d}. {len(p):4d} 字  {p[:30]}…")
    return tot


def dup_check(paras):
    """滑窗找 ≥WIN 字的重复片段；白名单词内部的片段全部跳过。"""
    def norm(s):
        return re.sub(r"[^\u4e00-\u9fffA-Za-z0-9]", "", s)

    body = [norm(p) for p in paras]
    # 每段记录位于白名单词内部的位置索引
    protected = []
    for p in body:
        fixed = set()
        for w in WHITELIST:
            for m in re.finditer(re.escape(w), p):
                fixed.update(range(m.start(), m.end()))
        protected.append(fixed)

    seen = defaultdict(set)
    for i, p in enumerate(body):
        for j in range(len(p) - WIN + 1):
            if all(k in protected[i] for k in range(j, j + WIN)):
                continue
            seen[p[j:j + WIN]].add(i)

    merged = []
    for g, ps in sorted((x for x in seen.items() if len(x[1]) > 1), key=lambda x: -len(x[1])):
        if any(g in m[0] for m in merged):
            continue
        # 跨窗口边界碎片：与白名单词高度重叠（差 1-2 字）也算白名单
        if any(w in g or g in w or g[1:] in w or g[:-1] in w or w[1:] in g or w[:-1] in g
               for w in WHITELIST):
            continue
        merged.append((g, sorted(ps)))

    if merged:
        print(f"\n⚠️ 发现 {len(merged)} 处重复片段：")
        for g, ps in merged:
            print(f"  段落#{ps} → 「{g}」")
    else:
        print("\n✅ 未发现成段重复（已排除首尾呼应/固定提法）")
    return merged


if __name__ == "__main__":
    paras = load(SRC)
    tot = stats(paras)
    merged = dup_check(paras)
    assert tot > 1000, f"正文只有 {tot} 字符，疑似读错文件"
    assert not merged, "仍有重复内容，见上方列表"
