# -*- coding: utf-8 -*-
"""
docx 表单填字容量核算 + 页数验证（manuscript-length-fitting 配套）

用法：
    python docx_form_fit.py <表单.docx>

输出：每行 trHeight / hRule、单元格每行字数、各栏容量与当前内容所需行数、
      以及是否溢出。把溢出的栏精简到 OK，再转 PDF 复核页数。

⚠️ 中文路径直接传参是安全的（Python 内部按 Unicode 处理）。
   PowerShell 调用 python3.14 传中文参**会吞字符**，见 windows-wsl2-script-exec——
   若必须走 PS，用 `$env:FORMDOC` 传路径，别写在命令行里。
"""
import sys
import docx
from docx.oxml.ns import qn

TWIPS_PER_CM = 567
EMU_PER_PT = 12700


def row_height(row):
    """返回 (twips_val, hRule) 或 (None, None)"""
    trPr = row._tr.trPr
    if trPr is None:
        return None, None
    for c in trPr:
        if c.tag.endswith('}trHeight'):
            return int(c.get(qn('w:val'))), c.get(qn('w:hRule'))
    return None, None


def main(src):
    d = docx.Document(src)
    sec = d.sections[0]
    avail_h = sec.page_height - sec.top_margin - sec.bottom_margin
    print(f"页面可用高 {avail_h / 360000:.2f}cm  "
          f"可用宽 {(sec.page_width - sec.left_margin - sec.right_margin) / 360000:.2f}cm")

    total = 0
    for ti, t in enumerate(d.tables):
        print(f"\n=== 表 {ti}: {len(t.rows)}行 x {len(t.columns)}列 ===")
        for ri, row in enumerate(t.rows):
            h, rule = row_height(row)
            n_par = sum(len(c.paragraphs) for c in row.cells[:1])
            txt = "".join(dict.fromkeys(c.text for c in row.cells))  # 合并单元格去重
            flag = "" if rule else "  ⚠️ hRule缺省=atLeast(行会长高)"
            if h:
                total += h
            print(f"row{ri}: {h}twips={h / TWIPS_PER_CM:.2f}cm "
                  f"rule={rule} 段数={n_par} 内容={len(txt)}字{flag}")

        print(f"\n-- 逐栏容量 --")
        for ri, row in enumerate(t.rows):
            h, _ = row_height(row)
            if not h:
                continue
            for ci, cell in enumerate(row.cells):
                txt = cell.text.strip()
                if not txt or len(txt) < 20:
                    continue
                wpt = cell.width / EMU_PER_PT
                per_line = max(int(wpt / 10.5), 1)          # 10.5pt 宋体
                pars = [p for p in cell.paragraphs if p.text.strip()]
                n = len(txt.replace("\n", ""))
                lines = -(-n // per_line) + len(pars)        # 首行缩进损耗
                need = lines * 10.5 * 1.3 * 20               # pt -> twips
                verdict = "OK" if need <= h else f"溢出 {need - h:.0f}twips"
                print(f"({ri},{ci}) 宽{wpt:.0f}pt→{per_line}字/行 | "
                      f"{n}字/{len(pars)}段→{lines}行 需{need:.0f} vs 容{h} → {verdict}")

    print(f"\n显式行高合计 {total}twips = {total / TWIPS_PER_CM:.2f}cm")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    main(sys.argv[1])
    # 自检：页数必须用 Word COM 复核（见 SKILL.md「验证页数」）
