# -*- coding: utf-8 -*-
"""派生文档残留自检：扫 .pptx / .docx，报出「原件专属词」是否还留在新件里。

用法：
    python3.14 check_variant_residue.py <文件1> [文件2 ...] --bad 王子涵 转专业 吉速车队

或改下面的 DEFAULTS 直接无参跑（最常用）。

为什么要这个脚本（不要手写一次性版本）：
  · PPT 的文字藏在 group 里（shape_type == 6）——不递归就漏
  · PPT 的表格在 shape.has_table 上，不在 text_frame——不单独取就漏
  · docx 的表格单元格不在 doc.paragraphs 里——不单独拼就假阴性
  这三条每一条都单独坑过一次。写死在这里，别再重犯。

退出码：0 = 三处全清；1 = 有残留（脚本会打印具体所在页/位置）。
"""
from __future__ import annotations

import argparse
import os
import sys


def scan_pptx(path: str) -> list[tuple[int, str]]:
    """返回 [(页号, 文本), ...]，含 group 递归与表格。"""
    from pptx import Presentation

    out: list[tuple[int, str]] = []

    def walk(shapes, pageno: int) -> None:
        for s in shapes:
            if s.shape_type == 6:          # GROUP —— 必须递归，否则漏组合里的文字
                walk(s.shapes, pageno)
                continue
            if s.has_text_frame and s.text_frame.text.strip():
                out.append((pageno, s.text_frame.text))
            if getattr(s, "has_table", False) and s.has_table:
                for r in s.table.rows:
                    for c in r.cells:
                        if c.text.strip():
                            out.append((pageno, c.text))

    prs = Presentation(path)
    for i, slide in enumerate(prs.slides, 1):
        walk(slide.shapes, i)
    return out


def scan_docx(path: str) -> list[tuple[int, str]]:
    """返回 [(0, 文本), ...]。表格单元格必须单独拼（不在 .paragraphs 里）。"""
    from docx import Document

    d = Document(path)
    out = [(0, p.text) for p in d.paragraphs if p.text.strip()]
    for t in d.tables:
        for r in t.rows:
            for c in r.cells:
                if c.text.strip():
                    out.append((0, c.text))
    return out


def scan(path: str) -> list[tuple[int, str]]:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pptx":
        return scan_pptx(path)
    if ext == ".docx":
        return scan_docx(path)
    raise ValueError(f"不支持的类型：{ext}（只做 .pptx / .docx）")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--bad", nargs="+", required=True,
                    help="原件专属词黑名单（旧名/旧经历/旧专业/旧城市…）")
    args = ap.parse_args()

    total_hits = 0
    for f in args.files:
        if not os.path.exists(f):
            print(f"[跳过] 不存在：{f}")
            continue
        print(f"\n=== {os.path.basename(f)} ===")
        try:
            chunks = scan(f)
        except Exception as e:                       # noqa: BLE001
            print(f"  !! 读取失败：{e}")
            total_hits += 1
            continue

        hits = []
        for bad in args.bad:
            for pageno, text in chunks:
                if bad in text:
                    where = f"P{pageno}" if pageno else "段落/表格"
                    hits.append((bad, where, text.replace("\n", " | ")[:140]))

        if not hits:
            print("  残留：无 ✅")
        else:
            for bad, where, snippet in hits:
                print(f"  ❌ [{bad}] {where}: {snippet}")
            total_hits += len(hits)

    print("\n" + ("=" * 50))
    if total_hits:
        print(f"结果：发现 {total_hits} 处残留 —— 未通过")
        return 1
    print("结果：全部通过（三处文件零残留）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
