# -*- coding: utf-8 -*-
"""参考实现：照现有表格 PDF 生成新版（听写表/词表/答题卡）。

本文件是从一次真实交付（高考词汇听写表 → 四六级词汇听写表）抽出来的骨架，
已验证跑通 4539 + 2219 词、逐条回读零差异。**拿它当起点改，别从零写。**

核心要点（每一条都踩过坑，详见 references/pymupdf-table-pdf.md）：
  1. 几何从源 PDF 量出来照抄，不要重新设计。
  2. 落字用 insert_text()，不要用 insert_textbox()（后者静默丢字）。
  3. 中英混排：ASCII 走 Times、CJK 走宋体、IPA 留在宋体。
  4. 换行用 Font.text_length 量宽度，不要用字符数估。
  5. 行高不设上限（上限就是静默截断）。
  6. 渲染完重开文件断言文字层存在。
  7. 交付前逐条回读比对。

用法：改 SRC 几何 + parse() + 跑 main，然后**必须**跑 verify()。
"""
import re, io, sys
import pymupdf

# ---- 1. 几何：从源 PDF 量出来后写死（示例值来自 高考词汇听写表）----
CJK_FONT = "/mnt/c/Windows/Fonts/simsun.ttc"
LAT_FONT = "/mnt/c/Windows/Fonts/times.ttf"
X0, X1 = 38.64, 549.48
COLS = [X0, 174.6, 267.8, 361.6, 455.3, X1]
HDR_TOP, HDR_BOT = 33.48, 49.08
PAGE_BOTTOM = 819.84
LEADING, PAD, FS, FS_HDR = 12.0, 2.0, 9.5, 10.5
HEADERS = ["汉语", "听写三", "听写二", "听写一", "字母排序"]
CJK = re.compile(r"[\u4e00-\u9fff]")

cjk_f = pymupdf.Font(fontfile=CJK_FONT)
lat_f = pymupdf.Font(fontfile=LAT_FONT)


# ---- 3. 中英混排：IPA 归 CJK 侧，否则 Times 无字形会渲染成点 ----
def runs(text):
    out, cur, cur_lat = [], "", None
    for ch in text:
        o = ord(ch)
        is_lat = o < 0x2E80 and not (0x0250 <= o <= 0x02FF) and ch not in "ˈˌː"
        if cur_lat is None or is_lat == cur_lat:
            cur += ch
        else:
            out.append((cur_lat, cur))
            cur = ch
        cur_lat = is_lat
    if cur:
        out.append((cur_lat, cur))
    return out


def char_w(ch, size, is_lat):
    return (lat_f if is_lat else cjk_f).text_length(ch, fontsize=size)


def text_w(text, size=FS):
    return sum(char_w(ch, size, is_lat) for is_lat, chunk in runs(text) for ch in chunk)


# ---- 4. 换行：量宽度，CJK 任意断，ASCII 单词不拆 ----
def wrap(text, avail, size=FS):
    lines, cur = [], ""
    for tok in re.findall(r"[A-Za-z0-9@\.\'\-/]+|\s+|[^\s]", text):
        if tok.isspace() and not cur:
            continue
        if text_w(cur + tok, size) <= avail or not cur:
            cur += tok
        else:
            lines.append(cur.rstrip())
            cur = "" if tok.isspace() else tok
    if cur.strip():
        lines.append(cur.rstrip())
    return lines or [""]


def draw(page, x, ytop, text, avail, size=FS):
    """逐 run 换字体落字，手工累加 cx。"""
    base = ytop + PAD + size
    for ln in wrap(text, avail, size):
        cx = x
        for is_lat, chunk in runs(ln):
            page.insert_text((cx, base), chunk, fontsize=size,
                             fontname="tiro" if is_lat else "china-s",
                             fontfile=LAT_FONT if is_lat else CJK_FONT)
            cx += text_w(chunk, size)
        base += LEADING


# ---- 词性归一化（顺序敏感，见 reference）----
POS = [(r"^adj\.?", "adj."), (r"^adv\.?", "adv."), (r"^a\.", "adj."), (r"^ad\.", "adv."),
       (r"^vt\.", "vt."), (r"^vi\.", "vi."), (r"^v\.", "v."), (r"^n\.", "n."),
       (r"^prep\.", "prep."), (r"^conj\.", "conj."), (r"^pron\.", "pron."),
       (r"^num\.", "num."), (r"^art\.", "art."), (r"^int\.", "int."), (r"^aux\.?", "aux.")]


def norm_pos(m):
    m = re.sub(r"^[\s\d\[\]\(\)\.]*", "", m)
    m = re.sub(r"^\[[^\]]*\]\s*", "", m)
    m = re.sub(r"^[^\s\]]*\]\s*", "", m)
    m = re.sub(r"^\(pl[^)]*\)\s*", "", m)
    m = re.sub(r"^（pl[^)]*\)\s*", "", m)
    m = re.sub(r"^pl\s+[^)]*\)\s*", "", m)
    m = re.sub(r"^\s*/\s*", "", m)                     # 斜杠必须在音标之前
    m = re.sub(r"^[ˈˌ\u0250-\u02FF][^\s]*\s*", "", m)
    m = re.sub(r"^[^\s/]{2,}\s*/\s*(?=(?:adj|adv|n|v|vt|vi|prep|conj|pron|num|art|int|aux)\.)", "", m)
    m = re.sub(r"^adj·", "adj.", m)
    for pat, full in POS:
        if re.match(pat, m):
            return re.sub(pat, full, m, count=1)
    return m.strip()


# ---- 5. 行高：不设上限（min() 就是静默截断）----
def row_lines(item):
    kind, payload = item
    if kind == "L":
        return 1
    w, m = payload
    return max(len(wrap(m, COLS[1] - COLS[0] - 2 * PAD)),
               len(wrap(w, COLS[5] - COLS[4] - 2 * PAD)), 1)


def paginate(seq):
    pages, cur, y = [], [], HDR_BOT
    for item in seq:
        h = row_lines(item) * LEADING + 3.0
        if y + h > PAGE_BOTTOM and cur:
            pages.append(cur)
            cur, y = [], HDR_BOT
        cur.append(item)
        y += h
    if cur:
        pages.append(cur)
    return pages


def build_sequence(entries):
    seq, cur_letter = [], ""
    for w, m in entries:
        letter = re.sub(r"[^A-Za-z]", "", w)[0].upper()
        if letter != cur_letter:
            cur_letter = letter
            seq.append(("L", letter))
        seq.append(("W", (w, m)))
    return seq


def make_pdf(label, entries, outfile):
    doc = pymupdf.open()
    pages = paginate(build_sequence(entries))
    total = len(pages) + 1

    cov = doc.new_page(width=595.3, height=841.9)
    cov.insert_textbox(pymupdf.Rect(60, 300, 535, 370), label, fontsize=28,
                       fontname="china-s", fontfile=CJK_FONT,
                       align=pymupdf.TEXT_ALIGN_CENTER)
    for i, t in enumerate(["班级：____________", "姓名：____________",
                           f"共 {len(entries)} 词"]):
        cov.insert_textbox(pymupdf.Rect(60, 390 + i * 40, 535, 425 + i * 40), t,
                           fontsize=13, fontname="china-s", fontfile=CJK_FONT)

    for pi, rows in enumerate(pages):
        page = doc.new_page(width=595.3, height=841.9)
        page.insert_textbox(pymupdf.Rect(X0, 20, X1, 32), f"{label}   {pi + 2}/{total}",
                            fontsize=8.5, fontname="china-s", fontfile=CJK_FONT,
                            align=pymupdf.TEXT_ALIGN_CENTER)
        for c in range(5):
            page.draw_rect(pymupdf.Rect(COLS[c], HDR_TOP, COLS[c + 1], HDR_BOT),
                           color=(0, 0, 0), width=0.7)
        hb = HDR_BOT - (HDR_BOT - HDR_TOP - FS_HDR) / 2 - FS_HDR * 0.22
        for c, htxt in enumerate(HEADERS):
            cx = (COLS[c] + COLS[c + 1] - text_w(htxt, FS_HDR)) / 2
            for is_lat, chunk in runs(htxt):
                page.insert_text((cx, hb), chunk, fontsize=FS_HDR,
                                 fontname="tiro" if is_lat else "china-s",
                                 fontfile=LAT_FONT if is_lat else CJK_FONT)
                cx += text_w(chunk, FS_HDR)
        ytop = HDR_BOT
        for item in rows:
            ybot = ytop + row_lines(item) * LEADING + 3.0
            for c in range(5):
                page.draw_rect(pymupdf.Rect(COLS[c], ytop, COLS[c + 1], ybot),
                               color=(0, 0, 0), width=0.7)
            kind, payload = item
            if kind == "L":
                draw(page, COLS[4] + PAD, ytop, payload, COLS[5] - COLS[4] - 2 * PAD)
            else:
                w, m = payload
                draw(page, COLS[0] + PAD, ytop, m, COLS[1] - COLS[0] - 2 * PAD)
                draw(page, COLS[4] + PAD, ytop, w, COLS[5] - COLS[4] - 2 * PAD)
            ytop = ybot
    doc.save(outfile, deflate=True, garbage=3)
    n = doc.page_count
    doc.close()

    # 6. 强制门：insert_text* 有静默失败模式，必须自证文字层存在
    chk = pymupdf.open(outfile)
    body = chk[1].get_text()
    assert "汉语" in body and CJK.search(body), f"{outfile}: 文字层缺失（检查写入方式）"
    chk.close()
    return n


# ---- 7. 验证：回读产物逐条比对（必须做，别只数行数）----
def norm(s):
    """SimSun 有一批字形 get_text() 读不回来，这些等价类必须去掉再比。"""
    s = re.sub(r"[\s…⋯·’'①②③④⑤⑥⑦⑧⑨⑩]", "", s)
    s = re.sub(r"\[[^\]]*\]", "", s)
    return s.strip()


def join_lines(items):
    """items=[(y,x,text)]：先按 y 聚成视觉行，行内按 x 排（只按 x 会交错）。"""
    lines = []
    for y, x, t in sorted(items):
        if lines and abs(lines[-1][0] - y) < 1.2:
            lines[-1][1].append((x, t))
        else:
            lines.append([y, [(x, t)]])
    return "".join("".join(t for _, t in sorted(ts)) for _, ts in lines)


def verify(pdf_path, src_map):
    doc = pymupdf.open(pdf_path)
    seen = {}
    for pno in range(1, doc.page_count):
        p = doc[pno]
        # 行带用画出来的行框 y 值（固定 ±9 会跨行串味）
        bands = sorted({round(d["rect"].y0, 2) for d in p.get_drawings()
                        if d["rect"].width > 100})
        if len(bands) < 2:
            continue
        cells = {}
        for b in p.get_text("dict")["blocks"]:
            if b["type"]:
                continue
            for l in b["lines"]:
                for s in l["spans"]:
                    t = s["text"].strip()
                    if not t or t in HEADERS or "词汇听写版" in t:
                        continue
                    yc = (s["bbox"][1] + s["bbox"][3]) / 2
                    bi = max(0, sum(1 for y in bands if y <= yc) - 1)
                    col = "zh" if s["bbox"][0] < COLS[1] else (
                          "en" if s["bbox"][0] > COLS[4] else None)
                    if col:
                        cells.setdefault(bi, {"zh": [], "en": []})[col].append(
                            (yc, s["bbox"][0], t))
        for bi in sorted(cells):
            zh, en = join_lines(cells[bi]["zh"]), join_lines(cells[bi]["en"])
            if en and zh:
                seen[en.lower()] = zh
    doc.close()
    missing = [w for w in src_map if w not in seen]
    extra = [w for w in seen if w not in src_map]
    bad = [(w, src_map[w], seen[w]) for w in src_map
           if w in seen and norm(seen[w]) != norm(src_map[w])]
    print(f"words={len(seen)} (src {len(src_map)}) missing={len(missing)} "
          f"extra={len(extra)} mismatch={len(bad)}")
    for m in bad[:5]:
        print("  ", repr(m[0]), "|src:", repr(m[1][:50]), "|got:", repr(m[2][:50]))
    assert not missing and not extra and not bad, "验证失败"
    print("PASS")


if __name__ == "__main__":
    print(__doc__)
    print("改 parse()/几何后跑 make_pdf()，务必接 verify()。")
