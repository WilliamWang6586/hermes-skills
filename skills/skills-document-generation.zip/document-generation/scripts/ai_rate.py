# -*- coding: utf-8 -*-
"""中文稿件 AI 率实测（政论/学术场景版）。配套说明见 references/ai-rate-detection.md。

用法:
    uv run python ai_rate.py 正文.txt              # 只出指标
    uv run python ai_rate.py 报告.docx             # 直接吃 docx，自动截到"参考文献"前
    加 --verbose 打印每个 更/第一/最后/—— 的上下文，供人工判性质

判据口径与误报剔除规则写在 references/ai-rate-detection.md，改词表前先读。
"""
import re
import sys

# 政论文里会大面积误报的词已剔除（全面/充分/正是/深刻/更/首先/最后/第一…）。
# 真正有判别力的是套话整句。
CLICHE = ["综上所述", "总而言之", "由此可见", "众所周知", "毋庸置疑", "值得注意的是",
          "意义重大", "深远影响", "深刻内涵", "时代价值", "理论价值", "实践价值",
          "提供了根本遵循", "指明了前进方向", "必由之路", "根本保证", "生动体现",
          "彰显了", "充分说明", "深刻表明"]
AI_WORDS = ["赋能", "闭环", "抓手", "维度", "层面", "不可或缺", "至关重要", "一言以蔽之"]
ORAL = ["其实", "换句话说", "原先", "没注意", "忘了", "说个", "我觉得", "想明白", "预想", "直觉"]
HEDGE = ["大致", "可能", "也许", "材料有限", "还需要再读", "不好回答", "没想明白"]
CONNECTORS = ["更", "第一", "第二", "第三", "最后", "——"]


def load(path):
    if path.lower().endswith(".docx"):
        import docx
        text = "\n".join(p.text for p in docx.Document(path).paragraphs)
        text = text.split("参考文献")[0]
    else:
        text = open(path, encoding="utf-8").read()
    return re.sub(r"\s+", "", text)


def analyze(body):
    sents = [s for s in re.split(r"[。！？；]", body) if len(s) >= 2]
    lens = [len(s) for s in sents]
    n = len(body)
    avg = sum(lens) / max(len(lens), 1)
    sd = (sum((x - avg) ** 2 for x in lens) / max(len(lens), 1)) ** 0.5

    cliche = {w: body.count(w) for w in CLICHE if body.count(w)}
    ai = {w: body.count(w) for w in AI_WORDS if body.count(w)}
    ai_total = sum(ai.values())
    density = ai_total / max(n, 1) * 1000
    wo = body.count("我")
    wo_rate = wo / max(n, 1) * 1000
    oral = {w: body.count(w) for w in ORAL if body.count(w)}
    hedge = {w: body.count(w) for w in HEDGE if body.count(w)}

    score = 0
    score += 20 if density <= 2 else (10 if density <= 5 else 0)
    score += 25 if not cliche else (10 if len(cliche) <= 2 else 0)
    score += 25 if sd > 12 else (15 if sd > 8 else 5)
    score += 15 if wo_rate > 4 else (8 if wo else 0)
    score += 10 if sum(oral.values()) >= 5 else (5 if sum(oral.values()) >= 2 else 0)
    score += 5 if sum(hedge.values()) >= 3 else 0

    return dict(n=n, sents=len(sents), avg=avg, sd=sd, min=min(lens, default=0),
                max=max(lens, default=0), cliche=cliche, ai=ai, density=density,
                wo=wo, wo_rate=wo_rate, oral=oral, hedge=hedge, score=score)


def main(argv):
    verbose = "--verbose" in argv
    args = [a for a in argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        return 2
    body = load(args[0])
    r = analyze(body)

    print(f"字数 {r['n']} / 句数 {r['sents']} / 平均句长 {r['avg']:.1f} / 句长标准差 {r['sd']:.1f}"
          f"（{r['min']}~{r['max']} 字）")
    print(f"套话整句 {r['cliche'] or '0 处'}   ← 判别力最强")
    print(f"AI 词 {r['ai'] or '无'} → {r['density']:.2f}‰")
    print(f"'我' {r['wo']} 次（{r['wo_rate']:.1f}‰）/ 口语自指 {sum(r['oral'].values())} 处"
          f" / 承认局限 {sum(r['hedge'].values())} 处")
    print(f"\n真人度 {r['score']}/100 → 推算 AI 率 ≈ {100 - r['score']}%（规则法估值）")

    if verbose:
        print("\n--- 需人工判性质的命中上下文 ---")
        for w in CONNECTORS:
            for m in re.finditer(re.escape(w), body):
                print(f"[{w}] …{body[max(0, m.start()-14):m.end()+12]}…")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
