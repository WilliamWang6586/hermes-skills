"""
批量提取文件夹内 PDF/DOCX/DOC 文本内容。
用法: python extract_all.py <源目录> [输出目录]
默认输出到 <源目录>/_extracted/
"""
import os, sys

def extract_pdf(filepath):
    try:
        import fitz
        doc = fitz.open(filepath)
        text = "\n".join([f"--- 第{page.number+1}页 ---\n{page.get_text()}" for page in doc])
        doc.close()
        return text
    except ImportError:
        print("  SKIP: pymupdf not installed (pip install pymupdf)")
        return ""

def extract_docx(filepath):
    try:
        from docx import Document
        doc = Document(filepath)
        return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
    except ImportError:
        print("  SKIP: python-docx not installed (pip install python-docx)")
        return ""

def extract_doc(filepath):
    try:
        import olefile
        ole = olefile.OleFileIO(filepath)
        stream = ole.openstream('WordDocument')
        data = stream.read()
        ole.close()
        # 提取可读文本（跳过二进制头部）
        text = data.decode('utf-8', errors='ignore')
        # 简单过滤：保留可打印字符较多的行
        lines = []
        for line in text.split('\n'):
            printable = sum(1 for c in line if c.isprintable() or c in '\t\r')
            if printable > len(line) * 0.3 and len(line.strip()) > 1:
                lines.append(line)
        return "\n".join(lines)
    except ImportError:
        print("  SKIP: olefile not installed (pip install olefile)")
        return ""
    except Exception as e:
        print(f"  DOC extraction failed: {e}")
        return ""

def safe_name(dirpath, filename):
    """用目录名_文件名避免重名"""
    rel = os.path.relpath(dirpath, source_dir).replace(os.sep, '_')
    if rel == '.':
        return filename
    return f"{rel}_{filename}"

def main(source_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    stats = {"pdf": 0, "docx": 0, "doc": 0, "skip": 0}

    for root, dirs, files in os.walk(source_dir):
        # 跳过提取输出目录
        if '_extracted' in root:
            continue
        for fname in files:
            ext = fname.lower()
            filepath = os.path.join(root, fname)
            out_name = safe_name(root, fname)
            txt_path = os.path.join(output_dir, f"{out_name}.txt")

            try:
                if ext.endswith('.pdf'):
                    text = extract_pdf(filepath)
                    stats["pdf"] += 1
                elif ext.endswith('.docx'):
                    text = extract_docx(filepath)
                    stats["docx"] += 1
                elif ext.endswith('.doc') and not ext.endswith('.docx'):
                    text = extract_doc(filepath)
                    stats["doc"] += 1
                else:
                    stats["skip"] += 1
                    continue

                if text.strip():
                    with open(txt_path, 'w', encoding='utf-8') as f:
                        f.write(text)
                    size_kb = os.path.getsize(txt_path) // 1024
                    print(f"  OK ({size_kb} KB): {out_name}")
                else:
                    print(f"  EMPTY: {out_name}")
            except Exception as e:
                print(f"  FAIL: {fname} - {e}")

    print(f"\nDONE: {stats['pdf']} PDF + {stats['docx']} DOCX + {stats['doc']} DOC extracted, {stats['skip']} skipped")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python extract_all.py <source_dir> [output_dir]")
        sys.exit(1)
    source_dir = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(source_dir, '_extracted')
    main(source_dir, output_dir)
