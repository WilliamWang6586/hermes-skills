# PPTX → Word 图文对照讲义

实测流程（2026-09，吉林大学《人工智能》第一章 PPT：105MB / 71页 / 82图 / 16页有备注 → 21.5MB / 约62页 docx，全部校验通过）。

## 第 0 步：先探结构，别急着写转换器

```python
from pptx import Presentation
prs = Presentation(SRC)
print("slides:", len(prs.slides), "size:", prs.slide_width, prs.slide_height)

with_notes = 0
for slide in prs.slides:
    if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
        with_notes += 1
print(f"with_notes={with_notes}/{len(prs.slides)}")
```

拿到三个数就能判断形态：页数、备注覆盖率、图片量。**备注覆盖率低（本例 16/71）意味着大部分页只能给"要点列表"——要在交付时讲清楚，别让用户以为你漏了内容。**

同时 dump 每页的 `texts / notes / images(name, w, h, l, t) / tables` 到 JSON，用 `read_file` 分批读——比一轮轮打印到终端更好读，也避免终端截断/编码坑。

⚠️ 终端直接把大 JSON `print` 出来会被 `Select-Object -First N` 截断，且 Windows 终端 GBK 下中文可能崩。写 JSON 落盘再 `read_file`。

## 第 1 步：抽图 + 去重 + 过滤装饰图

```python
import hashlib, os, re

def extract_images(prs, outdir):
    paths = {}
    for idx, slide in enumerate(prs.slides, 1):
        for sh in slide.shapes:
            try:
                if sh.shape_type == 13 or sh.__class__.__name__ == 'Picture':
                    img = sh.image
                    safe = re.sub(r'[^\w\u4e00-\u9fa5]', '_', sh.name)
                    fn = f"s{idx:02d}_{safe}.{img.ext}"
                    fp = os.path.join(outdir, fn)
                    with open(fp, "wb") as f:
                        f.write(img.blob)       # 直接写 blob，不要走 sh.image.filename
                    paths[(idx, sh.name)] = (fp, sh.width, sh.height)
            except Exception:
                pass    # 部分 shape 的 image 会抛异常，跳过
    return paths
```

**按 blob 的 md5 去重**——PPT 里页眉 logo / 页脚横幅每页都出现，不去重体积会翻几倍（本例 80 → 69 张）。

**装饰图过滤**（本例剔掉 12 张）：
```python
def is_decor(w, h):                       # w/h 单位 EMU
    wi, hi = w / 914400, h / 914400       # EMU → 英寸
    if wi > 12 and hi > 3: return True    # 页脚大横幅
    if wi < 1.0 and hi < 1.0: return True # 小图标
    return False
```

去重后的原图**保留在磁盘目录**（`课程讲义/_img/`），交付时提一句"原图都在，随时可取"。

## 第 2 步：建 docx

中文排版要点（**必须设 eastAsia，否则中文掉回宋体**）：
```python
from docx.oxml.ns import qn
st = doc.styles['Normal']
st.font.name = '微软雅黑'
st.font.size = Pt(10.5)
st._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
st.paragraph_format.line_spacing = 1.3
```
| 元素 | 字号 | 颜色 |
|---|---|---|
| 章节大标题 | 18pt 加粗 | 1A56DB 深蓝 |
| 页标题 `[PPT n] xxx` | 13pt 加粗 | 1A56DB |
| 正文要点 | 10.5pt | 默认 |
| 讲稿 `【讲稿】`标签 | 10.5pt 加粗 | C05000 橙棕 |
| 讲稿正文 | 10.5pt | 333 |

**页标题加 `keep_with_next = True`**，避免标题落单在页底。

**图片缩放**：
```python
MAXW = 6.4   # A4 去掉左右边距后的可用宽度(英寸)
scale = min(MAXW / wi, 4.2 / hi, 1.0)   # 同时限宽和限高，不放大原图
```

**备注讲稿分段**：`notes.split("\n")` 逐行成一个段落 —— 讲稿原文靠换行分段，整块塞进一个段落会成一坨。空行过滤掉。

**文本去重**：同一句可能因占位符重复出现，按 `seen_t` 集合去重。

**跳过空白页**：`not texts and not notes and not real_imgs` → continue。

**章节大标题**：按页号映射（`{1: "一、…", 5: "二、…"}`），插入前 `add_page_break()`。

## 第 3 步：验证（必做，别省）

**解包验图片真的进包了**：
```python
import zipfile
z = zipfile.ZipFile(DOCX)
media = [n for n in z.namelist() if n.startswith('word/media/')]
print(len(media), sum(z.getinfo(n).file_size for n in media) / 1024 / 1024, "MB")
```

**再核这些指标**：
```python
from docx import Document
d = Document(DOCX)
len(d.inline_shapes)          # 内嵌图数, 应 >= 去重后图片数
len(d.tables)                 # 表格数, 要与源 PPT 的 has_table 数量一致
full = "\n".join(p.text for p in d.paragraphs)
# ⚠️ 表格文本必须单独拼进来 —— 见 SKILL.md Pitfall #5
full += "\n" + "\n".join(c.text for tb in d.tables for r in tb.rows for c in r.cells)
```
再抽查：页标记数量（`re.findall(r'\[PPT (\d+)\]', full)`）、讲稿段数（`full.count("【讲稿】")` 应等于源 PPT 有备注的页数）、章节标题、若干内容关键词。

**校验脚本报"缺失"时的排查顺序**：① 校验器覆盖面（表格？页眉页脚？文本框？）② 分段/换行差异 ③ 才是产物本身。本例 `708/750` 就在表格里，是校验器盲区。

## 交付话术模板

给一张「章节 → PPT 页码范围」的对应表，再给一张「校验项 → 结果」的实测表（不要只说"生成成功"）。最后单独列**未做项**（未生成PDF / 图片去重剔了什么 / 无备注页没有编写内容），并说明按需可补。
