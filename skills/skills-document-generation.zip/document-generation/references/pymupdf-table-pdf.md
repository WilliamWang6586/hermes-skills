# 用 PyMuPDF 复刻/生成表格类 PDF（听写表、词表、答题卡、登记表）

场景：用户丢来一份现成的表格 PDF 说「按这个格式，把 XX 内容填进去，做成 XX 版」。
典型：高考词汇听写表 → 四六级词汇听写表；模板答题卡 → 新版答题卡。

**核心思路：不要重新设计版式，从源 PDF 里把几何量抠出来照抄。**
用户认的就是那个观感，重画必翻车。

## 第 0 步：环境（本机实测）

- `pymupdf` 在 **Windows 侧 python3.14 已装**；WSL 的 python3.12 默认没有，
  装法（PEP668 要 `--break-system-packages`）：
  ```bash
  wsl -d Ubuntu-24.04 -- bash -lc "python3 -m pip install --user --break-system-packages \
      pymupdf -i https://mirrors.aliyun.com/pypi/simple"
  ```
  ⚠️ `pypi.tuna` 对 pip 返 403（症状极误导："no matching distribution"），换 aliyun 镜像。
- **WSL 路线更适合本任务**，原因：`/mnt/c/Windows/Fonts/simsun.ttc` 可直接引用，
  且 WSL 下 Python 脚本无 PowerShell 引号撕裂问题（见下）。
- WSL 里中文路径 OK，但脚本一律用 `write_file` 落盘再 `python3 xxx.py` 执行，
  **绝不用 `python3 -c "..."`** —— PowerShell 5.1 会把内联 Python 的引号/括号撕碎
  （`“,”后面缺少表达式` 之类的一堆语法假错）。这是本机反复踩的坑。

## 第 1 步：把源 PDF 的几何量抠出来

`find_tables()` 一把梭，比手写行聚类可靠得多：

```python
import pymupdf
doc = pymupdf.open(SRC)
t = doc[1].find_tables().tables[0]
print(t.bbox)                       # (38.64, 33.48, 549.48, 819.84) ← 表格外框
print(t.row_count, t.col_count)     # 51, 5
for r in t.extract():
    print([re.sub(r"\s+", " ", (c or "").replace("\n", "")).strip() for c in r])
```

再取列边界和行高（**画出来的线是 0.7pt 描边矩形，不是零面积线**，
宽高过滤阈值要放宽，否则 `xs/ys` 抓不到）：

```python
p = doc[1]
xs, ys = set(), set()
for d in p.get_drawings():
    r = d["rect"]
    if r.height < 1.5 and r.width > 50: ys.add(round(r.y0, 1))   # 横线
    if r.width  < 1.5 and r.height > 10: xs.add(round(r.x0, 1))   # 竖线
# -> xs: [174.1, 267.8, 361.6, 455.3]  列宽 93.7 均匀
# -> 行高 = 相邻 ys 差 = 14.63pt
```

本会话挖到的参考几何（A4 585.3×841.9pt 表，可直接照抄）：
```
X0, X1 = 38.64, 549.48
COLS   = [38.64, 174.6, 267.8, 361.6, 455.3, 549.48]
HDR_TOP, HDR_BOT = 33.48, 49.08
SINGLE_ROW = 14.63        # 行高
FS_ZH = FS_EN = 9.5       # 正文字号（这是 14.63pt 行能容纳的上限）
FS_HDR = 10.5
FONT = "/mnt/c/Windows/Fonts/simsun.ttc"   # fontname="china-s" 配 fontfile
```

## 第 2 步：写内容 —— 用 insert_text，不要用 insert_textbox

### 🔴 头号坑：insert_textbox 会静默丢文字

`insert_textbox(rect, text, fontsize=9.5)` 在 14.63pt 行里**返回负数**
（= 文字放不进度量框），**然后什么都不画、不抛异常、不打印警告**。
产物 PDF 有完整的表格线，但**一个字的文字层都没有**，
`page.get_text()` 返回 `''`。最毒的地方是它看起来"生成成功了"。

实测返回值对照（14.63pt 行高）：
```
fontsize=8   -> +2.04   写入
fontsize=9   -> +0.46   写入
fontsize=9.5 -> -0.33   ❌ 丢弃
fontsize=10  -> -1.11   ❌ 丢弃
fontsize=11  -> -2.69   ❌ 丢弃
```
> 判断法：**`rc < 0` 就是没写进去**。`insert_textbox` 的返回值必须判，不能忽略。

**正解：`insert_text()` + 显式基线**，它按绝对坐标落字，没有"放不下"这个失败模式：

```python
def put(page, x, ytop, ybot, text, avail, size=FS_ZH, leading=11.6, pad=2.0):
    """从格子顶部往下铺换行后的行，逐行给显式基线。"""
    lines = wrap(text, avail, size)          # 见第 3 步
    base = ytop + pad + size                 # 第一行基线
    for ln in lines:
        if base > ybot: break
        page.insert_text((x, base), ln, fontsize=size,
                         fontname="china-s", fontfile=FONT)
        base += leading
```

### 强制门：交付前必须重开文件断言文字层存在

因为上面那个坑会静默通过，渲染函数末尾必须自证：

```python
chk = pymupdf.open(outfile)
body = chk[1].get_text()
assert "汉语" in body and CJK.search(body), f"{outfile}: 文字层缺失（检查写入方式）"
chk.close()
```
> 这是**唯一**能抓住空白 PDF 的东西。没这个 assert 就会交出 89 页空白表。

## 第 3 步：中文换行必须量宽度，不能用字符数估

`pymupdf.Font(fontfile=...).text_length(s, fontsize=)` 给真实宽度。
贪心换行，**CJK 可任意断，ASCII 单词整体不拆**：

```python
_font = pymupdf.Font(fontfile=FONT)
def text_w(s, size): return _font.text_length(s, fontsize=size)

def wrap(text, avail, size=FS_ZH):
    lines, cur = [], ""
    for tok in re.findall(r"[A-Za-z0-9@\.\'\-]+|\s+|.", text):
        if tok.isspace() and not cur: continue
        if text_w(cur + tok, size) <= avail or not cur: cur += tok
        else: lines.append(cur.rstrip()); cur = "" if tok.isspace() else tok
    if cur.strip(): lines.append(cur.rstrip())
    return lines or [""]
```
> 粗估法 `CJK=1.0em / ASCII=0.5em` 只够用来**先做可行性判断**（要不要换行、
> 有多少词超长），真正排版还是用 `text_length`。

## 第 3.5 步：字体混排 —— 英文必须换比例字体，音标必须留宋体

### 🔴 SimSun 是等宽 CJK 字体，英文会\"字距发虚\"

用户报\"每行内字之间间距不一样\"。根因实测（`Font.text_length` 逐字符量）：

```
'a'=5.000  'b'=5.000  'i'=5.000  'm'=5.000  'W'=5.000  '1'=5.000
'（'=10.000 '，'=10.000 '；'=10.000 '的'=10.000
```

**每个 ASCII 字符恰好 = 0.5em，不论字形宽窄**（SimSun 是 CJK 等宽字体，
ASCII 走半宽格子）。所以 `abandon` 看着像逐字撑开，而中日韩混排更难看。

**正解：按 run 切分，ASCII 走比例字体、CJK 走宋体。**

```python
CJK_FONT = "/mnt/c/Windows/Fonts/simsun.ttc"
LAT_FONT = "/mnt/c/Windows/Fonts/times.ttf"     # 本机有此文件

cjk = pymupdf.Font(fontfile=CJK_FONT)
lat = pymupdf.Font(fontfile=LAT_FONT)

def char_w(ch, size, is_lat): return (lat if is_lat else cjk).text_length(ch, fontsize=size)

def runs(text):
    """切 (is_latin, chunk)。IPA 不能算 latin —— 见下。"""
    out, cur, cur_lat = [], "", None
    for ch in text:
        o = ord(ch)
        is_lat = o < 0x2E80 and not (0x0250 <= o <= 0x02FF) and ch not in "ˈˌː"
        if cur_lat is None or is_lat == cur_lat: cur += ch
        else: out.append((cur_lat, cur)); cur = ch
        cur_lat = is_lat
    if cur: out.append((cur_lat, cur))
    return out
```

落字时逐 run 换字体，`cx` 手工累加宽度：

```python
for is_lat, chunk in runs(ln):
    page.insert_text((cx, base), chunk, fontsize=size,
                     fontname="tiro" if is_lat else "china-s",
                     fontfile=LAT_FONT if is_lat else CJK_FONT)
    cx += text_w(chunk, size)
```
> `text_w` 也要走 `runs()` 按字符分别量，不能整串用宋体量。

### 🔴 音标/IPA 必须留在宋体上，否则变一排点

Times-Roman **没有 IPA 字形**。二级实测：把 `[əˈbjuːs]` 交给 Times 后
渲染成 `[bjus]`、甚至 `[··bju·s]`（点占位）。所以 `runs()` 里
**IPA 区段（U+0250–U+02FF）和重音符 `ˈˌː` 必须判为 CJK 侧**，
它们走宋体才有字形。上面对 `is_lat` 的判断已含这一条。

### 验证混排是否真的生效（别信辅助视觉模型的判断）

辅助视觉模型**在这件事上不可靠** —— 本会话它两次断言英文列\"是等宽字体\"，
但硬数据反驳：字体声明 `Times-Roman`、`ability`=24.28pt vs `abandon`=32.19pt、
每字符宽度 3.85–4.81 波动。**用数值判，不要用眼看缩略图**：

```python
for s in spans_in_word_column:
    print(s["font"], s["text"], s["bbox"][2]-s["bbox"][0])
# 判据：font == 'Times-Roman' 且 不同词的 per_char 不等 → 比例排版成立
```

## 第 3.6 步：词性标签（adj/adv）—— 两套体系必须归一化

用户明确要求\"adj 和 adv 之类的一定要区分好\"。**这是真问题，源数据有两套写法：**

| 概念 | 四级词表 | 六级词表 |
|---|---|---|
| 形容词 | `a.` | `adj.` |
| 副词 | `ad.` | `adv.` |

`a.` 与 `ad.` 视觉上几乎一样（一个字母之差），在听写表里极易混淆。
**统一归一化成全称 `adj.` / `adv.`**，物理上不可能再混：

```python
POS = [(r"^adj\.?", "adj."), (r"^adv\.?", "adv."), (r"^a\.", "adj."), (r"^ad\.", "adv."),
       (r"^vt\.", "vt."), (r"^vi\.", "vi."), (r"^v\.", "v."), (r"^n\.", "n."),
       (r"^prep\.", "prep."), (r"^conj\.", "conj."), (r"^pron\.", "pron."),
       (r"^num\.", "num."), (r"^art\.", "art."), (r"^int\.", "int."), (r"^aux\.?", "aux.")]
```
> 顺序有讲究：`^adv\.` 必须排在 `^ad\.` 前面，否则 `adv.` 被 `ad` 吃掉。

### 源数据在词性前面还塞了一堆噪音，必须剥掉

实测六级有 **64 条**（占 3%）词性标签被这些前缀挡住而识别不到：

```
'1 [buːm] v. ...'          ← 义项序号 + 音标
'ˈplætəʊ n. 高原'           ← 行首音标（无斜杠）
'plateau / ˈplætəʊ n. ...'  ← 斜杠 + 音标
'(pl analyses) n. ...'      ← 复数标注
'pl analyses) n. ...'       ← 复数的 "(" 被行拆分吃掉
'drɑːft /n. ...'            ← 无重音音标 + 斜杠
'adj·傲慢无礼的'             ← 间隔号错字（应为 adj.）
```

剥离**顺序是关键**（这里踩过坑）：

```python
def norm_pos(m):
    m = re.sub(r"^[\s\d\[\]\(\)\.]*", "", m)          # 序号/括号
    m = re.sub(r"^\[[^\]]*\]\s*", "", m)              # 完整音标块
    m = re.sub(r"^[^\s\]]*\]\s*", "", m)              # 音标尾巴 "keɪp]"
    m = re.sub(r"^\(pl[^)]*\)\s*", "", m)
    m = re.sub(r"^（pl[^)]*\)\s*", "", m)
    m = re.sub(r"^pl\s+[^)]*\)\s*", "", m)            # "(pl" 丢了括号
    m = re.sub(r"^\s*/\s*", "", m)                    # ⚠️ 斜杠必须在音标之前剥
    m = re.sub(r"^[ˈˌ\u0250-\u02FF][^\s]*\s*", "", m)  # 行首 IPA
    m = re.sub(r"^[^\s/]{2,}\s*/\s*(?=(?:adj|adv|n|v|vt|vi|prep|conj|pron|num|art|int|aux)\.)", "", m)
    m = re.sub(r"^adj·", "adj.", m)
    for pat, full in POS:
        if re.match(pat, m): return re.sub(pat, full, m, count=1)
    return m.strip()
```

**🔴 踩实了的坑**：`plateau / ˈplætəʊ n. 高原` 里，若**先剥音标再剥斜杠**，
行首的 `/` 会挡住 IPA 规则，结果 `n.` 前面永远残留音标（本会话最后 2 条 mismatch 就是它）。
**斜杠必须先剥。**

另一条：`^[^\s/]*\s*/\s*` 这种宽泛的斜杠规则会**吃掉四级释义里正常出现的 `/`**
（如 `n./ v.有利，利益/……`），实测让四级无标签数从 10 飙到 59。
**斜杠规则必须带前瞻锁定后面是词性标签**（上面那条 `(?=(?:adj|adv|...)\.)`）。

## 第 4 步：行高 —— 能不能套用原版式，先量再说

**这是本类任务最容易翻车的设计决策。别假设，用脚本量分布：**

```python
counts = {}
for w, m in entries:
    counts[len(wrap(m, avail))] = counts.get(len(wrap(m, avail)), 0) + 1
print(sorted(counts.items()))     # {1: 4539} vs {1: 831, 2: 857, 3: 359, ...}
```

本会话实测（词义列净宽 132pt ≈ 13~14 个汉字）：

| 词表 | 释义单行占比 | 结论 |
|---|---|---|
| 四级大纲 | **100%**（最长 100pt） | ✅ 原封不动套 14.63pt 行高 |
| 六级大纲 | **37%**（最长 161 字符 ≈ 9 行） | ❌ 单行物理上放不下 |

- **全部单行 → 直接照抄模板几何**（四级就这么干的，89 页，零改动）。
- **有超长 → 给行高自适应**：`row_h = max(释义行数, 词头行数, 1) * leading + 3`。
  列/字体/观感全不变，只是释义长的行变高。分页也改成按真实行高累加，
  并**避免字母分隔行被孤立在页脚**。
- ❌ **不要为了迁就行高去截断释义** —— 实测六级砍掉例句和括号标注后
  仍有 61% 超长，砍到能塞进去就等于删内容。宁可行高不均。
- ❌ **也不要给行高设上限**（如 `min(n, 4)`）。本会话一度设了 4 行上限，
  结果**静默吃掉 38 条**（1.71%，`temper`/`classic`/`force` 这些）的释义尾巴——
  产物看着完好，只有逐条比对才发现。
  **实测：放开上限只多 1 页**（73→74 页），因为超长条目本来就只有 38 条。
  > 教训：`min()` 这类\"保护性\"上限在渲染路径上就是**静默截断**。
  > 要么不设，要么设了就必须用「逐条回读比对」把损失量出来。
- ⚠️ **全局统一行高可能爆炸**：六级按最长条目（8 行）统一的话，
  2219 条全撑成 8 行 = **322 页**（vs 自适应 74 页）。
  所以\"统一\"只在**全部条目本就单行**时才可行（四级 100% 单行 → 91 页，照抄原版式）。
  别为了\"整齐\"牺牲 4 倍页数。
- 分岔时**把选择摆给用户**（整齐 vs 完整），别自己默认。

## 第 5 步：下载权威词表（中国大陆网络）

北京/校园网直连 GitHub raw 会超时，VPN 未开时也别急着挂。**可用的镜像**：

```
https://ghproxy.net/https://raw.githubusercontent.com/<user>/<repo>/master/<file>.txt   ✅ 实测通
https://cdn.jsdelivr.net/gh/...      ❌ 基础连接已关闭
https://raw.gitmirror.com/...        ❌ 未能解析此远程名称
https://gitee.com/api/v5/repos/...   ❌ 404（该仓库没镜像）
```
### 🔴 第 5.1 步（必做）：先确认这份词表是「全表」还是「增量表」

**本会话最大的事故**（用户当场抓出）：六级成品只有 2219 词、页数还比四级少，
而六级本应**多于**四级。根因 —— 直接把 `CET6_edited.txt` 当成「六级大纲全表」，
它其实只是**六级相对四级的净增部分**。

**证据（README 原文）**：

> 2）大学英语四、六级词汇表（**CET4+6_edited**）整理自《全国大学英语四、六级考试大纲》2016年版

仓库里那份带 `CET4+6` 的才是合并全表。实测三者关系：

| 文件 | 词数 | 真实含义 |
|---|---|---|
| `CET4_edited.txt` | 4615 | 四级大纲（有表头、有 `A`~`Z` 分隔行） |
| `CET6_edited.txt` | 2273 | ⚠️ **六级净增**（无表头、无分隔行 —— 就是信号） |
| `CET_4+6_edited.txt` | 8013 | ✅ 四六级合并全表（**只有裸单词，无释义**） |
| `六级词汇表.xlsx` | 2220 | 同样是净增表 |

`len(CET4 ∪ 净增) = 5800`（净增里 1041 词本就在四级内）→ 这才对得上官方
「六级约 5500–6000 词 / 四级约 4500 词」的口径。

**识别增量表的信号（任一命中就要警惕）**：
1. **没有表头行**（没有 `大学英语X级大纲单词表` / `(共 N 词)`）——全表一定有。
2. **没有 `A`~`Z` 字母分隔行**。
3. **词数明显偏小**，与官方口径（四级 ~4500、六级 ~5500–6000）不符。
4. **首词不是 `a`**（本会话净增表首词是 `abandon`；全表必然以 `a`/`an` 开头）。

**规则：拿到词表先做三件事，再写一行生成代码。**
```python
# ① 打印头 4 行 —— 有没有表头一目了然
print([l[:60] for l in io.open(path, encoding="utf-8-sig").readlines()[:4]])
# ② 数词条 + 数字母分隔行
# ③ 和官方规模对表：四级 ~4500 / 六级 ~5500-6000
```

**更重要的通用教训：先验证输入源的「范围（scope）」，再验证产物的「正确性」。**
本会话把全部精力花在渲染细节（字体、行高、校验回读）上，逐条比对全部 PASS ——
但**比对的是错的范围**：4539/4539 全中，因为源本身就只有那么多词。
**校验再严密，也救不了范围错误的输入。**
用户是用**常识**（六级不该比四级少）发现的，不是靠我的校验器。
→ 产物出现「反直觉的规模」（高等级词表反而更小、页数更少）时**立刻停下来查源**，
别急着解释。

### 已知词表的正确用法

```bash
B=https://ghproxy.net/https://raw.githubusercontent.com/mahavivo/english-wordlists/master
curl -sSL "$B/CET4_edited.txt"       -o cet4.txt    # 四级全表（含释义）
curl -sSL "$B/CET6_edited.txt"       -o c6delta.txt # ⚠️ 只是净增，别当全表
curl -sSL "$B/CET_4%2B6_edited.txt"  -o combined.txt# 合并全表 8013（裸词）
```

- **做四级** → 直接用 `CET4_edited.txt`。
- **做六级（要含四级基础）** → `CET4_edited.txt` ∪ `CET6_edited.txt`（净增优先，
  因六级释义更详尽）= 5800 词。
- **要一份不漏的全集** → 用 `combined.txt`(8013) 当**骨架**（它含 `abbreviation`/
  `accessible`/`zoology` 这些两个 edited 文件都缺的词），再从
  `COCA_with_translation.txt`（2.5MB，全词带中文）或 `六级词汇表.xlsx` 补释义。
- **⚠️ 交付前必须把选择摆给用户**：5800（六级专用，对齐官方口径）vs
  8013（四六级合并全集）。别默认。
- 仓库树可用 GitHub API 直连列（ghproxy 不代理 API）：
  `curl -sSL "https://api.github.com/repos/<u>/<r>/git/trees/master?recursive=1"`

下载后**必须核对条目数**，别信"下载成功"。

## 第 6 步：解析词表行的正则 —— 非贪婪是陷阱

词表行格式：`abandon [əˈbændən] vt.丢弃；放弃，抛弃`

❌ 错：`r"^([A-Za-z][A-Za-z'\-\. ]*?)..."` —— `*?` 非贪婪只吃 **1 个字符**，
于是 `abandon` 被切成词头 `a` + 正文 `bandon [əˈbændən] ...`。
症状：**只解析出 25 条（全是字母分隔行 A~Z）**。

✅ 对：词头用贪婪字符类，再靠**前瞻**收尾：
```python
ENTRY = re.compile(r"^([A-Za-z][A-Za-z'\-\.]*(?:\s*\([^)]*\))?)(?=\s|\[)\s*(?:\[[^\]]*\]\s*)?(.*)$")
```
`(?=\s|\[)` 挡住 `ˈclock [əˈklɔk] ad.…点钟` 这种**行首带音标**的行
（否则词头空匹配，产生幻影词条 `o`）。

其他解析要点：
- 音标块必须剥掉，否则漏进释义（`m.startswith("[")` 自检）。
- 源数据有脏字符：私用区字形 `\uf000-\uf8ff`（OCR 残留）→ `re.sub` 清掉。
- 字母分隔行（`len(line)<=2 and line.isalpha()`）跳过，**自己按词头首字母重新生成**
  （六级源文件里根本没有分隔行）。
- 每条都要 `assert CJK.search(meaning)`，否则会把噪音行当词条。

## 第 7 步：验证 = 从产物回读，和源头逐条比对

不要只数行数。**回读文字层 → 按 x 列分左右 → 按 y 邻近配对 → 和源 dict 比**：

```python
# 按列分：左列（释义）x < COLS[1]；右列（词头）x > COLS[4]
# 配对：每个右列 span 锚定一个词，吸收从本行顶到下一个词行顶之间的左列 span
#       （多行释义会产生多个左列 span，按 y 排序拼回来）
# 判据：missing=0 and extra=0 and mismatch=0，否则 FAIL
```

配套坑：
- ⚠️ **别用 `find_tables()` 做验证** —— 全 90 页跑要 >180s 超时。用上面的
  span 定位法，快得多。
- ⚠️ **别再依赖画出来的表格线去划分行**（0.7pt 描边矩形过不了朴素宽度过滤，
  实测抓到 0 条线）。按 y 坐标邻近配对比按线划分稳。
- ⚠️ **混排后一行会产生多个 span**（Times 一个、宋体一个），
  配对时必须**先按 y 聚成视觉行、行内再按 x 排序**，否则出现
  `'1.女等船只…抛弃，放弃)'` 这种乱序。只按 x 排会把不同视觉行交错：
  ```python
  def join_lines(items):        # items = [(y, x, text)]
      lines = []
      for y, x, t in sorted(items):
          if lines and abs(lines[-1][0] - y) < 1.2: lines[-1][1].append((x, t))
          else: lines.append([y, [(x, t)]])
      return "".join("".join(t for _, t in sorted(ts)) for _, ts in lines)
  ```
- ⚠️ **行带划分：固定 `yc±9` 会跨行串味**（长行高表里 `钝` 从上一行漏进 `blur`）。
  正解是用**画出来的行框 y 值**当分界：取 `width>100` 的 drawing 的 `y0` 去重排序，
  再按 y 中心落带。行高不再是固定值时尤其必须这样。
- ⚠️ **SimSun 有一批字形 `get_text()` 读不回来**，会产生成片假 mismatch。
  实测（归一化里必须一起去掉）：
  ```
  …(U+2026) → ⋯(U+22EF)      U+2019 → ·        ①-⑩ 圈码 → ·
  IPA 整段读不出（如 [əˈbjuːs] → [bjus]）
  跨字体 run 边界的空格丢失
  ```
  ```python
  def norm(s):
      s = re.sub(r"[\s…⋯·’'①②③④⑤⑥⑦⑧⑨⑩]", "", s)
      s = re.sub(r"\[[^\]]*\]", "", s)       # 音标整块丢弃再比
      return s.strip()
  ```
  > 这些是**提取侧的损失，不是产物缺陷**。先用字体探针证明字形在
  > PDF 里，再把这些等价类加进 norm —— 别为了「让校验变绿」去改产物。
- 校验器报「缺失」时**先怀疑校验器**：本会话多次 FAIL 全是校验逻辑的锅
  （行聚类错位、行带检测失效、span 顺序、未归一化字形），产物其实是对的。

## 第 8 步：去重 —— 同形异义词必须保留多个义项

**本会话第二个静默数据损失**（和 Pitfall #8 的 `insert_textbox`、#11 的行高上限同一性质）。

初版解析器按词形去重：

```python
if word.lower() in seen: continue      # ❌ 吞掉同形异义词的第二个义项
```

后果：**四级 72 个词少了一个义项**，成品 4539 词，而源表头明写 `(共 4615 词)`。

被吞掉的例子（这些都该出现两行）：

| 词 | 义项 1 | 义项 2 |
|---|---|---|
| bear | `n.熊；粗鲁的人` | `vt.容忍；负担；生育` |
| box | `n.箱，盒；包箱` | `vi.拳击，打拳` |
| can | `aux.v.能，会，可能` | `n.罐头，听头；容器` |
| light | `n.光，光线；灯，光源` | `adj.轻的，少量的` |
| March/march | `n.三月` | `vi.行军；游行示威` |
| fair | `adj.公平的；相当的` | `n.定期集市；博览会` |

**正解：去重键 = `(word, meaning)`；排序让同一词的多个义项相邻。**

```python
seen = set()
...
k = (word.lower(), meaning)
if k in seen: continue
seen.add(k)
out.append((word, norm_pos(meaning)))
# 排序键带词形做次级排序，保证同词的义项排在一起
out.sort(key=lambda x: (re.sub(r"[^a-z]", "", x[0].lower()), x[0]))
```

修复后四级 **4539 → 4614 词**（源表头 4615，仅差 1 条解析失败的行）。

> **通用教训：源文件里声明的规模就是免费的校验基准。**
> 表头写 `(共 4615 词)` 你只解析出 4539 —— 差的 76 条不是"正常损耗"，
> 是 bug。**永远拿源声明的数字去对表**，别只看"有没有报错"。

## 第 9 步：多源回退补释义（合并全表必然缺释义）

`CET_4+6_edited.txt`（8013）**只有裸单词**，而大纲文件只覆盖 5715 词 ——
剩下 2600+ 派生词（`abbreviation`/`accessible`/`zoology`/`zoom`）**没有任何释义**。

按优先级回退，`key()` 归一化（去重音 + 小写 + 只留 a-z）：

```python
for name in ("CET6", "CET4", "OALD8", "TOEFL", "ECDICT", "COCA"):
    for cand in candidates(w):
        if cand in srcs[name]: mean, src = srcs[name][cand], name; break
    if mean: break
```

实测各源贡献（8012 词成品）：

| 源 | 覆盖 | 说明 |
|---|---|---|
| CET4/CET6 大纲 | 3241 + 2171 | 首选，释义最贴合考试 |
| **ECDICT `translation`** | 1954 | **补派生词的主力**，覆盖面最广 |
| TOEFL | 644 | 次级回退 |
| OALD8 | 1 | ⚠️ 见下 |

**🔴 OALD8 补不了四六级缺词**：该文件是"**删除了四六级词汇之后**"的剩余词典，
你要补的词恰好被它删掉了 —— 逻辑上注定补不上（实测只贡献 1 条）。别在这上面耗时间。

**ECDICT 的定位要搞清**：
- ✅ 当**释义源**极好（74 万条，`translation` 列带中文）。
- ❌ **不能当词表骨架**：它的 `tag` 列标记**不完整**（`cet4` 只标 3849，
  而大纲是 4615；`cet6` 标 5407）。实测 `cet4|cet6` = 5805，**只能用来交叉验证范围**
  （和官方「六级 5500–6000」吻合，是个有用的 sanity check）。
- 下载 66MB，**必须断点续传**：
  ```bash
  curl -sSL -C - --max-time 300 -o ec.csv \
    "https://ghproxy.net/https://raw.githubusercontent.com/skywind3000/ECDICT/master/ecdict.csv"
  # 实测一次 120s 只下到 38MB/66MB，-C - 续传后 206 完成
  ```

### 剩余的钉子户：重音字母 + 源表错拼

补完还剩 3~7 条匹配不上，两类：

1. **带重音的外来词**：`cliché` / `coup d'état` / `résumé` —— ECDICT 按无重音拼写存。
   解：`unicodedata.normalize("NFKD")` 去掉 combining 字符再匹配。
2. **源表自带的错拼**：`celcius`(→celsius)、`honourary`(→honorary)、
   `instalation`(→installation)、`microwavable`。解：小 `ALIAS` 映射表手工兜。

```python
import unicodedata
def fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))
def key(w):
    return re.sub(r"[^a-z]", "", fold(w).lower())
```

### 英式 → 美式拼写归一

`authorise`/`armour`/`colour` 这类英式词在美式词典里查不到，加变体：
`our→or`、`ise→ize`、`isation→ization`、`yse→yze`、`re→er`。
**但对大纲文件本身禁用**（那是权威拼写，改了就错位）。

## 交付形态清单

- 封面页：标题 + 班级/姓名填空 + 词数统计。
- 页脚/页眉：`{标题}   {页码}/{总页数}`。
- 保留原模板里"要用户手填的空列"（听写一/二/三 这种），**留白就是功能**。
- 交付话术说清：词数、页数、来自哪个词表、哪些行高做了自适应。

## 相关

- 源 PDF 只是拿来当模板 → 同类任务见 `document-variant-respin`（参数化 + 残留自检）。
- 只是抽文字、不生成 → `ocr-and-documents`。
- 篇幅/版面硬约束收敛 → `manuscript-length-fitting`。
