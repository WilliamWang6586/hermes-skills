# 批量文档提取与分析

从混合格式文件夹中批量提取文本内容并建立知识库。

## 工具矩阵

| 格式 | 工具 | 安装 |
|------|------|------|
| PDF（文字型） | PyMuPDF (fitz) | `pip install pymupdf` |
| PDF（扫描版） | PyMuPDF + Tesseract | 文字型可，扫描版需 OCR |
| DOCX | python-docx | `pip install python-docx` |
| DOC（旧版） | olefile | `pip install olefile` |

## 批量提取脚本模板

见 `scripts/extract_all.py`

## .doc 文件特殊处理

旧版 .doc（Word 97-2003）无法被 python-docx 读取。两种方案：

### 方案A：olefile 提取（推荐，零安装）
- 仅提取文本流，不保留格式
- Windows/Mac/Linux 通用
- 安装：`pip install olefile`
- 限制：加密或损坏的 .doc 可能失败

### 方案B：LibreOffice 转换
- 保真度高，可转 .docx
- 需安装 LibreOffice（~500MB）
- 命令：`soffice --headless --convert-to docx input.doc`

## 输出目录结构

```
原始文件夹/
├── *.pdf, *.docx, *.doc ...（原始文件）
└── _extracted/
    ├── 子目录_文件名.pdf.txt
    ├── 子目录_文件名.docx.txt
    └── ...
```

## 注意事项

1. **纯图片 PDF**：无文字层，PyMuPDF 提取为空。需 OCR 或 vision_analyze。
2. **中文字符**：提取脚本设置 `encoding='utf-8'` 保存。
3. **大文件**：167 页 PDF 提取可能产生 360KB+ 的 txt 文件。
4. **文件重名**：用 `_` 连接子目录名和文件名避免冲突。
