# 文档变体派生（原独立技能 document-variant-respin，2026-10 并入 document-generation）

用户已拿到一套成品（报告 + 表单 + PPT），现在要**给另一个人或另一个场景再出一套**，
明确说「不要全部一样，要有改动，但大体不变」。**这不是重新做一遍** —— 重做等于把上次踩的坑再踩一遍。
正确做法：**把上次的生成脚本参数化，只替换文本层**。

## 派生还是重做？

| | 派生（本节） | 重做 |
|---|---|---|
| 版式/配色/骨架 | **完全复用**（继承主题、母版、页结构） | 重新设计 |
| 内容 | **替换文本层**，保留 70-80% 通用表达 | 全部重写 |
| 适用 | 用户说「大体不变」「要有改动」 | 用户说「重新做一版完全不同风格的」 |

判断法：用户强调的是「不一样」还是「不一样但看得出是同一套」。后者走本节；前者直接重做。

## 标准流程（4 步）

### 1. 先把上次的脚本参数化（不是新写脚本）

凡**会因为人而变**的字面量，都提到顶部一个 `P` dict：

```python
P = {
    "name":  os.environ.get("P_NAME",  "原件主人名"),
    "photo": os.environ.get("P_PHOTO", r"...\默认照片.jpg"),
    "major": os.environ.get("P_MAJOR", "交通运输"),
    "grade": os.environ.get("P_GRADE", "2026 级"),
    "title1": os.environ.get("P_T1", "原始主标题"),
    "out":   os.environ.get("P_OUT", ""),
}
OUT = P["out"] or os.path.join(BASE, f"{P['name']}_生涯发展展示.pptx")
```

用 `patch` 把硬编码的姓名/照片/标题串换成 `P[...]`。**做完原件不受影响**（env 默认值 = 原值）。
⚠️ 先用 `Select-String` 列出所有命中行号，**逐处改**，别全局盲替。

### 2. 替换表脚本：复制脚本 → 定点替换文本 → 执行

不要重抄生成逻辑。读原脚本、字符串替换、写成 `_gen_xxx_人名.py`、再跑它：

```python
src = io.open(SRC_SCRIPT, encoding="utf-8").read()
REPL = [("旧串", "新串"), ...]           # 见「排序铁律」
n = 0
for old, new in REPL:
    if old in src: src = src.replace(old, new); n += 1
    else:          print(f"⚠️ 未命中: {old[:40]}")     # ← 收敛指标，不是噪音
io.open(TMP_SCRIPT, "w", encoding="utf-8").write(src)
print(f"替换 {n}/{len(REPL)} 处")
```

第一轮通常只命中 60%，剩下 40% 就是你要补的。

### 3. 排序铁律（会咬人的 bug）

替换顺序执行，短串会污染长串：

| 反模式 | 症状 |
|---|---|
| `("车辆工程", "车辆工程（电控方向）")` 在前 | 后面再命中新串 → `车辆工程（电控方向）（电控方向）` |
| `("智能网联", "三电系统")` 写在 `("智能网联汽车", ...)` 前 | 长串永远匹配不到 |

**规则：长的在前，短的在后。** 仍冲突时用占位符二段替换（先藏成 `@@VE@@`，再放出来）。

### 4. 源文件里长串常被拆成相邻字面量 → 长串匹配不到

```python
box(s, ..., "智能网联汽车正从辅助驾驶向高阶自动驾驶演进，\n"
            "市场对同时掌握车辆底盘/电子架构与软件开发能力\n")
```

整串替换必 `未命中`（实测 24 条里漏 10 条，漏的正好是关键页）。
**修法**：改成替换**每个独立短段**。发现漏了靠自检输出反查，别靠读源码找。

## ⭐ 成品级残留自检（唯一能证明改完的东西）

把「原件主人的专属词」当黑名单扫一遍：

```python
BAD = ["原件主人名", "原件特有经历1", "原件专业", "原件城市"]

def scan_pptx(p):        # 必须递归进 group + 读表格
    pr = Presentation(p); t = []
    def w(shs):
        for s in shs:
            if s.shape_type == 6: w(s.shapes); continue          # GROUP 递归
            if s.has_text_frame: t.append(s.text_frame.text)
            if getattr(s, "has_table", False) and s.has_table:
                for r in s.table.rows:
                    for c in r.cells: t.append(c.text)
    for sl in pr.slides: w(sl.shapes)
    return "\n".join(t)

def scan_docx(p):        # 表格单元格不在 .paragraphs 里！（老坑）
    d = Document(p)
    return ("\n".join(x.text for x in d.paragraphs) + "\n" +
            "\n".join(c.text for t in d.tables for r in t.rows for c in r.cells))
```

**别只看「生成成功」就交付** —— 用户验收标准是「看不出是套模板的」。
现成脚本：`scripts/check_variant_residue.py 新件1.pptx 新件2.docx --bad 旧名 旧专业 旧经历`
（退出码 0 = 零残留，可直接当交付门禁）。

## 内容改动的分寸（「大体不变但有改动」怎么落地）

按用户感知强度排序，必改：姓名/照片/署名 → **主标题隐喻**（最显眼）→ **核心方向/主题词** →
**核心张力/起点故事** → 可量化目标 → 备选航道/兜底方案。**版式/配色/页序不动**。

### 个人信息处理

用户说「瞎编就行」「能隐去就隐去」时分开对待：
- **籍贯/专业/年级/学号/手机** → 留空或删除，别编（政审/核对会穿帮）
- **未来规划/职业目标/发展路径** → 用户明确授权时可以虚构式扩写

### 报名表勾选框：`☐` 是独立 run

`'☐成长赛道' in r.text` 永远为假 —— `☐` 与后面文字是两个独立 run。要按 run 精准替换
（`if r.text.strip() == "☐": r.text = "☑"`）。替换后自检断言：旧名不残留 / 新名已写入 / 占位符已清。

## Pitfalls

1. 替换表**长的在前**，否则短串污染长串。
2. 源码长文本是相邻字面量拼接 → 整串替换必 `未命中`，改替换独立短段。
3. PPT `☐` 是独立 run → 按整格文本判断永远为假。
4. `doc.paragraphs` 不含表格文本 → 自检必须单独拼表格单元格。
5. PPT 要递归进 group（`shape_type == 6`）。
6. 封面标题走 env 变量时，光改替换表不生效，要同时传 `env["P_T1"]`。
7. **改源头不打补丁**：派生脚本会重跑生成器时，补丁打在生成器源头，否则重跑覆盖回原样。
8. 交付附一张**改动对照表**（原件 vs 新件：主题/方向/张力/目标）。
9. **一次性跑完全部产物**（一个 `_ke_all.py` 循环调 4 个子脚本），减少 PowerShell 往返与编码坑。

## 更多踩坑实录

`references/respin-pitfalls.md`、`references/respin-pitfalls-2.md`。
