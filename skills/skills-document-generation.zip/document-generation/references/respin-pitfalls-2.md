# 定点替换的坑 · 第二轮补充（源.py 拼接 / docx 表格 / COM 转 PDF）

> 本文件是 `document-variant-respin` 第二份参考文件（`references/respin-pitfalls.md` 的补充）。
> 两个文件都读，覆盖派生第二份的全部实测坑。

## A. 替换命中的假象：源 .py 里的相邻字面量拼接

**症状**：替换表 52 条只命中 24-37 处，「未命中」的全是关键句。

**根因**：源 `.py` 里长文本常写成相邻字面量拼接：

```python
txt = ("我从小拆装机械，对「东西怎么动起来」有天然的执念。进大学前我以为交通就是修路和管车流，"
       "真正接触专业后才发现，让车自己判断、自己决策，才是这个行业正在发生的事。")
```

Python 运行时是整串，**文件里是两段**。替换键用拼接后的整串 → `in` 判定为假。

**修法**：替换键一律用**独立短段**（每段在文件中唯一即可），不要用拼接后的完整句。

## B. 词根后缀要穷举，否则残留

只写 `智能网联汽车` 而漏了 `智能网联方向` / `智能网联相关系统` → 残留。**替换表必须穷举词根的所有后缀组合**。

推荐顺序：**长 → 短**，天然消解覆盖问题：

```python
("智能网联汽车 / 汽车电子工程师", "新能源汽车电控 / 三电工程师"),  # 最长，先
("智能网联汽车", "新能源汽车三电系统"),
("智能网联方向", "三电或电控方向"),
("智能网联相关系统", "三电相关子系统"),
("智能网联", "三电系统"),                                        # 最短，最后
```

**占位符只用于「自替换循环」**，不要滥用：

```python
("车辆工程（电控方向）", "@@VE@@"),      # 先捞走已改好的
("转入车辆工程", "对准三电方向"),
("车辆工程", "车辆工程（电控方向）"),     # 再改裸词
("@@VE@@", "车辆工程（电控方向）"),      # 放回
```

## C. docx 表格内容不在 `document.paragraphs` 里

```python
"\n".join(p.text for p in doc.paragraphs)   # ⚠️ 漏掉所有表格单元格
```

必须补：

```python
tbl = "\n".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
full = para_text + "\n" + tbl
```

**症状**：段落扫描报「零残留」，实际表格里还留着旧词（本次漏了 2 处，靠补扫才抓到）。

## D. BAD 词表用子串会误报 → 打印上下文定夺

`BAD = ["转专业", ...]` 会因目标文本**合法保留该词**而误报（例：「· 争取本硕方向选择或校内**转专业**的机会」）。

**判定法**：命中后打印该形状全文再肉眼定夺。只报 `残留=['转专业']` 无用，要输出
`P6: '…争取本硕方向选择或校内转专业的机会…'` 才能一秒定性。

## E. PPT 自检须递归钻 group

`slide.shapes` 顶层不含组合内形状：

```python
def walk(shapes, out):
    for s in shapes:
        if s.shape_type == 6:      # GROUP
            walk(s.shapes, out); continue
        if s.has_text_frame: out.append(s.text_frame.text)
        if getattr(s, "has_table", False) and s.has_table:
            for r in s.table.rows:
                for c in r.cells: out.append(c.text)
```

## F. 复用脚本要参数化「按人配置」，别复制脚本

```python
P = {
    "name":  os.environ.get("P_NAME", "王子涵"),
    "photo": os.environ.get("P_PHOTO", r"...\人像.JPG"),
    "t1":    os.environ.get("P_T1", "把车造出来"),            # 封面主标题
    "t2":    os.environ.get("P_T2", "做智能网联汽车落地的实践者"),
}
```

再写一个只做「复制脚本 → 定点替换文本 → 执行副本」的 `_ke_*.py`，**不新建生成逻辑**。

## G. 编排多条子脚本：用 Python，别用 PowerShell

本机 PowerShell 按 GBK 读无 BOM 的 `.ps1`，脚本里任何中文（**含 `C:\Users\王子涵\...` 这类路径**）都会乱码 → 解析器报 `Unexpected token`。

**修法**：编排循环用 Python 写：

```python
for f in ["_ke_ppt.py", "_ke_doc.py", "_ke_gen.py", "_ke_form.py"]:
    r = subprocess.run([PY, "-u", p], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env=env)
```

实测：从「反复 20+ 次 exit 1」变成「一次跑完 4 条链全 exit 0」。

## H. Word COM 转 PDF 比 Edge headless 可靠

- **Edge headless** `--print-to-pdf`：首次调用常干等 90s 后 `subprocess.run` timeout 抛出
- **Word COM**（须先 `pip install pywin32 -i https://mirrors.aliyun.com/pypi/simple/`）：秒级完成

```python
import win32com.client as wc
w = wc.Dispatch("Word.Application"); w.Visible = False
d = w.Documents.Open(tmp_ascii_path)      # 先复制到 %TEMP% 的 ASCII 路径
d.SaveAs2(pdf_ascii_path, FileFormat=17)  # 17 = wdFormatPDF
d.Close(0); w.Quit()
```

**坑**：
- COM 对**含中文的路径**偶发失败 → 先 `shutil.copy` 到 `%TEMP%\x.docx` 再转，最后复制回目标目录
- 转完 `Word`/`PowerPoint` 进程会锁文件 → 重新生成前 `Get-Process POWERPNT,WINWORD | Stop-Process -Force`
- 装完 pywin32 后**重新起 Python 进程**才 import 得到（旧进程的 sys.path 无新包）
