# Windows Edge Headless HTML→PDF 转换

在 Windows 上无需 LibreOffice 即可将 HTML 文档转为 PDF 的可靠方法。

## 适用场景

- 需要从 HTML/Markdown 生成 PDF
- 没有安装 LibreOffice / reportlab 不足以处理复杂排版
- DOCX→PDF 直接转换失败（Edge headless 渲染 DOCX 经常超时）

## 推荐工作流

```
python-docx 生成 .docx → 用相同内容写成 .html → Edge headless 转 PDF
```

或直接写 HTML（排版控制更精确）。

## PowerShell 命令

```powershell
$edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
$html = "C:\path\to\document.html"
$pdf = "C:\path\to\output.pdf"

Start-Process -FilePath $edge -ArgumentList @(
    "--headless",
    "--disable-gpu",
    "--print-to-pdf=$pdf",
    "--no-pdf-header-footer",
    "$html"
) -Wait -NoNewWindow
```

## 关键注意事项

1. **DOCX 直接转 PDF 不可靠**：Edge headless 渲染 .docx 经常超时（60s+ 仍未完成），错误日志显示 `fallback_task_provider.cc:126` 任务管理器警告。原因是 Edge 需要通过 Office Online 组件渲染 DOCX，这在 headless 模式下不稳定。

2. **HTML 转 PDF 非常快**：通常 2-5 秒完成。

3. **路径中的 `&` 问题**：不要用 `&` 调用运算符，改用 `Start-Process`。否则 Hermes terminal 工具会将 `&` 误判为后台进程标记。

4. **PDF 输出路径**：`--print-to-pdf=` 后直接跟完整绝对路径，不要有空格。

5. **页边距**：通过 CSS `@page { margin: 20mm 18mm; }` 控制。

6. **中文字体**：HTML 中指定 `font-family: "Microsoft YaHei", "微软雅黑", sans-serif` 确保中文正常渲染。

## 与 LibreOffice 对比

| 方案 | 优点 | 缺点 |
|------|------|------|
| Edge headless HTML→PDF | Windows 内置、零安装、速度快 | 仅 HTML 输入 |
| LibreOffice headless | DOCX/ODT 直接转、高保真 | 需额外安装（~500MB） |
| reportlab | Python 原生、纯代码 | 排版能力有限 |

## 实测数据

本会话中，一份 20KB HTML 文档通过此方法在 3 秒内生成 1.37MB 高质量 PDF（含中文、表格、彩色标题、分页）。
