# 课件（PPTX）→ 期末复习讲义 docx + PDF

实测：吉大《人工智能导论》6 个 PPT / 418 页 → 37 页 docx+PDF，3.3 万字。
用户原话「蒸馏一下…总结重要知识点生成文档和pdf方便我期末复习」。与图文对照版
（`pptx-to-docx-handout.md`，逐页复刻原 PPT）是**不同的产物**——这个要的是压缩重组的复习材料。

## 1. 提取：正文在文本框，公式在图片里

```python
# 递归进 group shape，逐页输出 "===== Slide n =====" + 文本 + 表格 + [NOTE] 备注
def walk(shapes, out):
    for sh in shapes:
        if sh.shape_type == 6:               # GROUP
            walk(sh.shapes, out); continue
        if sh.has_text_frame and sh.text_frame.text.strip():
            out.append(sh.text_frame.text.strip())
        if getattr(sh, 'has_table', False) and sh.has_table:
            out.append('[TABLE]\n' + '\n'.join(
                ' | '.join(c.text.replace('\n',' ').strip() for c in r.cells)
                for r in sh.table.rows))
```

- 备注（`notes_slide`）里常有大段教师口语讲解，**信息密度比正文页更高**，读的时候别只读正文。
- 一页只有一句标题、又带着 PICTURE 的，**公式和计算过程就在图里**（Sigmoid 表达式、卷积输出尺寸、
  LSTM 门控、BP 链式展开都是这么丢的）。→ 把整个 PPT 另存 PDF，`fitz` 按页 `get_pixmap(dpi=140)`，
  逐张 `vision_analyze` 抄公式。只挑这几类页，别全渲染。
- 备注页写作 `[NOTE]` 段，读大文件前先 `re.sub` 把它们剥掉单独看，不然 8 万字里一半是重复口语。

## 2. 拆分大文件

单章 87k 字符（117 页）一次读不完：按 `===== Slide (\d+) =====` 切块，14 页一组写 `part_XX.txt`，
每块 8~15k 字符，刚好一次读完。同时生成 `outline.txt`（每页首行）先看骨架，决定哪几页值得深挖。

## 3. 正文结构（用户认可的形态）

- 开头一张「章 → 一句话抓住它 → 常见题型」总表
- 每章按小节走，**保留原始数字与年份**（418 页课件里真正会被考的就是这些）
- 标记体系：★ 最易考概念点、▲ 建议动手算的公式
- 附录：**公式速查表**（编号+公式+出处章节）、**易混概念对比**、**自测题带答案**、考前冲刺清单
- 章节间用 `---` 分页，每个 `# ` 一级标题在 docx 里换页

## 4. 生成

- Markdown 是唯一真身；`_md2docx.py` 只做渲染：`#`→Heading1+分页、表格→Table Grid+表头底纹、
  `- / 1.`→悬挂缩进列表、`>`→左竖线引用块、`**x**`→加粗、`` `x` ``→Consolas 变色。
- 合并段落时顺手做错字替换（自写长文必有零星错字：`非极大值佬制`、`似识别`），
  替换前 `if a in txt: print("fix:", a)` 让修复可见。
- 中文：`w:eastAsia` 必须是微软雅黑（见 SKILL.md Pitfall #4）。
- PDF 用 Word COM `SaveAs(FileFormat=17)`，直接传中文路径本次没问题（ASCII 中转仍是更稳的默认）。
  `doc.ComputeStatistics(2)` 拿页数、`(0)` 拿字数。

## 5. 验证（用户要求"不能只凭 status 报完成"）

`fitz` 渲染抽查 5~8 页 → `vision_analyze` 问三件事：
**中文有无乱码 / 表格有无挤压变形 / `ŷ Σ ∂ ⊙ ⌊⌋ σ η` 等符号有无变方框**。
这次全部通过 = 微软雅黑 + python-docx 对 Unicode 数学符号够用，**不需要 OMML 原生公式**，
别上 `latex2mathml` 那套复杂度。

## 6. 不要做

- 不要替课程编内容：课件没写的推导就不补（"只整理不创作"，同 handout 版红线）。
- 不要每页都插图——复习讲义要的是密度，图片只在公式确实抽不出文本时才渲染核对。
