# 批量文档提取与分析

从混合格式文件夹中批量提取文本内容并建立知识库。
（合并原 `document-generation/references/batch-document-extraction.md` 与独立技能
`batch-document-extraction`，2026-10 并入本技能。）

## 工具矩阵

| 格式 | 库 | 方法 | 坑 |
|------|------|------|------|
| PDF（文字型） | PyMuPDF (fitz) | `page.get_text()` | 纯图片 PDF 返回空 → 需 OCR |
| PDF（扫描版） | PyMuPDF + Tesseract / `marker-pdf` | — | 判据：输出 0 字节 |
| DOCX | python-docx | `Document(path).paragraphs` | 表格单元格**不在** `.paragraphs` 里，要单独取 |
| DOC（旧版） | olefile | 从 OLE `WordDocument` 流抽 UTF-16LE 字符 | python-docx 读不了 .doc |

安装：`pip install pymupdf python-docx olefile`

## 批量提取脚本

现成脚本 `scripts/extract_all.py`，或 `python extract_all.py`。
输出到 `<folder>/_extracted/`，一文档一 `.txt`，文件名 = 相对路径把分隔符换成 `_`。

## .doc 特殊处理

**方案 A：olefile（推荐，零安装）** —— 只提文本流不留格式，Win/Mac/Linux 通用，
加密或损坏的 .doc 可能失败。
**方案 B：LibreOffice** —— `soffice --headless --convert-to docx input.doc`，保真但需装 ~500MB。
**方案 C：Word COM（Windows）** —— `New-Object -ComObject Word.Application`。
**方案 D：Linux/WSL** —— `catdoc`、`antiword`。

## 输出目录结构

```
原始文件夹/
├── *.pdf, *.docx, *.doc ...（原始文件）
└── _extracted/
    ├── 子目录_文件名.pdf.txt
    └── ...
```

扁平命名的代价：丢原目录层级但避免冲突与超长路径。层级很深时改成在 `_extracted/` 下镜像目录。

## 注意事项

1. **纯图片 PDF**：无文字层，`get_text()` 为空。需 OCR 或 `vision_analyze`。
2. **损坏 PDF**：MuPDF 会报 `syntax error: unknown keyword` 警告但仍产出部分文本 —— **看输出字节数，不看报错**。
3. **中文字符**：脚本统一 `encoding='utf-8'` 保存。
4. **大文件**：167 页 PDF 可产出 360KB+ txt。
5. **Windows + WSL2 混合环境**：涉及中文路径的批处理优先用 Windows 原生 Python
   （`wsl -d Ubuntu -- bash -c "..."` 有编码问题）。

## 验证完成

```bash
python -c "import os; d='folder/_extracted'; files=[f for f in os.listdir(d)]; print(f'{len(files)} files'); [print(f'{os.path.getsize(os.path.join(d,f))//1024:5d} KB  {f}') for f in sorted(files)]"
```
向用户报告：总文件数、0 KB 文件（图片型 PDF）、输出目录路径。
