---
name: officecli
description: Create, analyze, proofread, and modify Office documents (.docx, .xlsx, .pptx) using the officecli CLI tool. Use when the user wants to create, inspect, check formatting, find issues, add charts, or modify Office documents.
version: "1.0.0"
homepage: "https://officecli.ai"
---

# officecli

AI-friendly CLI for .docx, .xlsx, .pptx. Single binary, no dependencies, no Office installation needed.

## Install

If `officecli` is not installed:

```bash
# Windows (PowerShell)
irm https://d.officecli.ai/install.ps1 | iex
```

Verify with `officecli --version`. If still not found after install, open a new terminal.

---

## Strategy

**L1 (read) → L2 (DOM edit) → L3 (raw XML)**. Always prefer higher layers. Add `--json` for structured output.

## Help System (IMPORTANT)

**When unsure about property names, value formats, or command syntax, ALWAYS run help instead of guessing.**

```bash
officecli help                                  # All commands + global options
officecli help docx                             # List all docx elements
officecli help docx paragraph                   # Full schema
officecli help docx set paragraph               # Verb-filtered
officecli help docx paragraph --json            # Structured schema
```

Format aliases: `word`→`docx`, `excel`→`xlsx`, `ppt`/`powerpoint`→`pptx`. Verbs: `add`, `set`, `get`, `query`, `remove`.

## Performance: Resident Mode

Every command auto-starts a resident on first access (60s idle timeout). Explicit `open`/`close` recommended for longer sessions (12min idle):

```bash
officecli open report.docx       # explicitly keep in memory
officecli set report.docx ...    # no file I/O overhead
officecli close report.docx      # save and release
```

Run `save` or `close` **before a non-officecli program reads the file** (python-docx/openpyxl, Word, renderer, delivery).

## Quick Start

**PPT:**
```bash
officecli create slides.pptx
officecli add slides.pptx / --type slide --prop title="Q4 Report" --prop background=1A1A2E
officecli add slides.pptx '/slide[1]' --type shape --prop text="Revenue grew 25%" --prop x=2cm --prop y=5cm
```

**Word:**
```bash
officecli create report.docx
officecli add report.docx /body --type paragraph --prop text="Executive Summary" --prop style=Heading1
officecli add report.docx /body --type paragraph --prop text="Revenue increased by 25% year-over-year."
```

**Excel:**
```bash
officecli create data.xlsx
officecli set data.xlsx /Sheet1/A1 --prop value="Name" --prop bold=true
officecli set data.xlsx /Sheet1/A2 --prop value="Alice"
```

## L1: Create, Read & Inspect

```bash
officecli create <file>               # Create blank .docx/.xlsx/.pptx
officecli view <file> <mode>          # outline | stats | issues | text | annotated | html
officecli get <file> <path> --depth N # Get a node and its children [--json]
officecli query <file> <selector>     # CSS-like query
officecli validate <file>             # Validate against OpenXML schema
```

## L2: DOM Operations

```bash
officecli set <file> <path> --prop <name>=<value>   # modify properties
officecli find <file> <path> --find "text"          # format or replace matched text
officecli add <file> <path> --type <element> --prop # add elements or clone
officecli batch <file> --ops file.json              # multiple operations in one save cycle
officecli remove <file> <path>                      # remove elements
officecli move / swap / sort                        # rearrange
```

## L3: Raw XML

`officecli get <file> <path> --raw` and `officecli set <file> <path> --xml` for full XML control.

## Common Pitfalls

- Always use `officecli help <cmd>` when unsure about property names
- Use `--json` for machine-readable output
- Save/close before non-officecli programs read the file
- Use stable ID addressing (`/doc/paragraph[2]`) or CSS-like queries (`#myId`, `.myClass`)

## Specialized Skills

Fundraising decks, academic papers, financial models, dashboards, and Morph animations need their own skill loaded first.
