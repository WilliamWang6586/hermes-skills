# Agent Reach — 各平台详细命令参考

> 根据 `agent-reach doctor --json` 的 `active_backend` 选择对应的命令组。

## 零配置渠道（Tier 0）

### 🌐 任意网页 (Jina Reader)
```bash
curl -s "https://r.jina.ai/URL" -H "User-Agent: agent-reach/1.0"
```

### 📺 YouTube (yt-dlp)
```bash
# 下载字幕
yt-dlp --write-sub --skip-download -o "/tmp/%(id)s" "URL"
# 搜索
yt-dlp "ytsearch:关键词" --dump-json --no-download --playlist-end 5 2>/dev/null
```

### 📡 RSS (feedparser)
```bash
curl -s "RSS_FEED_URL" | python3 -c "
import sys, xml.etree.ElementTree as ET
data = sys.stdin.read()
root = ET.fromstring(data)
for entry in root.iter('{http://www.w3.org/2005/Atom}entry')[:10]:
    title = entry.find('{http://www.w3.org/2005/Atom}title').text
    link = entry.find('{http://www.w3.org/2005/Atom}link').attrib.get('href','')
    print(f'* [{title}]({link})')
"
```

### 🅱️ B站搜索（无需登录）
```bash
# 搜索（API 直连）
curl -s "https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=关键词&page=1"
# 视频详情
curl -s "https://api.bilibili.com/x/web-interface/view?bvid=BVxxx"
# 视频字幕（bili-cli 安装后）
bili get "BVxxx" --sub-only
bili search "关键词" --type video -n 5
```

### 💬 V2EX（公开 API）
```bash
curl -s "https://www.v2ex.com/api/topics/hot.json" -H "User-Agent: agent-reach/1.0"
curl -s "https://www.v2ex.com/api/topics/latest.json" -H "User-Agent: agent-reach/1.0"
```

### 🐙 GitHub（gh CLI）
```bash
gh search repos "query" --sort stars --limit 10
gh search issues "query" --limit 10
gh repo view owner/repo
gh issue list -R owner/repo --limit 5
gh pr list -R owner/repo --limit 5
```

---

## 需登录态渠道（Tier 1）

### 🐦 Twitter/X (twitter-cli)
```bash
# 安装
pipx install twitter-cli
# 搜索
twitter search "query" -n 10
# 用户推文
twitter user username -n 10
# 读单条
twitter tweet tweet_id
```

### 📕 小红书 (OpenCLI)
```bash
opencli xiaohongshu search "query" -f yaml
opencli xiaohongshu note NOTE_URL -f yaml
opencli xiaohongshu profile USER_ID -f yaml
```

### 🔴 Reddit (OpenCLI / rdt-cli)
```bash
# 桌面：OpenCLI
opencli reddit search "query" -f yaml
opencli reddit subreddit NAME -f yaml
# 服务器：rdt-cli
rdt search "query" --limit 10
rdt post POST_URL
```

### 👔 LinkedIn (Jina Reader / linkedin-scraper-mcp)
```bash
# 基本：Jina Reader 读公开页面
curl -s "https://r.jina.ai/PROFILE_URL"
# 完整：linkedin-scraper-mcp
mcporter call 'linkedin.search_linkedin(query: "关键词", limit: 5)'
```

### 🎵 小宇宙播客
```bash
# 搜索播客
curl -s "https://api.xiaoyuzhoufm.com/v1/search?q=关键词"
# 转录（需要 groq-whisper）
agent-reach transcribe PODCAST_URL
```

### 📈 雪球（需登录 Cookie）
```bash
# 搜索
curl -s "https://xueqiu.com/query/v1/search/web/search.json?q=股票代码"
# 行情
curl -s "https://stock.xueqiu.com/v5/stock/quote.json?symbol=SH600000"
```

### 📘 Facebook (OpenCLI)
```bash
opencli facebook search "query" -f yaml
opencli facebook group GROUP_ID -f yaml
```

### 📸 Instagram (OpenCLI)
```bash
opencli instagram search "query" -f yaml
opencli instagram user USERNAME -f yaml
```

---

## 全网语义搜索（Tier 0，需配置 Exa）

```bash
# 安装 mcporter + Exa MCP
npm install -g mcporter
mcporter config add exa https://mcp.exa.ai/mcp

# 搜索
mcporter call 'exa.web_search_exa(query: "关键词", numResults: 5)'

# 高级搜索
mcporter call 'exa.web_search_exa(query: "关键词 site:github.com", numResults: 10)'

# 免费额度：1000次/月（exa.ai 注册）
```

---

## 多平台调研工作流

```
1. Exa 搜索 → 获取全网相关页面
2. 读 top 搜索结果内容（Jina Reader）
3. Twitter 搜讨论
4. Reddit 搜讨论
5. 小红书搜中文用户评价
6. B站搜中文解读
7. GitHub 搜相关项目
8. RSS 订阅持续追踪
```
