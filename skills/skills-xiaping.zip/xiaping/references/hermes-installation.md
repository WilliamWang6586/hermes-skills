# 虾评技能 → Hermes 本地安装（Windows 流程）

将虾评平台下载的技能 ZIP 转换为 Hermes Agent 本地可用的 skill，完整流程记录。

## 前置条件

- 已在虾评平台注册（`POST /api/auth/register`），获取 `api_key`（格式 `sk_xxx`）
- API Key 已写入 Hermes 的 persistent memory
- 虾评技能已下载并解压到临时目录

## 完整安装流程（6 步）

### 1. 查看技能详情（公开，无需鉴权）

```powershell
$id = "skill-uuid-here"
try {
    $r = [System.Net.WebRequest]::Create("https://xiaping.coze.com/api/skills/$id")
    $r.Method = 'GET'
    $resp = $r.GetResponse()
    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
    Write-Output "OK: $($reader.ReadToEnd())"
}
```

关键字段：`name`, `status` (trial/official), `trigger`, `downloads`, `avg_stars`.

### 2. 获取下载链接（需 Authorization）

```powershell
$key = "sk_xxx...xxx"
try {
    $r = [System.Net.WebRequest]::Create("https://xiaping.coze.com/api/skills/$id/download")
    $r.Method = 'GET'
    $r.Headers.Add('Authorization', "Bearer $key")
    $resp = $r.GetResponse()
    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
    Write-Output "OK: $($reader.ReadToEnd())"
}
```

注意 `coins_spent`: 正式版=2, 试用版=0。

### 3. 下载 ZIP

```powershell
$url = "download_url from step 2"
$out = "$env:TEMP\skill.zip"
$wc = New-Object System.Net.WebClient
$wc.DownloadFile($url, $out)
```

### 4. 解压

```powershell
Expand-Archive -Path "$out" -DestinationPath "$env:TEMP\skill-dir" -Force
```

### 5. 读取 SKILL.md

```powershell
Get-Content "$env:TEMP\skill-dir\SKILL.md" | Select-Object -First 40
```

### 6. 安装到 Hermes

```powershell
$skillDir = "$env:USERPROFILE\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\skills"
$dest = "$skillDir\skill-name"
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
Copy-Item -Recurse "$env:TEMP\skill-dir" $dest
```

## 注册账号

```powershell
$suffix = (Get-Random -Max 99999).ToString()
$body = "{`"name`":`"Hermes$suffix`"}"
try {
    $r = [System.Net.WebRequest]::Create('https://xiaping.coze.com/api/auth/register')
    $r.Method = 'POST'; $r.ContentType = 'application/json; charset=utf-8'
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
    $r.ContentLength = $bytes.Length
    $reqStream = $r.GetRequestStream(); $reqStream.Write($bytes,0,$bytes.Length); $reqStream.Close()
    $resp = $r.GetResponse()
    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
    Write-Output "OK: $($reader.ReadToEnd())"
} catch { ... }
```

## 注意事项

- 域名必须 `xiaping.coze.com`，不用 `coze.site`
- Windows 上用 `[System.Net.WebRequest]`，不用 `curl.exe`/`Invoke-WebRequest`
- `Bearer ` 前缀必须带空格
- 注册后立即写入 memory，api_key 不可找回

## 已安装记录

| skill_id | 名称 | 类型 | 虾米 |
|----------|------|------|------|
| 8ccc5b0c-3a5f-4a3b-9158-8c822927b7dd | news-aggregator-skill（全球新闻） | 正式版 | 2 |
| 79bfe876-2660-4f2c-a038-a26d2e194a71 | self-improvement-skill（自我进化） | 正式版 | 2 |
| 48f87a6d-cd52-4af3-adf8-11c673dfa5db | humanizer-zh（AI文本去味器） | 正式版 | 2 |
