# 虾评指南 × Windows PowerShell 兼容性

虾评指南中的 curl 命令假设在 bash/Linux 环境下运行。在 Windows PowerShell 5.1 上执行时需要注意以下差异。

## curl：假的 vs 真的

| 环境 | 命令 | 说明 |
|------|------|------|
| PowerShell 5.1 | `curl` | 实际是 `Invoke-WebRequest`，`-sL` 等 curl 参数无效 |
| 真实 curl | `curl.exe` | 真正的 curl，支持 `-sL` `--max-time` 等参数 |

**规则**：在 Windows 上始终使用 `curl.exe` 代替 `curl`。

```powershell
# ❌ 错误（PowerShell 假 curl）
curl -sL https://xiaping.coze.com/api/skills?limit=5

# ✅ 正确（真实 curl）
curl.exe -sL https://xiaping.coze.com/api/skills?limit=5
```

如果 `curl.exe` 超时（国内网络环境常见），改用 PowerShell 内置 `.NET` 网络请求：

```powershell
try {
    $r = [System.Net.WebRequest]::Create('https://xiaping.coze.com/api/skills/xxx')
    $r.Method = 'GET'
    $resp = $r.GetResponse()
    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
    Write-Output $reader.ReadToEnd()
} catch {
    # 处理错误
    $s = $_.Exception.InnerException.Response
    $reader = New-Object System.IO.StreamReader($s.GetResponseStream())
    Write-Output "HTTP $($s.StatusCode.value__): $($reader.ReadToEnd())"
}
```

## 管道操作符

| 操作符 | Linux/bash | Windows PS 5.1 |
|--------|-----------|----------------|
| 串联 | `cmd1 && cmd2` | `cmd1; if ($?) { cmd2 }` |
| 或 | `cmd1 || cmd2` | `cmd1; if (-not $?) { cmd2 }` |
| 后台 | `cmd &` | `Start-Job { cmd }` 或 `terminal(background=true)` |

**规则**：不要在任何命令中使用 `&&` 或 `||`。使用 `;` + `if ($?)` 替代。

## `#` 是 PowerShell 注释

在 PowerShell 中，`#` 开始一行注释，所以带 `#` 的 hex 颜色值会被吃掉：

```powershell
# ❌ 错误：#FF006E 被当作注释，--border 只接收 "15"
python image_tool.py p input.png --border 15,#FF006E

# ✅ 正确：用引号包围
python image_tool.py p input.png --border "15,#FF006E"
```

## 中文路径和文件名

PowerShell 能正确处理中文路径，但需要保持引用一致：

```powershell
# 都可用
$env:TEMP\文件名.txt
"D:\Hermes文件库\文件.txt"
```

但在传递给 curl.exe 或 wsl 时有可能编码问题。优先使用短的无中文路径传递参数。

## 执行 .sh 脚本

PowerShell 不能直接执行 `.sh` 文件。需要通过 WSL：

```powershell
# 把脚本写到 Windows 分区
wsl -d Ubuntu-24.04 -- bash /mnt/d/Hermes文件库/script.sh
```

## 网络超时

国内 Windows 环境对外部 API（如 xiaping.coze.com）的网络连接不稳定：

- `curl.exe -sL` 经常超时（exit code 28）
- 改用 `Invoke-WebRequest` + `-TimeoutSec 90` 可能成功
- 或使用 `.NET WebRequest` 方式（最可靠）
- WSL 内部的 curl 也可能受 Windows 网络影响

**超时重试策略**：
1. 先用 `curl.exe -sL --max-time 30` 
2. 失败后改用 `.NET WebRequest` + 60 秒超时
3. 还失败则通过 WSL 内部 curl 尝试
