# continue/break 顺序陷阱验证脚本

## 用途
验证 `continue` 和 `break` 顺序错误导致的循环未终止问题。

## 错误写法（原问题）
```python
print("=== 错误写法 ===")
for i in range(1, 21):
    if i == 15:           # 本想 15 时终止
        break
    if i % 3 == 0:        # 但 15 是 3 的倍数，被 continue 跳过
        continue
    print(i)
print(f"结束于{i}")       # 输出 20，错误！
```

## 正确写法
```python
print("=== 正确写法 ===")
for i in range(1, 21):
    if i % 3 == 0:        # 先判断是否要跳过
        continue
    if i == 15:           # 再判断是否要终止
        break
    print(i)
print(f"结束于{i}")       # 输出 15，正确！
```

## 运行方法
```python
# 直接运行这个脚本，对比两种写法的输出
```

## 预期输出
```
=== 错误写法 ===
1
2
4
5
7
8
10
11
13
14
结束于20

=== 正确写法 ===
1
2
4
5
7
8
10
11
13
14
结束于15
```