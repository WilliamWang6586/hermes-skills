"""探针：gdb(MI) 能否在给定路径下调试 —— 用于判定 VSCode F5 失败的根因。

用法：
    python probe_gdb_ascii_path.py
    # 或改脚本底部的 CASES 列表，换成你自己的路径

判据：第一条 MI 命令 `-environment-cd <路径>` 的返回
    ^done   → 路径 OK，F5 能工作
    ^error  → gdb 不认这个路径（中文会变成 \\346\\226\\207 八进制转义），F5 必失败

为什么要走 stdin 而不是 `gdb -ex` / `-x`：
    -ex 的引号会被 PowerShell 吃掉、命令根本没执行，看起来像「路径有问题」；
    -x 读的是 GDB 命令文件，MI 命令在里面不被识别。
    只有 stdin 才是和 VSCode cpptools 完全相同的调用方式。
"""
import subprocess
import sys

GDB = r"D:\mingw64\bin\gdb.exe"

# 可替换成自己的路径：(标签, 目录, 目录下的 exe 文件名)
CASES = [
    ("ASCII", r"D:\C_Learning\week02_branch\answers", "task_02_1_answer.exe"),
    ("CN",    r"D:\Hermes文件库\01_学习与课程\C_Programming\week02_branch\answers",
              "task_02_1_answer.exe"),
]


def probe(directory, exe_name):
    cmds = [
        "-environment-cd " + directory,
        "2-file-exec-and-symbols " + exe_name,
        "3-break-insert main",
        "-1-gdb-exit",
    ]
    p = subprocess.run(
        [GDB, "--interpreter=mi", "-q"],
        input="\n".join(cmds) + "\n",
        capture_output=True, text=True, timeout=30, errors="replace",
    )
    out = p.stdout
    # 第一条 -environment-cd 的响应：^done 或 ^error,msg="...No such file..."
    cd_line = next((l for l in out.splitlines() if l.startswith("^")), "")
    return {
        "cd_ok": cd_line.startswith("^done"),
        "cd_line": cd_line,
        "breakpoint": "bkpt=" in out,
        "raw": out,
    }


def main():
    failed = False
    for label, d, exe in CASES:
        r = probe(d, exe)
        status = "OK" if (r["cd_ok"] and r["breakpoint"]) else "FAIL"
        print(f"[{label}] {status}  cd_ok={r['cd_ok']} breakpoint={r['breakpoint']}")
        if not r["cd_ok"]:
            print("    " + r["cd_line"][:170])
            failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
