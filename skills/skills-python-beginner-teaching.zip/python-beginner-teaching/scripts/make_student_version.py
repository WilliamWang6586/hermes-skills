# -*- coding: utf-8 -*-
"""
Python 学习包「同学版」生成器（清空作答 + 脱敏 + 打包 + 实测校验）。

用法：python3.14 make_student_version.py
产出：DST 目录 + ZIP（zip 内层保留 DST 顶层目录名）

铁律：SRC 全程只读，前后各做一次全量 SHA256 指纹比对，不一致就报错退出。
"""
from pathlib import Path
import hashlib
import shutil
import tempfile
import zipfile

# ============ 改这里 ============
SRC = Path(r"D:\Hermes文件库\Python学习计划")          # 原版（含已写好的作答）
DST = Path(r"D:\Hermes文件库\Python_Learning")         # 同学版目录名 = zip 顶层目录名
PLAN = "学习方案.md"                                    # 需归零进度的文件
# ===============================

ZIP = DST.parent / (DST.name + "_同学版.zip")

# 切割标记：W1-W3 用前者，W4（# %% Cell 格式）用后者；全角冒号 \uff1a
MARKERS = ["# 在下面写你的代码：", "# %% 在下面写你的代码："]
CLEAR_TAIL = 1                     # 标记后留几个空行给同学写
ANSWER_KEYS = ["答案", "示范", "完整", "TODO"]   # 命中的 = 答案文件，原样保留
REDACT = [("王子涵", "姓名"), ("交通运输", "你的专业")]
PROGRESS_TRACES = ["[x]", "10/6 完成", "5/5 通过"]   # 进度痕迹，归零用


def snapshot(root: Path) -> dict:
    return {
        str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest()
        for f in sorted(root.rglob("*")) if f.is_file()
    }


def is_answer(rel: str) -> bool:
    return any(k in Path(rel).name for k in ANSWER_KEYS)


def cut_task_file(text: str) -> str | None:
    """返回截断后的文本；无标记返回 None。"""
    cut = -1
    for m in MARKERS:
        i = text.find(m)
        if i != -1 and (cut == -1 or i < cut):
            cut = i + len(m)
    if cut == -1:
        return None
    return text[:cut].rstrip("\n") + "\n" + "\n" * CLEAR_TAIL


def main() -> int:
    before = snapshot(SRC)
    print(f"[0] 原目录文件数 {len(before)}")

    if DST.exists():
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # ---- 1. 清空任务文件的作答 ----
    cleared, kept, untouched = [], [], []
    for rel in sorted(before):
        if not rel.lower().endswith(".py"):
            continue
        f = DST / rel
        text = f.read_text(encoding="utf-8")
        if is_answer(rel) or "_demo" in rel:
            kept.append(rel)
            continue
        new = cut_task_file(text)
        if new is None:
            untouched.append(rel)
        else:
            f.write_text(new, encoding="utf-8")
            cleared.append(rel)
    print(f"[1] 清空作答 {len(cleared)} / 答案保留 {len(kept)} / 无标记保留 {len(untouched)}")

    # ---- 2. 脱敏 + 进度归零 ----
    for f in sorted(DST.rglob("*")):
        if not f.is_file() or f.suffix.lower() not in {".py", ".md", ".txt"}:
            continue
        raw = f.read_bytes()
        bom, body = (b"\xef\xbb\xbf", raw[3:]) if raw.startswith(b"\xef\xbb\xbf") else (b"", raw)
        text = body.decode("utf-8")
        orig = text
        for a, b in REDACT:
            text = text.replace(a, b)
        if f.name == PLAN:
            for t in PROGRESS_TRACES:
                text = text.replace(t, "[ ]" if t == "[x]" else "")
            text = text.replace("选 `D:\\Hermes文件库\\Python学习计划`", "选解压出来的 `Python_Learning` 文件夹")
        if text != orig:
            f.write_bytes(bom + text.encode("utf-8"))
    print("[2] 脱敏 + 进度归零 完成")

    # ---- 3. 打包 ----
    ZIP.unlink(missing_ok=True)
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in sorted(DST.rglob("*")):
            if f.is_file() and not f.name.endswith(".pyc") and "__pycache__" not in f.parts:
                z.write(f, (Path(DST.name) / f.relative_to(DST)).as_posix())
    print(f"[3] 打包 {ZIP.name} {ZIP.stat().st_size / 1024:.1f} KB")

    # ---- 4. 实测：解包逐条校验 ----
    tmp = Path(tempfile.mkdtemp(prefix="verify_"))
    with zipfile.ZipFile(ZIP) as z:
        z.extractall(tmp)
    unpacked = tmp / DST.name

    code_left, sens_hits = 0, []
    for f in sorted(unpacked.rglob("*.py")):
        rel = str(f.relative_to(unpacked))
        if is_answer(rel) or "_demo" in rel:
            continue
        lines = f.read_text(encoding="utf-8").splitlines()
        idx = max((i for i, ln in enumerate(lines) if ln.strip() in MARKERS), default=None)
        tail = lines[idx + 1:] if idx is not None else []
        code_left += len([ln for ln in tail if ln.strip() and not ln.strip().startswith("#")])
    for f in sorted(unpacked.rglob("*")):
        if f.is_file() and f.suffix.lower() in {".py", ".md", ".txt"}:
            t = f.read_text(encoding="utf-8")
            sens_hits += [(str(f.relative_to(unpacked)), k) for k in
                          ["王子涵", "交通运输", "Python学习计划", *PROGRESS_TRACES] if k in t]

    n_orig = len([f for f in SRC.rglob("*") if f.is_file()])
    n_new = len([f for f in unpacked.rglob("*") if f.is_file()])
    print(f"[4] 残留代码行={code_left}(应0)  敏感词={len(sens_hits)}(应0)  "
          f"文件数 {n_orig}->{n_new}({'一致' if n_orig == n_new else '不一致'})")
    for h in sens_hits:
        print("     ⚠️", h)

    # 语法完整性：证明清空没留下残缺
    import py_compile
    bad = []
    for f in sorted(unpacked.rglob("*.py")):
        try:
            py_compile.compile(str(f), doraise=True, cfile=str(f) + ".pyc")
        except Exception as e:
            bad.append((str(f.relative_to(unpacked)), str(e).splitlines()[-1]))
    print(f"[5] py_compile 通过 {len(list(unpacked.rglob('*.py'))) - len(bad)} / 失败 {len(bad)}")
    for r, e in bad:
        print("     FAIL:", r, e)

    shutil.rmtree(tmp, ignore_errors=True)

    # ---- 6. 原目录必须一字未动 ----
    if snapshot(SRC) != before:
        print("[6] ❌ 原目录发生变化，已中止！")
        return 1
    print("[6] ✅ 原目录哈希全等，未被触碰")
    print("\n交付：", ZIP)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
