# 递归删除事故复盘（2026-10-19）

## 发生了什么

用户要求「给同学发一份，不动我已完成的，把我写的内容删掉再打包」。我：

1. 先对**错误路径** `D:\Hermes文件库\Python学习计划`（已不存在）操作 → 连续 4 次 `Copy-Item`/`Get-ChildItem` 报 `ItemNotFoundException`。
2. 用户纠正路径后，复制了 `D:\Hermes文件库\01_学习与课程\Python_Learning` → `_副本`。
3. 在副本上删 `task*.py`（保留 answers）——**这一步是对的**。
4. 但用户随后说「给同学的我已经完成了，不用弄了，你把那些删了，我说的是我自己学习写的代码在那里面」。
   我理解成「删掉用户真实目录里的 task 文件」，于是在**原目录**执行了同一条递归删除命令：

```powershell
# ☠️ 这条命令删掉了用户 W1-W4 全部手写作业
Get-ChildItem -Path "D:\Hermes文件库\01_学习与课程\Python_Learning" -Recurse |
  Where-Object { $_.Name -like "task*.py" -and $_.FullName -notlike "*answers*" } |
  Remove-Item -Force
```

5. `-Force` 不走回收站；`$env:APPDATA\Code\Backups` 只有一条 8/31 的旧记录；
   `05_备份\hermes-backup-20260922_0937` 里也没有。**不可恢复**。

## 根因（三条，都是我的问题）

1. **把「删副本的 task」这个动作模式直接复制到真实目录**，没有重新判断用户这句话说的是哪个目录。
2. **递归 `Remove-Item -Force` 是破坏性不可逆操作，却没有干跑确认**。
3. 前期路径反复出错（`Python学习计划` 不存在）说明我一直在猜路径，没有先 `search_files` 定位真实目录。

## 正确做法（已写进 SKILL.md）

```powershell
# 第一步：干跑，把清单贴给用户确认
Get-ChildItem -Path $DST -Recurse -File |
  Where-Object { $_.Name -like "task*.py" -and $_.FullName -notlike "*answers*" } |
  Select-Object FullName, Length, LastWriteTime

# 第二步：确认后才删，且 $DST 必须是副本目录变量
```

更强的前提：**用户真实作业目录永不写、永不删**。同学版只做复制件操作。

## 事故后的补救顺序（下次直接照做）

1. 立刻 `Get-ChildItem -Recurse` 列出剩余文件，明确告诉用户「哪些还在、哪些没了」。
2. 查回收站：`(New-Object -ComObject Shell.Application).Namespace(0xA).Items()`。
3. 查 `$env:APPDATA\Code\Backups` 和 `%APPDATA%\Code\User\workspaceStorage`。
4. 查 `05_备份\` 下所有备份目录。
5. 全部落空 → 明确说「救不回来」，不粉饰。然后给两个选项：重建空白题面 / 只重建未完成周。
6. 记住用户已通关的周（W1-W3）的知识不会因为文件丢失而丢失，重写更快。

## 附带教训：路径确认

`D:\Hermes文件库` 在 2026-10-18 重组为 5 组（01_学习与课程 / 02_吉林大学 / 03_工具与项目 / 04_游戏 / 05_备份）。
- Python 学习真实目录 → `01_学习与课程\Python_Learning\`
- 记忆外置库 → `02_吉林大学\记忆外置库\`
- 日报 → `03_工具与项目\每日科技日报\`

任何硬编码旧路径的操作前，先 `search_files(target='files')` 验证存在。
