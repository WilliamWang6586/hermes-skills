# 吉大 AI 学院转专业「程序设计（C）」备考 —— 教程生成规格

**用途**：用户要「按考纲书生成 C 语言教程 / 周包 / 练习题」时，照这份规格做。
Python 版周包模板见技能 `python-beginner-teaching`，C 版是它的移植 + 三块 C 特有内容。

---

## 一、考试口径（官方原文，别凭印象）

数据源（本地已存）：
- `吉林大学相关文件\_extracted\转专业文件_吉林大学各学院2026年本科生集中考核转专业工作实施细则汇总 (1).pdf.txt`（搜「人工智能学院2026」，第 119-123 页）
- 学院官网 `https://sai.jlu.edu.cn/info/1066/5316.htm`

| 项目 | 口径 |
|---|---|
| 形式 | 初试（**笔试 + 机试**）+ 面试 |
| 科目/语言 | 《程序设计》，**C** |
| 参考书 | 《程序设计基础（第3版）》**陈娟、张长海**，高等教育出版社 2019 |
| 初试成绩 | **笔试 × 70% + 机试 × 30%** |
| 总成绩 | （初试 × 50% + 面试 × 50%）× 志愿系数（一志愿 1.0 / 二志愿 0.9 / 三志愿 0.8） |
| 进面 | 初试排名取接收计划 150% |
| 名额 | 2026 年总 15 人，其中 2025 级 11 人 |

**报名硬门槛（比 C 语言更要紧，任何一条不过就进不了考场）**：
1. 必修+限选课 GPA 排名**本专业前 30%**（大一口径 = 只看第一学期）
2. 微积分 ≥80（数学 A/W/B 类）或 ≥85（C/D/E 类）—— 用户修**微积分 BⅠ**，线是 80
3. 无缓考、无学业预警、无违纪；高考选考物理；第一外语英语

> 所以教程排期必须给微积分期末让路（见第三节的时间纪律）。

## 二、资料库现状（2026-10 核实）

`D:\Hermes文件库\02_吉林大学\吉林大学相关文件\电子教材\` 有 5 本 C 书
（谭浩强第五版、金海龙第三版、C语言程序设计教程、实验指导与习题解析、曹志成数据库程序设计），
**没有考纲指定的陈娟《程序设计基础（第3版）》**。

处理：按全国通用章节顺序编排，每周 `任务.md` 顶部标
`> 对照考纲书：陈娟《程序设计基础（第3版）》第 N 章（章号待拿书核对）`。
用户提供书/目录页后一次性校准，别为了「对齐」去编造章号。

## 三、教程目录与周包结构

根目录：`D:\Hermes文件库\01_学习与课程\C_Programming\`（与 `Python_Learning` 平级）

⚠️ **用户明确要求产物必须在 `D:\Hermes文件库` 里，不要放 D 盘根目录**（原话：「你别直接放D盘里面」）。
2026-10-22 我曾为躲中文路径把教程挪到 `D:\C_Learning3`，被用户纠正后搬回。
正确做法：**根目录留在文件库，只把这一棵子树内的目录名/文件名全部改成 ASCII**
（父路径 `Hermes文件库` 的中文实测不影响 gcc 编译与 run.cmd 运行，只影响 F5，见第五之二节）。

```
C_Programming\
├── README.md            # 考试口径 + 进度看板 + 三种运行方式 + 本机坑
├── .vscode\
│   ├── tasks.json       # gcc -g，输出到 ${fileDirname}
│   └── launch.json      # F5 绑定 gcc + gdb + preLaunchTask
├── week0N_主题\
│   ├── week0N_task.md   # 【本周知识点】【VS Code/gcc 避坑】【OJ 输入输出规范】【实操编程任务】【自测清单】
│   ├── task_0N_1.c ~ 5.c
│   ├── run.cmd
│   └── answers\
│       ├── task_0N_1_answer.c ~ 4_answer.c   # 逐行中文注释
│       ├── task_0N_5_TODO.c                  # 只给关键句式，不给完整逻辑
│       ├── task_0N_5_answer.c
│       └── extended.md                        # 3-4 道，尽量含洛谷原题号
```

### 题目骨架铁律（沿用 Python 版的「题面零代码」）
- `task_0N_x.c` 只含：头部注释块（题目要求 + 样例输入/输出 + 坑点提示）+ `#include` + `int main(void){ TODO 注释 }` + `return 0;`
- **骨架必须能直接编译通过**（留白不报错）—— 生成后批量 `gcc -Wall` 验证
- 每周第 5 题是「周任务」，难度升一档，配 TODO 提示版

### 每周必须有的三块 C 特有内容

1. **OJ 输入输出规范**（机试占 30%，多数人死在格式而不是算法）
   - `scanf("%d %d", &a, &b)`、多组输入 `while (scanf(...) != EOF)` 或 `== 2`
   - `%c` 前要加空格吃掉残留空白
   - 输出行末 `\n`、小数 `%.2f`、行首/行尾不许有多余空格（`if (!first) printf(" ");` 手法）
   - 题面写 `even/odd` 就原样输出英文，别翻译
2. **编译/运行时错误对照表**：`expected ';'` / `implicit declaration` / `format '%d' expects int` /
   `Segmentation fault`（scanf 少 `&`、数组越界、野指针）/ `if (a>b);` 多分号
3. **Python 老习惯对照表**（用户有 Python 基础，优势也是坑）：
   `print(x)`→`printf`、`for i in range()`→`for(int i=0;i<n;i++)`、缩进→大括号、
   `len()`→自己传长度、`append`→定长数组+计数变量、不用管内存→越界即崩

## 四、排期（与用户学业同步，别排满）

起点 W1 = 11 月初。**12/21 → 1/15 四周 C 语言降为保温模式**（只刷旧题、不推新章），
因为期末 2027/1/4 开考且 GPA 前 30% / 微积分 80 是硬门槛。3/19 前后考试，W14-W16 做机试/笔试专项 + 全真模拟。

主题顺序：W1 程序结构/数据类型/输入输出 → W2 分支 → W3 循环 → W4 一维数组与排序 →
W5 二维数组与字符串 → W6 函数与递归 → W7 指针上 → W8 指针下 → W9 结构体 →
W10 动态内存与链表 → W11 文件 → W12/W13 算法专题 → W14-W16 冲刺。

## 五、本机 MinGW 已知坑（2026-10 实测，gcc 8.1.0 @ D:\mingw64\bin）

- **`%lld` 不准**：旧 msvcrt 报 `warning: unknown conversion type character 'l' in format`
  （输出其实对，但 `-Wall` 不干净）。**教程内统一用 `%I64d`**，并在答案注释里说明原因。
  换新 MinGW 后 `%lld` 正常。
- **`run.cmd` 里不能写中文注释**：GBK 环境下变乱码，脚本用纯 ASCII。
  更隐蔽的坑：**写了中文 + `chcp 65001` 会连带把 `%TARGET%` 变量吃掉**——
  实测 `run.cmd` 里中文提示语导致 `set /p` 后变量为空、gcc 收到 `.c` 报 `no input files`。
  定论：`.cmd`/`.bat` 一律纯 ASCII，要中文提示就别用批处理。
  交互式 `pause` 用在交付给用户自己双击的场景（不想让黑框闪退），
  但**自动化验证时要 `< nul` 喂空输入**，否则 `pause` 会挂住测试脚本。
- 输入型程序的自动化验证见下节。

## 五之二、🔴 教程目录必须是纯 ASCII 路径（否则用户 F5 调试必失败）

**症状**（2026-10-22 真实卡了几轮）：用户在 VSCode 里按 F5，弹

> Unable to start debugging. Program path `...\task_01_1_完整.exe` is missing or invalid.
> GDB failed with message: `...\task_01_1_完整.exe`: No such file or directory.

**而 `.exe` 明明就在那儿**（资源管理器里看得到、时间戳也新）。用户会以为是代码问题，其实是路径。

**根因（2026-10-22 用 MI 协议实测坐实，别再猜）**：gdb 的 `-environment-cd` 命令
**不认中文路径**，cpptools 传进去后 gdb 直接把中文转成八进制转义并报错：

```
1-environment-cd D:\Hermes文件库\...
^error,msg="D:\\Hermes\346\226\207\344\273\266\345\272\223\\01_...: No such file or directory."
# 同一命令，D:\C_Learning\...  →  ^done
```

**判据必须走 MI 协议**（和 VSCode 调试器完全相同的调用方式），
`gdb -ex "..."` 或 `-x` 脚本的结论都不可信——我曾因此误判成「gdb 能读中文」。
验证脚本见 `scripts/probe_gdb_ascii_path.py`（对比 ASCII / 中文两条路径的 `-environment-cd` 结果）。

⚠️ **必须澄清一个容易搞混的点**：中文路径**只影响 F5 调试**，
**不影响** gcc 编译、`run.cmd`、右上角 ▶ 运行。所以
「教程跑不起来」≠「路径有问题」，先分清是哪种跑法失败。

**铁律：C 教程根目录与全部子目录/文件名一律纯 ASCII，父目录也是。**

**2026-10-22 已定论**：gdb 连**父目录**的中文都不认（`D:\Hermes文件库\...` → `^error`），
所以「只把子树改 ASCII、根目录留在文件库」这条路 **F5 走不通**。
用户拍板后教程主目录 = `D:\C_Learning`，文件库里的 `C_Programming\` 只留一个「已迁移」说明 md。

下次同类项目的正确顺序（别重走我踩的三轮）：
1. 先跑 `scripts/probe_gdb_ascii_path.py` 确认父路径能否 F5
2. 预先告诉用户「要 F5 就得纯 ASCII 根，要放文件库就只能 run.cmd/▶」——**一次说清，让用户选**
3. 用户选完再动手，不要先做完再搬

如果**父目录含中文**（`D:\Hermes文件库\...`）且用户坚持要放在文件库里，
F5 就一定失败，此时只有两条路，**必须让用户选**：
1. 子树搬到一个纯 ASCII 根（如 `D:\C_Learning`）—— F5 可用，但脱离了文件库
2. 留在文件库 —— F5 不可用，用 `run.cmd` / ▶ 代替

🔴 **不要自己替用户决定搬出文件库**。用户 2026-10-22 明确要求产物在文件库里
（「别直接放 D 盘里面」）；我为躲中文路径擅自挪到 `D:\C_Learning3`，被要求搬回。
搬回后用户再问「F5 为什么还是不行」，才暴露出父目录中文是硬限制——
这时应**如实告知取舍并让用户拍板**，而不是再擅自搬一次。

```
D:\Hermes文件库\01_学习与课程\C_Programming\   # 根目录留在文件库（用户要求）
├── .vscode\{tasks.json, launch.json}
├── README.md                  # 原 学习方案.md
├── week01_io\                 # 原 第01周_程序结构与输入输出
├── week02_branch\             # 原 第02周_分支结构
└── week03_loop\               # 原 第03周_循环
     answers\task_01_1_answer.c   # 原 task_01_1_完整.c（"完整"→"answer"）
     answers\extended.md          # 原 扩展练习.md
     week01_task.md               # 原 01_任务.md
```

改名映射：`完整`→`answer`、`扩展练习`→`extended`、`0N_任务`→`week0N_task`、`学习方案`→`README`、
`第0N周_主题`→`week0N_主题`。

**必须配 `launch.json`**（没有它 cpptools 自动生成的那份在中文父路径下更容易出岔子）。
`externalConsole: false` —— 让程序跑在 VSCode 内置终端，**不弹那个让人误以为是报错的 cmd 黑框**：

```json
{
  "version": "0.2.0",
  "configurations": [{
    "name": "C: gcc 调试当前文件",
    "type": "cppdbg", "request": "launch",
    "program": "${fileDirname}\\${fileBasenameNoExtension}.exe",
    "cwd": "${fileDirname}",
    "externalConsole": false,
    "MIMode": "gdb",
    "miDebuggerPath": "D:\\mingw64\\bin\\gdb.exe",
    "preLaunchTask": "C/C++: gcc.exe 生成活动文件"
  }]
}
```

**验证 gdb 链路是否真的通**（自己先跑通再去麻烦用户，别只说「已修复」）：

```powershell
cd <answers目录>
gcc task_01_1_answer.c -g -o t.exe
@'
break main
run
quit
'@ | Set-Content _g.txt -Encoding ASCII
gdb -batch -x _g.txt --args t.exe   # 看到 "hit Breakpoint 1, main () at ...:9" 才算通
```

**改名后别忘**：`README.md` 里的路径引用同步替换；旧目录先留着不删，
等用户确认新路径能 F5 跑通再问要不要清理（这次就是靠「留着」避开了不可逆操作）。

**用户会问「右上角那支 ▶ 出来的黑框是什么」**（2026-10-22 原话：「为什么出来的是一个命令框」）。
**那不是报错，是程序自己的控制台窗口，printf 输出就在里面**，跑完自动关。
解释顺序：先一句话点明「黑框 = 你的程序在跑」，再给三种运行方式对比表，别先铺配置细节。

**验证 F5 链路是否真的通**（不用开 VSCode，直接模拟 cpptools 的 MI 调用）：

```powershell
gcc task_01_1_answer.c -g -o t.exe
# 用 scripts/probe_gdb_ascii_path.py，或手写 MI 命令走 stdin（不能走 -x / -ex）
#   看 1-environment-cd 返回 ^done 还是 ^error —— ^error 就是路径不认
```

交付时给用户三种跑法（README 里写清）：

| 方式 | 操作 | 特点 |
|---|---|---|
| 双击 `run.cmd` | 进周目录双击 | ⭐推荐新手，带 `pause` 窗口不闪退 |
| 右上角 ▶ | 打开 .c 点三角 | 快，但黑框跑完即关 |
| F5 | 打开 .c 按 F5 | 能看变量/单步，走内置终端 |

**目录改名会被占用卡住**：VSCode / 资源管理器打开着目录时 `Rename-Item` 报
`访问被拒绝`/`在使用中`。绕过：先用中间名建好完整副本，最后一步再改；
或者干脆接受中间名（`C_Learning3` 这种纯 ASCII 名功能上完全没问题，不值得为好看去折腾）。

## 六、答案验证（交付前必做，不是可选项）

用 PowerShell 批量跑，所有答案 + 所有骨架都要过：

```powershell
# 核心两点：① 编译零警告 ② 喂输入文件，用 cmd /c ... < file 重定向
#   ⚠️ PowerShell 的 | 管道喂 stdin 给 gcc 编译的 exe 会卡死/读不到，
#     必须写输入文件再 "cmd /c `"$exe`" < `"$in`""
Set-Content $in -Value "7 2" -Encoding ASCII
$c = (& gcc $src -o $exe -Wall -Wextra 2>&1)
$o = (& cmd /c "`"$exe`" < `"$in`"" 2>&1) -join "`n"
```

断言用 `$o -like "*期望串*"`（比 `-match` 省转义麻烦）。
自测逻辑（如二分法 1~1000 最多 10 次）用 `#ifdef SELFTEST` 包一个独立 main，
`gcc x.c -DSELFTEST` 单独编译跑，不加宏时就是干净 OJ 提交版 —— 比拆成两个文件省事（拆文件会撞 multiple definition of main）。

### ⚠️ 用 write_file / MCP 批量写文件后，必查 `\r\r\n`

2026-10-22 实测：一次写 40 个中文文件，**每个 `\n` 前都多出一个 `\r`，变成 `\r\r\n`**，
文件看着正常、gcc 也能编译，但 `Get-Content` 读出来每行之间夹一个空行，
用行数/长度做的自检会误判成「文件被截断」。批量写完先跑一遍归一化：

```powershell
Get-ChildItem $root -Recurse -Include '*.c','*.md' | ForEach-Object {
  $raw = [Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($_.FullName))
  $new = $raw -replace "`r`r`n", "`r`n"
  if($new -ne $raw){ [IO.File]::WriteAllText($_.FullName,$new,(New-Object Text.UTF8Encoding($false))) }
}
```

（无 BOM 的 `UTF8Encoding($false)` 才对；带 BOM 会让 gcc 在文件首行塞进不可见字符。）

## 七、历次生成结果（可接续）

| 日期 | 交付 | 实测 |
|---|---|---|
| 2026-10-22 | W1 程序结构与输入输出、W2 分支结构、W3 循环（各 5 题 + 答案 + 扩展） | 答案 15/15 编译运行通过、`-Wall -Wextra` 零警告；骨架 15/15 编译通过；`run.cmd` 全链路验证 |
| 2026-10-22 | 按用户要求**搬回** `D:\Hermes文件库\01_学习与课程\C_Programming\`，子树内全 ASCII（week01_io / week02_branch / week03_loop）+ 补 `launch.json`（`externalConsole:false`）+ 重写纯 ASCII `run.cmd`（带 pause） | gcc/run.cmd 全通、中文输出正常 |
| 2026-10-22 | 用户反馈搬回后 F5 仍报 `-environment-cd ... No such file` → **MI 协议实测坐实 gdb 不认中文路径**；产出 `scripts/probe_gdb_ascii_path.py` 探针 | ASCII 路径 `^done`、中文路径 `^error`。**F5 与「放在文件库」不可兼得，取舍交用户决定** |
| 2026-10-22 | 用户拍板：搬到 `D:\C_Learning`，F5 实测通过（终端输出 6 行全对）。中文路径旧目录清空只留指路 md | F5 通 ✅ |
| 2026-10-22 | **W4 一维数组与排序**（week04_array：输入输出+最值 / 逆序+查找 / 冒泡+选择 / 二分+去重 / 周任务=成绩统计） | 答案 5/5 通过、骨架 5/5 编译通过、`-Wall -Wextra` 零警告 |

**下一步**：W5 二维数组与字符串（`char[]` 是第二个大坑区：`\0` 结尾、`strlen` vs `sizeof`、`gets` 禁用）。

**已定论**：教程主目录 = `D:\C_Learning`（纯 ASCII）。文件库内保留的 `C_Programming\` 只放了一个「已迁移」说明 md。
用户在「能 F5」和「放在文件库」之间**选择了能 F5**——以后同类项目直接问一次，别反复试探。

**W4 出题要点（复用 W5+ 时参考难度曲线）**：
- 三个必埋的新手坑：求最小值初值写 `int mn = 0;`（全正数时永远 0）、逆序交换 `i < n` 换两遍白干、
  周任务只换成绩不换学号（平行数组错位）
- 平行数组同步交换是 W4 的核心考点，答案里要把「忘了交换 id 那三行」标成最经典错误

## 关键词
C语言教程 / 转专业 / 人工智能学院 / 程序设计 / 陈娟 张长海 / 程序设计基础第3版 /
周包生成 / OJ输入输出 / 多组输入 / scanf & / %lld %I64d / MinGW / 题面零代码 / 洛谷 /
F5调试失败 / Unable to start debugging / cppdbg 中文路径 / environment-cd / MI协议探针 / launch.json / 纯ASCII目录 / \r\r\n
