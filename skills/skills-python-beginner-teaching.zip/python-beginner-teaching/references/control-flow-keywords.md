# continue / break / return 准确语义与教学要点

## 三者的精确行为

| 关键字 | 作用域 | 行为 | 循环是否继续 | 后续代码是否执行 | 类比 |
|---|---|---|---|---|---|
| `continue` | 循环内 | 跳过本次循环剩余部分，进入下一轮 | ✅ 继续 | ❌ 本次剩余不执行 | "这局不算，重开" |
| `break` | 循环内 | 直接跳出整个循环 | ❌ 终止 | ✅ 循环外的代码执行 | "游戏结束，退大厅" |
| `return` | **函数内** | 从函数返回，终止函数内一切执行 | ❌ 终止（连带） | ❌ 函数内后续全不执行 | "下班打卡，连人带工位消失" |

## 关键事实

1. **`return` 只能在函数内部使用**。在脚本顶层（不在任何 `def` 里）写 `return` → `SyntaxError: 'return' outside function`。
2. `return` 终止循环是**副作用**，它的本职是"终止函数"。
3. 只有 `continue` 会让循环继续跑。
4. `break` 后，循环之后的代码**正常执行**（它只跳出循环，不跳出函数）。

## 三个验证脚本（教学时直接跑）

### a_continue.py
```python
print("=== continue ===")
for i in range(1, 6):
    if i == 3:
        continue
    print(i)
print("循环外的句子")
# 输出: 1 2 4 5 + "循环外的句子"
```

### b_break.py
```python
print("=== break ===")
for i in range(1, 6):
    if i == 3:
        break
    print(i)
print("循环外的句子")
# 输出: 1 2 + "循环外的句子"
```

### c_return.py
```python
def check():
    print("=== return（在函数内部）===")
    for i in range(1, 6):
        if i == 3:
            return
        print(i)
    print("这句在循环后面，但因为 return 也走不到")

check()
print("函数外面的句子，会执行")
# 输出: 1 2 + "函数外面的句子，会执行"
# 注意: "这句在循环后面" 和 check() 后面的 print 都不执行
```

## 常见混淆对速查

| 混淆对 | 区别 | 一句话 |
|---|---|---|
| `=` vs `==` | 赋值 vs 相等判断 | `=` 存进去，`==` 比相等 |
| `sort()` vs `sorted()` | 原地修改(返回 None) vs 返回新列表 | `sort()` 吃掉原列表 |
| `append()` vs `extend()` | 加一个元素 vs 加一批元素 | `append([1,2])` 得到嵌套列表 |
| `%` 取余 vs `/` 除法 | 余数 vs 商 | `7 % 3 = 1`, `7 / 3 = 2.333...` |
| `continue` vs `break` vs `return` | 见上表 | 只有 continue 让循环继续 |