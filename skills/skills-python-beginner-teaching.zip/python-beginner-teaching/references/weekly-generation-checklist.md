# W4 起每周生成自检清单（生成完跑一遍，全过才交付）

## 1. 题面零代码泄漏
```powershell
Set-Location "D:\Hermes文件库\Python学习计划\第0N周_主题"
Get-Content task_0N_*.py | Select-String -Pattern '^\s*[^#\s]'
```
预期：无任何输出（有输出 = 有裸代码泄漏进题面，必须删）。
注意：PS5.1 的 Get-Content 读 UTF-8 无 BOM 文件会显示乱码但不影响正则判断（`#` 开头的行仍匹配不到裸代码模式）。

## 2. 答案实跑
```powershell
py answers\task_0N_1_示范.py   # 无输入类直接跑
# input 类：无 BOM 文件重定向（echo 管道首行会读空）：
[IO.File]::WriteAllText("$dir\_in.txt", "输入1`n输入2", (New-Object System.Text.UTF8Encoding($false)))
cmd /c "py answers\task_0N_5_完整.py < ..\_in.txt"
Remove-Item _in.txt
```
菜单循环类（while True + 多次 input）必须喂完整多步输入序列，验证：
- 每个功能分支至少走一次
- 退出分支正常 break
- 无效输入分支走一次

## 3. 分支覆盖核对表（每条都实测过）
- [ ] 主路径（正常输入）
- [ ] 边界分支（钱不够/次数用完/空背包/猜中）
- [ ] 无效输入分支（菜单选 9 之类）
- [ ] 退出路径干净（exit=0）

## 4. 输出比对
实跑输出与 0N_任务.md 里的「运行效果示例」逐字核对（数字/措辞/格式）。示例本身先在心里跑一遍——示例错了答案跟着错。
