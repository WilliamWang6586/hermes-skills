# 初学者高频内置方法对照表（实测口径）

用户反复问的几组「长得像但不一样」的方法，直接照抄表格讲，别重新组织语言。

## 1. 列表删除三法

```python
items = ["钻石", "木板", "铁镐", "苹果", "水", "火把"]
items.remove("水")        # 按值删，删第一个找到的，返回 None
popped = items.pop(1)     # 按索引删，返回被删的值
del items[0]              # 按索引删，不返回
```

| 写法 | 括号里填 | 返回值 | 找不到时 |
|---|---|---|---|
| `remove(x)` | **值** | `None` | `ValueError` |
| `pop(i)` | **索引** | 被删的值 | `IndexError` |
| `del x[i]` | **索引** | 无 | `IndexError` |

两个高频错：

- `items.remove(2)` —— 不是「删第 3 个」，是「删值为 2 的元素」
- `items = items.pop(1)` —— 灾难，整个列表变量被覆盖成那个字符串

**删完后面的元素整体前移，索引全变、len 减 1**（用户必问，先讲这条）。
所以「边遍历边删」会漏元素：`for x in nums: nums.remove(x)` 只删一半。
正确做法从后往前删：`for i in range(len(nums)-1, -1, -1): nums.pop(i)`，或 `nums.clear()`。

## 2. 反转三法

```python
rev = items[::-1]           # 新列表，原列表不变
items.reverse()             # 原地反转，返回 None
list(reversed(items))       # 迭代器要套 list()，原列表不变
```

坑：`rev = items.reverse()` → `rev` 是 `None`。

## 3. 排序两法

```python
new = sorted(items, key=lambda x: x[1], reverse=True)   # 返回新列表，原列表不变
items.sort(reverse=True)                                # 原地，返回 None
```

`key=lambda x: x[1]` 讲法：`lambda x : x[1]` = 参数 `x`、冒号右边是返回值，等价于

```python
def get_score(x):
    return x[1]
```

「按子列表第 2 项比大小」。嵌套列表 `[['小明',85], ...]` 直接 `sorted()` 会 `TypeError`，
必须给 `key`。第 8 周才讲函数，现在只让他照抄 + 记住等价写法。

## 4. 切片速记

- `[1:3]` = 索引 1、2，**含头不含尾**
- `[1:]` = 从索引 1 到末尾（题目说「到末尾」就该写这个，别写死 `[1:5]`）
- `[::-1]` = 倒序
- `[::2]` = 隔一个取一个

## 5. `enumerate` 两个参数

```python
for i, item in enumerate(items):            # i 从 0 开始
for i, item in enumerate(items, start=1):   # i 从 1 开始，不用写 i+1
```
