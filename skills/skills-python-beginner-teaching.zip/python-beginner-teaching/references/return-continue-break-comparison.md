# return/continue/break 三兄弟对比表（教学用）

## 核心区别
| 关键字 | 作用范围 | 行为 | 比喻 |
|---|---|---|---|
| `continue` | 循环内部 | 跳过本轮剩余代码，进入下一轮 | "这局不算，重开一局" |
| `break` | 循环内部 | 跳出整个循环，循环终止 | "游戏结束，退大厅" |
| `return` | 函数内部 | 从函数返回，函数+循环都结束 | "下班打卡，连人带工位消失" |

## 实测对比脚本

### 1. continue 示例
```python
print("=== continue ===")
for i in range(1, 6):
    if i == 3:
        continue      # 跳过 i==3 这一轮
    print(i)
print("循环外的句子")
```
**输出**：
```
=== continue ===
1
2
4
5
循环外的句子
```

### 2. break 示例
```python
print("=== break ===")
for i in range(1, 6):
    if i == 3:
        break        # 直接跳出整个循环
    print(i)
print("循环外的句子")
```
**输出**：
```
=== break ===
1
2
循环外的句子
```

### 3. return 示例（在函数内）
```python
def check():
    print("=== return ===")
    for i in range(1, 6):
        if i == 3:
            return   # 从函数返回，循环和函数都结束
        print(i)
    print("这句在循环后面，但因为 return 也走不到")

check()
print("函数外面的句子，会执行")
```
**输出**：
```
=== return ===
1
2
函数外面的句子，会执行
```

## 使用场景
- `continue`：过滤不需要的数据（如跳过 3 的倍数）
- `break`：找到目标后提前结束（如猜中数字、找到元素）
- `return`：函数需要返回结果时（如计算值、处理状态）

## 常见错误
1. **return 顶层脚本**：不在函数里用 `return` 会报 `SyntaxError: 'return' outside function`
2. **break 顺序错误**：如 continue 在 break 前面，可能让本该终止的被跳过
3. **忘记循环更新**：while 循环里忘记更新变量条件，导致死循环