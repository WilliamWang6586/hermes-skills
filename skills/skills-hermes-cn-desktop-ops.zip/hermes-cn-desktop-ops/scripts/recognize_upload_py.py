# -*- coding: utf-8 -*-
"""DashScope qwen-vl-max 识别图片（Windows Python 版，无参数长度限制）
用法: python recognize_upload_py.py <图片路径> [提示词]
Key: 从 ~/.hermes/.env 读 DASHSCOPE_API_KEY
"""
import base64, json, urllib.request, os, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# 1. 读 API Key
key = None
env_path = os.path.expanduser(r"~\.hermes\.env")
try:
    with open(env_path, encoding='utf-8', errors='replace') as f:
        for line in f:
            m = re.match(r'\s*DASHSCOPE_API_KEY\s*=\s*["\']?([^"\'\s]+)', line)
            if m:
                key = m.group(1)
                break
except Exception as e:
    print("读取 .env 失败:", e)
if not key:
    print("ERROR: DASHSCOPE_API_KEY 未找到")
    sys.exit(1)

# 2. 图片 base64
img_path = sys.argv[1] if len(sys.argv) > 1 else input("图片路径: ")
with open(img_path, 'rb') as f:
    b64 = base64.b64encode(f.read()).decode()
print(f"图片 base64: {len(b64)} 字符")

# 3. 调用 API
prompt = sys.argv[2] if len(sys.argv) > 2 else "这是用户上传的图片，请详细描述图片内容，包括所有文字。如果是错误提示或程序界面，请说明具体显示什么。"
payload = {
    "model": "qwen-vl-max",
    "messages": [
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                {"type": "text", "text": prompt}
            ]
        }
    ],
    "max_tokens": 800
}
req = urllib.request.Request(
    "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
    data=json.dumps(payload).encode('utf-8'),
    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
)
try:
    with urllib.request.urlopen(req, timeout=60) as r:
        d = json.load(r)
    if d.get('choices'):
        print(d['choices'][0]['message']['content'])
    elif d.get('error'):
        print("API 错误:", d['error'])
    else:
        print("未知响应:", str(d)[:500])
except Exception as e:
    print("调用失败:", e)
