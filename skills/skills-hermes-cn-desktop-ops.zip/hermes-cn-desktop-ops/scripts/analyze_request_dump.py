# -*- coding: utf-8 -*-
"""拆 Hermes request_dump —— 量每轮请求里 系统提示 / 工具 schema / messages 各占多少。

用法: python3.14 analyze_request_dump.py "<hermes-home>/sessions/request_dump_*.json"

request.body 是 JSON 字符串，需二次 json.loads。字符数/3 是粗 token 估算（中英混排）。
"""
import json
import os
import sys


def size(o):
    return len(json.dumps(o, ensure_ascii=False))


def main(p):
    d = json.load(open(p, encoding="utf-8"))
    body = d.get("request", {}).get("body")
    if isinstance(body, str):
        body = json.loads(body)
    msgs = body.get("messages", [])
    tools = body.get("tools", [])

    print("dump: %s  (%d bytes)" % (os.path.basename(p), os.path.getsize(p)))
    print("model: %s" % body.get("model"))

    print("\n=== messages: %d | %d chars (~%d tok) ===" % (len(msgs), size(msgs), size(msgs) // 3))
    for i, m in enumerate(msgs):
        c = m.get("content")
        cs = size(c) if c else 0
        if i == 0 or cs >= 3000:  # 只列 system 和大消息
            print("  [%d] %-10s %8d chars (~%dtok)" % (i, m.get("role"), cs, cs // 3))

    print("\n=== tools: %d | %d chars (~%d tok) ===" % (len(tools), size(tools), size(tools) // 3))
    for t in sorted(tools, key=size, reverse=True):
        fn = t.get("function", t)
        print("  %-34s %7d" % (fn.get("name", "?"), size(t)))

    print("\nTOTAL body: %d chars (~%d tok)" % (size(body), size(body) // 3))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3.14 analyze_request_dump.py <request_dump_*.json>")
        sys.exit(1)
    main(sys.argv[1])
