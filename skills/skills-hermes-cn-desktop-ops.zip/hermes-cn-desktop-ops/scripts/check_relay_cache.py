#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""缓存校验器：验证任意 OpenAI 兼容端点是否透传 DeepSeek 前缀缓存。

用法:
    python check_relay_cache.py <base_url> <api_key> [model]

原理:
    发两次完全相同的长 prompt（固定前缀 ~2400 token）。
    第1次 = cache miss（全价）；第2次 = cache hit（应命中大部分）。
    读 usage 的 prompt_cache_hit_tokens / prompt_tokens_details.cached_tokens。

判定:
    命中率 >= 50%  -> 缓存生效（✅） 退出码 0
    0 < 命中率 < 50% -> 部分生效（⚠️）前缀可能被中转改写  退出码 1
    == 0            -> 缓存失效（❌）该中转按全价扣费      退出码 1

⚠️ 重要局限: 本脚本只看【返回字段】。中转可以"字段活着但按全价扣费"
   （new-api 只在 ChannelTypeDeepSeek 分支映射计费字段）。
   要确认【真的省了钱】，必须改用余额扣减法 —— 见 references/ai-cost-audit.md。

自检: 对 https://api.deepseek.com 跑，应输出 命中率 >= 50%、退出码 0。
"""
import sys, json, time, urllib.request

PAD = "You are a rigorous assistant. " * 400   # ~2400 token 固定前缀


def call(base, key, model, msg):
    url = base.rstrip("/") + "/chat/completions"
    body = json.dumps({
        "model": model,
        "messages": [{"role": "system", "content": PAD},
                     {"role": "user", "content": msg}],
        "max_tokens": 16, "temperature": 0.0,
    }).encode()
    req = urllib.request.Request(url, data=body, headers={
        "Authorization": "Bearer " + key, "Content-Type": "application/json"})
    t0 = time.time()
    r = json.loads(urllib.request.urlopen(req, timeout=90).read().decode())
    return r, time.time() - t0


def extract(r):
    u = r.get("usage", {}) or {}
    hit = u.get("prompt_cache_hit_tokens")
    if hit is None:
        hit = (u.get("prompt_tokens_details") or {}).get("cached_tokens")
    return hit, u.get("prompt_tokens", 0) or 0, u


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    base, key = sys.argv[1], sys.argv[2]
    model = sys.argv[3] if len(sys.argv) > 3 else "deepseek-chat"

    print("端点: %s\n模型: %s\n%s" % (base, model, "-" * 60))
    res = []
    for i in (1, 2):
        try:
            r, dt = call(base, key, model, "Reply with exactly: OK%d" % i)
        except Exception as e:
            print("第%d次调用失败: %s" % (i, e))
            sys.exit(1)
        hit, tot, u = extract(r)
        res.append((hit or 0, tot))
        print("第%d次  %.2fs  model=%s" % (i, dt, r.get("model")))
        print("       输入=%s  缓存命中=%s  usage=%s"
              % (tot, hit, json.dumps(u, ensure_ascii=False)))
        time.sleep(1.5)

    h2, t2 = res[1]
    ratio = h2 / t2 if t2 else 0
    print("-" * 60)
    if ratio >= 0.5:
        print("OK 缓存生效: 命中率 %.1f%%" % (ratio * 100))
    elif ratio > 0:
        print("WARN 部分生效: 命中率 %.1f%% (前缀可能被改写)" % (ratio * 100))
    else:
        print("FAIL 缓存失效: 第2次命中 0 -> 该端点按全价扣费，方案作废")
        print("     (注意: 也要核对余额扣减，字段可能只是显示正常)")
    sys.exit(0 if ratio >= 0.5 else 1)


if __name__ == "__main__":
    main()
