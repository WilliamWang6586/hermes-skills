"""把 state.db 里所有会话的 model 统一成指定值。

为什么分两步：
  - Hermes 运行时对 state.db 独占锁 → 直接写必报 `disk I/O error`
  - 但**副本不受锁影响** → 先在副本上改，等桌面端退出后再把副本换上去

用法（WSL 跑，HERMES_HOME 指向 hermes-home 的 /mnt/c 路径）：
  python3 fix_session_models.py --build --target deepseek-flash   # 生成 state.db.fixed
  python3 fix_session_models.py --swap                            # 桌面端已退出，替换

坑（实测）：
  - 判锁只认 Windows 侧（[IO.File]::Open ... 'None'）；WSL 的 open('r+b') 可能假性成功
  - 用户可能关了窗口又立刻重开 → swap 前必须查 state.db-wal 非空就拒跑
"""
import os, sys, json, time, shutil, sqlite3, argparse

ap = argparse.ArgumentParser()
ap.add_argument("--target", default="deepseek-flash")
ap.add_argument("--provider", default="deepseek")
ap.add_argument("--base-url", default="https://api.deepseek.com")
ap.add_argument("--build", action="store_true")
ap.add_argument("--swap", action="store_true")
ap.add_argument("--session", default=None, help="只改这一条会话 id")
args = ap.parse_args()

home = os.environ.get("HERMES_HOME") or sys.exit("!! 先 export HERMES_HOME")
db = os.path.join(home, "state.db")
fixed = db + ".fixed"
T = args.target


def build():
    tmp = db + ".work"
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(db + ext):
            shutil.copy2(db + ext, tmp + ext)
    con = sqlite3.connect(tmp, timeout=30)
    cur = con.cursor()
    rows = cur.execute("select id, model, model_config from sessions").fetchall()
    todo = [(sid, mc) for sid, m, mc in rows
            if m != T and (args.session is None or sid == args.session)]
    for sid, mc in todo:
        try:
            cfg = json.loads(mc) if mc else {}
        except Exception:
            cfg = {}
        cfg.update(model=T, provider=args.provider, base_url=args.base_url)
        cur.execute("update sessions set model=?, model_config=? where id=?",
                    (T, json.dumps(cfg, ensure_ascii=False), sid))
    con.commit()
    left = cur.execute("select count(*) from sessions where model<>? ", (T,)).fetchone()[0]
    con.close()
    for ext in ("-wal", "-shm"):
        p = tmp + ext
        if os.path.exists(p):
            os.remove(p)
    if os.path.exists(fixed):
        os.remove(fixed)
    os.replace(tmp, fixed)

    c = sqlite3.connect(fixed)
    bad = c.execute("select count(*) from sessions where model<>? ", (T,)).fetchone()[0]
    c.close()
    assert args.session or bad == 0, "自检失败：副本里还有 %d 条不是 %s" % (bad, T)
    print("已改 %d 条 | 剩余未统一 %d | 副本 -> %s" % (len(todo), left, fixed))


def swap():
    if not os.path.exists(fixed):
        sys.exit("!! 先跑 --build")
    wal = db + "-wal"
    if os.path.exists(wal) and os.path.getsize(wal) > 0:
        sys.exit("!! state.db-wal 非空：Hermes 没退干净，别换")
    try:
        fh = open(db, "r+b")
        fh.close()
    except OSError:
        sys.exit("!! state.db 仍被占用，先彻底退出桌面端（托盘 → 退出）")

    bak = db + ".bak-" + time.strftime("%Y%m%d_%H%M%S")
    shutil.copy2(db, bak)
    os.replace(db, db + ".old")
    os.replace(fixed, db)
    for ext in ("-wal", "-shm"):
        p = db + ext
        if os.path.exists(p):
            os.remove(p)
    os.remove(db + ".old")

    c = sqlite3.connect(db)
    bad = c.execute("select count(*) from sessions where model<>? ", (T,)).fetchone()[0]
    total = c.execute("select count(*) from sessions").fetchone()[0]
    c.close()
    assert bad == 0, "替换后自检失败：%d/%d 条仍非 %s" % (bad, total, T)
    print("已替换并自检通过（%d 条全为 %s）。备份 -> %s" % (total, T, bak))
    print("重启桌面端后看 logs/agent.log 应出现 model=%s" % T)


if __name__ == "__main__":
    if args.swap:
        swap()
    else:
        build()
