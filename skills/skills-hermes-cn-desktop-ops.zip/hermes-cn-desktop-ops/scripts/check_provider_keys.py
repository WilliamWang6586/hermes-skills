# -*- coding: utf-8 -*-
"""扫各家 provider key 是否可用 / 欠费 / key 失效（对每家发最小 1-token 请求）。

用法:  python3.14 check_provider_keys.py
改 HERMES_HOME 或 TESTS 列表即可复用到其它机器。
只读：不写任何配置，只打印结果。
"""
import json
import os
import urllib.error
import urllib.request

HERMES_HOME = os.path.join(
    os.environ.get("LOCALAPPDATA", ""),
    "Hermes Agent CN Desktop", "data", "hermes-home",
)
ENV_PATH = os.path.join(HERMES_HOME, ".env")

# (显示名, chat/completions URL, 模型, .env 里的 key 变量名)
TESTS = [
    ("deepseek",   "https://api.deepseek.com/chat/completions",                          "deepseek-v4-flash",           "DEEPSEEK_API_KEY"),
    ("alibaba",    "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions", "qwen3.7-plus",                "DASHSCOPE_API_KEY"),
    ("volcengine", "https://ark.cn-beijing.volces.com/api/v3/chat/completions",          "doubao-seed-2-0-lite-260428", "ARK_API_KEY"),
    ("xiaomi",     "https://token-plan-cn.xiaomimimo.com/v1/chat/completions",           "mimo-v2.5-pro",               "XIAOMI_TOKEN_PLAN_API_KEY"),
    ("minimax-cn", "https://api.minimaxi.com/v1/text/chatcompletion_v2",                 "MiniMax-M3",                  "MINIMAX_CN_API_KEY"),
    # 同一家要分别探 flash 与旗舰：智谱 flash 免费、旗舰欠费（2026-10-06 实测）
    ("zai-flash",  "https://open.bigmodel.cn/api/paas/v4/chat/completions",              "glm-5.3-flash",               "GLM_API_KEY"),
    ("zai-旗舰",   "https://open.bigmodel.cn/api/paas/v4/chat/completions",              "glm-5.3",                     "GLM_API_KEY"),
]


def load_env(path):
    keys = {}
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                keys[k.strip()] = v.strip().strip('"').strip("'")
    return keys


def probe(url, model, key):
    body = json.dumps({"model": model, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 1}).encode()
    req = urllib.request.Request(url, data=body, headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            r.read()
            return "✅ 可用"
    except urllib.error.HTTPError as e:
        return f"❌ HTTP {e.code}  {e.read().decode('utf-8', 'ignore')[:160]}"
    except Exception as e:
        return f"❌ {type(e).__name__}: {str(e)[:140]}"


def main():
    assert os.path.exists(ENV_PATH), f"找不到 .env: {ENV_PATH}"
    keys = load_env(ENV_PATH)
    assert keys, ".env 解析为空，检查格式"
    for name, url, model, envkey in TESTS:
        key = keys.get(envkey)
        if not key:
            print(f"{name:12} ✗ 无 {envkey}（未配置）")
            continue
        print(f"{name:12} {probe(url, model, key)}")


if __name__ == "__main__":
    main()
