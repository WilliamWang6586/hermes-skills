import sqlite3, json, shutil, time, os

HOME = os.path.expandvars(r"%LOCALAPPDATA%\Hermes Agent CN Desktop\data\hermes-home")
UI = os.path.join(HOME, "desktop-ui.sqlite")
ST = os.path.join(HOME, "state.db")
KEY = "hermes-cn-ui.pinnedSessionIds"


def show():
    c = sqlite3.connect("file:" + UI + "?mode=ro", uri=True)
    row = c.execute("select value_json from ui_kv where key=?", (KEY,)).fetchone()
    ids = json.loads(row[0]) if row else []
    s = sqlite3.connect("file:" + ST + "?mode=ro", uri=True)
    for i in ids:
        r = s.execute("select title,source,message_count,archived from sessions where id=?", (i,)).fetchone()
        print(i, "->", r if r else "!! NOT IN state.db")
    print("total", len(ids))


def pin(ids):
    """整批写回置顶。桌面端必须先托盘退出，否则进程内存态会盖回。"""
    shutil.copy2(UI, UI + ".bak-" + time.strftime("%Y%m%d_%H%M%S"))
    s = sqlite3.connect("file:" + ST + "?mode=ro", uri=True)
    ids = [i for i in ids if s.execute("select 1 from sessions where id=? and archived=0", (i,)).fetchone()]
    c = sqlite3.connect(UI)
    c.execute("insert or replace into ui_kv(key,value_json,updated_at) values(?,?,?)",
              (KEY, json.dumps(ids), int(time.time() * 1000)))
    c.commit(); c.close()
    print("pinned", len(ids), ids)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        pin(sys.argv[1:])
    show()
