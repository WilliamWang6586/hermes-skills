"""最小 MCP stdio 探针：initialize -> notifications/initialized -> tools/list。

用途：装完 MCP server 包后、改 Hermes config 之前，先确认 server 本身能起。
用法（PS）：
    $env:PYTHONUTF8=1; python3.14 mcp_stdio_probe.py <可执行文件> [参数...]
例：
    python3.14 mcp_stdio_probe.py C:\\Users\\x\\.local\\bin\\uvx.exe windows-mcp serve
    python3.14 mcp_stdio_probe.py node.exe path/to/server.mjs mcp
"""
import json
import subprocess
import sys


def main(argv):
    if len(argv) < 2:
        print("usage: mcp_stdio_probe.py <command> [args...]")
        return 2

    p = subprocess.Popen(argv[1:], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8", bufsize=1)

    def send(obj):
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()

    try:
        send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
              "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                         "clientInfo": {"name": "probe", "version": "1"}}})
        init = json.loads(p.stdout.readline())
        info = init.get("result", {}).get("serverInfo", {})
        print("SERVER:", info.get("name"), info.get("version"))

        send({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
        send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        tools = json.loads(p.stdout.readline()).get("result", {}).get("tools", [])
        print("TOOL_COUNT:", len(tools))
        print("TOOLS:", [t["name"] for t in tools])
        assert tools, "server returned zero tools"
        return 0
    finally:
        p.kill()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
