' Hermes Gateway Guard - 启动后自检并确保网关单实例存活
' 2026-09-20 新建：解决"双实例互顶 dispatcher 锁 / 网关挂死无人拉起"导致的反复"重连"
'
' ⚠️ 本文件必须存为 UTF-16LE(BOM) 或 ANSI/GBK！
'    UTF-8 无 BOM 会被 WSH 按 GBK 读 → 中文用户名路径乱码 → 弹 "80070003 系统找不到指定的路径"
'    写回方法： [System.IO.File]::WriteAllText($p,$t,[System.Text.Encoding]::Unicode)
' 安装位置： %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Hermes_GatewayGuard.vbs
Option Explicit

Dim sh, fso, home, ver, exe, logFile, logs, i, n, killed
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' ---- 按本机实际路径改这两行（中文用户名照写，编码正确就不会乱）----
home = "C:\Users\<用户名>\AppData\Local\Hermes Agent CN Desktop\data\hermes-home"
ver  = "C:\Users\<用户名>\AppData\Local\Hermes Agent CN Desktop\data\versions\0.19.0-cn.7"

exe  = ver & "\hermes-agent-cn-runtime-win32-x64.exe"
logFile = home & "\logs\gateway-guard.log"

' 等系统/网络就绪（开机后 3 分钟；测试时可临时改 0）
WScript.Sleep 180000

' ---- 数当前有几个网关进程（VBS 没有 Get-Process，wmic 最稳）----
Set logs = sh.Exec("cmd /c wmic process where ""name='hermes-agent-cn-runtime-win32-x64.exe'"" get commandline /format:csv")
Dim out: out = logs.StdOut.ReadAll()
n = 0
Dim lines: lines = Split(out, vbCrLf)
For i = 0 To UBound(lines)
  If InStr(lines(i), "gateway run") > 0 Then n = n + 1
Next

If n = 1 Then
  Log logFile, fso, "OK 单实例存活，无需处理"
ElseIf n = 0 Then
  Log logFile, fso, "未发现网关进程 → 拉起"
  StartGateway sh, home, ver, exe
Else
  Log logFile, fso, "发现 " & n & " 个实例 → 全杀后重启单实例"
  sh.Run "cmd /c taskkill /F /IM hermes-agent-cn-runtime-win32-x64.exe", 0, True
  WScript.Sleep 4000
  StartGateway sh, home, ver, exe
End If

Sub StartGateway(sh, home, ver, exe)
  Dim env
  Set env = sh.Environment("PROCESS")
  env.Item("HERMES_HOME") = home
  env.Item("PYTHONIOENCODING") = "utf-8"
  env.Item("HERMES_GATEWAY_DETACHED") = "1"
  env.Item("VIRTUAL_ENV") = ver & "\.."
  env.Item("PYTHONPATH") = ver & "\_internal"
  ' 清代理残留 —— 防止继承 VPN 死端口导致"关 VPN 后不响应"
  env.Item("HTTP_PROXY") = ""
  env.Item("HTTPS_PROXY") = ""
  env.Item("ALL_PROXY") = ""
  env.Item("http_proxy") = ""
  env.Item("https_proxy") = ""
  env.Item("all_proxy") = ""
  sh.CurrentDirectory = home
  sh.Run """" & exe & """ -m hermes_cli.main gateway run", 0, False
End Sub

Sub Log(path, fso, msg)
  Dim f, ts
  ts = Year(Now) & "-" & Right("0" & Month(Now),2) & "-" & Right("0" & Day(Now),2) & " " & _
       Right("0" & Hour(Now),2) & ":" & Right("0" & Minute(Now),2) & ":" & Right("0" & Second(Now),2)
  On Error Resume Next
  Set f = fso.OpenTextFile(path, 8, True, -1)   ' -1 = Unicode(UTF-16LE)，否则中文日志乱码
  f.WriteLine ts & "  " & msg
  f.Close
End Sub
