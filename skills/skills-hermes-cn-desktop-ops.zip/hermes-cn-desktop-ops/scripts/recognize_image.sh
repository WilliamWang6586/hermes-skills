#!/bin/bash
# recognize_image.sh — 用 DashScope qwen-vl-max 识别任意图片（中文描述）
# 用途：主模型为纯文本（DeepSeek 等）时，作为 vision_analyze 的兜底。
# 用法：bash recognize_image.sh <image_path>
#       示例: bash recognize_image.sh "/mnt/c/Users/<user>/.../images/upload_xxx.png"
# 依赖：DASHSCOPE_API_KEY 在 ~/.hermes/.env；wsl 环境有 base64 + curl + python3

IMG="$1"
if [ -z "$IMG" ] || [ ! -f "$IMG" ]; then
    echo "Usage: $0 <image_path>" >&2
    exit 1
fi

KEY=$(grep DASHSCOPE /mnt/c/Users/王子涵/.hermes/.env 2>/dev/null | cut -d= -f2)
if [ -z "$KEY" ]; then
    echo "ERROR: DASHSCOPE_API_KEY not found in ~/.hermes/.env" >&2
    exit 1
fi

PROMPT="${2:-这是用户上传的图片，请详细描述图片内容，包括所有文字。如果是错误提示或程序界面，请说明具体显示什么。}"

B64=$(base64 -w0 "$IMG")

curl -s "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"model\": \"qwen-vl-max\",
    \"messages\": [
      {
        \"role\": \"user\",
        \"content\": [
          {\"type\": \"image_url\", \"image_url\": {\"url\": \"data:image/png;base64,$B64\"}},
          {\"type\": \"text\", \"text\": \"$PROMPT\"}
        ]
      }
    ],
    \"max_tokens\": 500
  }" --max-time 30 | python3 -c "
import sys, json
d = json.load(sys.stdin)
if d.get('choices'):
    print(d['choices'][0]['message']['content'])
elif d.get('error'):
    print('Error:', d['error'].get('message',''))
else:
    print('Unknown:', str(d)[:300])
"
