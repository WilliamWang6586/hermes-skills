# QQ Bot 网关排障全量手册（原独立技能 hermes-qq-bot-gateway-ops，2026-10 并入）

QQ 官方机器人 + 微信网关跑在同一个 `hermes-agent-cn-runtime-win32-x64.exe gateway run` 进程里。

## 1. 连接断了 / 一直要重连

最常见根因：**QQ Bot WebSocket 断开后重连失败，然后永久卡死**（日志只出现一次 `Reconnecting in 2s (attempt 1)` 就再也不动，或 `Reconnect failed: Failed to get QQ Bot gateway URL`）。

先别急着重启 —— 先看日志定位：

```powershell
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'gateway run' -and $_.Name -match 'hermes' } | Select ProcessId
Select-String -Path "C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\logs\gateway.log" -Pattern "Ready|Reconnect failed|WebSocket error|Session resumed|dispatcher" | Select-Object -Last 8
```

分层判断：
- `Session resumed` 频繁出现 = 正常 QQ 心跳（每 ~30 分钟服务器要求重连一次），自动恢复，无需干预。
- 出现 `Reconnecting...` 后**再无后续** = 卡死，看第 3 节。
- `Failed to get QQ Bot gateway URL: ...SSL...certificate key too weak` = QQ CDN 边缘节点瞬时弱证书，先 curl 实测再重启：

```powershell
curl.exe -s -o NUL -w "code=%{http_code} ssl=%{ssl_verify_result}" https://api.sgroup.qq.com/websocket
```

`ssl_verify_result=0` → 证书此刻正常，是瞬时故障，重启网关即可。

### 1.5 最快确认卡死：比日志时间戳

```powershell
$l = Get-Item "C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\logs\gateway.log"
"日志末行: $($l.LastWriteTime)  现在: $(Get-Date)"
Resolve-DnsName api.sgroup.qq.com -Type A | Select-Object IPAddress
```

日志末行比现在早 10 分钟以上、尾部是 `Reconnect failed: ... getaddrinfo failed` → **重连循环已死**。若 DNS 此刻已恢复但日志仍不动 = 印证「瞬时网络抖动触发异常、循环被杀死」，**不是网络还坏**。处置 = 直接干净重启，别等、别反复重试。

⚠️ `getaddrinfo failed`（DNS 瞬时失败）比 SSL 弱证书更常见 —— 校园网/切网/开关 VPN 的瞬间最容易踩。它本身自愈，卡死的是循环，所以每次发生都该确认第 2 节补丁在不在。

## 2. 根因修复：适配器重连循环被异常杀死

`MAX_RECONNECT_ATTEMPTS=100`、退避 `[2,5,10,30,60]` 都够，但 **`_reconnect()` 抛异常（gateway URL 获取失败是 raise 而非 return False）时直接杀死整个重连循环**。

文件：`data\versions\<ver>\_internal\plugins\platforms\qqbot\adapter.py`（约第 647-651 行）

```python
# 原：if await self._reconnect(backoff_idx):
# 改：
try:
    _ok = await self._reconnect(backoff_idx)
except Exception:
    _ok = False
if _ok:
    backoff_idx = 0
    quick_disconnect_count = 0
else:
    backoff_idx += 1
```

用 Python 写文件（PS 直接改中文会乱码），改前备份 `adapter.py.bak-<date>`。改完 `python -m py_compile` 校验，再重启网关。

⚠️ **升级 Hermes CN Desktop 后必须重新打这个补丁**（`_internal` 随版本被覆盖）。升级后第一件事：核对该段是否仍是裸 `if await self._reconnect(...)`。

## 3. 兜底：干净重启（单实例！）

```powershell
Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'gateway run' -and $_.Name -match 'hermes' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep 4
Start-Process -FilePath "C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\versions\0.19.0-cn.7\hermes-agent-cn-runtime-win32-x64.exe" -ArgumentList "gateway","run","--replace" -WindowStyle Hidden
Start-Sleep 15
Get-Content "...\hermes-home\logs\gateway.log" -Tail 6
```

**必须确认只有一个 `gateway run` 进程**。两个实例抢 `kanban dispatcher lock`，新起的「不派发消息」（`another gateway already holds the dispatcher lock; this gateway will NOT dispatch`），表现为消息收不到/要反复重连。看到这条就杀全部重新拉起单实例。

`hermes gateway restart` 可能拒绝 —— 报「检测到已安装的 Windows Hermes 网关服务（非桌面端托管）」是**假阳性**（Get-Service 查不到该服务），不要按提示 uninstall，直接跳过 CLI。

## 4. QQ 群消息发不出去

三件事缺一不可：
1. 机器人被拉进群（openid 要出现在频道目录）
2. **`platforms.qqbot.extra.group_policy` 在 config.yaml 里设为 `open`** —— ⚠️ 它**覆盖 .env 的 `QQ_GROUP_POLICY`**（适配器 `_is_group_allowed` 只读 config）。改 .env 无效。
3. `.env` 里 **`QQ_ALLOW_ALL_USERS=true`** —— 安全护栏：group_policy=open 没这个会直接拒绝启动（`Refusing to start: ... if neither GATEWAY_ALLOW_ALL_USERS nor QQ_ALLOW_ALL_USERS is enabled`）。DM 仍受 `dm_policy: allowlist` 保护。

群消息被丢弃时 `_handle_group_message` 在 policy 检查处直接 return、**不落日志**，所以日志里没记录 ≠ 没消息。

群 `group_openid` 从哪拿：让用户在群里 @ 机器人，看网关日志的 inbound 行。`GET /v2/groups` 对该 bot 类型返回 **404**，只能靠群消息事件拿。已注册频道见 `hermes-home\channel_directory.json`。

**官方机器人还要在 QQ 开放平台后台给机器人开通"群聊消息"能力 + 白名单群里**，否则平台根本不转发群事件（群里只回"机器人服务异常"）。这是平台侧配置，本地改不了。

移植适配器后注意：新版 gateway 重连调用 `connect(is_reconnect=...)` 会报 `unexpected keyword argument` 导致重连死循环 → 把 `async def connect(self) -> bool:` 改为 `async def connect(self, is_reconnect: bool = False) -> bool:`。

## 5. 微信侧「iLink sendmessage rate limited; cooldown active for 30.0s」

**这不是连接故障** —— 网关日志里微信始终是 `✓ weixin connected`，`weixin/accounts/<acct>@im.bot.sync.json` 的 `get_updates_buf` 游标持续更新 = 接收轮询正常。

含义：iLink（微信）对机器人**主动发送**（`hermes send` / 主动推送）有配额。
- 反复执行 `hermes send --to weixin ...` 每次都返回 `cooldown active for 30.0s`，**等待 45~65 秒后重试仍被拒**。
- 说明冷却计时被每次新尝试刷新，或当天主动推送额度已耗尽 —— 靠等待**无法**恢复。

处置：
1. 不要反复重试（只会持续刷新冷却）。停 5~10 分钟再试一次即可区分短冷却 vs 日配额。
2. **被动回复不受此限制**：让用户直接在微信里给 bot 发一条消息，bot 回复即可验证链路正常。
3. 日配额已尽 → 等次日；主动推送类定时任务失败时优先怀疑这条。

## 6. 主动给用户发文件（`hermes send` + `MEDIA:`）

```powershell
hermes send --list                                  # 先看可用目标
#  Qqbot:
#    qqbot:64DA51D14D10994791BFD51D9F64B177 (dm)
hermes send --to qqbot:<openid> "说明文字...
MEDIA:C:\path\to\file.pptx"
```

`--help` 原文：**"To send an image/document as an attachment, use `MEDIA:<path>` in the message text instead."**

| 坑 | 处理 |
|---|---|
| **PowerShell 把 `&` 当后台符**，`& $exe send ...` 直接被拒 | 用 `subprocess.run([exe, "send", ...])`，**别在 PS 里拼这条命令** |
| **PS here-string / 中文参数被吞或损坏** | 同上 —— 一律走 Python `subprocess`，argv 列表 + UTF-8 |
| **MEDIA 路径带空格会被截断** | 先 `shutil.copyfile` 到无空格路径（如 `<hermes-home>\_qqsend.pptx`）再发 |
| 目标写法 | `qqbot:<openid>` 发私聊；裸 `qqbot` 发 home channel |

```python
r = subprocess.run([EXE, "send", "--to", "qqbot:<openid>", f"说明...\nMEDIA:{staged}"],
                   capture_output=True, text=True, encoding="utf-8", errors="replace")
# r.returncode == 0 且 stdout 含 "Sent to qqbot home channel (chat_id: ...)"
```

### ⚠️ 发送成功 ≠ 能自证送达（汇报时务必说清）

`hermes send` 返回 `exit 0` + `Sent to ...` 只证明**平台 API 接受了消息**。它是独立进程直连平台 API、不经过 gateway，所以 **`gateway.log` 里不会有本次发送的记录** —— 日志末行可能还停在几十分钟前。

**不要因为日志没更新就判成失败**，也**不要因为 `exit 0` 就断言"已送达"**。想确认送达只有两条路：用户确认（最可靠，尤其带附件）或平台后台统计（一般拿不到）。

汇报模板：「发送 API 返回成功（exit 0），**请在 QQ 确认是否收到附件**」。

## 7. 验证

- 日志出现 `✓ qqbot connected` + `Ready, session_id=...` + `holding singleton dispatcher lock` = 正常。
- 发给用户一条测试消息确认通路。

## 关键词

QQ Bot / 微信网关 / gateway / qqbot-platform / 重连 / dispatcher lock / 群消息 / group_policy / QQ_ALLOW_ALL_USERS / weixin / iLink / rate limited / cooldown / getaddrinfo failed / 日志不刷新 / hermes send / MEDIA / 发文件 / 主动推送 / 附件
