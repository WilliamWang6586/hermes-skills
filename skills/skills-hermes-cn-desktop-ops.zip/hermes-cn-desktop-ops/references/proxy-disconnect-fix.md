# Hermes 断连根因：代理残留三件套（2026-09-02 / 09-13 两次实战）

## 症状

用户开启过 VPN/代理（本机是**夜煞云 yeshayun**，`C:\Program Files\yeshayun\`，本地端口 7892）后：

- **关闭"系统代理"开关** → Hermes 能响应
- **完全退出 VPN / 断开链接** → Hermes 卡住、不响应
- 用户直觉会认为是"IP 问题"或"网络不通"，**实际是本地代理残留**

## 根因：Python 解析代理的顺序 + 三处残留源

Python HTTP 客户端（`urllib.request.getproxies()` / requests）按顺序取：

1. **环境变量** `HTTP_PROXY` / `HTTPS_PROXY` / `ALL_PROXY`（最高优先级）
2. **Windows 系统代理注册表**

代理软件会**同时污染两处**，且各有独立的固化/读取时机：

| # | 残留源 | 位置 | 生效时机 | 为什么难发现 |
|---|--------|------|---------|-------------|
| 1 | 注册表环境变量 | `HKCU:\Environment` 的 `HTTP_PROXY` 等 | gateway **进程启动时继承**，启动后固化 | 改注册表对**已运行进程无效**；必须进程重启才生效 |
| 2 | 系统代理注册表 | `HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings` → `ProxyEnable` / `ProxyServer` | Python **每次请求实时读** | 代理退出后端口 7892 消失，但注册表还指着它 → 请求发往死端口 → 卡死 |
| 3 | terminal 会话自身 env | Hermes `terminal` 工具的 shell | shell 在代理开启时启动 → env 固化 | `$env:HTTP_PROXY=$null` 只影响后续命令，**这个 shell 自己**仍带着旧值 |

**关键推论**：三处必须**全部**清理，且 gateway 进程必须在**清理完成之后**、从**干净环境**重启。任何一步顺序错了，新进程又会继承代理 —— 这是同一次故障"修了三次才成功"的原因。

## 诊断命令（按序，一步步缩小）

```powershell
# ① 一锤定音：Python 实际读到的代理
python3.14 -c "import urllib.request; print(urllib.request.getproxies())"
#   返回 {'all': 'http://127.0.0.1:7892', ...} = 还有残留
#   返回 空 dict / EMPTY                  = 干净

# ② 查三处残留源
$env:HTTP_PROXY                                                      # 会话 env
Get-ItemProperty HKCU:\Environment | Select HTTP_PROXY,HTTPS_PROXY,ALL_PROXY   # 注册表 env
$s = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
"ProxyEnable=$($s.ProxyEnable) ProxyServer=[$($s.ProxyServer)]"        # 系统代理
netsh winhttp show proxy                                              # WinHTTP（通常无关，Direct 即正常）

# ③ 谁在监听代理端口 / 谁连着它
Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 7892 | Select OwningProcess
Get-NetTCPConnection -State Established | Where-Object { $_.OwningProcess -eq <PID> -and $_.RemotePort -eq 7892 }

# ④ Hermes 进程清单 + 命令行（区分 gateway / dashboard / desktop）
Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'hermes-agent-cn' } |
  Select-Object ProcessId, ParentProcessId, Name, CommandLine | Format-List
```

**判定成功的两条硬标准**（缺一不可）：
1. `getproxies()` 返回空
2. 目标进程**没有**到 7892 的 Established 连接；它的外连应是公网 IP 直连（微信/QQ 服务器 42.81.x / 101.227.x 等）

## 修复（顺序至关重要）

```powershell
# 步骤 1：清注册表环境变量（先备份）
Get-ItemProperty HKCU:\Environment | Select HTTP_PROXY,HTTPS_PROXY,ALL_PROXY,NO_PROXY |
  ConvertTo-Json | Set-Content D:\Hermes文件库\proxy_env_backup.json -Encoding UTF8
Remove-ItemProperty HKCU:\Environment -Name HTTP_PROXY,HTTPS_PROXY,ALL_PROXY,NO_PROXY -ErrorAction SilentlyContinue

# 步骤 2：关系统代理注册表（不要恢复！测试后也别恢复成 1）
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable -Value 0
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyServer -Value ""

# 步骤 3：确认 Python 已读不到代理（必须为空才继续）
python3.14 -c "import urllib.request; print(urllib.request.getproxies() or 'EMPTY')"

# 步骤 4：在【同一条命令】里清 env + 杀旧进程 + 干净环境重启
#   ⚠️ 后台启动脚本的第一行也要再清一遍 env，否则子进程继承 shell 的旧值
$env:HTTP_PROXY=$null; $env:HTTPS_PROXY=$null; $env:ALL_PROXY=$null; $env:NO_PROXY=$null
Stop-Process -Id <旧gatewayPID> -Force
& "<versions>\hermes-agent-cn-runtime-win32-x64.exe" -m hermes_cli.main gateway run --replace
```

重启后验证：`logs\gateway.log` 出现 `✓ qqbot connected` + `✓ weixin connected` + `Gateway running with 2 platform(s)`。

## ⚠️ 操作顺序铁律（本次最大的坑）

**绝不能先杀 VPN 再修 Hermes。** Hermes 自己就走在这条代理上，杀了 VPN 的瞬间 agent 就失联，没法继续操作（等于自断手脚）。

正确顺序：**先把 Hermes 切到直连并重启验证 → 再关 VPN → 再验证一次**。

若写自动化脚本，务必分成两个阶段执行，中间留出"确认 agent 仍在线"的检查点：
- 阶段 A：关系统代理注册表 + 重启 gateway（不动 VPN），验证直连 OK
- 阶段 B：确认 A 成功后，才退出 VPN 进程，再验证

## Hermes 进程拓扑（本机）

`hermes-agent-cn-desktop.exe`（Electron 壳）→ 子进程 `hermes-agent-cn-runtime-win32-x64.exe`。runtime 有两种角色，**由 CommandLine 区分**：

| 角色 | CommandLine 特征 | 作用 |
|------|-----------------|------|
| gateway | `-m hermes_cli.main gateway run` | 微信/QQ 等消息平台通道 |
| dashboard | `-m hermes_cli.main dashboard --host 127.0.0.1 --port ...` | 桌面 UI / 本地面板服务 |

**重要**：只重启 gateway **不会**让桌面 UI 会话脱离代理 —— 它跑在 desktop 派生的 runtime 上。要彻底清理，桌面应用本体也得重启。本次就是"重启了 gateway 但桌面 UI 仍卡"，漏掉了这一层。

退出 VPN 的进程名（夜煞云）：`yeshayun` / `yeshayunCore`（**监听 7892 的是它**）/ `yeshayunHelperService`。

## 校园网 A 类 IP 的边界（与代理无关，别混淆）

关 VPN 后在吉大校园网裸连，以下**直连正常**（2026-09-13 实测，`--noproxy "*"`）：

- `api.deepseek.com` → 401（未带 key 的正常响应，说明网络通）
- `ilinkai.weixin.qq.com` → 404（域名可达）
- `api.sgroup.qq.com` → 404（域名可达）

境外站点（github.com / Steam 国际服）不通是**校园网无国际出口**导致的预期行为，不是代理 bug。

### GitHub 访问方案（2026-09-13 实测，裸连无 VPN）

| 方式 | 结果 |
|------|------|
| github.com 直连 | ❌ 超时 |
| kgithub.com 镜像 | ❌ 超时（**已失效，弃用**） |
| **ghproxy.net** | ✅ 200，最快 ~1.1s，clone/下载/raw 全通 |
| gh-proxy.com / ghfast.top | ✅ 备选 |

用法：任意 `https://github.com/...` 前加 `https://ghproxy.net/`，例如
`git clone https://ghproxy.net/https://github.com/<owner>/<repo>.git`（已实测 clone 成功）。
Steam 走 Watt Toolkit Hosts 加速（仅国内 CDN，勿开代理模式）。

## 收尾检查表

- [ ] `getproxies()` 为空
- [ ] `ProxyEnable=0` 且 `ProxyServer` 为空
- [ ] 所有 Hermes runtime 进程无 7892 连接
- [ ] gateway.log 两条 `✓ ... connected`
- [ ] 云端/平台链路直连测试通过（deepseek / weixin / qq 三个域名）
- [ ] 用户完全退出 VPN 后，agent 仍能响应（终极验收）
