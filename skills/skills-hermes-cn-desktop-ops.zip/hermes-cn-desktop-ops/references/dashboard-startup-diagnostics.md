# Dashboard 启动失败：端口排除区间诊断

适用：桌面端报 `Dashboard startup failed`、`dashboard exited before ready`，尤其伴随 Windows `WinError 10013`。

## 先验证，不要先重启服务

1. 确认桌面端、Dashboard runtime 与端口归属：

```powershell
Get-NetTCPConnection -State Listen -LocalPort 9119,9120,9121,9122 -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process | Where-Object {
  $_.Name -match 'hermes-agent-cn-runtime|hermes-agent-cn-desktop'
} | Select-Object ProcessId,ParentProcessId,Name,CommandLine
```

2. 检查当前端口排除区间：

```powershell
netsh interface ipv4 show excludedportrange protocol=tcp
```

只有当 Dashboard 候选端口（通常为 9119–9122）落入排除区间，且日志/手动复现显示绑定失败时，才把端口排除认定为根因。

3. 对监听中的端口做 HTTP 验收：

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:9120/
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:9120/api/status
```

首页或 `/api/status` 返回 200 说明服务已起来；认证保护的接口返回 401 不等于服务失败。

## 本类故障的最小修复

- 当前端口命中 Windows 动态排除区间时，优先按用户确认执行一次 `WinNAT` 重启：

```powershell
net stop winnat
net start winnat
```

- 重启后重新检查排除区间，再验证端口监听和 HTTP 响应。
- 必须提醒：WinNAT 重启可能短暂影响 WSL/容器网络；它是本次故障的恢复手段，不是永久保证。
- 不要仅因为 Dashboard 启动失败就盲目重启 WinNAT；先确认端口排除与绑定错误的关联。
- 不要把当时可用的 9310 或其他端口宣称为永久根治；动态排除区间可能变化。
- 不要把插件警告、认证接口 401 或正常的 Dashboard 路由加载日志误判为启动根因。

## 收尾验证

- 端口由桌面端启动的 runtime 持有，而不是残留的手动测试进程。
- `Get-NetTCPConnection` 显示候选端口 Listen。
- Dashboard 首页和至少一个非认证状态端点返回 200。
- 网关状态单独检查，不把 gateway 的 running 等同于 Dashboard 已就绪。
- 检查 `gui.log` / `agent.log` 的最新时间段；历史失败记录不能代替当前验收。
- 没有必要时不要改端口、配置或添加自动修复脚本；先完成证据闭环。

## 安全

配置检查或日志摘录时不要输出 Dashboard 明文密码、secret、API key 或 token。若凭据已经出现在工具输出或日志转录中，应建议轮换，但不要擅自修改导致当前登录失效。
