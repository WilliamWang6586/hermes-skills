# QQ Bot 扫码绑定 — API 细节与踩坑（2026-08 实测）

Hermes CN Desktop 的 QQ Bot 接入走「扫码绑定」流程，**不需要 QQ 开放平台注册**。
以下细节来自 GitHub `NousResearch/hermes-agent` 仓库 `gateway/platforms/qqbot/` 源码
（本地安装目录为打包产物搜不到源码，直接读 GitHub；当时下载到 `D:\Hermes文件库\qqbot_*.py`）。

## 绑定流程（onboard）

1. **create_bind_task**
   - `POST https://q.qq.com/lite/create_bind_task`
   - body: `{"key": <base64 的 32 字节随机 AES key>}`
   - 响应: `{"retcode": 0, "data": {"task_id": "..."}}`，非 0 即失败
2. **生成二维码**（有效期约 60 秒）
   - URL: `https://q.qq.com/qqbot/openclaw/connect.html?task_id={task_id}&_wv=2&source=hermes`
   - 用 `qrcode` 库渲染 PNG，`os.startfile()` 打开（用户手机 QQ 扫电脑屏幕）
3. **poll_bind_result**（每 2 秒轮询）
   - `POST https://q.qq.com/lite/poll_bind_result`，body: `{"task_id": ...}`
   - 响应 `data.status`: `0` 无 / `1` 等待中 / `2` 完成 / `3` 过期
   - 完成时返回: `bot_appid`（str）、`bot_encrypt_secret`（base64 密文）、`user_openid`（扫码者的 QQ openid）
4. **本地解密 client_secret**（AES-256-GCM）
   - base64 解码密文 → `IV(12B) ‖ ciphertext ‖ AuthTag(16B)`
   - `AESGCM(key).decrypt(iv, ciphertext_with_tag, None)` → UTF-8 明文
   - 关键点：key 只在本地生成并传给 create_bind_task，secret 全程不以明文过网络

## HTTP 头要求

```python
{
    "Content-Type": "application/json",
    "Accept": "application/json",      # 缺了会返回 JS 反爬挑战页
    "User-Agent": "QQBotAdapter/1.1.0 (Python/3.14; windows; Hermes/0.19.0)",
}
```

## 环境变量（预期）

QQ Bot 平台适配器从 `.env` 读取 `QQ_*` 变量（app_id / client_secret / 允许用户等）。
绑定拿到凭证后：
- 把 `app_id` / `client_secret` / `user_openid` 写入 `hermes-home\.env`
- `WEIXIN_*` 同款白名单模式（`QQ_ALLOWED_USERS` 之类，参考 adapter.py 确认确切名）
- 重启 gateway 生效（`hermes gateway restart` 或桌面端重启）

## 踩坑

1. `hermes gateway setup` 交互菜单在 PTY 自动化下会崩（退出码 3221225786 = CTRL_C_EXIT），
   自动化配置不要走 TUI，直接写脚本调 onboard API。
2. qrcode 库需要 `pip install qrcode`（httpx / cryptography 一般已有）。
3. 二维码 60 秒过期，过期后 `poll` 返回 status=3，需重新 create_bind_task。
4. 绑定脚本是长时间运行的后台进程：用 `terminal(background=true)` + `notify_on_complete=true` 启动，
   不要前台等 60 秒轮询。
5. 手机 QQ 扫码后要在手机上确认授权（一次性的）。

## 产物

- 绑定脚本：`D:\Hermes文件库\qqbot_bind.py`（已跑通 create + 二维码 + 轮询，凭证 JSON 落桌面）
- 源码参考副本：`D:\Hermes文件库\qqbot_*.py`（GitHub 下载的 8 个模块）
