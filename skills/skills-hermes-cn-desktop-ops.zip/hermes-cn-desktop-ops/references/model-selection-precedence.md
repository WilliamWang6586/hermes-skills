# 实际生效模型 ≠ config.yaml：会话级模型覆盖（2026-10-19 实测定位）

> 用户问「为什么你默认用的是 X 模型，我配置里明明设的是 Y」「我在配置里都设置成 Y 了，你这是怎么回事」
> → **先别解释、也别改 config**：多半是**会话级选择**盖住了全局默认，config 根本没问题。

## 三层优先级（高 → 低）

| 层 | 存放位置 | 决定什么 |
|---|---|---|
| ① 会话级选择 | `desktop-ui.sqlite` 里 **`ui_kv` key = `session_ui_state`**（按 session id）+ 最近一次全局选择 `hermes:last-used-model:managed:http%3A%2F%2F127.0.0.1%3A9120:default` | **当前对话每次开口实际用哪个模型** |
| ② 全局默认 | `config.yaml` 的 `model.default` / `providers.<p>.model` | 只决定**新会话的初始模型**，改它对已存在会话无效 |
| ③ fallback 链 | `config.yaml` 的 `fallback_providers`（**`fallback_models` 是无效键**） | 只在 429/529/503/连接失败时接管 |

## 判定：「配置是对的，但请求走的是别的模型」

1. 核对配置层（这些都是读，不改）：
   ```powershell
   hermes config get model.default
   hermes config get providers.deepseek      # 看 provider 段自己的 model
   hermes config get fallback_providers
   ```
2. **看日志的真相**（唯一可靠，配置不代表请求）：
   ```powershell
   Select-String -Path "$env:HERMES_HOME\logs\agent.log" -Encoding UTF8 -Pattern "conversation turn: session=.* model=" | Select-Object -Last 5 | % { $_.Line }
   # 以及每次调用："API call #N: model=... provider=... in=... out=... cache=..."
   ```
3. **看切换记录**（本坑的指纹）：
   ```powershell
   Select-String -Path "$env:HERMES_HOME\logs\agent.log" -Encoding UTF8 -Pattern "Model switched in-place" | Select-Object -Last 15 | % { $_.Line }
   ```
   ```
   Model switched in-place: deepseek-chat (deepseek) -> deepseek-chat (deepseek)
   ```
   **`A -> A` 空转重设 = 会话级选择器每轮把旧值重新盖上去**，永远不读 config 里的新默认。这就是根因，不是「agent 自己选的模型」，也不是 provider 侧改名。

## 修复（按懒=稳排序）

1. **会话标题栏的模型下拉手动切一次** → 只修本会话，但会同步写 `last-used-model`，后续新会话跟着走。**首选**。
2. `/new` 开新会话 → 按 `model.default` 起。
3. 改 `desktop-ui.sqlite` 的 `session_ui_state` → 要托盘退出再改（活库被占）、重开可能又被 UI 盖回，不如 1 稳，**基本别用**。

## 坑

- **别用 `hermes model current` / `hermes models list`** —— 本版本（0.19.0-cn.7）没有这些子命令：`hermes model` 只有 `--refresh/--portal-url/...` 的**交互式选择器**，加 `current` 直接 `unrecognized arguments`。查当前模型只能读日志。
- **`hermes model`（无参数）是交互式 TUI**，脚本里调会挂 → 需要改默认用 `hermes config set model.default <名>`。
- **`state.db` 反推不了当前模型**（那是历史用量）；`config.yaml` 是当前配置 —— 两者都不能替代 agent.log 的 `model=` 字段。
- **模型名有效 ≠ 被用上**：先打 provider 的 `/models` 确认名字真实存在（DeepSeek：`GET https://api.deepseek.com/models`，返回 `deepseek-flash`=V4.1-Flash / `deepseek-v4-pro`）。名字对了还走错，就一定是上面的会话级覆盖。
- **provider 插件里的默认值会误导**：`_internal\plugins\model-providers\deepseek\__init__.py` 写着 `fallback_models=("deepseek-chat","deepseek-reasoner")` + `default_aux_model="deepseek-chat"` + `aliases=("deepseek-chat",)`。这是插件兜底/别名，**不代表用户配置被忽略**，别拿它当证据。`deepseek-chat` 是 V3 非 thinking 模型（`_model_supports_thinking` 对 `deepseek-v3*` 返回 False → 不注入 `extra_body.thinking`）。
- 上报给用户时要给**一张证据表**（配置层 vs 日志层各显示什么），用户对「配置对不对」这件事只信实测，不信断言。

## 顺手该看的两件事（每次排这个坑都查）

- `config.yaml` 里有没有 **明文 `api_key:`**（应为 `api_key_env: XXX_API_KEY` 指向 .env）→ 有就提醒用户这文件别外传。
- `fallback_providers` 里有没有**付费模型**（zai 的 `glm-5.3-flashx` 是付费、`glm-4.5-flash` 免费）→ 主模型挂掉时会自动跳过去扣钱。
