# 缓存计费核验：字段活着 ≠ 计费生效

> 2026-09 实测。补充 `ai-cost-audit.md`，不重复其真实用量提取部分。
> 铁律：**判据只能看「后台扣费」，不能看「返回字段」。**

## 为什么字段会骗人（源码级证据）

调查 `new-api` / `one-api` 类中转网关。仓库已迁移：
`Calcium-Ion/new-api` → **`QuantumNous/new-api`**（旧址 301，48.5k★）。

- **计费是减法模型** — `service/text_quota.go:303-353`：
  ```
  费用 = (prompt_tokens − cached_tokens) × 全价 + cached_tokens × 折扣价
  ```
  若 `cached_tokens == 0` → 减法不执行 → **全部 prompt_tokens 按全价**。

- **失效点** — `relay/channel/openai/usage.go:10-51`：
  把 `PromptCacheHitTokens` 搬到计费读取的 `PromptTokensDetails.CachedTokens`
  的**唯一代码**在 `case ChannelTypeDeepSeek` 分支内。
  中转把 DeepSeek 配成**通用 OpenAI 渠道**（转卖多模型的常见做法）→ 分支不匹配
  → `CachedTokens` 保持 0 → **JSON 里字段还活着，但按全价计费**。
  网关无需"故意坑人" —— 字段没填就自动全价。

- **两个隐藏杀手**：
  - `UsageSemantic` / `legacyClaudeDerived` 为真时同样绕过减法
    （`text_quota.go:306`，跨协议转换的中转会踩到）
  - `DefaultCacheRatio = 1.0` — 模型名不在映射表（用了别名/前缀如 `deepseek-v3`）
    → **缓存折扣静默归零**

- **其他缓存杀手**：注入 system 提示/时间戳（前缀一变必然 miss）、
  多上游 key 轮询、超时重试打到另一上游。

## 核验协议（唯一可靠判据）

```
冷热两次相同长 prompt（>2K token），对比后台扣费：
  热/冷 ≈ 0.25  → ✅ 真生效
  热/冷 ≈ 1.0   → ❌ 缓存被吞（按输入总量计费）
  字段显示 cached>0 但扣费仍全价 → ❌ 典型"字段活着但全价收"
```

最坏情况是**输入侧费用约 4 倍**（不是整单 4 倍）。

**小额试运行清单**（遵守硬性约束）：
1. 充值 ≤¥10-20，**绝不预存大额**
2. 记余额 → 发同一长 prompt 两次 → 再记余额
3. 按上面判据判定；不通过**立即弃用**
4. 跑 3-5 天对比累计扣费 vs 官方同量
5. ❌ 绝不提交私有代码/密钥到灰色中转

## 盈亏平衡点（实测推导，关键数字）

```
缓存失效情况下，中转必须打到 0.71 折（官方价的 7.1%）才能追平官方
市面常见 6.5-9 折 → 全部亏本
```

推导：月 581M token、命中率 96.3% 时，官方 ¥41.89/月；
缓存失效后即使 5 折仍 ¥293.08（贵 7 倍）。

## 校验脚本

| 脚本 | 层次 | 说明 |
|---|---|---|
| `scripts/check_relay_cache.py` | **字段层（简易）** | 两次相同 prompt 对比 `prompt_cache_hit_tokens`，退出码 0/1/2 |
| `check_ds_cache.py`（会话产出） | **冷热计费层（严谨）** | 输出字段层判定 + 计费确认指引；配套 `test_check_ds_cache.py` 自检 |

字段层脚本**不足以定论** —— 它正是本文开头证明"会骗人"的那一层。有真实中转 key 时必须用计费层。

自检（无 key 也能跑）：
```powershell
$env:PYTHONUTF8="1"
Start-Process -FilePath "C:\Users\王子涵\AppData\Local\Python\bin\python.exe" `
  -ArgumentList "-u","D:\Hermes文件库\每日科技日报\test_check_ds_cache.py" `
  -NoNewWindow -Wait
# 期望: OK: 真透传=pass, 剥离字段=flag, 归一化=flag
```

## 结论模板（小额用量下"省钱"是负期望）

```
实测：月均 581M token，缓存命中 96.3%，官方实际 ¥41.89/月
  6.5 折缓存正常 → 年省 ¥176
  6.5 折缓存失效 → 年亏 ¥4,069
  → 赔率 1:23，期望值为负
```

**用量涨 10 倍（月 >60 亿 token）前不建议碰中转** —— 那时年省 ¥1,760 才值得
验证成本 + 隐私风险。**瓶颈不是单价，是缓存命中率**。

**零风险优化优先**（比换渠道划算）：
1. 锁死主力模型为便宜的 flash（避免手滑/误配用 v4-pro，贵 4.5 倍）
2. 批量任务挪谷时（高峰仅 9:00-12:00 / 14:00-18:00 工作日）
3. 提示词前缀保持稳定 —— 别插时间戳/随机数
