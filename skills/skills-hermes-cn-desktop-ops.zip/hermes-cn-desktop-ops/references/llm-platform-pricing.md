# LLM 平台价目表 + config 诊断（2026-09~10 实测）

## 智谱 zai / BigModel（2026-10-13 官方价格表核实，浏览器渲染抓取）

**官方明文免费**（FAQ「智谱有免费的API模型吗」原文，全免费含缓存）：
- **GLM-4.7-Flash**（文本，200K 上下文）
- **GLM-4.6V-Flash**（视觉）

收费价（元/百万 tokens）：

| 模型 | 输入 | 缓存命中 | 输出 | 备注 |
|---|---|---|---|---|
| GLM-5.3（旗舰，1M ctx） | 8 | 2 | 28 | 编程体感较前代 +50%，开源 SOTA，纯文本 |
| GLM-5.3-Flash（1M ctx） | 0.8（限时五折 0.4） | 0.23（折 0.115） | 2.8（折 1.4） | **原生多模态**：视频/图像/文件/文本 |
| GLM-5.2 | 8 | 2 | 28 | 纯文本 |
| GLM-5.1 | 6（≥32K 8） | 1.3 / 2 | 24（≥32K 28） | 分档 |
| GLM-OCR | 0.2 | — | 0.2 | 32K ctx，PDF/图片 |
| GLM-5V-Turbo | 5（≥32K 7） | — | 22（≥32K 26） | 视觉 |
| GLM-4.6V | 1 / 2（≥32K） | — | 3 / 6（≥32K） | 视觉 |
| GLM-4.6V-FlashX | 0.15（≥32K 0.3） | — | 1.5（≥32K 3） | 视觉低价 |

- Batch API 五折；多款模型「缓存存储限时免费」。
- **GLM Coding Plan**：GLM-5.3-Flash 已全量进入，宣称「额度翻 3 倍」——重度用 5.3 系时优先与按量比价。
- ⚠️**「实测 200 OK」≠ 免费**：`glm-5.3-flashx` 不在官方价格表，但新用户赠包会覆盖它（2026-10-13 用户核对控制台确认），包烧尽即 429/1113。判免费唯一依据 = 控制台资源包 + 上表官方免费名单。
- 官方模型页定位：5.3-Flash/FlashX = 思考模式仅 enabled 不可关、稀疏+线性注意力混合架构；FlashX 宣称编程体感对齐 Claude Opus 4.x。
- 性能锚点：GLM-4.5（355B-A32B）12 基准综合 63.2 分（发布时全球第3，HF README）；Intern-S2（书生 397B）科学多模态但免费通道算力受限（30rpm、长推理可超时）→ 兜底不当主力。
- 同题快测（2026-10-13）：flashx 2.7-3.4s 全对；glm-4.5-flash 10-23s 全对但有事实小错（朱自清卒年答错）；代差明显，4.5 系只配当回落层。
- 抓价坑：docs.bigmodel.cn/cn/pricing 是 SPA，curl 拿空壳须浏览器渲染；根路径 /cn/pricing 会 404，从首页「价格」入口进。

## DeepSeek 官方权威价（人民币，元/百万 token）

来源 `api-docs.deepseek.com/zh-cn/quick_start/pricing`（Docusaurus SSR，`<table>` 在静态 HTML 里，无需渲染）。

| 模型 | 输入(缓存命中) | 输入(未命中) | 输出 |
|---|---|---|---|
| **deepseek-flash** 谷时 | **0.02** | 1 | 4 |
| **deepseek-flash** 高峰 | 0.04 | 2 | 8 |
| deepseek-v4-pro 谷时 | 0.15 | 4.5 | 13.5 |
| deepseek-v4-pro 高峰 | 0.30 | 9.0 | 27.0 |

美元价对照（flash）：命中 $0.003/$0.006，未命中 $0.15/$0.30，输出 $0.60/$1.20。

- **缓存折扣 = 50 倍**（1 → 0.02）← 这是核心，也是中转失效后暴亏的根源
- **`deepseek-chat` / `deepseek-reasoner` 已下线**（模型列表只剩 `deepseek-flash` + `deepseek-v4-pro`）
- `deepseek-v4-flash` **已退役** → 旧名仍可调用，但由 `DeepSeek-V4.1-Flash` 承接，按 flash 价计费
- 高峰 = 工作日 9:00-12:00 / 14:00-18:00（北京时间，**不含法定节假日**）；谷时 = 高峰价一半
- 并发：flash 2500 / v4-pro 500
- flash 支持图像理解；v4-pro 不支持
- 上下文 1M，最大输出 384K，默认思考模式
- 同时有充值余额与赠送余额时，**优先扣减赠送余额**

## 其他平台（2026-09 实测，别照搬厂商宣传）

### 硅基流动 — **不是折扣渠道**

| 模型 | 输入 | 输出 | 缓存命中 |
|---|---|---|---|
| DeepSeek-V4-Pro | 12.00 | 24.00 | 1.00 |
| **DeepSeek-V4-Flash** | 高峰3.00/低谷1.50 | 9.00/4.50 | 0.30/0.15 |
| DeepSeek-V3.2 | 4.00 | 6.00 | 0.40 |

⚠️ V4-Flash 谷时输入 ¥1.5/M vs 官方 ¥1.0/M —— **贵 50%，比官方还贵**。
分时：低谷 2:00～8:00。R1 与非 Pro V3 在该页无价格行。

**抓价坑**：`cloud.siliconflow.cn/models` 和 `/pricing` 都 **307 跳登录页**；
改用公开的 **`www.siliconflow.cn/pricing`**（无登录，728KB）。列顺序：输入→输出→缓存。

### 豆包 doubao-seed — **有缓存优惠**（常被误认为没有）

来源 `docs.volcengine.com/docs/ark/model-pricing`（旧路径 `82379/1099320` 已 301）。

| 模型 | 条件 | 输入 | **缓存命中** | 输出 |
|---|---|---|---|---|
| **doubao-seed-2.0-mini** | [0,32k] | 0.2 | **0.04** | 2.0 |
| doubao-seed-2.0-mini | (32k,128k] | 0.4 | 0.08 | 4.0 |
| doubao-seed-2.0-mini | (128k,256k] | 0.8 | 0.16 | 8.0 |

- **隐式缓存**：自动启用、**不可关闭**、系统自动识别公共前缀、**存储不计费**、命中不保证
- **显式缓存**：需手动创建、确定性命中、可配过期时间、**存储计费**（¥0.017/百万token/小时）
- 用显式缓存时隐式缓存不生效
- 缓存命中价**随上下文长度分档**（[0,32k] / (32k,128k] / (128k,256k]）
- 缓存最少 token 门槛默认 1024（部分模型 2048；`deepseek-v4-1-flash-260910` 为 256）
- 支持隐式缓存：doubao-seed-code、doubao-seed-2.0 及之后系列
- 另有「低延迟」「低优」两档推理，低优约为常规价一半

### 千问 Token Plan

官方页是 `qianwenai.com/benefits/tokenplan`（**不是** `help.aliyun.com/...`，那个 404）。

| 套餐 | 月付 | 额度（**7 天刷新，不结转**） | 并发 Agent |
|---|---|---|---|
| Lite | ¥39 | 2,500 Credits/7天 | 1~2 |
| Essential | ¥79 | 5,625 Credits/7天 | 2~3 |
| Standard | ¥139 | 10,000 Credits/7天 | 3~4 |
| Pro | ¥499 | 40,000 Credits/7天 | 6~8 |

- 超出额度自动按 **88 折**结算；个人版加油包 ¥100/月
- ⚠️ 需用套餐专属 API Key（`sk-sp-` 前缀）+ 专属 base URL；**用通用 key 不抵扣套餐额度**
- ⚠️ 仅支持**华北 2（北京）**
- ❌ **Credits → token 换算比例未公开**（页面 FAQ 需展开，抓不到）
- **Credits ≠ Token** —— 别把额度数字当 token 数比较

### 抓价通用坑

- `curl` 在 PowerShell 里是 `Invoke-WebRequest` 别名 → 必须用 **`curl.exe`** 并加 `-L`（站点多有 301/307）
- 但某些站 `curl.exe` 只回 432 字节（被挡），**`Invoke-WebRequest -UseBasicParsing` 反而正常拿 23KB 完整 SSR HTML** → **两种都试**
- 定价页多为 Docusaurus SSR 或 JS 渲染：先看原始 HTML 里有没有 `<table>`，有就直接抽，别上浏览器；SPA 空壳（如 docs.bigmodel.cn）则必须浏览器渲染
- `volcengine.com/api/doccenter/...` 返回 `UnauthorizedAccess`，必须走渲染后的 `docs.volcengine.com` 页面
- PS 里对中文关键字做 `IndexOf` 会因编码失败 → 改用 ASCII 锚点（如 `deepseek-flash`）定位

## ⚠️ config 诊断：先读 config，别从账单反推当前模型

**本次踩坑（用户纠正）**：`state.db` 的 `session_model_usage` 是**历史用量记录**，
`config.yaml` 是**当前配置**。从账单里看到 `deepseek-chat` 就断言
"你现在配置还是 chat" 是**错的** —— 用户早已改成 `deepseek-flash`，只是历史数据留着旧模型名。

**正确顺序**：查 `config.yaml` 的 `model.default` / `provider.model` → 再看 fallback → 最后才看账单。
（另注：同一 session 里 agent 与用户可能并行改同一文件，若发现脚本输出与自己写的代码不符，
先确认文件是否被覆盖，别把别人的输出当自己的结果。）

### 三处易错配置（本项目实测全中）

1. **`model.api_key_env` 与 `base_url` 是否指向同一家**
   实测：`base_url: https://api.deepseek.com`（DeepSeek 官方）
   但 `api_key_env: DASHSCOPE_API_KEY`（阿里）+ 硬编码 `api_key: ark-...`（火山方舟）
   → **key 与地址对不上，该线一直 401 废置**，全靠 `providers.deepseek` 段兜住。
   排查法：把 `.env` 里所有 `*_KEY` 的**前缀**列出来（`sk-` / `sk-ws-` / `ark-` / `sk-sp-`），
   与各 provider 的 `base_url` 对照，一眼看出错配。

2. **硬编码 `api_key` 可能是已作废的旧值**
   实测：config 里 `ark-30979345-...`，`.env` 里 `ARK_API_KEY=ark-829dc710-...`
   —— **前缀都不是同一个**。硬编码 key 要清掉，走 `api_key_env`。

3. **`fallback_models` 不是有效键**
   `hermes config set fallback_models ...` 会警告
   `⚠ 'fallback_models' is not a recognized config key — it was saved anyway`，
   并提示 `Did you mean: fallback_providers`。
   正确名是 **`fallback_providers`**（默认 `[]` = 未配置）。
   配错的后果：**fallback 实际未生效**，主模型挂了直接报错，而不是静默降级。

### 改 config 的正确姿势

agent 直接 `patch` config.yaml 会被拒：
`Refusing to write to Hermes config file ... Agent cannot modify security-sensitive configuration.`

走官方 CLI：
```powershell
$exe = "$env:LOCALAPPDATA\Hermes Agent CN Desktop\data\versions\<ver>\hermes-agent-cn-runtime-win32-x64.exe"
# ⚠️ PS 里 & 会被判后台符（exit -1）→ 必须用 Start-Process
$args = @("config","set","model.api_key_env","DEEPSEEK_API_KEY")
Start-Process -FilePath $exe -ArgumentList $args -NoNewWindow -Wait
# 删除: @("config","unset","model.api_key")
# 读取: @("config","get","fallback_providers")
```

**JSON 值必须先用单引号变量存再传数组** —— 内联嵌套引号会被 PS 撕碎：
```powershell
$json = '[{\"provider\":\"deepseek\",\"model\":\"deepseek-v4-flash\"}]'
$args = @("config","set","fallback_providers",$json)   # ← 不要写成内联字符串再转义
```

**改完要重启 gateway** 才生效（进程持着旧值）。
（实操补充 2026-10-11/13：生产上用 `python3.14` 脚本直读直写 config.yaml 更稳——`io.open(..., newline="")` 保 CRLF，替换后按行打印关键键自检；每次先 `shutil.copy2` 备份到 D:\Hermes文件库\config-backup-<场景>-<时间戳>.yaml。）
