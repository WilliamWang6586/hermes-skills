# LLM 成本审计与方案对比（实测方法论）

场景：用户要求核算 Agent 的模型账单、对比多套计费方案、校验缓存是否真的省钱。
核心教训：**别信估算和文档，从本地 DB 取真实用量，从官方站抓真实价目表。**

---

## 一、真实用量在哪（先查这个，别估算）

`hermes-home/state.db` → `session_model_usage` 表（SQLite）

关键列：
- `cache_read_tokens` — 缓存命中输入
- `input_tokens` — 未命中输入
- `output_tokens` — 输出
- `first_seen` — 时间戳（用于判断高峰/谷时）
- `model` — 模型名（用于区分主力/调试期）

查询要点：
- 先 `PRAGMA table_info(...)` 拿列名，别猜
- 按 `model` 分组看谁在花钱 —— **调试期的 pro/reasoner 调用常占大头**
- 用 `MIN/MAX(first_seen)` 确定数据跨度，再折算月均

**踩坑**：用户给的"月 token / 月账单"口径常与实际不符（含调试期高价模型）。
先用官方价目表反算本地记录，再与用户锚点对照 —— 差异往往就是"调试期 v4-pro"这类。

## 二、官方价目表怎么抓

- DeepSeek：`https://api-docs.deepseek.com/zh-cn/quick_start/pricing`（**SSR 静态 HTML，可直接抓**）
  对比 `platform.deepseek.com/api-docs/pricing`（JS 渲染，抓不到价格表）
- 硅基流动：`https://www.siliconflow.cn/pricing`（公开）
  ⚠️ `cloud.siliconflow.cn/models` 和 `/pricing` **307 跳登录页**，无账号抓不到
- 火山/豆包：`https://docs.volcengine.com/docs/ark/model-pricing?lang=zh`（旧 URL 301 到此）
- 千问 Token Plan：`https://www.qianwenai.com/benefits/tokenplan`（**不是** help.aliyun.com）

抓法：`curl.exe -s -A "Mozilla/5.0" -o out.html -w "HTTP=%{http_code}" <url>` 后正则抽 `<tr>`。
⚠️ PowerShell 里 `curl` 是 `Invoke-WebRequest` 别名 → **用 `curl.exe`**。

## 三、🔴 核心陷阱：缓存"生效" ≠ "为缓存付费"

这是整个审计里最重要的发现，源码级证据（new-api 网关）：

```go
// service/text_quota.go
费用 = (prompt_tokens − cached_tokens) × 全价 + cached_tokens × 折扣价

// relay/channel/openai/usage.go
// 把 PromptCacheHitTokens 搬到计费用的 CachedTokens 的【唯一代码】，
// 在 case ChannelTypeDeepSeek 分支内
```

**失效路径**：中转站把 DeepSeek 上游配成**通用 OpenAI 渠道**（转卖多模型的常见做法）
→ 分支不匹配 → `CachedTokens` 保持 0 → **全部 token 按全价扣费**。

而返回的 JSON 里字段**还是"活着"的**（能看到 `cached_tokens: 2176`）。
网关无需故意坑人 —— 字段没填就自动全价。

**→ 校验协议（唯一可靠）**：
1. 充值 ≤¥20（绝不预存大额）
2. 记余额 B0
3. 发同一段长 prompt（>2K token）两次，中间记 B1，之后记 B2
4. 判定：
   - `(B1-B2) ≈ (B1-B0) × 0.02` → ✅ 缓存生效（约 1/50）
   - `(B1-B2) ≈ (B1-B0)` → ❌ 缓存失效 → **立即弃用**
   - 字段显示 cached>0 但扣费仍全价 → ❌ 典型"字段活着但全价收"
5. 跑 3-5 天对比累计扣费

## 四、可复用探针

`scripts/check_relay_cache.py` —— 发两次相同长 prompt，对比 `prompt_cache_hit_tokens`。
用于快速筛查（**注意**：这只能看"字段层面"，判 ✅ 不等于计费 ✅，仍需扣费核验）。
自检：对官方端点跑应输出命中率 ≥50%。

## 五、核算公式

```
月费 = Σ(命中M × 命中价) + Σ(未命中M × 全价) + Σ(输出M × 输出价)
```
- 高峰时段折算：DeepSeek 高峰=工作日 9:00-12:00 / 14:00-18:00（北京时间，不含法定节假日）
- 用 `first_seen` 逐条判断峰谷，比"整体平均"准

**反解校验**：拿官方价目表算本地记录，看能否逼近用户账单锚点。
能逼近 → 模型/价目表/用量三者自洽，可信。

## 六、结论模板（用户要的是决策，不是数据罗列）

必给的几块：
1. **真实用量表**（含缓存命中率、月均）
2. **官方价目表**（带来源 URL）
3. **方案对比表**（月费 + vs 基准 + 结论）
4. **缓存失效代价**（倍数 + 绝对额）← 决策的关键杠杆
5. **检查项逐条结论**（对应用户列的每一条）
6. **最终推荐 + 风险表**

**决策启发式（重要）**：
> 基数低时，折扣方案没有意义。
> 例：月费 ¥57.8，6.5 折年省 ¥243；但缓存失效单月多花 ¥528。
> → 年省 < 单月风险 → **维持官方，不折腾。**

只有在用量涨 10 倍以上时，才值得花精力验证中转。

## 七、环境坑（本机）

- 读 `state.db` 用 `sqlite3`（stdlib），无需装包
- 脚本执行：写临时 .py → `Start-Process python.exe -Wait -RedirectStandardOutput`（见主 SKILL.md / `windows-wsl2-script-exec`）
- 多会话并发写同一临时文件名会互相覆盖 → **临时脚本放在不被其他会话清理的目录**，或带唯一前缀
