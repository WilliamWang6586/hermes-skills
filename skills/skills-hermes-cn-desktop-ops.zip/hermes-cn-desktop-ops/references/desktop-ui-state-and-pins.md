# 桌面端侧边栏：置顶 / 标题 / 工作区存储位置与「改了不生效」的成因

场景：用户问「左侧置顶对话没了 / 置顶项目没了 / 只剩一条置顶」。
这类问题**没有 UI 开关**，也没有 CLI 命令，只能摸数据层。本文记录 2026-10-19 实测结论。

## 文件分布（先认清谁是谁）

| 路径 | 是什么 |
|---|---|
| `hermes-home\desktop-ui.sqlite` | 桌面端 UI 状态库（`ui_kv` 键值表 + `session_ui_state` 表） |
| `hermes-home\state.db` | 主库，`sessions` 表（id/title/source/message_count/archived…）；体积可达数百 MB |
| `data\dashboard\web_dist\assets\index-*.js` | **内置 TUI 网关**的 Web 界面（:9120 那个）→ **没有置顶栏**，别在这找 |
| `data\versions\<ver>\_internal\hermes_cli\web_dist\...` | 同上，另一份副本 |
| `data\webview2\EBWebView\Default\...` | WebView2 浏览器侧存储 → **置顶不在这里**（Local Storage 里只有 `VERSION`，不要浪费时间扫 leveldb / Code Cache） |
| 桌面壳前端 | **编译进 `hermes-agent-cn-desktop.exe`**，磁盘上无独立 JS 文件可搜 |

## 相关键

`desktop-ui.sqlite` → `ui_kv` 表（`key` / `value_json` / `updated_at`）：

- `hermes-cn-ui.pinnedSessionIds` — JSON 字符串数组，元素 = `state.db.sessions.id`
- `hermes-cn-ui.sessionTitleOverrides` — `{session_id_prefix: 标题}`
- `hermes-cn-ui.sessionWorkspaces` — `{session_id_prefix: 工作区路径}`
- `hermes-cn-ui.workspaceProjects` — 项目列表（曾出现过误加的 `D:\` 根目录项）

`session_ui_state` 表有 `pinned` / `archived` / `title_override` / `workspace_path` 列，
但**桌面端侧边栏的置顶不走这张表**（实测四条记录 pinned 全 0，而 ui_kv 里有 8 条置顶）。
可以当第二处试写点，但没有验证成功过。

## 关键坑：写库 ≠ 界面更新

1. 直接改 `ui_kv` 的 `pinnedSessionIds`，**回读确认写入成功**、值也对，但界面仍显示旧置顶。
2. 原因是桌面壳把 UI 状态当作自己的内存态，启动时**回写覆盖** DB（观察：13:41 写入后，13:45 该 key 被整批 UI 键重写，值被还原）。
3. 桌面壳 ↔ 前端之间走 WebSocket 推送（`pinnedSources` 等事件，出现在 `desktop-ui.sqlite` 与 `state.db-wal` 的字符串里）。
   **改库对运行中的进程无效**；即使重启，启动时读到旧内存快照也会再盖回去。
4. 结论修正（2026-10-19 晚，读源码后）：**「完全不能改库」是错的**。
   `web/src/lib/ui-store.ts` 显示 UI 状态来自 Tauri 桥的 `uiStoreSnapshot()`，`writeUiValue` 只是异步 `uiStoreSetKv` 落库
   → sqlite 是缓存副本。所以在**桌面端关闭时**（托盘退出，进程不在）写入 `ui_kv` 再启动，值不会被回写覆盖，能生效。
   「改了没变化」多半是：① 进程还开着（内存态盖回）② `pinnedSessionIds` 里的 id 不是界面显示的那条（见下）。
   **别把一次被覆盖上升成「这条路不通」**——先读 `references/desktop-shell-frontend.md` 的源码再下结论。

## 「置顶里显示的不是我要的那条」（先别急着改标题）

侧边栏按 id 精确取会话，**最新源码无标题归并**（详见 `references/desktop-shell-frontend.md`）。
所以「置顶少了几条 / 显示的不是那条」的第一嫌疑不是撞标题，而是：

1. `pinnedSessionIds` 里**根本没有那个 id**（早期版本 UI 会把查不到的 id 静默清掉——
   源码 `workbench-sidebar.tsx` 有 `unpinSessions(staleIds)` 逻辑：拿到的会话列表里找不到的置顶 id 会被**自动删除**）。
   → 会话暂时拉不到（跨渠道 / 列表分页未加载完）时，置顶就被永久清掉了。**这才是「置顶自己没了」的根因。**
2. id 是 `desktop`/`tui`/`qqbot` 混合的；跨渠道会话若列表里不出现，同理被 reap。
3. 才轮到 `sessionTitleOverrides` 把两条会话标题改成了同一个。

修法（2026-10-19 实测）：备份 → 逐条到 `state.db` 验证 id 存在且 `archived=0` →
`insert or replace into ui_kv(key,value_json,updated_at) values('hermes-cn-ui.pinnedSessionIds', json.dumps([...]), <ms>)`
→ **托盘退出桌面端再启动**（进程开着会内存态盖回）→ 让用户核对。

### 排查这事的正确顺序（省时间）

1. 先只读确认数据在不在：`ui_kv.pinnedSessionIds` 的值 + 逐个 ID 到 `state.db.sessions` 查存在性/archived/标题。
2. 再确认「界面上显示的是什么」——问用户或看截图。数据全在、界面只有一条 → 是显示层，不是数据丢失。
3. 想改：先找 UI 入口（右键/悬停），没有就如实告诉用户只能改源码；**不要**反复写库 + 让用户重启。

## 版本差异提示

`0.18.2-cn.2` 与 `0.19.0-cn.7` 的 `web_dist` 都有，但内置 Web 界面 UI 文案里查不到「置顶对话/最近对话/新建对话」这些词
（`看板` 能查到，`置顶` 查不到）→ 反过来证明侧边栏来自桌面壳，不是这份 web_dist。
启动包全目录搜 `pinnedSessionIds` 只命中：`desktop-ui.sqlite`(+bak)、`state.db`、`state.db-wal`、`memories\MEMORY.md`（我自己写进去的）。

## 只读探查片段

```python
import sqlite3
p = r"...\data\hermes-home\desktop-ui.sqlite"
c = sqlite3.connect("file:" + p + "?mode=ro", uri=True)   # 只读，避免碰锁
print(c.execute("select key,value_json,updated_at from ui_kv where key like '%pinned%'").fetchall())
print(c.execute("select * from session_ui_state").fetchall())
```

```python
# 校验置顶 ID 是否还活着
s = sqlite3.connect("file:" + r"...\state.db" + "?mode=ro", uri=True)
for sid in ids:
    print(s.execute("select id,title,source,message_count,archived from sessions where id=?", (sid,)).fetchone())
```

## 顺带记下的其它发现

- `logs\gui.log` 里的 `ws closed ... reaped_sessions=N` 会出现在会话「被偷偷结束」的场景：桌面断开连接时把关联会话标成 `ws_orphan_reap`。遇到「会话莫名结束」先查这条。
- `session_ui_state.archived=1` 的两条会话即「已归档」，侧边栏不显示。
