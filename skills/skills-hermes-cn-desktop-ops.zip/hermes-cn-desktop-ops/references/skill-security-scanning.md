# 第三方技能安全扫描（SkillSpector）

安装任何第三方技能（虾评/市场/hub）后，用 NVIDIA SkillSpector 做静态安全扫描。
工具本身 14k⭐，专门检测 AI agent 技能的漏洞/恶意模式（68 个模式 / 17 类）。

## 安装

```powershell
uv tool install git+https://github.com/NVIDIA/skillspector.git
# 可执行文件落在 %USERPROFILE%\.local\bin\skillspector.exe
```

## 快速扫描（免 API Key）

```powershell
# --no-llm = 纯静态分析，不需要配 LLM/API Key
skillspector scan "C:\...\skills\<技能名>" --no-llm --format json 2>$null
```

JSON 关键字段：

```json
{
  "risk_assessment": { "score": 0-100, "severity": "LOW|MEDIUM|HIGH|CRITICAL",
                       "recommendation": "SAFE|REVIEW|..." },
  "issues": [ { "id":"EA2", "category":"Excessive Agency",
                "pattern":"Autonomous Decision Making", "severity":"MEDIUM",
                "location": {"file":"SKILL.md"} } ]
}
```

判定：`recommendation == SAFE` 且 score 低 → 安全；score ≥ 60 或含
HIGH/CRITICAL issue → 提示用户谨慎/卸载。不做 LLM 语义分析（默认会尝试连
NVIDIA/OpenAI 等，没 Key 就报 ValueError + traceback——**用 --no-llm 避免**）。

## PowerShell 批量扫描脚本坑

- **PS 5.1 读含中文的 .ps1 必须 UTF-8 BOM**：write_file 存的是无 BOM UTF-8，
  `powershell -File` 会把中文读成乱码报 `Unexpected token`。修复：
  ```powershell
  $c = Get-Content "x.ps1" -Raw -Encoding UTF8
  [System.IO.File]::WriteAllText("x.ps1", $c, (New-Object System.Text.UTF8Encoding($true)))
  ```
- 从 WSL 调 Windows exe（`/mnt/c/.../skillspector.exe`）路径解析易失败，
  直接在 PowerShell 侧跑。
- 扫描慢（每技能几秒~几十秒），批量时逐技能跑并汇总，勿一条命令全跑超时。

## 2026-08 实测结果（本用户 9 个虾评技能）

| 技能 | 风险分 | 结论 |
|------|:---:|------|
| news-aggregator-skill | **95 CRITICAL** | 🚨 提示词注入(HIGH×3)、数据外泄、隐藏指令、未固定依赖（requests 10 个 CVE） |
| word全能工具箱 | **69 HIGH** | 🚨 MCP 工具投毒、凭据访问、17 个问题（大量 subprocess/getattr） |
| pdf全能工具箱 | **66 HIGH** | 🚨 YARA exploit_framework 匹配、MCP 工具投毒、sudo/root 执行 |
| pua-debugging | 14 LOW | ⚠️ Excessive Agency（提示词型技能固有，可接受） |
| humanizer-zh | 10 LOW | ⚠️ MCP Rug Pull / Scope Creep 低危 |
| agent-reach / content-multi-platform / ai-text-humanizer / self-improvement-skill | 0 | ✅ 完全安全 |

> 结论：含脚本执行的工具箱类技能（PDF/Word）风险集中在"运行外部命令"，
> 属功能需要但仍须留意 MCP 投毒/YARA 命中；news-aggregator 的提示词注入+
> 已知 CVE 依赖最值得警惕。给用户汇报时用 ✅/⚠️/🚨 三档，别丢原始数字。
