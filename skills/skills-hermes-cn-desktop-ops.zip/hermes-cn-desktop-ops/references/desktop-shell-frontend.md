# 桌面壳前端源码（Tauri + React + TS）—— 侧边栏行为的权威出处

桌面壳 exe 里没有可搜的 JS（打包压缩），**判断 UI 行为必须读源码**：
GitHub `Eynzof/Hermes-CN-Desktop`（公开仓库，源码完整）。
commit 取自 `data\versions\<ver>\manifest.json` 的 `sourceCommit`（0.19.0-cn.7 = `cd88e29…`），
或用 release 的 `target_commitish`（如 `270f6ba…`，2026-10-19 实测可读）。

**注意别读错仓库**：`_internal\hermes_cli\web_dist` 的源码在 `Eynzof/Hermes-CN-Core`，
是**内置 Web 界面（:9120）**，跟桌面端侧边栏无关。侧边栏在 `Hermes-CN-Desktop` 的 `web/src/`。

## 取文件（比 API contents 稳）

```powershell
# git trees 递归清单 → 落盘再读，别在 Python 里解析 curl 输出（中文路径下会吞）
curl.exe -s -m 90 -H "User-Agent: hermes" -o D:\_tmp\tree.json `
  "https://api.github.com/repos/Eynzof/Hermes-CN-Desktop/git/trees/<sha>?recursive=1"
# 单个文件
curl.exe -s -m 40 -o D:\_tmp\x.tsx -w "%{http_code} %{size_download}`n" `
  "https://raw.githubusercontent.com/Eynzof/Hermes-CN-Desktop/<sha>/web/src/<path>"
```

## 关键文件

| 路径 | 内容 |
|---|---|
| `web/src/components/app-shell/workbench-sidebar.tsx` | 侧边栏：§编号分区、置顶对话/置顶项目/最近对话、右键菜单 `togglePin` |
| `web/src/lib/session-ui-state.ts` | `readPinnedSessionIds` / `writePinnedSessionIds` / `togglePinnedSession` |
| `web/src/lib/ui-store.ts` | **真相**：UI 状态来自 `window.hermesDesktop.uiStoreSnapshot()`（Tauri 桥），`writeUiValue` 只推 `uiStoreSetKv` 异步落库 → **sqlite 是缓存副本，不是权威源** |
| `web/src/lib/sidebar-session-lists.ts` | 列表派生逻辑（见下） |
| `web/src/lib/session-title.ts` | `sessionDisplayTitle`（标题覆盖优先级） |

## 列表派生逻辑（读这个就不会瞎猜）

最新版源码**没有标题去重**（2026-10-19 复核 `270f6ba`，`sidebar-session-lists.ts` 全文 44 行）：

```ts
const pinned = Array.from(pinnedIds).flatMap((id) => {   // 只按 id 精确查
  const session = sessionById.get(id);
  return session ? [session] : [];     // id 查不到 → 静默丢弃，界面无提示
});
// active = 正在跑的；recent = 其余，限 8 条（RECENT_SESSION_LIMIT=8），按 ended_at/started_at 降序
```

由此可推出两条硬事实：

1. **置顶显示不全 = `pinnedSessionIds` 里缺 id**（不是撞标题、不是渲染层）。逐条对照 `state.db` 里 id 是否存在 + 是否 archived。
2. **置顶与「最近对话」互斥**：置顶的会话从 recent 里被剔除，所以置顶多了 recent 就少，反之亦然。
3. 置顶列表**按数组顺序**渲染，顺序 = `pinnedSessionIds` 里的顺序，可用来排优先级。

> 历史记录里曾有「侧边栏渲染按标题归并、同标题撞车」的说法（2026-10-19 早先版本推论），
> 复核源码后**不成立**，别再拿它当诊断依据。真出现「置顶里是另一条会话」，优先怀疑
> `sessionTitleOverrides` 把标题改成了同一条，或 id 前缀撞了（`sessionWorkspaces` /
> `sessionTitleOverrides` 的 key 是 **id 前缀**，不是完整 id）。
4. ⚠️ **跨渠道会话可能拉不到**：`sessions.source` 有 `desktop` / `tui` / `qqbot` 等，8 条实测置顶里
   4 条是 `tui`（自身进化/新每日科技要闻/吉林大学百晓生）和 `qqbot`。若桌面端只拉 `desktop` 会话，
   这些 id 在 `sessionById` 里查不到 → 置顶静默消失。先看 `source` 再怀疑数据。

## 结论修正史（别再引用旧结论）

- 2026-10-19 早先记录「改 `ui_kv` 完全无效，只能改源码」——**过于绝对**。
  实际是：值会被桌面壳回写覆盖，但**在桌面端关闭时写入正确值**（备份→写→重启）可以生效。
  先读源码确认它读的是什么，再动手；不要把「一次写入被覆盖」上升成「这条路不通」。
