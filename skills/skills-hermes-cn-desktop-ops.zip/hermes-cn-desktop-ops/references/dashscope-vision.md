# DashScope（千问）视觉识图：API 格式与密钥

## 核心教训（2026-08 实测）

1. **compatible-mode 必须用 OpenAI 格式**，不是 DashScope 原生格式：
   - ❌ `{"input": {"messages": [{"role":"user","content":[{"image": b64}, {"text": q}]}]}}` → HTTP 400 "you must provide a messages parameter"
   - ✅ `{"messages": [{"role":"user","content":[{"type":"image_url","image_url":{"url":"data:image/jpeg;base64,..."}},{"type":"text","text": q}]}]}`
2. **国内 key 用国内 endpoint**：`https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions`
   - Hermes 内置 alibaba provider 默认指向国际站 `https://dashscope-intl.aliyuncs.com/compatible-mode/v1` → 国内 key 报 401。在 config.yaml providers.alibaba 中改 base_url 为国内站
3. **Hermes 内置 vision_analyze 工具 401**（用错了 key/endpoint）→ 不依赖它，直接用 Python 脚本调 API
4. **大图先压缩**：Pillow 限制最长边 1024、quality 85，避免 400

## 现成脚本

`D:\Hermes文件库\vision_ocr.py`：
```
python3.14 vision_ocr.py <图片路径> [问题]
```
- 自动从 .env 读 DASHSCOPE_API_KEY（备选：config.yaml 中 sk- 开头的 key）
- 输出图片内容描述/OCR

## 可用模型（models_dev_snapshot.json，51 个）

- qwen-vl-max：视觉（131072 ctx）
- qwen-vl-ocr：OCR 专用（34096 ctx）
- qvq-max：视觉 + 推理
- qwen-plus / qwen-flash / qwen-turbo：1M ctx 文本，支持工具
- 环境变量名：DASHSCOPE_API_KEY（Hermes 期望名）

## 验证命令

```
python3.14 test_qwen.py   # 简单文本连通性测试（qwen-plus）
```
