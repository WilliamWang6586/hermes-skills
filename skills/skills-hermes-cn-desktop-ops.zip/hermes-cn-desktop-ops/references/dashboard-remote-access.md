# Hermes Web Dashboard 手机遥控（2026-09-11 实测跑通）

## 场景
用户要「手机上看得到全部窗口/上下文/记忆/模型配置、能完成电脑上的一切、且**不用像 QQ Bot 那样每次连都重启网关**」→ **用 Hermes 自带的 Web Dashboard**（不是加消息平台）。Dashboard = 完整管理界面 + 内嵌聊天，**常驻 web 服务**。

## 侧栏（＝"所有窗口/上下文/记忆/配置"）
CHAT · SESSIONS · FILES · MODELS · LOGS · CRON · SKILLS · PLUGINS · MCP · CHANNELS · WEBHOOKS · PAIRING · PROFILES · CONFIG · KEYS · SYSTEM + 插件区(KANBAN/ACHIEVEMENTS)，右下角有 **Restart Gateway / Update Hermes** 按钮。

## 起服务
```
hermes dashboard --no-open --host 0.0.0.0 --port 9119 --skip-build
```
- 默认只绑 `127.0.0.1:9119`（本机访问免认证）；`--host 0.0.0.0` 绑所有网卡，手机才连得上
- `--skip-build` 跳过 npm 构建（用现成 web_dist；启动日志 `Using web dist from HERMES_WEB_DIST`）
- `--status` 看运行中的实例；`--stop` 停全部
- 启动成功的标志：输出 `HERMES_DASHBOARD_READY port=9119`

## 认证（公网绑定强制）
config.yaml 加：
```yaml
dashboard:
  basic_auth:
    username: admin
    password: <明文，加载时 scrypt 哈希>
    secret: <随机 hex>   # 重启后会话不失效
```
或环境变量 `HERMES_DASHBOARD_BASIC_AUTH_USERNAME / _PASSWORD / _PASSWORD_HASH / _SECRET / _TTL_SECONDS`。

- ⚠️ **2026-06 hardening 起 `--insecure` 是 NO-OP**：公网绑定**永远**要认证（password 或 OAuth），没有"裸奔"选项
- OAuth 路线：`hermes dashboard register`（写 `HERMES_DASHBOARD_OAUTH_CLIENT_ID` 到 .env，需 Nous Portal 登录）
- **判定认证开没开**：`curl -s -o NUL -w "%{http_code}" http://127.0.0.1:9119/` → **302**（`location: /login`）= 已开；**200** = 没认证
- 登录页 `/login`，填用户名密码 → 跳 `/sessions`
- 认证插件源码（4 个 provider：basic / nous / self_hosted / drain）：`data\versions\<ver>\_internal\plugins\dashboard_auth\`

## 配置写入
config.yaml 受保护（patch/write_file 拒绝）→ **用 Python 读写**（先 `Copy-Item` 备份到 `D:\Hermes文件库\config-backup-*.yaml`，改完 `yaml.safe_load` 验证）。CRLF 要保住：读二进制 → decode utf-8 → 拼接时用检测到的 `\r\n` → encode 回写。

## 开机自启（非管理员）
非管理员加不了 Windows 计划任务/防火墙规则 → 用**启动文件夹**（同 gateway 的降级方案）：
`C:\Users\<user>\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\hermes-dashboard.cmd`
```bat
@echo off
start "Hermes Dashboard" /min cmd /c ""C:\Users\<user>\AppData\Local\Hermes Agent CN Desktop\data\desktop-bin\hermes.cmd" dashboard --no-open --host 0.0.0.0 --port 9119 --skip-build"
```

## 防火墙
本机已有 `hermes-agent-cn-runtime-win32-x64.exe` 的**入站 Allow** 规则（Profile=**Public**、TCP、Any port）——覆盖 dashboard（它跑在同一个 runtime exe 上），**无需新增规则**。
核实：
```powershell
Get-NetFirewallRule -DisplayName "*hermes-agent-cn-runtime*" |
  ForEach-Object { $pf = $_ | Get-NetFirewallPortFilter; "$($_.Profile) $($_.Direction) $($_.Action) $($pf.Protocol) $($pf.LocalPort)" }
```

## 手机连接
- **同 WiFi**：`http://<PC局域网IP>:9119`（取 IP：`Get-NetIPAddress -AddressFamily IPv4`，排除 127./169. 和 WSL 的 `vEthernet (WSL)`）
- ⚠️ **校园网/公共 WiFi（如 JLU.PC，Profile=Public）常有 AP 隔离** → 手机与 PC 互不可见、连不上；且 IP 动态、网络不可信
- **跨网 + 更安全（推荐）**：Tailscale / ZeroTier（PC+手机同装）→ 任意网络可连、端口不暴露；把 dashboard 绑回 `127.0.0.1` 并用 `tailscale serve` 代理。国内备选：贝锐蒲公英、chmlfrp/樱花frp

## ⚠️ 这不是 RDP
**Windows 10/11 家庭版不能当 RDP 主机**（`HKLM:\System\CurrentControlSet\Control\Terminal Server\fDenyTSConnections=1`，且家庭版无 RDP 服务端）→ 别把系统 RDP 当方案。要镜像整机用 RustDesk/ToDesk/向日葵；但用户要的是"Hermes 的所有面板"，Dashboard 就够，不必镜像整机。

## 为什么这满足"不用每次重启网关"
QQ Bot = 消息通道（看不到上下文/记忆/配置，网关挂了还要重启）；
Dashboard = 完整管理界面 + 内嵌聊天，**持久 web 服务**，一次起好一直在线，需要时手机上直接点"重启网关"按钮。
