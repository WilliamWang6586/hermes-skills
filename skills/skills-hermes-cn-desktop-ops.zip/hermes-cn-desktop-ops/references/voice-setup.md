# 语音能力安装：本地 STT（faster-whisper）+ Edge TTS（原独立技能 hermes-voice-setup，2026-10 并入本 umbrella）


# Hermes CN Desktop 语音能力安装（本地 STT + Edge TTS）

## 触发场景
- 用户在「配置 → 语音」页点不动/报错，或说「帮我安了」「语音识别用不了」「测试朗读没反应」。
- 需要在 Hermes CN Desktop 里启用 Composer 麦克风（STT）和消息朗读（TTS）。

## 0. 先摸清环境（关键前提）

Hermes CN Desktop 是 **PyInstaller onedir frozen 应用**，不是普通 venv：

```
data/versions/<版本>/hermes-agent-cn-runtime-win32-x64.exe   ← 主程序
data/versions/<版本>/_internal/                              ← 这就是它的 site-packages
```

- **`_internal` 在 `sys.path` 上**（第 4 位），所以第三方纯 Python 包 / 带 `.pyd` 的包直接解包进去即可被 import。
- **pip 装到本机 Python（`pythoncore-3.14-64`）对运行时完全无效**，别白干。
- 运行时 Python 版本：3.14.6 / MSC v.1944 / win_amd64。
- 验证运行时信息的最快方式：临时插件（见 §5）。

## 1. 需要哪些包

| 用途 | 包 |
|---|---|
| TTS（Edge，免费免 key） | `edge-tts` + `tabulate`（`aiohttp`/`certifi`/`typing_extensions` 运行时已内置，**不要覆盖**） |
| STT（本地，免 key） | `faster-whisper`、`ctranslate2`、`onnxruntime`、`av`、`tokenizers`、`numpy`、`huggingface_hub`、`filelock`、`fsspec`、`tqdm` |

`faster_whisper` 各模块的硬依赖（别漏）：`audio.py→av`、`tokenizer.py/transcribe.py→tokenizers`、`vad.py→onnxruntime`、`utils.py→huggingface_hub`。

## 2. 选源（本机实测，2026-10）

| 源 | pip | curl 直连速度 |
|---|---|---|
| `mirrors.aliyun.com/pypi/simple/` | 能用 | **~84 KB/s（被限速，慢到超时）** |
| `pypi.tuna.tsinghua.edu.cn/simple` | **403 / "no matching distribution"（极端误导）** | — |
| `mirrors.tuna.tsinghua.edu.cn/pypi/web/simple/` | 同上 403 | **~11 MB/s** |
| `huggingface.co` | — | **超时（墙）** |
| `hf-mirror.com` | — | **~800 KB/s～11 MB/s（要 `curl -L` 跟重定向）** |

**结论：pip 用阿里云（慢但能用），大文件一律 curl 打清华 `/pypi/web/` 路径。**

## 3. 装 wheel 进 `_internal`（绕过 pip 依赖解析）

不要用 `pip install --target`：它会把 `aiohttp/certifi/packaging/requests/yaml` 等**运行时自带包**一起升级覆盖 → 可能直接搞坏桌面端。做法是逐个 `--no-deps` 下载 + 只解包白名单包。

更快的做法（大文件）：直接 curl 清华 simple index 抓 wheel 链接再下载。

```python
# 关键点
BASE = "https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple/"
# 1) curl -sS --noproxy "*" BASE + pkg + "/"  拿 HTML
# 2) re.findall(r'href="([^"]+\.whl)(?:#[^"]*)?"', html)
# 3) 选轮子：原生包要 cp314-cp314-win_amd64；纯包要 -py3-none-any.whl
#    tokenizers 没有 cp314 轮子 → 用 cp310-abi3（稳定 ABI，3.14 可用）
# 4) urljoin 出绝对 URL，curl -sS -L --noproxy "*" -o 下载
```

解包（只放白名单，绝不覆盖运行时自带包）：

```python
import zipfile
WANT = {"numpy","ctranslate2","onnxruntime","av","tokenizers","huggingface-hub",
        "filelock","fsspec","tqdm","faster-whisper","edge-tts","tabulate","hf-xet"}
with zipfile.ZipFile(wheel) as z:
    z.extractall(TARGET)   # TARGET = ...\data\versions\0.19.0-cn.7\_internal
```

版本参考（本机实测可用的组合）：
`numpy 2.5.3` / `ctranslate2 4.8.2` / `onnxruntime 1.31.0` / `av 16.1.0` / `tokenizers 0.23.3(cp310-abi3)` / `huggingface_hub 0.30.2` / `faster-whisper 1.2.1` / `edge-tts 7.2.8` / `tabulate 0.10.0`。

## 3.5 朗读没声音的**真正根因**：`lazy_deps` 版本钉死（2026-10-11 实测确认）

> ⚠️ **2026-10-19 更新：现在有两条独立的失效链，先分清是哪一条再看对应小节**
>
> | 症状（`POST /api/audio/speak` 返回） | 根因 | 修法 |
> |---|---|---|
> | `400 ... TTS generation failed (edge): 403` + URL 里 `Sec-MS-GEC-Version=1-143.0.3650.75` | **微软改了 DRM 令牌前缀 `1-`→`2-`**，edge-tts ≤7.2.8 全部 403 | 升到 **edge-tts 7.3.1**（§3.5b） |
> | `400 "No TTS provider available..."` | `lazy_deps` 版本钉死与 dist-info 不符 | 改 METADATA（§3.5a） |
>
> 这两条会**互相掩盖**：升级包后如果没同步 dist-info 版本，就从 403 变成 "No TTS provider"，看起来像没修好。

## 3.5b 403 / `Sec-MS-GEC-Version=1-` —— 微软 DRM 前缀变更（2026-10-19 实测确认）

**症状**：点「测试朗读」没声音，日志 `agent.log`：

```
ERROR tools.tts_tool: TTS generation failed (edge): 403, message='Invalid response status',
url='wss://speech.platform.bing.com/...&Sec-MS-GEC-Version=1-143.0.3650.75'
```

**排除法（都已实测排除，别再重复排查）**：`voices/list` REST 接口 HTTP 200 正常；TCP 443 通；
系统时钟准确；代理已关（`ProxyEnable=0`，7892 无监听）；`drm.py` 的 clock-skew 逻辑齐全。
→ **只有 WSS 合成被拒，纯协议层问题。**

**根因**：对比 PyPI 上 7.3.1 的 `constants.py` 与运行时内置版本：

```python
# 7.2.8（故障）
SEC_MS_GEC_VERSION = f"1-{CHROMIUM_FULL_VERSION}"
# 7.3.1（已修）
SEC_MS_GEC_VERSION = f"2-{CHROMIUM_FULL_VERSION}"
```

`CHROMIUM_FULL_VERSION` 两版都是 `143.0.3650.75`，**唯一差别就是前缀 `1-`→`2-`**。

**修复：升级到 7.3.1**（纯 Python 包，`--no-deps` 解包即可）：

```powershell
# 1) 从 PyPI JSON 拿 7.3.1 的 wheel URL（大陆直连 pypi.org 可用，不必走镜像）
$j = Invoke-RestMethod "https://pypi.org/pypi/edge-tts/json"
$url = ($j.releases."7.3.1" | ? { $_.filename -like "*.whl" } | Select -First 1).url
# 2) 下载解包，替换 edge_tts/ 与 dist-info
# 3) 关键：把新 dist-info 的 METADATA 版本改回 lazy_deps 钉死值（见 §3.5a）
```

**验证（必须验到出 mp3，别停在 import）**：

```python
import asyncio, edge_tts
from edge_tts import constants
print(constants.SEC_MS_GEC_VERSION)          # 必须是 2-143.0.3650.75
async def main():
    c = edge_tts.Communicate("你好，这是语音测试。", "zh-CN-XiaoxiaoNeural")
    n = 0
    async for ch in c.stream():
        if ch["type"] == "audio": n += len(ch["data"])
    print("AUDIO_BYTES =", n)                # 实测 17712
asyncio.run(main())
# mp3 头字节应为 fff3（MP3 frame sync）
```

**⚠️ 三个必踩的坑**：

1. **改 `constants.py` 的 `SEC_MS_GEC_VERSION` 不够！** `communicate.py` 模块顶端用
   `from .constants import SEC_MS_GEC_VERSION` **按值拷贝**了它（第 468 行用模块全局）。
   只改 `constants`，`communicate` 里仍是旧值 → 照样 403。要么升级整个包，要么把 **两个模块** 都 patch。
2. **升级后必然触发 §3.5a**：新 dist-info 声明 7.3.1 ≠ 钉死 7.2.7 → 变成 "No TTS provider"。
   改 METADATA 回 `7.2.7` 即可（**代码是 7.3.1，元数据谎报 7.2.7，这是刻意为之**）。
3. **已运行进程不会热重载**：`dashboard`/`gateway` 进程里 `edge_tts` 已 import 进内存，
   改完磁盘文件**必须重启桌面端**才生效。判断依据：报错 URL 里的 `Sec-MS-GEC-Version` 还是 `1-` 就是没重载。

> 被 CLASSPATH 骗过一次的教训：`cd` 到哪都无所谓，**用系统 Python 做诊断会读到
> `%APPDATA%\Roaming\Python\Python314\site-packages\edge_tts-7.2.8`（另一份 7.2.8 安装）**，
> 而 Hermes 真实加载的是 `versions/<ver>/_internal/edge_tts`。
> 看 `agent.log` 的 traceback 里 `File "...\_internal\edge_tts\communicate.py"` 才是准的。

## 3.5a `lazy_deps` 版本钉死（2026-10-11 实测确认）

**症状**：运行时里 `import edge_tts` 成功、`importlib.metadata` 能解析、`edge-tts.exe` 也在 PATH 上，但界面「配置 → 语音」底部出现红字「回复朗读尚未配置可用的语音合成提供方…」，点「测试朗读」没声音，接口返回：

```
POST /api/audio/speak  ->  HTTP 400
{"detail":"No TTS provider available. Install edge-tts (pip install edge-tts) or set up NeuTTS for local synthesis."}
```

**根因（一句话）**：运行时 `tools/lazy_deps.py` 把 Edge TTS 的依赖**钉死为 `edge-tts==7.2.7`**，而 `_internal` 里内置的 dist-info 声明的是 **7.2.8**。版本不匹配 → `check_tts_requirements()` 返回 `False` → 判定"没有可用的 TTS 提供方"。**与 PATH、与有没有装 edge-tts 命令完全无关。**

运行时内探针实测证据：

```python
tools.lazy_deps.LAZY_DEPS['tts.edge']   == ('edge-tts==7.2.7',)
importlib.metadata.version('edge-tts')  == '7.2.8'          # ← 不匹配
tools.tts_tool.check_tts_requirements() == False
tools.tts_tool.text_to_speech_tool(...) == {"success":false,"error":"No TTS provider available..."}
# 另外 lazy 安装被关掉了，所以它不会自己修：
# FeatureUnavailable: lazy installs disabled (security.allow_lazy_installs=false)
```

**修复（改元数据，不动代码）**：把 dist-info 的 METADATA 版本改回 `7.2.7`。脚本：`D:\Hermes文件库\语音安装备份\修复语音EdgeTTS.ps1`。

```powershell
$meta = "…\data\versions\<ver>\_internal\edge_tts-*.dist-info\METADATA"
$txt  = [IO.File]::ReadAllText($meta, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText($meta, [regex]::Replace($txt,'(?m)^Version:.*$','Version: 7.2.7'),
                        (New-Object Text.UTF8Encoding($false)))
```

> 必须 `[IO.File]::WriteAllText` + `UTF8Encoding($false)`（**不带 BOM**）；PS5.1 的 `Set-Content -Encoding UTF8` 会写 BOM，可能影响元数据解析。

**改完立即生效，不用重启 App**（dashboard 每次请求现算）。实测：

```
check_tts_requirements() -> True
feature_missing('tts.edge') -> ()   /  is_available('tts.edge') -> True
text_to_speech_tool -> {"success":true,"provider":"edge", ...}      # 真出 mp3
POST /api/audio/speak -> HTTP 200 {"ok":true,"data_url":"data:audio/mpeg;base64,..."}
```

**升级必复发**：换到 `versions/<新版本>/` 后内置的又是 7.2.8 → 重跑修复脚本。

### 怎么掏出这些事实（frozen 应用的通用掏底手法）

PYZ 不在磁盘上，但 loader 能直接开归档：

```python
import sys
ld  = sys.modules["hermes_cli.plugins"].__loader__   # PyiFrozenLoader
arc = ld._pyz_archive                                # ZlibArchiveReader
arc.toc                                              # 16849 个模块名（含 hermes_cli.*）
co  = arc.extract("tools.tts_tool")                  # → code 对象，可扫 co_consts
import tools.lazy_deps as lz; lz.LAZY_DEPS           # 直接读钉死版本表
```

- 探针插件源码必须是**纯 ASCII**：写了中文再加 `# -*- coding: ascii -*-` 会让插件加载直接 SyntaxError（日志里是 `Failed to load plugin ... codec can't decode byte 0xeN`）。
- 判断候选模块：`arc.toc` 里 grep `tts|voice|audio|speak` → 直接锁定 `tools.tts_tool` / `agent.tts_provider` / `agent.tts_registry`。

### 用 dashboard 自带 session token 打真实接口（比猜快得多）

`GET http://127.0.0.1:9120/` 的首页 HTML 里**明文带着** `window.__HERMES_SESSION_TOKEN__="…"`；带上下面的头就能直接调所有 `/api/*`（不用登录、不用 cookie）：

```python
# POST /api/audio/speak  {"text": "..."}
hdr = {"X-Hermes-Session-Token": TOKEN, "Content-Type": "application/json"}
# 200 -> {"ok":true,"data_url":"data:audio/mpeg;base64,…"}
# 400 -> {"detail":"No TTS provider available..."}
```

配合 `GET /openapi.json`（同样带头）拿全部 246 个端点——**这是验证语音问题最快的手段**，别再用 Basic auth 绕。

### 附：早期误判记录（`shutil.which("edge-tts")`）—— **不是**本问题的原因

> 下面几段是我早前的分析，曾据此改 PATH、复制 `edge-tts.exe`。它描述的 `edge_playback` 机制**确实存在**（那是「语音模式」播放链路，另一条路），但它**不影响「测试朗读」**。留档备查，别再当成根因。

## 3.6 旧记录：TTS 还要一个「命令行可执行文件」

**症状**：运行时里 `import edge_tts` 明明成功、`importlib.metadata` 也能解析，但界面「配置 → 语音」底部出现红字
**「回复朗读尚未配置可用的语音合成提供方，请到'语音'设置选择 Edge TTS（需 edge-tts 依赖）…」**，点「测试朗读」没有声音。

**当时的猜测（后证实不是本问题的原因）**：Hermes 的 Edge TTS 走运行时自带的 `edge_playback` 包（`_internal\edge_playback\`），而它判定依赖靠**找可执行文件**：

```python
# _internal\edge_playback\__main__.py
def _check_deps(use_mpv: bool) -> None:
    deps = ["edge-tts"]                       # ← 不是 import，是 which
    for dep in deps:
        if not which(dep):
            pr_err(f"{dep} is not installed."); sys.exit(1)

def _run_edge_tts(...):
    edge_tts_cmd = ["edge-tts", f"--write-media={mp3_fname}"]   # ← 真的去 spawn 这个命令
    subprocess.Popen(edge_tts_cmd).communicate()
```

即：**PATH 上必须有个 `edge-tts` 可执行文件**，光有 Python 包不够。`edge_tts-7.2.8.dist-info/entry_points.txt` 写着两个 console_scripts：

```
[console_scripts]
edge-playback = edge_playback.__main__:_main
edge-tts      = edge_tts.__main__:main
```

用 zipfile 手工解包 wheel **不会生成这两个命令**（那是 pip 安装时才生成的）。于是「包在、命令不在」→ 后端判定没有可用 TTS 提供方。

**修复**：把 `edge-tts.exe` / `edge-playback.exe` 复制到一个**在 PATH 上**的目录。本机落点：

| 位置 | 说明 |
|---|---|
| `%LOCALAPPDATA%\Python\bin\` | **已在 User PATH**（持久，重启 App 后生效）← 首选 |
| `…\Hermes Agent CN Desktop\data\desktop-bin\` | Hermes 自己的 PATH 目录（hermes.bat 就在这） |

源：`%LOCALAPPDATA%\Python\pythoncore-3.14-64\Scripts\`（pip 生成的启动器，≈108 KB，内嵌绝对 python 路径，**可随意复制**）。

```powershell
$src = "$env:LOCALAPPDATA\Python\pythoncore-3.14-64\Scripts"
foreach ($d in @("$env:LOCALAPPDATA\Python\bin", "…\data\desktop-bin")) {
  Copy-Item "$src\edge-tts.exe","$src\edge-playback.exe" "$d\" -Force
}
```

**验证（必须验到这一层，别停在 import）**：

```python
import shutil, sys, threading
print(shutil.which("edge-tts"))      # 必须不是 None
def work():
    import edge_playback
    sys.argv = ["edge-playback", "--text", "\u4f60\u597d", "--voice", "zh-CN-XiaoxiaoNeural"]
    edge_playback._main()            # 真合成 + 真播放
threading.Thread(target=work).start()
```

成功标志：探针打印 `EDGE_PLAYBACK OK`，临时目录留下 mp3（设 `EDGE_PLAYBACK_KEEP_TEMP=1` 保留）。播放走 `_internal\edge_playback\win32_playback.py` 的 `mciSendStringW("Play … Wait")`，**不依赖 mpv / ffmpeg**（Windows 分支才用它）。

> 排查顺序：先分清「**合成**」和「**播放**」两段。`import edge_tts` 通过 ≠ TTS 可用，一定查 `shutil.which("edge-tts")`。

### 配套诊断手段（本机实测）
- **探针插件必须是合规插件才会加载**：`plugins/<name>/plugin.yaml`（name/version/description）+ `hermes plugins enable <name>`。规则是 *"Plugins are opt-in by default — only 'enabled' plugins load."* —— 只丢一个 `__init__.py` 进去**不会执行**。
- **前端 JS 不在磁盘上**（打进 exe 了），后端 Python 在压缩的 PYZ 里 → 全盘字节搜 UI 文案搜不到，**只能靠运行时插件探针**拿事实。
- dashboard 的 `/api/*` 全要登录态：**`Authorization: Basic` 头无效**；得 POST `/auth/password-login`（`provider=basic`，账号密码取 config.yaml 的 `dashboard.basic_auth`）拿签名 cookie，而拿到 cookie 后直连 API 仍可能 401 → 别在这上面耗时。
- 顺带：`hermes doctor` 不会检查 TTS/STT 依赖，别指望它。

## 4. 预下载 whisper 模型（必须走 hf-mirror）

- 模型缓存目录由 **`HF_HOME`** 决定；Hermes 桌面端进程里 `HF_HOME = <hermes-home>\cache\huggingface`（不是 `~/.cache/huggingface`）。子进程会继承，所以用本机 Python 预下载到同一路径即可离线可用。
- 用**本机 Python** 装 `huggingface_hub` 后预下载（不要在运行时里下载，会阻塞启动）：

```python
import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"   # huggingface.co 在这网络下超时
from huggingface_hub import snapshot_download
snapshot_download("Systran/faster-whisper-small")
```

- **模型质量（本机实测，同一段中文音频）**：
  - `base`：# 你好,這是雨嬰河城測試,今天天氣不錯   ← 繁体 + 严重错字，**中文不可用**
  - `small`：# 你好,这是语音合成测试。今天天气不错。  ← 完全正确，**中文选 small**
- 体积：base ≈141 MB，small ≈464 MB（hf-mirror 13s / 35s）。
- 顺手给用户设持久镜像兜底：`[Environment]::SetEnvironmentVariable("HF_ENDPOINT","https://hf-mirror.com","User")`。

## 5. 写配置（必须用 `hermes config set`）

```powershell
hermes config set stt.enabled true
hermes config set stt.provider local
hermes config set stt.local.model small          # base 中文太差
hermes config set stt.local.language zh
hermes config set tts.provider edge
hermes config set tts.edge.voice zh-CN-XiaoxiaoNeural   # 默认 en-US-AriaNeural 读中文很怪
```

- 有效键：`stt.{enabled,provider,local.model,local.language}`、`tts.{provider,edge.voice}`。
- 用 `/api/config/schema`（**免鉴权**）可查全部键名：`Invoke-WebRequest http://127.0.0.1:9120/api/config/schema`。
- `/api/audio/speak`、`/api/audio/transcribe` 需要登录态，直接 POST 一律 **401**，别指望用它做验证。

## 6. 验证：运行时内自检探针（唯一可靠的验证手段）

frozen 应用没法 `import` 试，也打不进 HTTP 接口，就用**临时插件**在真实运行时里跑代码：

1. 建 `data/hermes-home/plugins/zzprobe/__init__.py`（纯 Python，import 时自动执行）。
2. 里面把结果写进 `data/hermes-home/_voice_probe.txt`，然后 `hermes -z "reply with just: ok"` 触发。
3. **红线：插件在协程环境里被 import**，任何 `asyncio.run()` 要放到**独立线程**里跑，否则 `RuntimeError: asyncio.run() cannot be called from a running event loop`：

```python
def run_async(coro):
    import threading, asyncio
    box = {}
    def w():
        try: box["v"] = asyncio.run(coro)
        except BaseException as e: box["e"] = e
    t = threading.Thread(target=w); t.start(); t.join()
    if "e" in box: raise box["e"]
    return box.get("v")
```

4. 端到端测法：**edge-tts 语音合成 → 存 mp3 → 立刻用 faster-whisper 转写同一段音频**，比对文字是否一致。这一条同时证明了两个方向都通。
5. **验证完必须删掉 `plugins/zzprobe/` 和探针输出文件**（它每次启动都会跑，还拖慢启动）。

```python
from faster_whisper import WhisperModel
model = WhisperModel("small", device="cpu", compute_type="int8")
segs, info = model.transcribe(mp3_path, language="zh")
text = "".join(s.text for s in segs)
```

## 7. 交付与收尾
- 把测试音频（`MEDIA:<path>`）发给用户，让他直接听到效果。
- 告诉用户：**重启一次 Hermes 桌面端**更稳妥，然后到「配置 → 语音」点「测试朗读」，麦克风按钮试识别。
- 提醒用户：**UI 上不要带着旧的 `en-US-AriaNeural` 点「保存配置」**，否则会覆盖掉改好的中文音色（重新进页面会自动读回正确值）。
- 归档 wheel + 脚本到 `D:\Hermes文件库\语音安装备份\wheels\`。

## 8. 坑清单
- **⚠️ 升级桌面端 / 时间推移 → Edge TTS 会因微软改 DRM 协议而整体 403**（2026-10-19：`1-`→`2-` 前缀）。
  这不是配置问题，改音色/重装都没用，只能升 edge-tts 包（§3.5b）。**先看报错 URL 里的 `Sec-MS-GEC-Version` 前缀**。
- **桌面端升级会换掉整个 `versions/<新版本>/_internal`，语音会再次失效** → 保留 wheels 备份，重跑 §3 解包即可（模型缓存在 hermes-home，不受升级影响，无需重下）。
- 阿里云 pypi 只给 84 KB/s，pip 解析大包会像"卡死"；不要误判为网络不通，先 `curl` 测速。
- 清华 pip 403 的报错是 `Could not find a version that satisfies the requirement ... (from versions: none)`，看着像包名写错，其实是被拒。
- 只解包白名单 wheel；覆盖 `aiohttp/certifi/requests/pyyaml/packaging` 有搞坏桌面端的风险。
- 探针插件失败时不会报错到终端，只会静默不产出文件 → 先确认 `plugins/` 下目录名没写错。
