# 给 Hermes 接入 MCP 服务器（2026-10-19 实测：REA + Windows-MCP）

## 铁律：只用 `hermes mcp add`，别手写 config.yaml

三重阻碍决定这条路径：

1. `patch` / `write_file` 写 config.yaml 被安全锁拒绝（`Refusing to write to Hermes config file`）
2. `hermes config set` **只认标量** —— 传 JSON 数组或对象会被存成**字符串字面量**，YAML 解析器直接无视：
   ```yaml
   # 错误示范：看起来"设置成功"，实际读不进去
   windows-mcp: '{command:C:\Users\xxx\.local\bin\uvx.exe,args:[windows-mcp,serve],enabled:true}'
   args: '[windows-mcp,serve]'
   ```
   `config set` 返回 `✓ Set ...` 会骗人，**必须读回 config.yaml 核验类型**。
3. `hermes mcp add` 是唯一正路：它会真连一次、列出发现的工具、写正确的嵌套结构。

## 标准流程

```powershell
# 0) 先备份
Copy-Item "$env:HERMES_HOME\config.yaml" "$env:HERMES_HOME\config.yaml.bak-mcp" -Force

# 1) 连接 + 发现 + 写入（交互确认必须从管道喂 Y，否则静默 Cancelled 不落盘）
"Y" | hermes mcp add <名字> --command <可执行文件绝对路径> --connect-timeout 180 --args <参数1> <参数2>

# 2) 验证三连
hermes mcp list                  # 状态列要 ✓ enabled
hermes mcp test <名字>           # 真连一次，打印工具清单
Select-String -Path "$env:HERMES_HOME\config.yaml" -Pattern "<名字>" -Context 0,8
```

成功输出：`✓ Connected! Found N tool(s)` → `✓ Saved '<名>' to .../config.yaml (N/N tools enabled)` → `Start a new session to use these tools.`

**必须重启桌面端 / 开新会话**，MCP 工具在会话启动时加载。

写完后 config.yaml 里应长这样（`args` 是真列表，不是字符串）：

```yaml
mcp_servers:
  windows-mcp:
    command: C:\Users\王子涵\.local\bin\uvx.exe
    args:
      - windows-mcp
      - serve
    connect_timeout: 180.0
    enabled: true
```

## 已接入清单（本机）

| 名字 | 启动命令 | 工具数 | 备注 |
|---|---|---|---|
| `rea` | `%LOCALAPPDATA%\hermes\node\node.exe ...\rea-agents\scripts\rea.mjs mcp` | 207 | 逆向工程。由 `rea setup --client hermes` 自写，**不需要 `hermes mcp add`** |
| `windows-mcp` | `C:\Users\王子涵\.local\bin\uvx.exe windows-mcp serve` | 20 | Windows 桌面 UI 自动化（App/PowerShell/Screenshot/Click/Type/Registry…） |

## REA 特例：它有自己的 setup，且认 HERMES_HOME

```powershell
npm install --global rea-agents --registry=https://registry.npmmirror.com
$env:HERMES_HOME = "C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\hermes-home"
rea setup --client hermes --dry-run     # 先看目标路径对不对
rea setup --client hermes --yes
```

**不带 `HERMES_HOME` 会写进默认的 `%LOCALAPPDATA%\hermes`（桌面端根本不读）** —— dry-run 的 `target` 字段就是用来确认这个的。
REA 支持的 client 列表里有 `hermes`，它会同时装技能到 `skills\reverse-engineer-anything`。

## Pitfall：uvx / uv 装包卡死 = PyPI 直连不通

症状：`uvx windows-mcp --help` 打印几行 `Downloading xxx` 后**永久挂住**（600s 超时）。
修复：换阿里云镜像，秒装。

```powershell
$env:UV_DEFAULT_INDEX = "https://mirrors.aliyun.com/pypi/simple/"
$env:UV_HTTP_TIMEOUT = "120"
uvx --refresh --from windows-mcp windows-mcp --help
```
（`pip` 侧同理见记忆中 pypi.tuna 403 那条，统一走 aliyun。）

## 免重启验证 MCP server 能起（改配置前先探针）

装完包先手工握一次手，确认 server 本身健康，再动 Hermes 配置 —— 免得把配置问题和包问题混在一起排查。
最小 stdio 探针（initialize → notifications/initialized → tools/list）见 `scripts/mcp_stdio_probe.py`：

```powershell
$env:PYTHONUTF8=1; python3.14 <技能目录>\scripts\mcp_stdio_probe.py <可执行文件> <参数...>
```

## 排障速查

| 现象 | 原因 |
|---|---|
| `hermes mcp add` 打印全部工具后 `Cancelled.` | 交互确认没输入 → 用 `"Y" \| hermes mcp add ...` |
| `✓ Set` 了但工具不出现 | `config set` 存成了字符串字面量 → `hermes mcp rm <名>` 重来 |
| 配置对但工具不在 | 没重启桌面端 / 没开新会话 |
| 首次启动很慢 | uvx 首次解析依赖；`--connect-timeout 180` 兜住 |
