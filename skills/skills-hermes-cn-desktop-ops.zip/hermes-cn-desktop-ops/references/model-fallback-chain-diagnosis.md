# 回落链失效诊断实录（2026-10-11）

## 症状
用户：「为什么我使用 glm-5.3-flash 的时候他会自动切换 deepseek」→ 下一句「flash 也跑不通」。

**定式结论：「自动切换」几乎从不是随机行为 —— 是你回落链前面的层真的挂了。**

## 第一步：读日志定因（别猜、别看账单）

`logs\agent.log` 里搜 `Fallback`，紧邻的上一行就是死因：
```
API call failed (attempt 1/3) error_type=RateLimitError provider=zai
Fallback to alibaba/qwen3.7-plus: attached fallback credential pool
API call failed error_type=AuthenticationError provider=alibaba     ← 日志里 base_url 显示 dashscope-intl
Fallback activated: qwen3.7-plus → deepseek-v4-flash (deepseek)
API call #1: model=deepseek-v4-flash provider=deepseek ✅            ← 付费层兜住
```
主力死 + 回落1死 ⇒ 必然落到第 2 层付费。逐层探活比看账单快且准。

## 第二步：逐层探针实测（当天结果）

| provider | model | 结果 |
|---|---|---|
| zai | glm-5.3-flash | ❌ 429 code **1113** 余额不足（**已不在免费轨道**） |
| zai | glm-4.5-flash | ✅ 200 |
| zai | glm-4-flash | ✅ 200 |
| alibaba | qwen3.7-plus | ❌ **403 Free quota exhausted**（免费额度耗尽） |
| shuchen | intern-latest | ✅ 200（key 早已配好，可直接当免费层） |
| deepseek | deepseek-v4-flash | ✅ 200（付费兜底） |
| minimax | MiniMax-M3 | ❌ 401 —— **探针用错端点**（config 是 `api.minimaxi.com/anthropic`，我探的是 `/v1`），不代表 provider 坏 |

## 两个非显然机制

1. **凭据池 base_url 覆盖 config**（本次 401 的真因）
   `auth.json` → `credential_pool.alibaba[0].base_url = https://dashscope-intl.aliyuncs.com/compatible-mode/v1`（国际站），
   而 `config.yaml` 的 `providers.alibaba.base_url` 写的是国内站。
   **实际请求走凭据池那个** ⇒ 只在 config 改国内站无效，国内 key 照旧 401。
   查法（注意 **值是 list，不是 dict**，按 dict 迭代只会打印出一堆 `id`）：
   ```python
   cp = json.load(open(auth_json))["credential_pool"]      # {provider: [ {base_url, last_error_code, ...} ]}
   for p, rows in cp.items():                              # rows 是 list
       for r in rows: print(p, r.get("base_url"), r.get("last_error_code"))
   ```
2. **错误码分诊表**（判错会得出相反结论）
   | 码 | 含义 |
   |---|---|
   | 智谱 429 `1113` | 该**模型本身要钱**（不是限流，别重试） |
   | 智谱 429 `1305` | 免费但**当前排队**，等一下重试 |
   | 阿里 `403 Free quota exhausted` | 免费额度耗尽（≠ 401 key 坏，别去换 key） |
   | 401 + `dashscope-intl` | 端点串了（查凭据池，见上） |

## 第三步：最小修复

`config.yaml` 三处（Python 直写、保留 CRLF）：
```
model.default:                          glm-5.3        → glm-4.5-flash
providers.zai.model:                    glm-5.3        → glm-4.5-flash
fallback_providers:  [alibaba, deepseek, shuchen] → [shuchen, deepseek]   # 删掉死掉的千问层
```
验证两查：
1. 探针 —— 逐层最小请求（`scripts/check_provider_keys.py`）
2. `hermes chat -q hi -v` → 应见 `API call #1: model=glm-4.5-flash provider=zai` 且**没有 Fallback 行**

⚠️ `model.default` 和 `providers.<x>.model` 是**两个位置**，只改一个会留下另一个指向收费模型（本次默认值竟还停在收费的 `glm-5.3`）。

## 可复用教训
- 免费名单**逐模型、逐日**变 → 出事先探活，别引用上次会话的结论（本次旧记录说 glm-5.3-flash 免费，已失效）。
- 桌面端 UI 的模型是**会话级覆盖**：改完 config.yaml，UI 里旧会话可能仍钉着死模型 → 提醒用户去 UI 切换或新开会话。
