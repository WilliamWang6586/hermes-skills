# QQ Bot 网关运维：重连挂死根因·补丁·群发/文件投递

## 重连挂死 bug（根因 + 补丁，2026-08-12 确认）
- **现象**：QQ Bot WebSocket 断开后重连报 `Failed to get QQ Bot gateway URL`，之后永久卡死不再重试；
  weixin 也一起 `poll error`。
- **根因**：`adapter.py`（`data\versions\<ver>\_internal\plugins\platforms\qqbot\adapter.py` 约 647 行）
  的 `except Exception` 块里调用 `await self._reconnect(backoff_idx)`，而 `_reconnect` 在网关 URL
  获取失败时**抛异常**——异常穿透 except 块杀掉整个重连循环 → 永久静默。
- **补丁**：把该处 `_reconnect` 调用包 `try/except`，异常降级为"失败一次"（ok=False → backoff_idx+=1），
  循环继续按退避(2/5/10/30/60s)重试。改动后 `python -m py_compile` 通过，备份 `D:\Hermes文件库\adapter.py.bak-20260812`。
- ⚠️ **升级 Hermes CN Desktop 后需重新打补丁**（新版覆盖该文件）。对照脚本见 scan_bug 记录。
- 兜底手段：杀 gateway run 进程 → `hermes-agent-cn-runtime-win32-x64.exe gateway run --replace`（后台）
  → 15 秒后日志见 `Ready` 即恢复。杀进程命令：
  `Get-CimInstance Win32_Process | ?{$_.CommandLine -match 'gateway run'} | %{Stop-Process -Id $_.ProcessId -Force}`

## 双实例抢 dispatcher 锁（另一"断连"元凶）
- 症状：网关进程有两个 PID；日志出现 `another gateway already holds the dispatcher lock; this gateway will NOT dispatch`
  → 消息收不到。杀掉**所有** gateway run 进程，只拉起一个单实例即可。

## 群消息（group_openid）—— 配置生效源是 config.yaml，不是 .env！
- 要往 QQ 群发消息：① 把机器人拉进群 ② **config.yaml** `platforms.qqbot.extra.group_policy` 改为 `open`
  （适配器优先读 config，改 .env 的 QQ_GROUP_POLICY 无效！）③ `.env` 加 `QQ_ALLOW_ALL_USERS=true`
  （open 策略的强制安全门槛，否则启动报 `Refusing to start`）④ 重启网关
- ⚠️ 第④步若仍收不到群消息（日志无 group 事件），是 **QQ 开放平台后台**未授权"群聊消息"——
  需在 q.qq.com 开发者后台打开群聊能力 + 白名单授权群号，光拉人进群不够。
- 拿 group_openid：让用户在群里 @ 机器人一次，从 gateway.log 的 `inbound message: platform=qqbot chat=<openid>`
  抓；或群列表接口 `/v2/groups`（可能 404/需群机器人类型，不可靠）。

## 文件/图片投递（MEDIA）
- `hermes send --to qqbot` CLI **不支持 MEDIA 附件**（报 `...only supported for telegram, discord, matrix,
  weixin, signal, yuanbao, feishu, whatsapp`）——CLI 发不了 qqbot 文件。
- **网关对话回复通道**（我回复时写 `MEDIA:<路径>`）支持发文件：适配器 `send_document`（file_type=4）走分块上传，
  日志 `type=4`，HTML 等任意文件可发。图片走 `send_image`(type=1)。
- **HTML 报告发 QQ 用图片兜底**：Edge headless 渲染 → PNG 截图（Edge 路径
  `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`，`--headless=new --window-size=900,30000 --screenshot=...`）
  → Pillow 裁白边（用 `ImageChops.difference` 对页面实际背景色取 bbox，纯白 bbox 会整页误判）
  → 长图按 ~2300px 切 6 段再逐张 MEDIA。QQ 图片最稳，HTML 文件在微信端偶发收不到。

## 凭证/常量
- QQ 适配器常量：`MEDIA_TYPE_IMAGE=1 / VIDEO=2 / VOICE=3 / FILE=4`；`RECONNECT_BACKOFF=[2,5,10,30,60]`、
  `MAX_RECONNECT_ATTEMPTS=100`（constants.py）。intents=`1<<25|1<<30|1<<12|1<<26`（含群@消息）
