# 会话模型漂移：UI 选 flash，日志却一直走 chat

症状（2026-10-19 实录）：用户在桌面端把模型切成 `deepseek-flash`，`config.yaml` 也确认是
`model.default: deepseek-flash`，但 `logs\agent.log` 每轮 `API call #N: model=deepseek-chat`。
用户原话：「1的话每次切出去他就又弄到chat了，没有用」——即切走再切回会话，选择被重置。

## 结论：模型值有四个层级，改错层等于没改

| 层级 | 位置 | 作用 | 查法 |
|---|---|---|---|
| 1 全局默认 | `config.yaml` → `model.default` / `model.provider` | **只决定新会话的初始模型** | `hermes config get model.default` |
| 2 UI 最近选择 | `desktop-ui.sqlite` → `ui_kv` 键 `hermes:last-used-model:managed:<dashboard-url>:<profile>` | 下拉框的"记忆"，新会话沿用 | 读 `ui_kv` 该键 JSON 的 `selection.model` |
| 3 **会话级（真凶）** | `state.db` → `sessions.model` + `sessions.model_config`(JSON) | **resume/切走切回时按 session id 逐字恢复**，覆盖 1、2 | `select id, model, model_config from sessions order by rowid desc limit 8` |
| 4 运行中进程内存 | 桌面端进程 | `switch_model` 在进程内生效，进程重启后从 3 重读 | 日志 `Model switched in-place: a -> b` |

所以「每次切出去就变回去」= 层级 3 里那条会话的 `model_config` 写死了旧模型。
改 `config.yaml` 和 `ui_kv` 都动不了它。

## 诊断顺序（照抄）

1. `hermes config get model.default` → 对不对（排除层级 1）。
2. 读 `ui_kv` 的 `hermes:last-used-model*` → 对不对（排除层级 2）。
3. `logs\agent.log` 找本轮 session id，`API call #N: model=...` 看**实际**发了什么；
   再搜 `Model switched in-place` 看是不是 `X -> X` 空转（= 覆盖请求解析到的还是旧值）。
4. `state.db` 的 `sessions.model` / `model_config` → 命中即根因。
5. 顺带确认模型名真实存在于 provider：`GET https://api.deepseek.com/models`（带 `Authorization: Bearer $DEEPSEEK_API_KEY`，从 `.env` 读）。
   ⚠️别用「DeepSeek 只有 chat/reasoner」这种记忆下结论——2026-10 实测该端点返回 `deepseek-flash`、`deepseek-v4-pro`。

## 修复（按性价比排序，别一上来就改库）

**⓪ 首选 `/new`**：新会话没有层级 3 记录，直接读 `model.default`。用户只想「以后都走 flash」的话，
这一步就结束了，零风险零停机——**先把这个选项摆给用户，别急着动 372MB 主库**。

**① 只改当前会话**（用户坚持要这个老会话换模型时）——必须托盘退出桌面端
（否则 `state.db` 被主库锁住，写入报 `disk I/O error`；UI 也会把内存态盖回）。
退出后：

```sql
update sessions set model='deepseek-flash',
  model_config='{"model":"deepseek-flash","provider":"deepseek","base_url":"https://api.deepseek.com","api_mode":"chat_completions"}'
where id='<session_id>';
```

改前 `Copy-Item state.db state.db.bak-<日期>`。改完重启，再开一轮看日志
`model=deepseek-flash` + `Model switched in-place: deepseek-chat -> deepseek-flash` 才算成。

只改当前会话（最小改动）比批量改全部稳——历史会话的模型记录是事实，不该被篡改。

**② 批量改**（`scripts/fix_session_models.py`）：`--build` 把全库 model 统一成目标值
**写进副本 `state.db.fixed`**（副本不受锁影响，开着 Hermes 也能改），`--swap`
在桌面端退出后把副本换上去（自动备份 + 自检）。适合用户要求「所有会话都改」时。

## ⚠️ 致命坑：agent 活在 Hermes 进程里，改不了自己的库

- **杀掉 Hermes 进程 = 杀掉跑着这条命令的 agent 自己**。所以「退出→改库→重启」这个闭环
  **必须由用户抬手完成**（托盘退出），agent 只能准备好脚本 + 检查就绪状态。
- 用户说「退了」但进程还在：**别信自己上一秒的检测结果**，重查
  `Get-Process | ? ProcessName -like '*hermes*'` + `state.db-wal` 大小。实测用户会
  关了窗口又立刻重开（新 PID、新启动时间），这时任何写入都会失败。
- **别拿 WSL 的 `open(...,'r+b')` 判断锁**：WSL 经 9p/drvfs 映射到的 Windows 文件，
  即使 Windows 侧正被独占锁，WSL 侧 open 也可能成功 → 误报「可替换」。
  **判锁只认 Windows 侧**：`[IO.File]::Open($p,'Open','ReadWrite','None')` 抛异常 = 锁定；
  再加 `state.db-wal` 非空 = 没退干净。
- 换库脚本必须**先查 wal 非空就拒跑**，并用 `os.replace(db, db+'.old')` → `os.replace(fixed, db)`
  的挪走再放回，避免半写；替换后 `sqlite3` 自检 `count(model<>target)==0` 才算完。

## 坑

- **`state.db` 在进程运行时读不了**：`sqlite3.OperationalError: disk I/O error`。
  只读排查要先 `shutil.copy2` 到临时目录（连 `-wal`/`-shm` 一起拷）再开。
- **`desktop-ui.sqlite.ui_kv` 的列名是 `value_json` 不是 `value`**；表里还有
  `session_ui_state(session_id, title_override, archived, pinned, tags_json, workspace_path, updated_at)`，
  **没有模型字段** → 别在这里找模型，模型在 `state.db`。
- `ui_events` 表经常是空的（0 行），`turn_stats` 有 `model` 列可交叉核对每轮真实模型。
- 打包版运行时（PyInstaller 单文件 exe）**搜不到 Python 源码**：`deepseek-chat` 在 exe 里
  只剩字符串零散出现，`.py` 里一行都搜不到 → 别浪费时间去解 PYZ 看 `switch_model` 实现，
  行为已由日志（`Model switched in-place` / `reasoning_config resolved for <model>`）足够判定。
- CN Desktop 的 dashboard（:9120）MODELS 页写的 **"applies to new sessions"** 就是官方承认：
  这里改的只影响新会话，老会话按 `state.db` 走。
