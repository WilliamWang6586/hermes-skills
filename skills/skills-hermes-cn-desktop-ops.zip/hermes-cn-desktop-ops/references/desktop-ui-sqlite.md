# 桌面端 UI 状态真相源：desktop-ui.sqlite（置顶 / 标题 / 会话工作区）

> 2026-10-19 定位。用户问「置顶对话怎么没了」「置顶项目怎么都没了」「历史里显示置顶但左边置顶栏是空的」→ 一律先查这里，别再翻 WebView2 Local Storage（那是空的，2026-10-13 就翻错过一次，白跑一趟）。

## 位置与表结构

`%LOCALAPPDATA%\Hermes Agent CN Desktop\data\hermes-home\desktop-ui.sqlite`

```sql
ui_kv(key TEXT PRIMARY KEY, value_json TEXT, updated_at INTEGER)          -- 真正的 UI 状态都在这
session_ui_state(session_id, title_override, archived, pinned, tags_json, workspace_path, updated_at)
turn_stats / ui_events                                                     -- 遥测，排障一般用不上
```

`updated_at` 有两种单位混用（秒 / 毫秒）→ 转换前先判断 `> 1e12 则 /1000`，否则 `fromtimestamp` 抛 `OSError: [Errno 22]`。

## 关键 key（全部在 ui_kv，值为 JSON）

| key | 含义 |
|---|---|
| `hermes-cn-ui.pinnedSessionIds` | **置顶名单**，JSON 数组，元素 = `state.db.sessions.id` |
| `hermes-cn-ui.sessionTitleOverrides` | 会话标题（数组里有历史短 id 如 `581ac811`，与持久 id 混存） |
| `hermes-cn-ui.sessionWorkspaces` | 每条会话对应的 workspace 路径 |
| `hermes-cn-ui.workspaceProjects` | 侧栏工作区项目列表（`{name,path,createdAt}`） |
| `hermes-cn-ui.workspacePath` | 当前活动工作区 |
| `hermes:gateway-session-map` | 网关临时会话 → 持久 session id |
| `hermes:model-usage-log` | 模型使用计数 |

## 排查套路（把「没了」和「其实是空栏」分清）

1. 只读打开（活库被占用时 `ReadAllBytes` 会报「正由另一进程使用」→ 用 `sqlite3.connect("file:...?mode=ro", uri=True)`，**别复制 leveldb**）
2. 打印 `ui_kv` 全表 + `session_ui_state` 全表
3. 拿 `pinnedSessionIds` 的每个 id 去 `state.db` 的 `sessions` 对一遍：
   - 全部命中 → **数据没丢**，是左侧栏的显示过滤问题（当前工作区/来源筛选把它们挡掉了），别急着说「丢了」也别急着写库
   - 有 id 对不上 → 才是真脏数据，清理无效 id
4. 顺带看 `sessions.end_reason`：`ws_orphan_reap` = 桌面端 WebSocket 断连时被当成孤儿回收，**不是用户手动关的**（用户会以为是自己弄丢的）

## 已知事实（本版本 0.19.0-cn.7）

- **界面有置顶开关**（2026-10-19 实测，早先「没有入口」的结论是错的）：会话行右侧「⋯」菜单第一项就是 `置顶 / 取消置顶`。源码 `web/src/components/session-actions/session-row-menu.tsx`（`onTogglePin`）+ `web/src/lib/session-ui-state.ts`（读写 `ui_kv`，乐观更新后立刻落库）
- 前端 bundle 是 `data\dashboard\web_dist\assets\index-*.js`（无 `pinned` 字样，别在这找）；真正的 key 名藏在 WebView2 的 `Code Cache\js\*` 里 —— **用二进制扫 `hermes-cn-ui.` 前缀找约定位置**，比读 2MB minified bundle 快得多
- 改法：写前备份 `desktop-ui.sqlite`，只 UPDATE/DELETE `ui_kv` 那一个 key（`value_json` 保持 JSON 字符串），然后退出重开桌面应用

## ⛔ 致命坑：直接写 `pinnedSessionIds` 会被前端自动清空

`web/src/components/app-shell/workbench-sidebar.tsx`（v0.19.0 附近 commit）里有这段：

```ts
useEffect(() => {
  if (!data || data.total > sessions.length || pinnedSessionIds.size === 0) return;
  const liveIds = new Set(sessions.map(s => s.id));
  const staleIds = [...pinnedSessionIds].filter(id => !liveIds.has(id));
  if (staleIds.length > 0) setPinnedSessionIds(unpinSessions(staleIds));   // 写回 sqlite
}, [sessions, pinnedSessionIds]);
```

- 侧栏用的是 `useSessions()` **默认 limit=50**；`total > sessions.length` 时守卫跳过，分页拉满时守卫放行
- ⇒ **会话总数一旦 ≤ 50（或某次拉满），所有不在前 50 的置顶 id 会被当成「已删会话」永久抹掉**（连 sqlite 一起改）。写完重启一轮就少几条，别怀疑自己写错了值
- 症状指纹：只留下最新的 1~2 条置顶，老的全没了；`ui_kv` 回读确实只剩少数几条
- **正确做法 = 在 UI 里从「对话历史」底部（最老的会话）开始逐条「⋯ → 置顶」**，置顶的同时该会话已加载，清理逻辑删不到它。**别改库**（改几次被清几次）
- 真要根治只能改前端（按 id 单独拉数据 / 清理条件加 `data.total > 50` 判断），属上游 bug，可提 issue 给 `Eynzof/Hermes-CN-Desktop`

## 前端源码怎么读（不要拿 exe 硬解包）

- `hermes-agent-cn-desktop.exe` 是 Tauri/Rust 壳，前端打包在二进制里，**strings/asar 解析都挖不到**（实测白耗十几轮）
- 直接拉 GitHub 源码最快：`https://raw.githubusercontent.com/Eynzof/Hermes-CN-Desktop/<sha>/web/src/...`
  - 文件清单：`https://api.github.com/repos/Eynzof/Hermes-CN-Desktop/git/trees/<sha>?recursive=1`（一次拿全树，`raw.githubusercontent` 走 raw 域名更稳，api.github.com 常 429）
  - 关键文件：`web/src/components/app-shell/workbench-sidebar.tsx`（侧栏分区/置顶渲染）、`web/src/hooks/use-sessions.ts`（`limit` 默认值 + `api/sessions` 分页）、`web/src/lib/session-ui-state.ts`（ui_kv 读写）、`src/ui_store.rs`（Rust 侧 `snapshot`/`set_kv`，确认无缓存、每次直读 sqlite）
- 判断「改库有没有用」的顺序：先看前端有没有缓存/守卫 → 再看 Rust 侧 → 最后才动手写库

## 一行扫描器（找任意 UI key 落在哪个库）

```python
import os
for d,_,fs in os.walk(os.environ["LOCALAPPDATA"]+r"\Hermes Agent CN Desktop"):
    if any(s in d for s in ("node_modules","webview2","skills","bundled-")): continue
    for f in fs:
        p=os.path.join(d,f)
        try:
            if os.path.getsize(p)>80*1024*1024: continue
            if b"hermes-cn-ui." in open(p,"rb").read(): print(p)
        except Exception: pass
```
