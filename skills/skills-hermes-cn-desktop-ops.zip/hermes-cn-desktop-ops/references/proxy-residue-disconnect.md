# Hermes 因代理残留而"断连"——三层根因与修复

**触发症状**：用户说"我关掉 VPN/夜煞云，你就卡住/不响应了""明明网络是通的但你死了"。
**本质**：不是网络问题，是进程/系统里残留指向已死代理端口（如 `127.0.0.1:7892`）的配置，
代理服务一停，Hermes 把请求发往死端口 → 全部超时。

## 三层残留（缺一不可，每次都要全查）

Python 的 HTTP 栈解析代理的顺序：**环境变量 → Windows 系统代理注册表**。

### 第 1 层：环境变量
- `HKCU:\Environment` 的 `HTTP_PROXY` / `HTTPS_PROXY` / `ALL_PROXY`（服务器/VPN 客户端写入）
- ⚠️ **改注册表对已运行进程无效**——进程启动时已把 env 固化。必须让进程重启。
- ⚠️ Hermes `terminal` 工具的 shell 自身也可能带着旧 env（shell 在 VPN 开启时启动）。
  `$env:HTTP_PROXY=$null` 只影响后续命令，不影响已存在的其他进程。

### 第 2 层：Windows 系统代理注册表（最容易漏）
```
HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings
  ProxyEnable = 1
  ProxyServer = 127.0.0.1:7892
```
Python `urllib.request.getproxies()` / requests **每次请求实时读这里**。VPN 客户端
（夜煞云等）的"系统代理"开关就是写这两个值。VPN 一退，端口消失但注册表仍指着它。

### 第 3 层：进程继承
桌面应用启动时会派生 runtime（gateway / dashboard）。如果**父进程**带着代理，
子进程必然继承。只重启 gateway 而不重启桌面应用 = 没修好。

## 诊断（按序，一锤定音）

```powershell
# ① Python 实际读到的代理 —— 决定性判据
python3.14 -c "import urllib.request; p=urllib.request.getproxies(); print(p if p else 'EMPTY-OK')"
#   {'all': 'http://127.0.0.1:7892', ...} = 仍有残留
#   EMPTY-OK = 干净

# ② 三处残留源
$env:HTTP_PROXY
(Get-ItemProperty HKCU:\Environment).HTTP_PROXY
$s = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"; "$($s.ProxyEnable)|$($s.ProxyServer)"
netsh winhttp show proxy   # 通常无关，顺手看

# ③ 代理端口是否还活着（比查进程名更可靠）
Get-NetTCPConnection -State Listen -LocalPort 7892 -ErrorAction SilentlyContinue

# ④ Hermes 进程是否正连着代理
Get-Process | ? { $_.Name -match 'hermes-agent-cn' } | Select -ExpandProperty Id | % {
  Get-NetTCPConnection -State Established -EA SilentlyContinue | ? { $_.OwningProcess -eq $_ -and $_.RemotePort -eq 7892 } }
```

**判断 VPN 是否真退干净**：用 ③ 查端口监听，**不要**只看进程名——VPN 的 UI 壳进程可能残留，
但只要核心进程（如 `yeshayunCore`）退了、端口不再监听就已经干净。反之，关掉 VPN 后仍有
别的程序连 7892（豆包 / Edge / VPN 自身）是正常的，**只要不是 Hermes 进程就行**。

## 修复（三件套，顺序重要）

```powershell
# ① 清注册表环境变量（先备份值）
Remove-ItemProperty HKCU:\Environment -Name HTTP_PROXY,HTTPS_PROXY,ALL_PROXY,NO_PROXY -EA SilentlyContinue

# ② 关系统代理注册表（这一步是最常漏、也最关键的一步）
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable -Value 0
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyServer -Value ""

# ③ 在【同一条命令里】清空 env + 杀旧进程 + 干净重启 —— 三者必须同一次调用
$env:HTTP_PROXY=$null; $env:HTTPS_PROXY=$null; $env:ALL_PROXY=$null; $env:NO_PROXY=$null
Stop-Process -Id <旧gatewayPID> -Force
# 然后 background=true 拉起（启动命令里再清一次 env 兜底）：
#   versions\<ver>\hermes-agent-cn-runtime-win32-x64.exe -m hermes_cli.main gateway run --replace
```

**最省事的等价做法**：完成 ①② 后，让用户**手动退出并重开 Hermes 桌面应用**
（桌面应用会用当前干净环境重新派生全部子进程），比 agent 自己杀进程链更安全，
且不会切断正在进行的对话。推荐给用户选这条。

## 验证

- `getproxies()` 返回空 → 干净
- 新 gateway 进程**无** 7892 连接，外连全是公网 IP（如 42.81.x = 腾讯微信/QQ）
- 关掉 VPN 后仍能正常对话 = 真正修好

## 开机自启要加固（否则重启后又带残留）

Gateway 自启脚本（启动文件夹 `Hermes_Gateway.vbs` → `hermes-home\gateway-service\Hermes_Gateway.vbs`）
在 VPN 开启时创建的话，开机启动会继承当时的代理残留 → 重启后问题复发。
在 VBS 里**显式清空代理变量**再拉起进程：

```vbscript
' 加在 sh.Run 之前
env.Item("HTTP_PROXY") = ""
env.Item("HTTPS_PROXY") = ""
env.Item("ALL_PROXY") = ""
env.Item("http_proxy") = ""
env.Item("https_proxy") = ""
env.Item("all_proxy") = ""
env.Item("NO_PROXY") = ""
```

⚠️ 这只清 **Hermes 进程自己**的 env，不动系统代理 —— 用户自己上网照常走代理。

## ⛔ 反面做法：别去"永久清掉系统代理"来自动修复 Hermes

**踩过的坑（2026-09-13，用户明确纠正）**：为了让 Hermes 每次开机都干净，
差点往启动文件夹塞一个开机执行 `reg add ... ProxyEnable /d 0` 的 `.bat`。

这是**错的**——用户自己在校园网/家里上网**依赖**系统代理（夜煞云等）。
开机强清系统代理 = 用户自己的浏览器/VPN 全废。

正确的心智模型：
- **要修的是「让 Hermes 不受代理影响」，不是「把系统代理关掉」。**
- Hermes 的模型后端（DeepSeek / DashScope）都是**国内站，直连即可**，天然不需要代理。
- 落地点：只让 Hermes 自己的进程/启动脚本清 env（见上一节），系统代理一概不碰。
- 代理策略一句话：**有代理用代理，没代理走直连**；Hermes 侧永远直连最省事。

用户问「能不能做成自启动不再出错」时，先分清他要的是哪个：
**(A)** 让 Hermes 稳定（→ 清 Hermes 自己的 env，系统代理不动）
**(B)** 让某个上网工具（Watt Toolkit / 夜煞云）随开机启动（→ 启动文件夹加快捷方式，**先确认该软件已安装**）。
别把 (A) 和 (B) 混成一个"清代理"动作。

## 顺手查：要自启的软件装了没

加自启前先确认目标 exe 存在，别假设：

```powershell
Get-Process | ? { $_.Name -match 'watt|steam\+\+|SteamTools' } | Select Id,Name,Path
@("C:\Program Files","C:\Program Files (x86)","$env:LOCALAPPDATA\Programs") | % {
  Get-ChildItem $_ -Recurse -Include "SteamTools.exe","WattToolkit.exe" -EA SilentlyContinue -Depth 3 }
```

确认存在后，快捷方式进启动文件夹（非管理员也能用）：

```powershell
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut("$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\<名称>.lnk")
$s.TargetPath = "<exe 完整路径>"; $s.Save()
```

## 踩过的坑

- ❌ 只清注册表不重启进程 → 已运行进程仍带旧 env（这是"以为修好了其实没好"的最常见原因）
- ❌ 在带代理的 terminal 会话里重启 gateway → 新进程又继承代理，白重启
- ❌ 测试时临时把 `ProxyEnable` 设回 1 就忘了关 → Python 又走代理
- ❌ 只重启 gateway 不重启桌面应用 → 桌面 UI 那条链仍是旧进程
- ⚠️ `gateway_state.json` 可能不刷新 PID（新旧 PID 不一致是正常的，别被误导；以实际进程和日志为准）
- ⚠️ 参数化脚本时不要在子进程里调 `python3.14` 这种别名 —— `subprocess` 找的是可执行文件名，
  别名是 shell 层的，会 `FileNotFoundError [WinError 2]`。用完整路径
  `C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`。
