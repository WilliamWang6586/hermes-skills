# Hermes Token / 成本优化实操（2026-09-11 实测）

触发：用户说"优化 token 使用 / 省 token / 减少非必要消耗 / 账单太贵"。

## 1. 先量（别瞎优化）

### 宏观
```
hermes insights --days 7
```
输出：会话数/消息数、各模型 tokens、平台、Top 工具、Top 技能加载、活跃时段。
2026-09-11 实测本机 7 天：2 会话 / 260 消息 / **1240 万 tokens**；`deepseek-v4-flash` 占 10.9M。

### 微观 —— 拆 request dump（每轮到底发了多少）
Hermes 把请求体落盘到 `hermes-home\sessions\request_dump_*.json`。结构：
`{timestamp, session_id, reason, request:{method,url,headers,body}, error}`，其中 `request.body` 是 **JSON 字符串**（需 `json.loads`），含 `messages` / `tools`。

```
python3.14 scripts/analyze_request_dump.py "<request_dump_*.json>"
```
2026-09-11 实测某会话：**messages 802 条 / 35 万 tokens**；system 提示 33,136 字符（~11K tok）；tools 17 个 31,084 字符（~10K tok），其中 delegate_task 5,971 / terminal 6,168 / skill_manage 4,151 字符最大。

**结论：每轮固定开销 ≈ 21K tokens（系统提示 + 工具 schema），但真正的成本杀手是超长会话里 messages 的累积。**

## 2. 本机根因（2026-09-11）

- **`deepseek-v4-flash/pro` 上下文窗口 = 1,000,000**（`models_dev_cache.json` 里 `limit.context`）。默认 `compression.threshold: 0.5` → **50 万 tokens 才触发压缩** → 会话涨到 35 万也不瘦身。
- 压缩本身是开的（`hermes config` 的 "Context Compression" 段：Enabled=yes / Threshold=50% / Target ratio=20% / Protect last 20 / Protect first 3）。
- 单会话 token 数 ≈ O(n²)：每条消息每轮都重发，会话越长单请求越大。

## 3. 改法（已采用）

```powershell
hermes config set model.context_length 131072    # 按 128K 算窗口 → 压缩在 40%≈52K 触发
hermes config set compression.threshold 0.4      # 默认 0.5
hermes tools disable image_gen tts computer_use --platform cli
```
- 效果：长会话单请求上限 35万 → ~52K，**约 -85%**。
- 改后需**重启桌面应用 / 开新会话**生效。
- 改前备份：`Copy-Item config.yaml D:\Hermes文件库\config-backup-token-<日期>.yaml`。
- ⚠️ `model.context_length` 只是告诉 Hermes 按这个窗口算压缩时机，不会真的截断到 128K，安全。

### 平台名（踩坑）
`hermes tools disable/list` 的 `--platform` **没有 `desktop`**——桌面端会话用 **`cli`**。
有效值：`cli telegram discord slack whatsapp whatsapp_cloud signal bluebubbles email homeassistant mattermost matrix dingtalk feishu wecom wecom_callback weixin qqbot yuanbao webhook api_server cron`。

## 4. 固定开销瘦身

| 开销源 | 实测 | 减负 |
|---|---|---|
| 工具 schema | 17+ 工具 ~10K tok/轮 | `hermes tools disable <没用过的> --platform cli` |
| 技能清单 | `skills\` 下 179 个 SKILL.md，整份注入 ~5K tok/轮 | 移到 `skills-parked\`（可逆） |
| 记忆 | MEMORY.md 8.4KB + USER.md 1.5KB | 压缩流程见 hermes-desktop-ops |

- `hermes skills config` **纯交互式（无参数）**，脚本化不了 → 用文件系统挪目录代替（`Move-Item skills\<名> skills-parked\`，改回即恢复）。
- 7 天实测只加载过 4 个技能（windows-remote-ops / hermes-agent / codex / web-access）→ 绝大多数是死重。

## 5. 习惯（最省且免费）
- **一个任务一个 `/new`**：上下文每轮重发，会话越长越贵。
- 长任务中途 `/compress`。
- 别在 `request_dump` 里找 dump —— 它在 `hermes-home\sessions\`，文件名 `request_dump_*.json`。

## 6. 排查命令速查
```
hermes insights --days N
hermes config                                    # 看 Context Compression / model 段
hermes tools list [--platform cli]               # ✓enabled / ✗disabled
python3.14 scripts/analyze_request_dump.py "<request_dump 路径>"
```
