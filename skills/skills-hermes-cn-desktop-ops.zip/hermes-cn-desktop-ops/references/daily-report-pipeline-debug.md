# 日报 / 推送流水线排障（2026-09-21 实测，Windows + Hermes CN Desktop）

> 适用：`D:\Hermes文件库\每日科技日报\` 下的 `daily_pipeline.ps1` → `push_wechat.py` → 微信/QQ 推送链路。
> 同类问题（定时任务 `LastTaskResult != 0`、推送内容为空、板块缺失）先读本文件。

## 一、通用排障顺序（照这个走，别跳）

1. **先跑脚本看真实输出，别读代码猜。**
   `push_wechat.py` 成功时也会打印关键指标，一句话定位问题：
   ```
   ✓ 已生成文字版摘要 (106 字符, 0 板块)     ← 坏：0 板块 = 解析全废
   ✓ 已生成文字版摘要 (1931 字符, 13 板块)   ← 好
   ```
   **`0 板块` 是最高价值的单一信号** —— 出现即判定"解析器与 HTML 结构不匹配"，与网络/权限无关。

2. **确认读的是哪份文件。** 解析类的 bug 十次有九次是**读错源**，不是解析写错。
   脚本里找 `find_latest_html()` 之类函数，看它**优先**返回什么路径。

3. **用脚本里的正则直接测真实 HTML**，别肉眼比对。写成小脚本打印每个 pattern 的命中数：
   ```python
   for name, pat in [("title", title_pat), ("sub", sub_pat), ("card", card_pat)]:
       print(name, len(pat.findall(html)))
   ```
   **命中 0 的那个 pattern 就是 bug 所在。**

4. **最后才怀疑网络/权限/限流**（见第四节，限流往往不是你以为的那样）。

## 二、坑 1：读错了 HTML 源 → 内容被静默替换成旧版/残版

**症状**：摘要能生成，但**丢板块**（本次：丢了「📢 吉大校内通知」）。

**根因**：`push_wechat.py` 的 `find_latest_html()` **优先读**
`C:\Users\<user>\.hermes\cron\output\tech_daily_latest.html`。
该副本由**已废弃的** `deliver_report.ps1` 维护（它**只 touch 时间戳、不复制内容**），
因此**不含** `daily_pipeline.ps1` 中途前置进去的「吉大校内通知」块。

**验证手法**（一眼定案）：
```powershell
$c1 = [IO.File]::ReadAllText("C:\Users\<user>\.hermes\cron\output\tech_daily_latest.html", [Text.Encoding]::UTF8)
$c2 = [IO.File]::ReadAllText("D:\Hermes文件库\每日科技日报\<today>\科技日报_<today>.html", [Text.Encoding]::UTF8)
Write-Output "cron 副本含吉大通知: $($c1.Contains('吉大校内通知'))"
Write-Output "主产物含吉大通知:   $($c2.Contains('吉大校内通知'))"
```

**修法**：改 `find_latest_html()` 优先级为
**① 今日主产物 → ② 主产物里最近一天 → ③ cron 副本兜底**。

**⚠️ 通用教训**：**"生成产物" 与 "推送读取源" 必须指向同一份文件。**
流水线中途修改过产物（如前置注入内容）时，任何走缓存/副本的读取方都会拿到残版。

## 三、坑 2：正则假设的 class 不存在 → 0 板块 / 空壳消息

**症状**：`0 板块`，推送内容只有标题和空行，但**脚本不报错**（静默失败，最坑）。

**根因**：解析器找 `class="section-title"` + `<span class="icon">`，
但 HTML 生成器已改版，**这两个 class 根本不存在**。

**真实层级（日报 v2，2026-09 实测）**：
```html
<h2>今日头版 <span class="count">FEATURED</span></h2>          ← 板块（12 个）
<div class="sub-sec-title">每日最新论文（arXiv 实时）</div>     ← 子块（11 个）
<h3><a href="...">条目标题</a></h3>                            ← 正规条目
<div class="semi-card">…<h3><a>标题</a></h3>                   ← 半卡条目
<div class="band-card">…<h3><a>标题</a></h3>                   ← 带状卡条目
<div class="cam-brand">品牌<span class="cam-model">型号</span>   ← 相机行情
```

**✅ 正确做法**：以 **`<h2>` 切板块**，`sub-sec-title` 归入该板块的 `subs`。
**❌ 错误做法**：用 `sub-sec-title` 切板块 —— 会把**子块误当板块**，
且**漏掉没有子块的板块**（今日头版 / 财经 / 名词速查 / 热度榜）。

**⚠️ 通用教训**：**层级标签要选"每板块恰好一个"的那一级**。
`section-title` 和 `sub-sec-title` 只差一个 `sub-`，语义完全不同 ——
改版后务必先用命中次数验证哪一级才是板块。

## 四、坑 3：限流文案 ≠ 限流原因（不要照着文案去修）

**症状**：
```
{"error": "Weixin send failed: iLink sendmessage rate limited; cooldown active for 30.0s"}
```

**❌ 错误假设**：这是本地冷却计时器，等 30 秒就好 / 拉开任务间隔就好。

**✅ 实测证据（推翻错误假设）**：
| 观测 | 数据 | 推论 |
|---|---|---|
| 两次失败间隔 | **9 分钟** | 远超 30 秒 → 不是 30s 计时器 |
| 连续两次失败间隔 | **7 秒** | 计时器不会这样 |
| 等 **90 秒**后单发纯文本 | **仍失败** | 不是等待时长问题 |
| **同一时刻** QQ 推送 | ✅ 正常（82.7KB） | 不是 Hermes 发送链路问题 |

→ **`cooldown active for 30.0s` 是 iLink 服务端返回的固定文案**，
不代表真实等待时长。触发原因是**短时高频**（当日测试连发 5+ 条）导致的临时风控，**会自行恢复**。

**⚠️ 通用教训**：**限流/风控类错误，用"变间隔重试"证伪，别看文案猜。**
- 间隔 5s / 90s / 9min 都失败 → 服务端状态
- 只有短间隔失败、长间隔成功 → 才是真的计时器

**归因不要越界**：微信**文本**通道本身是通的（见 `weixin-media-send.md`），
只有**媒体/附件**不可用（`ret: -2`）。别把"文本限流"推断成"微信通道坏了"。

## 五、正确做法：把"发两次"合并成"发一次"

**原始架构缺陷**（本次的实际根因）：
```
18:30  Hermes每日科技日报       → 发微信（占额度）
18:35  Hermes每日科技日报推送   → 再发微信 → 必撞限流（LastTaskResult=1）
```
**两个任务给同一个渠道发同一类内容，本身就是错的**，限流只是把它暴露出来。

**修法**（比加重试/挪时间都干净）：
1. 把推送脚本作为日报流水线的后续步骤（本次是 `daily_pipeline.ps1` **第 5 步**）
2. 放在**产物落盘之后**（否则读到旧版 HTML／缺前置内容）
3. 删掉独立的推送定时任务：
   ```powershell
   Unregister-ScheduledTask -TaskName "Hermes每日科技日报推送" -Confirm:$false
   ```
4. 失败不阻断：`& $py … *>> $log` + `if ($LASTEXITCODE -ne 0) { Write-Host … }`

**⚠️ 通用教训**：**同一渠道的多次推送 = 先合并，再考虑重试。**
重试和挪时间都是在掩盖"不该发两次"这个设计问题。

## 六、验证清单（改完必跑）

- [ ] 单跑解析自检（**不发消息**）：`python 每日科技日报\test_push_wechat.py`
      断言应包含：板块数 ≥ 10、条目数 ≥ 20、摘要 > 1000 字符、关键板块（吉大通知）非空
- [ ] 单跑整条流水线，看 stdout 与 `pipeline_log.txt`
- [ ] 确认产物路径与读取源指向同一份文件（第二节验证手法）
- [ ] 确认定时任务只剩一个、且指向改过的脚本
- [ ] 清理调试用临时文件（`D:\Hermes文件库\_*.txt|_*.py`）

## 七、环境细节（别重复踩）

- **`pipeline_log.txt` 是 UTF-16** → `Get-Content -Encoding Unicode` 才能读；用 `-Encoding UTF8` 会得到乱码/空
- **定时任务无控制台时 stdout 默认 GBK** → 跑 Python 必须 `$env:PYTHONUTF8="1"`，否则 `print(emoji)` 直接崩
- **`hermes.cmd` 路径**：`<data>\desktop-bin\hermes.cmd`
- **cron 输出目录**：`C:\Users\<user>\.hermes\cron\output\`（**不是** `data\hermes-home\cache\cron\output\`，后者不存在）
- **只跑不发的自检**优于"跑了再说" —— 微信推送是**有外部副作用**的操作，测试时不要把消息发到用户手机上
