# 视觉（图片/视频识别）配置（原独立技能 hermes-vision-setup，2026-10 并入本 umbrella）

核心结论：**文本模型 ≠ 视觉模型**。DeepSeek 文本模型不能看图，必须单独配一个支持视觉的提供商。

## 何时用

- 用户问「怎么让你识别图片/视频」「支持多模态吗」
- 用户给了视觉模型 API Key 要求配置
- 要测试某个视觉 Key 是否可用
- `vision`/`video` 工具集或 `auxiliary.vision` 不工作

## 提供商视觉能力速查（2026-07 实测）

| 提供商 | 视觉模型 | 状态 | 说明 |
|--------|---------|------|------|
| DeepSeek | — | ❌ 无视觉 | 纯文本，配了也看不了图 |
| Google Gemini | gemini-2.x-flash | ✅ | 有免费额度，国内需代理 |
| 阿里 DashScope（千问） | qwen-vl-max / qwen-vl-plus | ✅ | 国内可充值，中文 OCR 强，**截图转录首选** |
| 智谱 GLM | glm-4v | ✅ | 国内可用 |
| 小米 MiMo / Token Plan | — | 视套餐 | 见 `references/llm-platform-pricing.md` |

## 配置位置

`config.yaml` 的 `auxiliary.vision`（模型 + provider + api_key_env）：
- 密钥写 `.env`（如 `DASHSCOPE_API_KEY`），config 里只放 `api_key_env` 引用，**不要写明文**
- ⚠️ `patch`/`write_file` 拒绝直接改 config.yaml（安全保护）→ 用 `hermes config set` 或 Python + `yaml.safe_load`
- 改完必须**重启桌面应用**（改配置文件不会热重载）；API Key 变更还需重启 gateway runtime

## Key 有效性测试

先单独打一次 HTTP 请求确认 Key 与模型名都对，再改 config：
```
POST https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions
{"model":"qwen-vl-max","messages":[{"role":"user","content":[{"type":"image_url","image_url":{"url":"data:image/png;base64,..."}},{"type":"text","text":"描述这张图"}]}]}
```
HTTP 200 且有内容 = Key 可用；401 = Key 错；404/model not found = 模型名或地域端点不对，**别误判成 Key 失效**。

## 常见错误

| 症状 | 根因 | 处理 |
|---|---|---|
| 看图工具报「模型不支持图片」 | 主模型是纯文本 | 配 `auxiliary.vision` 指向视觉模型 |
| 「Provider 配置未配置」 | config.yaml 缺 `providers:` 段 | 补 provider，密钥走 `api_key_env` |
| 401 | Key 错/过期/地域不对 | 单测 HTTP 再改 config |
| 429 / 余额不足 | 额度耗尽 | 换 provider 或充值，见 `references/ai-cost-audit.md` |
| 配置改了没生效 | 桌面应用未重启 / 被 UI 覆盖 | 重启桌面应用；查 `references/desktop-ui-sqlite.md` |

## 相关

- `references/dashscope-vision.md` — DashScope 视觉调用细节
- `references/bill-reconciliation-ocr.md` — 票据/账单 OCR 实战
- `scripts/recognize_image.sh`、`scripts/recognize_upload_py.py` — 现成识别脚本
- 截图转录（课表/选课）流程见 `jlu-knowledge-ops` 的 `references/screenshot-ocr-extract.md`
