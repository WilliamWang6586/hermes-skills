# 微信网关媒体发送诊断（2026-08-07 实测）

## 结论
- ilinkai 微信网关（WeixinClawBot 显示名）：**文本消息完全正常**，**媒体/文件附件不可用**。
- 错误码：`Weixin media send failed: getUploadUrl returned neither upload_param nor upload_full_url: {'ret': -2}`

## 验证过程
1. 对话内嵌 `MEDIA:/path` 发送 HTML → 用户未收到
2. 转 PDF 后 MEDIA 发送 → 用户未收到
3. PNG 截图 MEDIA 发送（多种路径格式含 `/C:/...`、`C:/...`）→ 用户未收到
4. `hermes send --to weixin:o9cq808CKNrAgBSHkl6Er7JazfSg@im.wechat "MEDIA:D:\...\x.png" --json`
   → `{"error": "Weixin media send failed: getUploadUrl returned neither upload_param nor upload_full_url: {'ret': -2}"}`
5. 同通道纯文本 `hermes send --to weixin:... "测试消息"` → `{"success": true, ...}` 用户确认收到

## 诊断要点
- `hermes send` 是验证渠道能力的最快路径：文本成功 + 媒体失败 = 问题在平台 CDN 上传接口，不是 Hermes 发送链路。
- `ret: -2` 由 ilinkai 平台的 getUploadUrl 接口返回，疑似账号媒体权限受限或服务端限制，本地无法修复。
- 配置：`WEIXIN_BASE_URL=https://ilinkai.weixin.qq.com`，`WEIXIN_CDN_BASE_URL=https://novac2c.cdn.weixin.qq.com/c2c`，`WEIXIN_TOKEN=f1b9d662a8d1@im.bot:...`（账号 f1b9d662a8d1@im.bot），DM 白名单 `WEIXIN_ALLOWED_USERS=o9cq808CKNrAgBSHkl6Er7JazfSg@im.wechat`。

## 替代方案（按优先级）
1. 文件放 `D:\Hermes文件库\` 下，告知用户路径，电脑上自取
2. 文本/Markdown 摘要（微信支持富文本渲染）
3. 若必须图片：生成 PNG 后仍走不了 CDN，只能本地路径

## 可行的文本推送模式（2026-08-07 实战验证）
- **`hermes send --to weixin:<chat_id> --file <utf8文本文件>`** — 从文件读消息体，成功且用户能收到。
- 必须用 `--file` 而不是把中文塞进命令行参数（Windows 命令行编码坑 + 引号转义坑）。
- 参考实现：`D:\Hermes文件库\每日科技日报\push_wechat.py` —— 解析 HTML 提取摘要 → 写临时 txt → `--file` 发送。用 subprocess 调 `hermes.cmd`（全路径），`capture_output=True, encoding="utf-8"`。
- 用 `hermes send --list` 确认当前可用目标（weixin 的 chat_id 是 `o9cq808CKNrAgBSHkl6Er7JazfSg@im.wechat`）。
