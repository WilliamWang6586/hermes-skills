# QQ Bot 平台接入（CN 桌面版移植配方）

## 背景

Hermes CN Desktop 打包版 **裁掉了 qqbot 适配器**（`_internal\gateway\platforms\` 只有 ADDING_A_PLATFORM.md），但 gateway setup 菜单仍显示 "🐧 QQ Bot"（菜单静态列出，实际无代码）。完整版代码存在于 pip 安装的 site-packages：`C:\Users\王子涵\AppData\Roaming\Python\Python314\site-packages\gateway\platforms\qqbot\`。

## 移植步骤（已验证 2026-08）

1. **复制适配器代码**到插件目录：
   ```
   src:  C:\Users\王子涵\AppData\Roaming\Python\Python314\site-packages\gateway\platforms\qqbot\*.py
   dst:  <HERMES_HOME>\..\bundled-plugins\platforms\qqbot\
   ```
   文件：adapter.py(123KB) / chunked_upload.py / constants.py / crypto.py / keyboards.py / onboard.py / utils.py / __init__.py

2. **改绝对导入为相对导入**（adapter.py + chunked_upload.py）：
   - `from gateway.platforms.qqbot.constants import ...` → `from .constants import ...`
   - 同理 utils / chunked_upload / keyboards

3. **__init__.py 补插件注册入口**（模仿 telegram 插件 bundled-plugins/platforms/telegram/__init__.py）：
   ```python
   import os
   from .adapter import QQAdapter, check_qq_requirements, MAX_MESSAGE_LENGTH

   def _build_adapter(config):
       return QQAdapter(config)

   def _is_connected(config) -> bool:
       app_id = getattr(config, "extra", {}).get("app_id") or os.getenv("QQ_APP_ID")
       secret = getattr(config, "extra", {}).get("client_secret") or os.getenv("QQ_CLIENT_SECRET")
       return bool(app_id and secret)

   def register(ctx) -> None:
       ctx.register_platform(
           name="qqbot", label="QQ Bot",
           adapter_factory=_build_adapter,
           check_fn=check_qq_requirements,
           is_connected=_is_connected,
           required_env=["QQ_APP_ID", "QQ_CLIENT_SECRET"],
           allowed_users_env="QQ_ALLOWED_USERS",
           allow_all_env="QQ_ALLOW_ALL_USERS",
           cron_deliver_env_var="QQBOT_HOME_CHANNEL",
           max_message_length=4000, emoji="🐧",
           allow_update_command=True,
       )
   ```
   注：QQAdapter 构造函数签名是 `__init__(self, config: PlatformConfig)`。
   注 2：**必须给 connect 加 `is_reconnect` 参数**——`async def connect(self) -> bool:` 改成 `async def connect(self, is_reconnect: bool = False) -> bool:`，否则新版 gateway 重连时传 `is_reconnect=` 报 `got an unexpected keyword argument`，重连永远失败（日志每 60-300s 重试递增）。

4. **plugin.yaml**（name 必须 `qqbot-platform`，kind: platform，requires_env 声明 QQ_APP_ID/QQ_CLIENT_SECRET，optional_env 声明 QQ_ALLOWED_USERS/QQ_ALLOW_ALL_USERS/QQ_HOME_CHANNEL/QQ_DM_POLICY/QQ_GROUP_POLICY）

5. **启用插件**：config.yaml `plugins.enabled` 加 `qqbot-platform`（⚠️ `hermes config set plugins.enabled ponytail,qqbot-platform` 会写成字符串，需 Python 修复为列表）

6. **.env 写入凭证**（插件通过 env 读取）：
   ```
   QQ_APP_ID=1905378483
   QQ_CLIENT_SECRET=<32位secret>
   QQ_ALLOWED_USERS=<openid>
   QQBOT_HOME_CHANNEL=<openid>   ← 必须，否则 send 报 "No home channel set"（旧名 QQ_HOME_CHANNEL 已废弃，会打 deprecated 警告）
   QQ_DM_POLICY=allowlist
   QQ_GROUP_POLICY=disabled
   ```

7. **重启 + 验证**：
   - 重启 Hermes CN Desktop → `hermes send --to qqbot "测试" --json` 看 `"success": true`
   - ⚠️ **重启桌面应用不会杀旧 gateway 进程**：改完插件/配置后检查 `data\gateway-runtime\gateway_state.json` 的 pid，若仍是旧进程 → `Stop-Process <pid>` 然后 `versions\<ver>\hermes-agent-cn-runtime-win32-x64.exe gateway run --replace` 手动拉起（日志确认 `[QQBot] Connected` + `✓ qqbot connected`）
   - ⚠️ **删 `__pycache__`**：插件目录下 py_compile 会生成 pyc；改 .py 后不删缓存，gateway 加载旧字节码，改了个寂寞

## 扫码绑定（无需开放平台注册）

官方支持扫码绑定，脚本流程（D:\Hermes文件库\qqbot_bind.py）：
1. `POST https://q.qq.com/lite/create_bind_task` body `{"key": aes_key_base64}`（key = base64(32字节随机)）→ task_id
2. 二维码 URL：`https://q.qq.com/qqbot/openclaw/connect.html?task_id={task_id}&_wv=2&source=hermes`（qrcode 库生成 PNG，os.startfile 弹出）
3. 手机 QQ 扫码 → `POST https://q.qq.com/lite/poll_bind_result` body `{"task_id": ...}`，status=2 完成
4. 返回 `bot_appid` + `bot_encrypt_secret`（AES-256-GCM：IV(12B)‖密文‖tag(16B)，key=第一步的 base64 key）+ `user_openid`
5. 凭证立即存文件（桌面 qqbot_credentials.json）—— 与虾评注册同理，防丢失

## 关键 API

- TOKEN_URL = `https://bots.qq.com/app/getAppAccessToken`（appId + clientSecret → access_token，2h 有效，验证凭证用）
- API_BASE = `https://api.sgroup.qq.com`
- 消息上限 4000 字符；媒体类型 MSG_TYPE_MEDIA=7；支持 markdown(2)、图片/视频/语音/文件

## 已知边界

- 官方机器人仅能主动给绑定用户（openid）发消息；双向聊天需用户在 QQ 会话中先发消息
- 群聊默认 disabled（group_policy）
