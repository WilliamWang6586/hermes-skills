---
name: hermes-cn-desktop-ops
description: Hermes CN Desktop 运维唯一总入口（umbrella）：升级/卸载备份与数据目录、config.yaml/providers 修复与 llm provider 坑（智谱/千问/书生）、hermes CLI、MCP 接入、消息平台（微信/QQ Bot）网关断连与发文件、Dashboard/手机遥控、token 成本优化、代理残留断连、桌面端 UI 状态（置顶/模型会话级覆盖）、DashScope 视觉、**视觉/语音能力安装（`hermes-vision-setup` + `hermes-voice-setup` 已并入）**、记忆外置。触发词：Hermes 升级/卸载/丢数据、hermes 命令找不到、微信、QQ机器人、网关、gateway、dispatcher lock、重连、provider配置、401/429、余额不足、MCP、手机连接、手机分身、手机遥控、dashboard、平台接入、MEDIA、config.yaml、记忆满了、优化token、省token、token消耗、上下文压缩、hermes insights、关VPN后不响应、断连、代理残留、proxy、卡住、置顶、置顶对话没了、置顶项目、会话列表、desktop-ui.sqlite、为什么你用的模型不对、实际用的模型、模型没生效、model.default 没生效、视觉模型、多模态、看图片/看图、看视频、API Key 配置视觉、语音、语音识别、STT、TTS、朗读没声音、edge-tts、faster-whisper、whisper、麦克风
---

# Hermes CN Desktop 运维

## 环境事实（本机固定路径）

- HERMES_HOME = `C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\hermes-home`（含 config.yaml / .env / memories/ / logs/）
- 桌面应用 `hermes-agent-cn-desktop.exe`；runtime 在 `data\versions\<ver>\hermes-agent-cn-runtime-win32-x64.exe`（CN 版打包时**裁掉了部分平台适配器**，见 qqbot 参考）
- CLI：`data\desktop-bin\hermes.cmd`（路径含空格 → PowerShell 必须 `& "完整路径"` 或 Start-Process + 参数数组；直接裸调会报错）
- Python：`C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`（`python`/`py` 别名失效）
- 桌面版网关由桌面应用托管（日志在 hermes-home/logs/gui.log + agent.log；`gateway.log` 会停更）。CLI `hermes gateway restart` 会报 "not installed"——**改配置后要重启桌面应用**，不是 CLI 网关

## 配置修改规则（详见下方「配置修复 / provider 坑」节）

- **patch/write_file 拒绝写 config.yaml**（安全保护）→ 用 Python 脚本读写（yaml.safe_load 验证）或 `hermes config set`
- `hermes config set plugins.enabled a,b` 会写成**字符串**而非 YAML 列表 → 插件系统不识别，必须手动改成列表格式
- config.yaml 中 platforms 键名必须与代码一致：**`qqbot` 不是 `qq`**
- UI 报"Provider 配置未配置"= config.yaml 缺 `providers:` 段；密钥用 `api_key_env` 引用 .env（DEEPSEEK_API_KEY / MINIMAX_CN_API_KEY / XIAOMI_TOKEN_PLAN_API_KEY / DASHSCOPE_API_KEY），勿把明文写进 config
- **hermes send 的 MEDIA 白名单 ≠ 平台适配器能力（2026-08-08 两次实测）**：纯附件 `hermes send --to qqbot "MEDIA:path"` 直接报错（qqbot 不在白名单）；**混合消息 `"文本 MEDIA:path"` 会静默吞掉附件**——CLI 报 "Sent to qqbot home channel" 但用户收不到文件，别信 CLI 的 Sent。适配器源码：`data\versions\<ver>\_internal\plugins\platforms\qqbot\`（chunked_upload.py，MEDIA_TYPE_FILE=4）。CLI 报"No home channel set" → `.env` 写 `QQBOT_HOME_CHANNEL=<openid>`（`QQ_HOME_CHANNEL` 已废弃）。
- **QQ 发文件的自动化姿势 = 独立脚本直调官方 API**（定时任务场景走不了"网关对话回复嵌 MEDIA"）：`POST https://bots.qq.com/app/getAppAccessToken` → `POST https://api.sgroup.qq.com/v2/users/{openid}/files`，body `{file_type:4, file_data:<base64>, srv_send_msg:true, file_name:xxx}`；<10MB base64，>10MB 走复刻 chunked upload。调试"CLI 不支持但适配器支持"的能力时：PyInstaller 打包的 exe 挖不到 CLI 源码 → 直接读 `_internal\plugins\platforms\<平台>\` 适配器源码复刻调用链。
- **PowerShell 5.1 中文乱码**：.ps1 无 UTF-8 BOM 会被当 ANSI 读；涉及中文路径一律用 Python 脚本。
- **修改 config 后配置被忽略**：日志 "edits to config.yaml are being IGNORED until the YAML is fixed" = YAML 解析失败（常见：字符串替换吞掉换行，如 `D:\AI文档platforms:` 粘连），修后用 `yaml.safe_load` 验证。
- **gateway 进程残留**：用户重启桌面应用**不会**杀掉旧 gateway runtime（`data\gateway-runtime\gateway_state.json` 的 pid 仍是旧进程，跑旧代码+旧配置）→ 改完插件/配置必须 `Stop-Process <旧pid>` 再手动拉起 `versions\<ver>\hermes-agent-cn-runtime-win32-x64.exe gateway run --replace`；改 .py 后还要删插件目录 `__pycache__`。

## 平台接入流程（通用）

1. 扫码/API 拿到凭证 → 写入 `.env`（`<平台>_APP_ID` / `<平台>_CLIENT_SECRET` / `<平台>_ALLOWED_USERS` / `<平台>_HOME_CHANNEL`）
2. 需要时在 config.yaml 加 `platforms.<平台>:` 段（含 enabled + extra 配置）
3. `plugins.enabled` 加入对应插件名（YAML 列表格式！）
4. **重启 Hermes CN Desktop**（GUI 图标退出重开）
5. 验证：`hermes send --to <平台> "测试" --json`，看 `"success": true`

## Dashboard 启动故障排查

Dashboard 启动失败时，先按 `references/dashboard-startup-diagnostics.md` 做端口监听、进程归属、Windows TCP 排除区间和 HTTP 验收；不要把一次成功的 WinNAT 重启、固定备用端口或历史日志当成永久根治或当前验收证据。认证接口返回 401 可能是正常保护，必须用首页和非认证状态端点确认服务是否就绪。复发时先确认候选端口确实落入排除区间，再考虑 WinNAT；操作后同时复核 WSL/容器网络影响。

## 手机遥控 / "手机分身"（Web Dashboard，2026-09-11 实测跑通）

用户要「手机上看得到全部窗口/上下文/记忆/模型配置、不用像 QQ Bot 每次连都重启网关」→ **不是加消息平台，是用 Hermes 自带的 Web Dashboard**（完整管理界面 + 内嵌聊天 + "重启网关"按钮，常驻服务）。侧栏：CHAT/SESSIONS/FILES/MODELS/LOGS/CRON/SKILLS/PLUGINS/MCP/CHANNELS/WEBHOOKS/PAIRING/PROFILES/CONFIG/KEYS/SYSTEM。完整配方见 `references/dashboard-remote-access.md`。

速记：
- 起：`hermes dashboard --no-open --host 0.0.0.0 --port 9119 --skip-build`（默认只绑 127.0.0.1；`--skip-build` 免 npm 构建；成功标志 `HERMES_DASHBOARD_READY port=9119`）
- 认证：config.yaml 加 `dashboard.basic_auth.{username,password,secret}`（**公网绑定强制要认证**，`--insecure` 已废；只绑 127.0.0.1 免认证）→ 改 config 走 Python（patch/write_file 被保护）
- **判定认证开没开**：`curl -s -o NUL -w "%{http_code}" http://127.0.0.1:9119/` → **302=已开**，200=没认证
- 自启（非管理员）：启动文件夹 `hermes-dashboard.cmd`（同 gateway 启动文件夹套路）
- 防火墙：`hermes-agent-cn-runtime-win32-x64.exe` 的入站 Allow 规则（Public 档、Any port）**已覆盖** dashboard，无需新增
- 手机连：同 WiFi 打开 `http://<PC局域网IP>:9119`；⚠️ 校园网(如 JLU.PC, Public)常 AP 隔离 → 跨网/安全推荐 Tailscale/ZeroTier
- ⚠️ **Windows 家庭版不能当 RDP 主机** → 别把系统 RDP 当方案

## 升级与卸载（备份优先）

> 来源：已归档技能 `hermes-cn-desktop-admin`（2026-08 内容，用户数据布局与备份步骤仍有效；CLI 位置/网关安装以本文件其他节为准）。

**⚠️ CN 桌面版用户数据在安装目录内部，卸载/更新前必须备份。**

```
安装目录: C:\Users\<user>\AppData\Local\Hermes Agent CN Desktop\
  ├── hermes-agent-cn-desktop.exe
  ├── bundled-plugins/ bundled-skills/ bundled-runtime/
  └── data\
      ├── desktop-bin\hermes.cmd      ← CLI 入口（不在 PATH）
      ├── versions\<ver>-cn.N\
      └── hermes-home\                ← 🔴 用户数据【在安装目录内！】
          ├── skills/ sessions/ memories/ images/ audio_cache/
          ├── weixin\accounts\*.json
          ├── cache\                  ← 含 cache\terminal，删了会破坏终端 cwd
          └── logs/ cron/ kanban/
用户目录: C:\Users\<user>\.hermes\     ← 只有部分副本（config.yaml/.env/auth.json/state.db）
```

备份（卸载会删 `data\hermes-home`）：

```powershell
$backupDir = "D:\Hermes文件库\hermes-backup-$(Get-Date -Format yyyyMMdd)"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$src = "C:\Users\<user>\AppData\Local\Hermes Agent CN Desktop\data\hermes-home"
Copy-Item -Recurse "$src\skills","$src\memories","$src\sessions" $backupDir -Force
Copy-Item "$env:USERPROFILE\.hermes\config.yaml" $backupDir -Force
```

升级后验收：技能数、`.env` 里各 `*_API_KEY`、config 的 providers 段、**QQ 适配器重连补丁是否还在**（`_internal` 随版本被覆盖，见 qqbot 节）。

## Token / 成本优化（2026-09-11 实测）

用户说"优化 token 使用 / 省 token / 减少非必要消耗 / 账单太贵"时，**先量再改**。完整量法 + 脚本见 `references/token-optimization.md` + `scripts/analyze_request_dump.py`。

速记：
- **测量**：`hermes insights --days 7`（各模型 tokens / Top 工具 / 技能加载）+ 拆 `hermes-home\sessions\request_dump_*.json` 的 `d["request"]["body"]`（是 JSON 字符串，须 `json.loads`）→ system 提示 / tools schema / messages 各占多少。实测每轮固定开销 ≈ 系统提示 11K + 工具 schema 10K tokens。
- **本机最大根因**：`deepseek-v4-flash/pro` 上下文窗口 = **100 万**（查 `models_dev_cache.json` 的 `limit.context`）→ 默认压缩阈值 50% = 50 万才触发 → 会话能涨到 **35 万 tokens/请求**仍不瘦身。**超长会话才是成本杀手，不是每轮固定开销。**
- **改法**：`hermes config set model.context_length 131072`（压缩提前到 ~52K）+ `hermes config set compression.threshold 0.4`；关没用过的工具集 `hermes tools disable image_gen tts computer_use --platform cli`。改后重启桌面应用/开新会话生效。
- ⚠️ **工具集没有 `desktop` 平台**——桌面端会话用 **`cli`**。有效值：cli/telegram/discord/slack/.../qqbot/weixin/webhook/api_server/cron。
- **技能目录死重**：`skills\` 有 **179 个 SKILL.md**，整份清单每轮注入（~5K tokens/轮），但 7 天只加载过 4 个 → 把用不到的打包技能移到 `skills-parked\`（可逆）。`hermes skills config` 是纯交互式（无参数），脚本化不了。
- **最省且免费**：一个任务一个 `/new`；长任务中途 `/compress`。

## 坑（每一条都实战踩过）

- **「为什么你用的是 X 模型，我配置里设的是 Y」→ 会话级覆盖，别改 config（2026-10-19 定位）**：桌面端模型下拉按 **session id** 记住每个对话的模型，存在 `desktop-ui.sqlite、为什么你用的模型不对、实际用的模型、模型没生效、model.default 没生效`（`ui_kv` 的 `session_ui_state` + `hermes:last-used-model:...`），**优先级高于 `config.yaml` 的 `model.default`**——后者只决定新会话初始模型。指纹：`agent.log` 里反复出现 `Model switched in-place: X -> X`（自己盖自己）且每轮 `API call: model=X`。修法首选在会话标题栏下拉手动切一次（同步写 last-used-model），或 `/new`；**不要**去改 config、更别去改 sqlite。⚠️ 本版本 `hermes model current` / `hermes models list` 不存在（`hermes model` 只有交互式选择器），查实际模型只能读 `logs\agent.log` 的 `model=` 字段。完整优先级表/排查命令/证据表模板见 `references/model-selection-precedence.md`
- **「置顶对话没了 / 置顶项目都没了 / 历史里显示置顶但左边置顶栏是空的」→ 先查 `desktop-ui.sqlite、为什么你用的模型不对、实际用的模型、模型没生效、model.default 没生效`**（2026-10-19 定位）：桌面端所有 UI 状态（置顶名单、会话标题、会话↔工作区映射、工作区项目）都不在 `state.db`、也不在 WebView2 Local Storage，而在 `hermes-home\desktop-ui.sqlite、为什么你用的模型不对、实际用的模型、模型没生效、model.default 没生效` 的 `ui_kv` 表 —— 置顶名单 = key `hermes-cn-ui.pinnedSessionIds`（JSON 数组，元素 = `sessions.id`）。**绝大多数情况数据没丢**：拿名单去 `state.db.sessions` 对一遍，全命中就是左侧栏的显示过滤问题，别宣称「丢了」、也别写库。另外 `sessions.end_reason='ws_orphan_reap'` 表示会话是被桌面端断连时回收的，不是用户关的。完整表结构 / 只读查询姿势 / 「二进制扫 `hermes-cn-ui.` 前缀定位 UI 库」的一行扫描器见 `references/desktop-ui-sqlite.md`。⚠️ **别直接写 `pinnedSessionIds` 去「恢复」置顶**（2026-10-19 栽过两次）：前端守卫生效时会把不在**已加载前 50 条**里的置顶 id 当成已删会话自动抹掉，写完重启即被打回；正解 = 在「对话历史」从底部最老的会话开始逐条「⋯ → 置顶」
- **微信媒体发送不可用**：`hermes send MEDIA:D:\\...` 报 `getUploadUrl ... {'ret': -2}`（ilinkai 平台 CDN 限制，仅文本可用）；回复消息里嵌 `MEDIA:/D:\\...`（带前导斜杠）会被网关判 "unsafe MEDIA directive" 直接跳过。**文本用 `hermes send --file`**（避免命令行中文编码问题）
- **hermes send 的 MEDIA 白名单 ≠ 平台适配器能力（2026-08-08 两次实测）**：纯附件消息 `hermes send --to qqbot "MEDIA:path"` 报错 "MEDIA delivery is only supported for telegram, discord, matrix, weixin, signal, yuanbao, feishu and whatsapp; target qqbot had only media attachments"；**混合消息 `hermes send --to qqbot "文本 MEDIA:path"` 会静默吞掉附件**——CLI 报 "Sent to qqbot home channel" 但用户 QQ 收不到文件（2026-08-08 实测，勿再信 CLI 的 Sent）。**唯一可靠路径 = 网关对话回复里嵌 `MEDIA:绝对路径`**（agent 回复走 gateway 发送管道，qqbot adapter 分块上传 `type=4` 文件 / `type=1` 图片，gateway.log 见 "Chunked upload start: file=xxx type=4" 即成功）。适配器源码：`data\versions\<ver>\_internal\plugins\platforms\qqbot\`（adapter.py / chunked_upload.py / constants.py，MEDIA_TYPE_FILE=4）
- **QQ 发文件的自动化姿势 = qq_send_file.py（2026-08-08 实测成功，用户确认收到）**：定时任务/脚本场景无法走"网关对话回复嵌 MEDIA"（那需要用户在对话里触发），正确方案是独立脚本直接调 QQ 官方 API——`POST https://bots.qq.com/app/getAppAccessToken`（appId+clientSecret）→ `POST https://api.sgroup.qq.com/v2/users/{openid}/files`，body `{file_type:4, file_data:<base64>, srv_send_msg:true, file_name:xxx}`（srv_send_msg=true 时 QQ 服务器直接推送文件消息，无需再发文本）；凭证读 hermes-home\.env 的 `QQ_APP_ID/QQ_CLIENT_SECRET/QQ_HOME_CHANNEL`；脚本 `D:\Hermes文件库\每日科技日报\qq_send_file.py`；<10MB 走 base64 简单上传，>10MB 走 chunked upload（复刻适配器 chunked_upload.py 三步流程）。调试这类"CLI 不支持但适配器支持"的能力时：PyInstaller 打包的 exe 挖不到 CLI 源码 → 直接读 `_internal\plugins\platforms\<平台>\` 适配器源码，复刻其 API 调用链即可
- **vision_ocr.py 传参坑**：`cmd /c "python vision_ocr.py <路径含空格>"` 路径在空格处被截断（PermissionError 指向截断路径）→ 用 PowerShell `& "python.exe" "script" "path"` 调用
- **CN 版裁掉 qqbot 适配器**：见 `references/qqbot-platform-plugin.md`（完整移植配方）
- **关 VPN 后 Hermes 不响应 / 卡住（2026-09-13 彻底定位）**：**不是网络问题**——是三层代理残留指向已死的代理端口（如 `127.0.0.1:7892`）：① 环境变量 `HKCU:\Environment` ② **Windows 系统代理注册表 `Internet Settings` 的 `ProxyEnable=1`**（Python 每次请求实时读它，最常漏的一层）③ 进程继承（桌面应用派生的 runtime 带着父进程的代理）。修复三件套 = 清注册表 env → 关系统代理 → **在清空 env 的同一次调用里**杀进程并干净重启（或直接让用户退出重开桌面应用，更安全且不断对话）。⚠️ 改注册表对**已运行进程无效**；只重启 gateway 不重启桌面应用 = 没修好。完整诊断/修复/踩坑清单见 `references/proxy-residue-disconnect.md`（含**开机自启加固**：gateway VBS 要显式清代理变量，否则重启后残留复发；以及**别为了自动修复去永久关系统代理**——那会废掉用户自己的 VPN 上网，要修的是"Hermes 不受代理影响"而非"关掉代理"）
- **VBS 自启脚本必须存 UTF-16LE(BOM) 或 ANSI/GBK（2026-09-14 实测）**：`Hermes_Gateway.vbs` 若存成 **UTF-8 无 BOM**，Windows Script Host 会按 GBK 解码 → 路径里的**中文用户名**（如 `C:\Users\王子涵\`）变成乱码 `鐜嬪瓙娑?` → 第 24 行 `sh.CurrentDirectory` 指向不存在的路径 → **开机弹 "Windows Script Host: 系统找不到指定的路径 (80070003)"**，且网关根本没起来（用户以为"又要重连"）。判定：`Get-Content` 看到路径乱码 + 报错行号指向 `CurrentDirectory`/`Run` 那两行。修复写法（PowerShell）：
  ```powershell
  $txt = [System.IO.File]::ReadAllText($vbsPath, [System.Text.Encoding]::UTF8)
  [System.IO.File]::WriteAllText($vbsPath, $txt, [System.Text.Encoding]::Unicode)  # UTF-16LE + BOM
  $b = [System.IO.File]::ReadAllBytes($vbsPath); "{0:X2} {1:X2}" -f $b[0],$b[1]     # 必须 FF FE
  ```
  ⚠️ `Set-Content -Encoding UTF8` 在 PS5.1 写的是**带 BOM 的 UTF-8**，WSH 同样认不对该 BOM 场景 → 一律用 `[System.IO.File]::WriteAllText(..., Encoding]::Unicode)`。**任何含中文路径的 .vbs/.js/WScript 自启脚本都适用**（不只 Hermes）。
- **⏱ 开机自启加固：`Hermes_GatewayGuard.vbs`（2026-09-20 新建并实测）**：用户反复喊"重连"的根因之一是**双 gateway 实例互顶 dispatcher 锁** + 挂死后无人拉起。启动文件夹加一个 Guard（开机后 `WScript.Sleep 180000` 自检）：
  | 检测到的 `gateway run` 实例数 | 动作 |
  |---|---|
  | 0（挂了） | 拉起单实例 |
  | 1（正常） | 不动 |
  | ≥2（互顶锁） | 全杀 → 重启单实例 |
  实例数用 `sh.Exec("cmd /c wmic process where ""name='hermes-agent-cn-runtime-win32-x64.exe'"" get commandline /format:csv")` 数含 `gateway run` 的行（VBS 里没有 Get-Process，wmic 是最稳的）。日志写 `hermes-home\logs\gateway-guard.log`，用 `fso.OpenTextFile(path, 8, True, -1)`（`-1`=Unicode，否则中文乱码）。脚本源在 `hermes-home\gateway-service\Hermes_GatewayGuard.vbs`（可复用模板：`scripts/hermes_gateway_guard.vbs`），**必须 UTF-16LE BOM**（同上一坑）。⚠️ 溯源：`cscript //nologo` 跑一次可即时验证（退出码 0 = 无脚本错误），但 cscript 输出到 PS 是 GBK 会显示乱码，看退出码即可。⚠️ 局限：只在开机时自检一次，运行中半夜挂死管不了 —— 要那种得用计划任务定时轮询。
- **gateway 进程残留**：用户重启桌面应用**不会**杀掉旧 gateway runtime 进程（`data\\gateway-runtime\\gateway_state.json` 的 pid 仍是旧进程，跑旧代码+旧配置）→ 改完插件/配置后必须：`Stop-Process <旧pid>` 再手动拉起 `versions\\<ver>\\hermes-agent-cn-runtime-win32-x64.exe gateway run --replace`（`--replace` 必加）；改 .py 后还要删插件目录 `__pycache__`（py_compile 生成的旧 pyc 会让 gateway 加载旧字节码）
- **gateway 挂死但进程活着（2026-08-08 实测，根因 2026-08-12 已修）**：QQ Bot WebSocket 断开后重连失败（日志 `Reconnect failed: Failed to get QQ Bot gateway URL:` 空 URL），之后日志 **50 分钟无任何输出**、进程仍在（`hermes gateway status` 显示 running 但机器人收不到消息）。处理：① `hermes gateway restart` 会拒绝——报"检测到已安装的 Windows Hermes 网关服务（非桌面端托管）"，这是**假阳性**（Get-Service 根本查不到该服务），不要按提示 uninstall，直接跳过 CLI；② `Get-CimInstance Win32_Process | ? { $_.CommandLine -match 'gateway' }` 找到 `gateway run` 进程 → `Stop-Process -Force`；③ 等 12s 看守护是否自动拉起（实测**不会**）→ 手动后台拉起 `versions\<ver>\...\hermes-agent-cn-runtime-win32-x64.exe gateway run --replace`（terminal background=true）；④ 验证：gateway.log 尾部出现 `[QQBot:1905378483] Ready, session_id=...` 和 `weixin connected`；⑤ 重发失败的消息。挂死判定口诀：**进程活着 + 日志停更 = 死**。**根因（2026-08-12 定位）**：adapter.py 的 `except Exception` 块里直接 `await self._reconnect(backoff_idx)`——`_reconnect` 获取 gateway URL 失败时**抛异常**（`Failed to get QQ Bot gateway URL: All connection attempts failed`），异常逃出 except 杀死整个重连循环（日志只有 attempt 1 就永久沉默，`MAX_RECONNECT_ATTEMPTS=100` 形同虚设）。**已打补丁**：把该调用包进 try/except，异常降级为 `_ok=False`（视为失败一次 → backoff_idx+1 → 循环继续自动重试），文件 `data\versions\<ver>\_internal\plugins\platforms\qqbot\adapter.py` 约 647 行，备份 `D:\Hermes文件库\adapter.py.bak-20260812`；改后 `py_compile` 验证 + 重启 gateway 生效。⚠️ **升级 Hermes CN Desktop 后 `versions\<ver>\` 被替换，必须重打补丁**（改前先备份）；复发时仍可走上方重启流程兜底
- **重连后仍"收不到/要重连"的两个进阶坑（2026-08-31 / 09-04 实测）**：
  - **双网关实例**：`Get-CimInstance Win32_Process` 查出**多个** `gateway run` 进程时，后起的实例日志打 `kanban dispatcher: another gateway already holds the dispatcher lock ... this gateway will NOT dispatch`——消息被晾着（用户端表现为"重连了还收不到"）。处理：**杀光所有** gateway 进程（不是只杀一个），再拉起唯一一个；验证标志 = 日志出现 `holding singleton dispatcher lock`（而非 another gateway...）
  - **SSL 瞬时故障**：日志 `Reconnect failed: Failed to get QQ Bot gateway URL: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: EE certificate key too weak (_ssl.c:1082)` = QQ CDN 边缘节点瞬时提供弱证书，**与本地代理无关**（直连与走代理 `curl.exe -o NUL -w "%{ssl_verify_result}"` 均=0 验证通过可佐证）。处理：重启 gateway；且此异常路径下重试循环可能同样停止打日志（09-04 实测），重启是兜底
- **QQ 群消息开通（2026-09-04 实测，三步缺一不可）**：机器人被拉进群后**默认无法发群消息**——群事件被适配器静默丢弃（群里 @bot 显示"机器人Hermes的服务异常，暂时无法响应"，gateway.log 无任何群消息记录；`_handle_group_message` 在 policy 检查处直接 return，不落日志）。开通完整流程：
  ① 群里邀请机器人（群管理搜 app_id 1905378483）
  ② **改 config.yaml 而非 .env**：`platforms.qqbot.extra.group_policy: disabled` → `open`（适配器 `_is_group_allowed` 只读 config 的 extra，`.env` 的 `QQ_GROUP_POLICY` **不生效**——2026-09-04 实测改 .env 后群事件依旧被丢弃）；Python 读写 + 备份
  ③ **必须同时给 .env 加 `QQ_ALLOW_ALL_USERS=true`**：否则网关直接拒绝启动，日志报 `Refusing to start: qqbot has dm_policy/group_policy set to 'open' but neither GATEWAY_ALLOW_ALL_USERS nor QQ_ALLOW_ALL_USERS is enabled`；DM 仍受 `dm_policy: allowlist` + `allow_from` 保护，不受此 flag 影响
  ④ 重启 gateway → 群里 @bot 发一条 → gateway.log 抓到含 `group_openid` 的 group_openid 群消息（适配器 intents 已含 `(1<<25)|(1<<30)|(1<<12)|(1<<26)` 覆盖 GROUP_AT_MESSAGE_CREATE，无需改 intents）
  ⑤ 之后可用 group_openid 向该群发送（`POST /v2/groups/{group_openid}/messages`）。群标识用 **group_openid**（长字符串）不是群号；⚠️ `GET /v2/groups` 群列表接口对该 bot 类型返回 **404**，拿 openid 只能靠群消息事件；已注册频道清单见 `hermes-home\channel_directory.json`（只有 DM 说明群未注册成功）。另外：新版 gateway 重连调用 `connect(is_reconnect=...)` 会报 `got an unexpected keyword argument` 导致重连死循环 → 移植后把 `async def connect(self) -> bool:` 改为 `async def connect(self, is_reconnect: bool = False) -> bool:`
- **DashScope**：compatible-mode 必须用 OpenAI 格式（顶层 `messages`，image 用 `{"type":"image_url","image_url":{"url":"data:image/jpeg;base64,..."}}`），不是 `input.messages`；国内 key 用 `https://dashscope.aliyuncs.com/compatible-mode/v1`（**不是** dashscope-intl，intl 会 401）；Hermes 内置 vision_analyze 报 401 → 用 `D:\Hermes文件库\vision_ocr.py`（详见 references/dashscope-vision.md）
- **PowerShell 5.1 中文乱码**：.ps1 无 UTF-8 BOM 会被当 ANSI 读，中文全乱；涉及中文路径一律用 Python 脚本
- **修改 config 后配置被忽略**：日志出现 "edits to config.yaml are being IGNORED until the YAML is fixed" 说明 YAML 解析失败（常见：字符串替换时吞掉换行，如 `D:\AI文档platforms:` 粘连），修复后用 yaml.safe_load 验证
- `hermes send --to qqbot` 报 "No home channel set" → `.env` 写 `QQBOT_HOME_CHANNEL=<openid>`（config set 不识别该 key；**`QQ_HOME_CHANNEL` 已废弃**，日志警告 rename，旧名虽可用但会产生 deprecated 警告）

## 视觉 / 语音 / 记忆外置（同属本 umbrella）

- **视觉（图片/视频识别）** → `references/vision-setup.md`（原 `hermes-vision-setup`）：
  文本模型 ≠ 视觉模型；各家视觉能力速查（DeepSeek 无视觉 / Gemini 免费额度 / DashScope qwen-vl-max 国内首选）；
  `auxiliary.vision` 配置位置与密钥走 `api_key_env`；先单测 HTTP 再改 config（401 vs 404 别误判）；
  改完必须重启桌面应用。配套 `scripts/recognize_image.sh`、`scripts/recognize_upload_py.py`、
  `references/bill-reconciliation-ocr.md`。
- **语音（本地 STT + Edge TTS）** → `references/voice-setup.md`（原 `hermes-voice-setup`）：
  CN Desktop 是 PyInstaller frozen 应用，`data/versions/<ver>/_internal` 才是它的 site-packages
  （**pip 装到本机 Python 对运行时无效**）；faster-whisper 模型走 hf-mirror；edge-tts 403 根因
  `SEC_MS_GEC_VERSION` 前缀 `1-`→`2-`（要连 `communicate.py` 一起 patch 或整包升级）；
  `lazy_deps` 版本钉死导致「No TTS provider」→ 改 METADATA 版本号；改完必须重启桌面端。

## 记忆外置（记忆满时的处理）

- 记忆文件：hermes-home/memories/MEMORY.md（8000 字符上限）/ USER.md（1375）
- 归档脚本：`D:\Hermes文件库\记忆外置库\archive_memory.py`（python3.14 运行，自动时间戳备份 + 保留最近 20 份）
- 长文资料放 `记忆外置库\详细知识\`，记忆里只留路径指针；压缩记忆用 Python 读写 MEMORY.md
- 用户习惯：直接说"记忆满了，归档一下"即可触发

## 验证清单

- `hermes send --list` 看平台是否注册
- `hermes plugins list` 看插件状态（enabled/not enabled）
- 检查 hermes-home/logs/agent.log 的 plugin 加载与报错
