#!/usr/bin/env python3
"""定位并清理 D:\\ 根目录下的编码乱码文件夹（UTF-8 被当 GBK 解码的产物）。

用法（Windows 侧 python3.14 直跑，勿用 python3 -c，中文会被 PS 吞）：
    python3 fix_mojibake_folder.py            # 预览：列出所有乱码候选 + 还原名 + 内容
    python3 fix_mojibake_folder.py --apply    # 执行：文件移入还原后的目标目录，删空壳

判据：D:\\ 下以 'Hermes' 开头（可按需改 PREFIX）、不含正常中文、且
名.encode('gbk').decode('utf-8') 能成功解码的目录 = 乱码目录。
"""
import os
import shutil
import sys

ROOT = "D:\\"
PREFIX = "Hermes"
DRY_RUN = "--apply" not in sys.argv


def candidates():
    """返回 [(乱码路径, 还原后的相对路径)]，还原失败的直接跳过。"""
    out = []
    for entry in os.scandir(ROOT):
        if not entry.is_dir() or not entry.name.startswith(PREFIX):
            continue
        # 正常目录名不含 0x80-0xFF 的 GBK 双字节噪声特征；直接尝试还原即可
        try:
            recovered = entry.name.encode("gbk").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue  # 还原失败 = 本来就是正常名字
        if recovered == entry.name:
            continue
        out.append((entry.path, recovered))
    return out


def main():
    found = candidates()
    if not found:
        print("没有发现乱码文件夹 ✅")
        return

    for src, recovered in found:
        print(f"\n乱码目录: {src}")
        print(f"还原为  : {recovered}")
        items = os.listdir(src)
        for name in items:
            kind = "[DIR]" if os.path.isdir(os.path.join(src, name)) else "[FILE]"
            print(f"   {kind} {name}")

        if DRY_RUN:
            continue

        dst = os.path.join(ROOT, recovered)
        os.makedirs(dst, exist_ok=True)
        for name in items:
            target = os.path.join(dst, name)
            if os.path.exists(target):
                print(f"   ⚠️ 已存在，跳过: {target}")
                continue
            shutil.move(os.path.join(src, name), target)
            print(f"   已移动: {name} → {dst}")
        if not os.listdir(src):
            os.rmdir(src)
            print("   空壳已删除")

    if DRY_RUN:
        print("\n（预览模式。确认无误后加 --apply 执行）")


if __name__ == "__main__":
    main()
