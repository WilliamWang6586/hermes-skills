# 批量整理文件目录 + 乱码修复（2026-10-15 实战，573→21 文件）

适用：用户说「文件夹很乱，整理一下」「里面太乱了」「归归类」。
用户 `D:\Hermes文件库` 是长期工作区，顶层平铺过 566 个文件（329 .py / 90 .txt
/ 39 .png …），全是历次任务的一次性脚本。**这类整理的唯一正确姿势是「移动
不删」**——用户的东西你无法判断哪条以后还要用。

## 铁律（用户已明确偏好）

1. **全部 dry-run 先行**：脚本默认只打印计划，`--apply` 才执行。
2. **移动 ≠ 删除**：归档到 `_脚本存档\`，用户随时能翻回来。本次 545 文件全部移动，零删除。
3. **同名不同内容时拒绝自动处理**：本次 `Python学习计划` vs `Python_Learning`
   看着像重复，逐文件 `filecmp.cmp` 比对发现 `学习方案.md` 有差异（新版勾了
   进度），脚本正确拒绝删除，改为「归档旧版」。**永远先验证再删，别信文件名。**
4. **保留白名单**：活跃成品/项目留顶层不动（写死在脚本 `KEEP` 集合里）。
5. **`_` 开头的文件先看时间戳再归档**：本次 `_cafuc_*`/`_logos_*`/`_hs_*` 是
   **1.2 天前的活项目**，不是垃圾。按「60 天未动」筛才安全。

## 脚本骨架

```python
# 默认 dry-run；--apply 才动文件
APPLY = "--apply" in sys.argv
KEEP = { "china-map.html", "hermes_logo.png", ... }   # 活跃资产，白名单写死

CATS = [ ("01_吉大百晓生发布", r"^(jlu|build_skill|gh_|publish|push_v)"),
         ("02_吉大通知教务",   r"^(read_kebiao|oa_|parse_oa)"),
         ... 15 类 ... ]
LOG_PAT = re.compile(r"_(out|err)\d*\.txt$", re.I)     # 日志单独一类

for f in files:
    if f in KEEP: continue
    dst = 按 CATS 正则匹配 → _脚本存档\<cat>\<f>
         不匹配 → _脚本存档\99_其他\<f>

if not APPLY: print("DRY RUN. 加 --apply 执行"); sys.exit(0)
shutil.move(...)                                        # 只 move，不 remove
```

已落地的成品：`D:\Hermes文件库\_脚本存档\00_整理工具\`（`_organize.py` /
`_organize2.py` / `_fix_mojibake.py` / `_diag_*.py` / `_plan*.py`）。

## 最终归档结构（可复用）

```
_脚本存档\
  00_整理工具  01_吉大百晓生发布  02_吉大通知教务  03_QQBot
  04_Minecraft 05_学生去向地图    06_Hermes运维    07_视觉OCR
  08_技能工具  09_WSL安装        10_考研资料      11_UI脚本测试
  12_日志输出  13_目录归档        99_其他
```

## 乱码目录/文件修复

**症状**：`D:\Hermes鏂囦欢搴揬flange_demo.dwg`、`Hermes鏂囦欢搴揬_tmp_pdf\`。

**根因**：GBK 字节被当 UTF-8 读（Python 路径拼接时编码链断裂）。

**还原公式**：`name.encode('gbk').decode('utf-8')` → `Hermes文件库\flange_demo.dwg`。

**另一类乱码**：目录名里**带反斜杠**且整串是路径，如
`D:\Hermes文件库\D: Hermes文件库 记忆外置库 归档` —— 这是 `os.makedirs` 把
路径串当成**单个目录名**创建的。本次两个（`归档`/`详细知识`）都是**空目录**，
直接 `os.rmdir`。判断：`.NET DirectoryInfo($p).LinkTarget` 为空 + 内容数 0。

**还遇到过**：`D:\Hermes文件库\Hermes文件库` 是**自指符号链接**（Mode 含 `l`），
`os.path.islink()` 为真 → `os.unlink()` 删。

**⚠️ 执行坑**：
- **不要用 PS 传中文路径给 python**（吞字符），全部写在 .py 里用 `os.scandir`
  前缀匹配定位。
- **WSL 里 D 盘是 `/mnt/d/`**，不是 `D:\`；`os.listdir("D:\\")` 在 WSL 报
  `FileNotFoundError`。
- `sed -i 's|...|g' file` 在 **PowerShell 里会被当重定向**（报 `D:\dev\null`
  找不到路径）→ 直接 `write_file` 重写文件，别用 sed。
- 跑脚本用 `wsl -d Ubuntu-24.04 -- python3 "/mnt/d/.../x.py"`；`.ps1` 需
  **UTF-8 BOM**，且 `& $script.ps1` 会被判后台符 → 用
  `powershell.exe -NoProfile -ExecutionPolicy Bypass -File $p`。

## 验收

```powershell
Get-ChildItem "D:\Hermes文件库" -File -Force | Measure-Object | % Count   # 目标: 顶层 ≤30
Get-ChildItem "D:\" -Force | Where-Object { $_.Name -match "鏂|欢搴|揬" }   # 目标: 空
```
