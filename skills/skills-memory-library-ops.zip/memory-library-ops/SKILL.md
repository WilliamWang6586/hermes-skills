---
name: memory-library-ops
description: >-
  维护 Hermes 记忆库（记忆外置体系）。当用户说「压缩记忆」「精简记忆」「记忆满了」
  「记忆外置」「完善记忆库」「按记忆系统 skill 落地」「蒸馏每日笔记」时使用。
  覆盖：MEMORY.md 字符上限管理、memory 工具批处理铁律（同条目不可批次内重复 /
  额度先算准否则锁死）、外置压缩（archive_memory.py / compress_memory.py）、
  四层记忆架构（SESSION-STATE 恢复层 / working-buffer 毛坯层 / MEMORY.md 长期层 /
  memory/ 每日笔记）、agent-memory-system-guide 技能的 memory_capture.py 命令用法、
  工作区目录批量整理（references/batch-file-organization.md，含乱码目录修复），
  以及本机路径与 PowerShell/WSL 运行坑。
version: "1.4"
updated_at: "2026-10-18"
platforms: [windows]
---

# 记忆库运维（记忆外置体系）

用户记忆体系分两层：**Hermes 系统记忆**（`hermes-home\memories\MEMORY.md`，
8000 字符上限，系统每轮注入，不可破坏其 `§` 分隔格式）和**记忆外置库**
（`D:\Hermes文件库\记忆外置库\`，详细知识 + 归档 + 四层工作文件）。

## 触发词

`压缩记忆` / `记忆满了` / `记忆外置` / `完善记忆库` / `蒸馏笔记` / `记忆系统`

## 一、MEMORY.md 满时压缩流程

1. **读现状**：`read_file` MEMORY.md，看字节数（中文 UTF-8 约 3 字节/字符，
   8000 字符上限 ≈ 10948 字节封顶）。
2. **归档**：跑 `python3 D:\Hermes文件库\记忆外置库\archive_memory.py`
   ——自动备份 MEMORY.md 到 `归档\MEMORY_backup_<时间戳>.md`，并把
   长条目外置到 `详细知识\`（model_config/qqbot_gateway/daily_report/soa3/
   lanlian/xiaping_ops 等主题文件）。
3. **压缩**：跑 `python3 D:\Hermes文件库\记忆外置库\compress_memory.py`
   ——把已外置的长条目替换成路径指针（如「模型配置详情→记忆外置库/
   详细知识/model_config.md」），保留关键操作信息（如"升级需重打补丁"
   这种不能只留指针）。
4. **验证**：read_file 确认内容完整、指针正确；实测 10948→7508 字节（-56%）。

⚠️ **压缩/改 MEMORY.md 后必须同步 memory 工具存储（2026-08 实测大坑）**：直接
Python 重写 MEMORY.md 文件**不是最终状态**——memory 工具有自己的权威存储，
下一次任何 memory 工具调用（add/replace）都会**以工具存储为准回写文件**，
把文件里其他会话新增的条目合并回来、覆盖掉你直接改的内容。本会话实测：
压缩后文件 19 条/5974 字符 ✅，随后一次 memory replace 操作后文件变回
22 条/6948 字符（工具存储里多了 3 条其他会话的条目）。结论：
- 压缩优先用 **memory 工具批量 operations**（remove 重复旧条目 + replace 合并版），
  一次调用原子完成，别直接动文件；
- 2026-10-11 复现（**走 operations 路径也中招**）：一批 12 op 把 6474→6024 后，
  下一次 memory 调用把**其他会话新增的 4 条**合并回来 → 变 50 条 / 7151 字符（89%）。
  正确反应：**以工具返回的 usage/entry_count 为真相**，再补一轮去重压缩
  （本次 89%→80%，合并 6 组同类条目：洛谷C×2 / 搞钱+RoseMe / 发布+技能 /
  清垃圾+环境速记 / 环境坑+WSL / JLU文件约定）。
- 若已直接改文件，改完立刻做一次 memory 工具的读操作，确认工具存储同步后的
  真实 usage/entry_count，以工具返回为准，别再按文件字节数汇报"压缩成功"。

⚠️ **必须用 Python 读写 MEMORY.md**（PS 5.1 无 BOM 会中文乱码）；两个脚本
都在 `记忆外置库\` 下，路径已是 WSL 格式（/mnt/c、/mnt/d），**用 WSL 跑**：
`wsl -d Ubuntu-24.04 -- python3 /mnt/d/Hermes文件库/记忆外置库/archive_memory.py`
（Windows 侧 `& python` 或 Start-Process 会因中文/空格路径失败或乱码）。

## 一之二、⚠️ memory 工具批处理铁律（2026-09-19 实测，两条血泪）

压缩/精简**一律走 memory 工具的 `operations` 批量数组**（原子生效）。但两个坑会把整批打回：

### 坑 1：同一条目在同一批次里**不能出现两次**

`old_text` 匹配的是**当前存储状态**。若第 5 个 op 已 `replace` 掉某条，第 7 个 op 再拿旧的 `old_text` 匹配同一条 → 报 `no entry matched` → **整批 all-or-nothing 回滚，一个 op 都不生效**。

2026-09-19 实测连栽 4 次：本想「先 replace 校园网条目、再加新条目」，却把新增 op 的 `old_text` 误写成校园网那条。修法：**每条目每批次只动一次**；新增一律用 `add` + 全新 `content`，绝不复用别的条目的 `old_text`。

### 坑 2：额度要**先算准**，别试错

额度校验发生在**批次最终结果**上（非逐个 op）。算式：

```
现有字符 - 删除的 + 新增的 ≤ 8000
```

失败三次全因没算账（`7956 - 358 + 1000 = 8598` 超限）。**试错会触发保护、把 memory 工具整轮锁死**（`Memory consolidation failed 4 times this turn. Stop retrying.`）——那一轮就再也写不进去。

**动手前先统计**（Python 直读，勿用 PS）。

⚠️ **在 WSL 里跑时不要用 `os.environ["LOCALAPPDATA"]`**（2026-09-30 实测直接
`KeyError: 'LOCALAPPDATA'`——WSL 环境没有这个变量）→ **写死 /mnt/c 路径**：

```python
import io
p = "/mnt/c/Users/<用户名>/AppData/Local/Hermes Agent CN Desktop/data/hermes-home/memories/MEMORY.md"
t = io.open(p, encoding="utf-8").read()
es = [e for e in t.split("\n§\n") if e.strip()]
print(f"chars {len(t)} / 8000   余量 {8000-len(t)}   entries {len(es)}")
for i, e in sorted(enumerate(es), key=lambda x: -len(x[1]))[:12]:
    print(f"{len(e):4d} | {e[:70]}")
```

按字数降序一眼看出该压哪些。算准再发批次，一次成功。
跑法：`wsl -d Ubuntu-24.04 -- python3 "/mnt/d/Hermes文件库/记忆外置库/_stat_mem.py"`
（统计脚本是临时的，用完即删，别留在库里）。

### 坑 3：删除条目的 action 是 `remove`，不存在 `delete`（2026-10-02 实测）

批量 ops 里删条目写 `{"action": "delete", "old_text": ...}` 会报
`Operation N (delete): unknown action` → **整批 all-or-nothing 回滚**。
与坑 1、坑 2 并列三坑。修正后同一批（26 ops：17 replace + 7 remove + 2 add）
一次通过，6704 → 5056 字符。

### 大条目 = 先落外置档，再替换成一行指针（2026-09-30 实测高效）

对 250-400 字符的长条目，**不要只删不建**。顺序固定：

1. **先把该条目的完整内容写成 `详细知识\<topic>.md`**（含原条目所有关键操作信息，
   不是摘要——信息丢了就白压了）
2. 再用 memory 工具 `replace` 把长条目换成 `主题→详细知识/<topic>.md；关键信息(≤半行)`
3. 多条讲同一件事的**合并成一条**（实测：微信推送相关 3 条 → 1 条、竞选PPT 2 条 → 1 条）

本会话战果：**7962 → 6594 字符（-17%），48 → 45 条，余量 38 → 1406**，
两轮批次 13 个 op 全部一次成功（无回滚）。外置新档 3 个。

### ⚠️ 库被「目录重组」搬走后指针全废（2026-10-19 实测，第二次复发）

**症状**：用户说「记忆是不是错乱了」，一试 `read_file 详细知识/hermes_ops.md` 扑空；
15 个指针**全部 MISS**，但记忆内容看起来完好、`hermes curator` 也正常。

**根因**：`D:\Hermes文件库` 2026-10-18 重组为 5 分组（01_学习与课程/02_吉林大学/…）时，
把整个 `记忆外置库` 当吉大资料**一起搬进了 `02_吉林大学`**，记忆里的路径没跟着改。
更麻烦的是后来有人在**根目录重建了一个同名空壳**（只有刚写的几个档），
于是「库看起来在，其实 33 个档不在」。第二个会话还会对着空壳继续写作，假性正常。

**排查（一条命令定性）**：

```python
# 记忆里所有指针 → 逐个 os.path.exists，同时全盘 glob 找同名文件
ptr_re = re.compile(r"详细知识[/\\]([A-Za-z0-9_\-.]+?\.md)")
for name in refs:
    p = os.path.join(KB, name)
    if not os.path.exists(p):
        print("MISS", name, "->", glob.glob(f"{ROOT}/**/{name}", recursive=True)[:1])
```

全盘命中 = 只是搬了家（改库位置）；全盘没有 = 真丢了（只能重建）。

**修法**：`shutil.move` 搬回原路径 + 合并空壳（同名文件用 `filecmp` 比对，
保留内容多的；确认无残留再 `rmtree`），最后**逐条验指针命中**才算完。

**防复发**：
- 目录重组脚本里**显式排除** `记忆外置库`、`Python_Learning`、日报目录等
  「带硬编码路径的目录」——任何被记忆/定时任务/脚本写死路径的目录都不许搬。
- 重组后立刻跑一次指针审计（上面的代码），别等用户发现。
- `📍外置记忆路径约定` 那条记忆必须写**当前真实全路径**，重组就同步改它。

### 指针必须写「全路径」，否则外置档=没外置（2026-10-15 实测，用户的直接投诉）

用户反馈「外置记忆仿佛也没读」——**根因不是没外置，是指针是半截相对路径**：
记忆里 20+ 条写 `→详细知识/xxx.md`，真实路径却是
`D:\Hermes文件库\记忆外置库\详细知识\xxx.md`。下次会话按记忆去 `read_file
详细知识/xxx.md` 必然扑空 → 退化成「凭印象答」→ 用户感觉记忆没起作用。

**修法（已落地，照抄）**：在 MEMORY.md 加一条**路径约定总纲**，一次性根治：

```
📍外置记忆路径约定：所有「详细知识/xxx.md」= D:\Hermes文件库\记忆外置库\详细知识\xxx.md
（记忆里简写不带根的，一律补此前缀）；库结构=SESSION-STATE.md(恢复层)+working-buffer.md(毛坯)
+memory\YYYY-MM-DD.md(日志)+详细知识\(长期)+归档\
```

然后条目里继续写简写即可（有总纲兜底），不必每条都写全路径（费字符）。

**验收动作**：改完指针后，`ls` 一遍外置库确认每个指针都命中，别只看工具返回的
usage 就报成功。本次 30/30 外置档全部存在才收工。

**顺带体检**（本次一并发现的问题，下次压缩时检查）：
- 条目内容开头带残留 `§`（上次写入格式串了）
- `§\n§` 连续分隔符 = 空条目（split 时被过滤不易察觉，用 `repr()` 看原文才现形）
- 条目里的**进度类描述会过时**（本次：Python 教学条目还写「已学 W1-W2」，
  实际已到 W4；路径也记错）。压指针时顺手核对一遍真实现状。

### 预算脚本：硬编码 old_len 会误报，先量再算（2026-10-19 实测）

写「预算校验脚本」（把 16 条 new_text 和各自 old_len 塞进列表，assert `len(new) < old`）
很省事，但**old_len 是手抄的，会偏**：本次 16 条里有 2 条手抄长度比真实内容**短** 3-4 字符
（`pypi.tuna` 写 99 实际 102、`Typora` 写 131 实际 135），assert 直接炸两次，
白跑三轮。统计输出里的长度才是真值，**抄进去之前先对上**。

**更重要的一步：算平均节省，别指望每条都省。** 本次 16 条平均省 66 字符，
但**短条目（<130 字符）基本压不动**——把「回滚=重跑输U不输Y」缩成「输U」也只省 4 字符，
还得留指针，净收益可能是负的。判据：**条目长度 < 指针本身长度 + 20 就别压，直接删**，
信息反正已经在外置档里。本次 pypi / Typora 两条就是这么处理的（99→58、131→58，
留着结论句 + 指针）。

**批次结果以工具返回为准**：预算脚本算 6896，工具报 6799 —— 手抄 old_len 偏差累积所致。
差多少不重要，**报数字用工具返回的 usage**，别用自己算的。

### 该外置哪几条（三类判据，2026-09-19 实摘）

| 判据 | 实摘例子 |
|---|---|
| ① 已归档成独立 md 文档 | 吉大校园网资源（184字，已有 `校园网资源清单（实测）.md`） |
| ② 已被技能完整覆盖 | WSL2 优先（144字→技能 `windows-wsl2-script-exec`）；抓取偏好（→ `china-university-web-research`） |
| ③ 每轮自动注入属冗余 | 已装技能清单（227字，技能列表系统每轮注入）；Adobe 全家桶（低价值） |

**别压**：高频刚需条目（选课定稿、转专业硬条件、环境坑、Token 优化）——留在记忆里每轮注入才有价值，压成指针反增读取成本。

### 压缩手法：指针 + 关键操作信息

关键操作信息不能只留指针：

- ✅ `Typora 已破解@D:\Typora\（唯一解=HTryone/-typora-patcher；回滚=重跑输Y）；详→详细知识/typora_crack.md`
- ❌ `Typora 详见 typora_crack.md`（丢了「回滚输Y」这种必须当场知道的）

**顺序：先建外置档，再改记忆**——反了会丢内容。外置目标：`详细知识\<topic>.md`。

实测战绩：**7956 → 7001 字符（-12%），41→39 条，余量 44→999**。

## 一之三、🚨 shell 后端挂掉时怎么继续做记忆运维（2026-10-20 实测）

**症状**：`terminal` / `read_file` / `search_files` / `write_file` / `patch` **全部**报
`RuntimeError: Unknown HERMES_SHELL_TYPE='...' on Windows`。

**根因**：`config.yaml` 的 `terminal.shell` 只接受 `auto|pwsh|powershell|bash`。写成
`wsl -d Ubuntu-24.04 -- bash -lc` 会让 `_resolve_shell()` 抛错，所有走 shell 后端的工具一起死，
连 `hermes config set` 都跑不了 → **agent 无法自修**。

**先试自救（别急着让用户动手）**：

| 通道 | 能力 | 备注 |
|---|---|---|
| `mcp__windows_mcp__PowerShell` | 跑任意 PS、读写 MEMORY.md | 独立 MCP 进程，不经 terminal 后端 |
| `mcp__windows_mcp__FileSystem` | read/write/move/list | 写中文**只能走这个**（PS 会乱码） |
| `browser_navigate` + `file:///D:/...` + `browser_console` 读 `document.body.innerText` | 只读任意文件、列目录 | 中文路径要 percent-encode |
| `memory` 工具 | 正常可用 | 记忆压缩本身不受影响 |

我2026-10-20 靠这三个通道完成了：备份+改 config → 统计额度 → 建 3 个外置档 → 19 op 压缩 → 指针审计。

**注意**：
- 改 config 后**当前会话仍用旧值**，需重启桌面端 → 因此优先「用 MCP 把活干完」，修复放最后。
- MCP `PowerShell` 里 `[IO.File]::ReadAllText($p)` 读 MEMORY.md 正常（可数条目/额度），
  但 `Get-Content` 读别的 UTF-8 中文 md 会乱码 → 读内容用 `FileSystem read`。

## 二、四层记忆架构（2026-08 按 agent-memory-system-guide 落地）

```
D:\Hermes文件库\记忆外置库\
├── SESSION-STATE.md    ← 恢复层：当前任务/已完成/卡点/下一步/恢复信息
├── working-buffer.md   ← 毛坯层：进行中/临时决策/新坑/待蒸馏/未完成
├── memory-capture.md   ← 捕获清单（脚本 bootstrap 生成）
├── memory\
│   └── YYYY-MM-DD.md   ← 每日笔记：完成/决策/踩坑/待办（原始记录不加工）
├── 详细知识\           ← 长期归档层：按主题存长文，MEMORY.md 只留指针
├── 归档\               ← 历史备份（MEMORY_backup_*.md / USER_*.md）
└── archive_memory.py / compress_memory.py
```

- **会话启动**：先读 SESSION-STATE.md → 最近 1-3 天 daily notes → 再查 MEMORY.md
- **每日笔记**：每天结束时写 `memory\YYYY-MM-DD.md`
- **蒸馏节奏**：每周把 working-buffer 待蒸馏项 + 每日笔记蒸馏进 MEMORY.md
- **本机惯例**：外置库留在 D 盘（本地优先零依赖）；OpenViking/Hindsight
  官方后端暂不启用（量大了再评估）

## 三、memory_capture.py 命令（agent-memory-system-guide 技能自带）

脚本：`hermes-home\skills\agent-memory-system-guide\scripts\memory_capture.py`
（用 WSL python3 跑，Windows 路径含空格+中文 Start-Process 会拆断）：

⚠️ **WSL 传路径必须转 /mnt/c/ 格式**（2026-08-23 实测）：把 `C:\Users\...` 原样传给
`wsl -- python3` 会被拼到 /mnt/d 下报 `No such file`。正确实例：
`wsl -d Ubuntu-24.04 -- python3 "/mnt/c/Users/<user>/AppData/Local/Hermes Agent CN Desktop/data/hermes-home/skills/agent-memory-system-guide/scripts/memory_capture.py" distill --workspace /mnt/d/Hermes文件库/记忆外置库`

`distill` 输出 `Suggested memory: none / Recovery only: none` 属**正常判定**：
毛坯内容已入 MEMORY.md 时无需 apply 写入；任务进度类内容也正确排除在 MEMORY.md
之外（落到每日笔记 memory/YYYY-MM-DD.md 与 SESSION-STATE.md 即可）。

```bash
python3 <script> doctor   --workspace <ws>   # 健康检查（缺啥文件一目了然）
python3 <script> report   --workspace <ws>   # 状态报告（永不写记忆文件）
python3 <script> bootstrap --workspace <ws>  # 补齐 SESSION-STATE/working-buffer/memory-capture.md
python3 <script> session-start --workspace <ws>  # 会话启动初始化
python3 <script> distill  --workspace <ws>   # 毛坯→候选记忆（suggested_memory/recovery_only/follow_up）
python3 <script> apply    --workspace <ws>   # distill 结果写入 MEMORY.md（candidate_document_id 防重复）
```

注意：doctor 对"纯外置库"（无 MEMORY.md/memory-capture.md/attachments）报
warn 属正常——外置库只是归档层，系统 MEMORY.md 在 hermes-home\memories\。

## 四、坑

- 🚑 **shell 类工具全崩时，先用 `browser_navigate` + `browser_console` 只读取证再谈蒸馏**
  （2026-10-20 实测）：`terminal`/`read_file`/`search_files`/`write_file` 全部在初始化阶段崩溃时，
  浏览器仍能读本地文件——`browser_navigate file:///D:/.../memory/` 看目录索引；
  单个 md 导航后 `snapshot` 可能为空，**改读 `document.body.innerText`**；`fetch()` 批量抓
  file:// 会被跨源拦（`Failed to fetch`），**一次一个文件**；中文/空格路径必须 percent-encode。
  → 这样即使写不了文件，也能先把 working-buffer / 最近几天日记读完、把蒸馏结论讲清楚，
  等用户修好配置立刻落盘。**别在工具瘫痪时空手回「等修好再说」。**
  （本次根因=`config.yaml` 的 `terminal.shell` 写了 `wsl -d ...`，agent 自己改不了，
  详见技能 `windows-wsl2-script-exec` 的「全部 shell 工具瘫痪」节。）
- ⚠️ **`replace` 的 `old_text` 必须匹配「工具存储里的当前内容」，不是你读到的那版**
  （2026-10-18 复踩）：我按记忆文件里读到的旧措辞（「①要求『按顺序来，都完成』」）去匹配 →
  `no entry matched` → 整批回滚；实际存储里那半句早已被改写成「①『按顺序来，都完成』」。
  修法：`old_text` 取该条目**当前确实存在的一段短唯一片段**（如「⑤深处议题=」这种半句），
  别用整段、更别用手抄的旧版本。失败后工具会打印当前全部条目，下一次直接从那份输出里摘字。
- ⚠️ **PS `-split "\`n§\`n"` 数不出条目数**（2026-10-18 实测返回 1，实际 49 条）——
  文件是 CRLF，分隔符是 `\r\n§\r\n`。数条目用 WSL python 或 `-split "§"`。
  字符数 `(Get-Content $p -Raw).Length` 是准的，可以留在 PS 里用。
- PS 5.1 读 UTF-8 中文文件乱码（GBK 解码）→ 用 read_file 工具或 WSL cat
- Start-Process 参数含空格+中文路径会被拆断 → 用 WSL 直跑 python3
- ⚠️ **PS `-replace` 第 2 参数不能用 `+` 拼接**（2026-09-30 复踩）：`$t -replace 'p','a'+'b'`
  报 `-ireplace 运算符只允许后面包含 2 个元素，而不是 4 个元素`。
  **改脚本（如复制 v170 脚本改版本生成 v171）一律用 Python 的 `re.sub` 做**，
  别在 PS 里做文本替换——`(Get-Content -Raw) -replace ... | Set-Content $dst` 这种写法必炸。
- ⚠️ **PS 前台命令含 `&` 会被判后台符拒绝** → 调 python 用 `Start-Process -FilePath <py>
  -ArgumentList @(script) -NoNewWindow -Wait -RedirectStandardOutput <log>` 传数组，
  输出从 log 读（`Get-Content $log -Encoding UTF8`）。
  ⚠️ **工具返回的 `exit_code:1` 常是误报** —— 只要 stdout 有正常内容就说明跑成功了，
  别被 exit_code 误导去反复重试。
- **️ archive_memory.py 等脚本创建中文路径时可能产生乱码文件夹**（2026-08-07 首现，
  **2026-09-13 复现**）：UTF-8 字节被当作 GBK 解码后当作文件夹名，在 `D:\` 根目录
  创建乱码目录（如 `Hermes鏂囦欢搴揬璁板繂澶栫疆搴揬褰掓。`，本意是
  `Hermes文件库\记忆外置库\归档`）。根因：脚本中路径拼接时编码链断裂。
  **还原与清理**（`scripts/fix_mojibake_folder.py` 可直接跑）：
  ```python
  mojibake.encode('gbk').decode('utf-8')   # → 文件库\记忆外置库\归档
  ```
  清理步骤：先列内容确认 → `shutil.move` 把文件归位到正确目录 → `os.rmdir` 删空壳。
  实测该乱码目录里是 `MEMORY_20260807_2235.md` / `USER_20260807_2235.md`，属归档层。
  ⚠️ **不要用 PowerShell 传中文路径给 python**（`Get-ChildItem "D:\Hermes鏂囦欢..."` 会
  报「路径不存在」，`python3 -c "..."` 里的中文字符也会被吞）→ 用 `os.scandir('D:\\')`
  按前缀匹配定位，全程写在 .py 脚本里跑（见 scripts/ 下的现成脚本）。
- skillspector 对记忆类技能报 Memory Poisoning 是**误报**（写 MEMORY.md 是本职，
  见 skill-security-scan 技能）
- 模板文件（agent-memory-system-guide/templates/*.md）用 `& python` 在 PS 下
  读会乱码，但文件本身是好的 UTF-8——别因乱码重写模板

## 五、专题档（非技术类，和记忆外置同一条流水线）

外置库不只放技术长文。用户的人生/决策类议题也该开档，写法和技术档不同：

- 文件放 `详细知识\<topic>.md`，MEMORY.md 只留一行指针（否则详细记忆永远不进 prompt）。
- 内容形态：把**反复出现的表面问题**排成表，右侧写它底下那个真问题；再加「证据」
  （从已有外置档/日志里摘原话，不臆造）、「子问题」、**空着的**家底表。
- ⚠️ **别替他下结论、别填「他想要什么」那栏**——留空问号比填错强。他只说「行」时，
  写档 + 放指针，不展开长篇。
- 已开档：`详细知识\roads_and_money.md`（转专业/闲鱼/RoseMe/省钱 都是「这条路值不值得、
  能不能换钱」的表层替代）。同类议题先看它，别另开重复档；计划类派生物放
  `详细知识\six_month_plan.md`。

### 五之二、人生/决策类议题的对话协议（2026-10-18 实测有效）

用户说「你来向我提问」「帮我找出答案」时，按此走：

1. **一次只问一个**，等他答完再问下一个。一次抛三个，他只会答最后一个。
2. **先问可核对的事实，别问感受**：「开过什么/多少小时」比「你热爱吗」有用——数字自己会
   说话（本次：144h 模拟器 + 真车 0h + 驾照没考，一句话把「热爱」定位到消费层）。
3. **先给一个可能的判断，再让他确认**（「我猜是这个，对吗」）。从零提问会被答成
   「都有吧」；先给靶子，他才好否掉或修正。
4. **抓住答案里的反证**：答案是保底/推脱时点出来（「后面也许也不愁吃喝」= 保底不是答案）；
   出现「不甘心」这类情绪词时，说明他真正在意什么。
5. **把焦虑项逐条判真伪**，其中一部分是他自己脑补的。实测：「没开工程制图，比别的专业
   落后」——工程制图是大二公共课，交通车辆都要学，**这条根本不成立**。判真伪要查课程/
   政策原文，别顺着他的焦虑点头。
6. **结论落到一句能立刻做的动作**，别停在「你要想清楚」。用户回「行」= 要可执行的东西。
7. **别做的**：四张路线图、横向对比表、每日 timetable、KPI 打卡表——他还没到能选的阶段，
   这些是替焦虑做装饰。计划里留自由时间（周六空着），否则撑不过两周。

⚠️ **提问本身就是产出**：用户会拿这轮问答当档案用，所以每次问答都要落档
（表格：我问的 / 他答的 / 我读到的东西），别只在聊天里过一遍。

## 相关技能

- `skill-security-scan`：第三方技能装前扫描（含 Memory Poisoning 误报判定）
- `agent-memory-system-guide`（虾评装的第三方技能）：完整方法论参考

## 附：可跑脚本

- `scripts/fix_mojibake_folder.py`：定位 D:\ 根目录编码乱码文件夹并归位（默认预览，
  `--apply` 执行）。详见「四、坑」中的乱码目录条目。

## 附：相关参考

- `references/batch-file-organization.md`：**批量整理工作区目录**（用户说「文件夹
  很乱」时用）。含 dry-run 脚本骨架、15 类归档结构、乱码目录/带反斜杠怪目录/
  自指符号链接三类修复法、以及「移动不删 + 逐文件比对后才允许删」的安全协议。
