---
name: jlu-knowledge-ops
description: >-
  吉林大学知识库运维——用户（吉大2026级新生，目标大一下转车辆工程）所有吉大相关问题的知识底座。
  **触发词**：吉林大学/吉大/JLU/转专业/车辆工程/机械工程/能源与动力/仿生/仪器/电气/计算机学院/转计算机/分流/大类分流/选课/军训/青马/思源/保研/校园网/培养方案/课表/推免/入党/入党申请书/思想汇报/转正申请/吉甲大师/TARS-Go/机甲大师/RoboMaster/吉速/吉速车队/JLU RACING/方程式/FSC/FSCC/FSEC/FSAC/巴哈/肯赛/赛车队/车队纳新/社团纳新。
  **同类操作触发词**：吉大通知/校内通知/oa/教务/教务系统/选课系统/icourses/英语分级/四六级/成绩/奖学
  金/综测/辅修/学籍/学位/政策文件/信息公开网/学院官网抓文件/推免细则/保研文件/学生干部/班干部/团支书/
  知识库发布/百晓生/吉大知识库更新。
  覆盖：资料目录与提取层位置、技能包更新发布全流程（学习→提取→合并references→WSL发布虾评）、
  用户主线的优先级（转专业>GPA>其他）、选课/军训/分流去向等高频知识索引、学院官网爬取与附件下载技巧。
platforms: [windows]
---

# 吉林大学知识库运维（JLU Knowledge Ops）

用户是**吉林大学2026级新生（交通学院交通运输类）**，核心目标：**大一下转专业到车辆工程**（GPA≥3.0 + 笔试数学=微积分BI+高中数学 + 面试；2026年名额44人：大一33/大二11；笔试50%+面试50%×志愿系数）。几乎所有吉大提问都围绕此主线展开：选课（拿分）、军训（班干部起跑线）、入党/青马/思源（背景加分）、保研（长远规划）。

## 资料位置（用户约定：所有吉大文件放这一个文件夹）

⚠️ **2026-10-18 全库重组**：`D:\Hermes文件库\` 根目录现在只有 5 个分组（`01_学习与课程` / `02_吉林大学` / `03_工具与项目` / `04_游戏` / `05_备份`）+ `00_文件库索引.md`。
所有旧路径需补前缀：`D:\Hermes文件库\吉林大学相关文件\` → `D:\Hermes文件库\02_吉林大学\吉林大学相关文件\`；`吉林大学百晓生v5`、`记忆外置库`、`入党申请书` 同样在 `02_吉林大学\` 下；日报/账单/词表/agent-reach 等在 `03_工具与项目\`；`_脚本存档` 在 `05_备份\` 下。

- **主目录**：`D:\Hermes文件库\02_吉林大学\吉林大学相关文件\`（26 个子目录；2026-10 新增 `就业\`、`公共课复习资料\`、`转专业文件\2026流动数据\`）
  - `_extracted\` — 全部 PDF/docx/xlsx 的文本提取层（fitz/openpyxl/olefile/图片识别txt），技能包内容来源于此
  - `选课\` — 选课定稿/全部课程信息汇总/课表/互助文档新版（336KB）/开课情况
  - `大学规划\` — 大一行动路线图(md+docx)/暑假备战规划/青马与思源详解/新生攻略/99条建议/社团名单
  - `校园网络\` — 吉大常用网站.md/校园网指南/相关网站.html
  - `竞赛与推免\` — 学科竞赛体系/保研去向报告/唐敖庆班通知
  - `军训\` — 2026级军训进度表.md；其余：转专业文件/政策文件/吉大推免文件/专业总览表/各专业培养方案/电子教材/英语资料/四史/工图习题集答案
- **主归档文件**：`选课\大一上选课定稿与学分统计.md`（12门定稿+课表+学分统计+待办）、`选课\全部课程信息汇总.md`（65条课程全量：课号/教师/时间/地点/学分/容量/冲突）
- **技能包源码**：`D:\Hermes文件库\02_吉林大学\吉林大学百晓生v5\`（SKILL.md + `references\` **27 篇**：12 个 `*_all.txt` 原始文档合并 + 15 个结构化专题 md，与线上 GitHub 一致）
  - ⚠️ **发布前 SKILL.md 要用 `_gh_jlu_repo\SKILL.md` 打底**（对外版 name=`jlu-baixiaosheng`），别直接复制本技能的 SKILL.md（见「发布脚本」坑 1）
- **虾评技能**：ID `ff4601bb-28d7-4f45-82aa-f4621ca510a6`（**线上 1.2.0 = 包内 v1.7.2**，2026-10-18），GitHub 仓库 `WilliamWang6586/JLU-xinshengbaixiaosheng`（27 篇 references）
- **发布脚本**：`05_备份\_脚本存档\01_吉大百晓生发布\{prep,push,publish}_v172.py`（改 SRC/FILES/CHANGELOG 即复用；虾评 key 在该目录 `publish_skill.py`）

## 学习→入库→发布 标准流程

1. **找新文件**：`os.walk` 按 mtime 过滤（72h内） 或 search_files 找新增
2. **提取**：PDF 用 fitz；xlsx 用 openpyxl（⚠️ 课表/评价表含 `=DISPIMG()` 公式单元格，导出时替换为 `[图片]`）；doc/docx 复用 `_extracted` 既有产物；纯图片 PDF/jpg/webp 用 qwen-vl-max 识别（脚本模式见 `D:\Hermes文件库\look_image*.py`，Key 从 `~\.hermes\.env` 的 DASHSCOPE_API_KEY 读）
3. **合并**：追加进 `references\<分类>_all.txt`（用 `===== 来源文件: xxx =====` 分隔），或整版替换（如选课文档新版直接替换旧版）
4. **SKILL.md**：更新知识库表格加一行（文件名/内容/用途）
5. **打包+发布**：zip 打包 v5 目录 → 写 `.sh` 文件（changelog 含中文，**勿用 Windows 侧 urllib/curl 直发**，schannel 对 coze.com 握手失败需走 WSL OpenSSL，见 windows-maintenance 技能）→ `wsl -d Ubuntu-24.04 -- bash -c "sed -i 's/\r$//' '<sh>' && bash '<sh>'"` → 成功看返回 JSON `version` 递增
6. 发布 API：`POST https://xiaping.coze.com/api/upload`（multipart：skill_id + changelog + `pledge={"agreed": true}` + requires_api_key=false + file=@zip），**不是** `/api/skills/{id}/versions`
   - ✅ **校园网直连可用**（2026-09 实测 HTTP 201）：Windows 侧 `urllib` 手拼 multipart 直接 POST 就成（模板 `D:\Hermes文件库\publish_v162_xiaping.py`），不必绕 WSL。
   - 字段顺序：`skill_id` → `changelog` → `pledge` → `requires_api_key` → `file`（file 段手拼二进制）
   - ⚠️ 脚本里的 key 别抄终端**显示截断**形态（`sk_PqV...m6s7` 是显示省略，不是真 key）——这是曾经 401 反复的根因

⚠️ 发布脚本内嵌 API Key（sk_PqVP4b...）——**任何发 GitHub/外传的内容先脱敏**。

## GitHub 仓库更新：Contents API 是「免交互凭据」首选
2026-09 时 `github.com` 不通、只有 `api.github.com` 直连 200，故改走 Contents API。
**⚠️ 2026-10-10 复测：`github.com` 直连 HTTP 200，`git clone` / `git ls-remote` 均 exit=0**（`git push` 未复测）。
Contents API 仍推荐继续用——它是**不碰交互凭据**的最省事路径、脚本已成型；
但「git push 必然失败」这个前提不再成立，别拿它当理由。
所以更新仓库用 Contents API：
```
PUT https://api.github.com/repos/{owner}/{repo}/contents/{path}
Authorization: Bearer <token>   body: {message, content: base64, sha, branch}
```
- **token 从 git 凭据管理器取**（Windows 凭据管理器键为 `git:https://github.com`）：
  ```python
  subprocess.run(['git','credential','fill'],
                 input=b'protocol=https\nhost=github.com\n\n', capture_output=True)
  # 输出里 password= 那行即 token（gho_ 开头 40 位）
  ```
- **改已存在文件必须带 `sha`**：先 `GET .../contents/{path}?ref=main` 取 `sha`，否则 409/422
- 现成脚本：`D:\Hermes文件库\gh_api_commit.py`（改 `FILES`/`OWNER` 即复用）+ `verify_gh_remote.py`（读回验证）
- ⚠️ 别把 remote 换成 `ghproxy.net` 来 push：凭据键是 `git:https://github.com`，换域名取不到凭据 → `could not read Username for 'https://ghproxy.net'`
- ⚠️ 提交后**必须读回验证**（GET contents 确认 version/关键词），别只信 PUT 的 200

## 校园网环境限制（影响知识库运维与抓取）

⚠️ **用户报「连不上 GitHub」别先动 VPN**（2026-10-10 教训：我第一反应去查/开夜煞云 → 判错方向，用户纠正「我要校园网直连，你之前都帮我做到的，去翻记忆」）。
**正确顺序**：①先翻 `吉林大学相关文件\校园网络\GitHub访问方案（不挂VPN）.md`（唯一权威）②跑下面的只读探测分诊 ③**按下面的两个分支判**——「单 IP 抖动」和「SNI 阻断」处置完全不同，别默认第一种。

### 🔴 2026-10-16 新增分支：SNI 层阻断（hosts 钉 IP **无效**，别白折腾）

确诊特征 —— **TCP 全通但 curl 拿不到码**：

| 检查 | 结果 | 判读 |
|---|---|---|
| `Test-NetConnection github.com -Port 443` | True | ⚠️ TCP **假通**（防火墙放行 SYN） |
| `Test-NetConnection <候选IP> -Port 443` | 全 True | TCP 层**完全不可信**，别用它判活 |
| `curl.exe https://github.com/` | **000 / 15.6s / exit 35** | TLS 握手被 reset ← **真因** |
| `curl.exe --resolve github.com:443:<IP>` | 同样 000 | **绕过 DNS 仍失败 ⇒ 不是 DNS 问题** |
| `curl.exe https://www.baidu.com` | 200 / 0.15s | 校园网本身正常 |

**铁律：`Test-NetConnection` 返回 True **不代表能用**；唯一可信判据是 `curl` 拿到 HTTP 码。**

```powershell
# 30 秒判据（TCP 通 + curl 000 = SNI 阻断 → 直接跳 ghproxy，别碰 hosts）
curl.exe -s -o NUL --max-time 10 -w "%{http_code}`n" https://github.com/
```

- ⚠️ `git` 报 `CRYPT_E_REVOCATION_OFFLINE (0x80092013)` = **证书吊销检查（CRL/OCSP）端点被墙**，
  与 GitHub IP 无关，钉 IP / 换 IP 都不解 —— 同样是「走 ghproxy」的信号。
- 若期望代理却 `7892` 无监听 = **VPN 客户端根本没启动**（无 clash/verge/xray/mihomo 进程）→ 先确认客户端在跑，再谈走代理。

**✅ 该分支唯一有效解法（零依赖，2026-10-16 实测通过）：git URL 重写**

```powershell
git config --global url."https://ghproxy.net/https://github.com/".insteadOf "https://github.com/"
```
配完 `git clone https://github.com/xxx/yyy.git` **无感自动走 ghproxy**（实测真 clone：28 文件、HEAD sha 一致、exit=0）。
- ⚠️ **大仓库（500+ 文件）clone 要 2-3 分钟**，前台短超时会被误判成失败 —— 先 `git ls-remote`（秒回）试连通性，clone 用 `background` + `notify_on_complete`。
- 回滚：`git config --global --unset url."https://ghproxy.net/https://github.com/".insteadOf`
- ⚠️ 此重写**只影响 git**，raw 文件仍要手拼前缀：`https://ghproxy.net/https://raw.githubusercontent.com/...`
- 镜像站实测可用性：`ghproxy.net` ✅ · `gh-proxy.com` ❌ · `ghfast.top` ❌ · `hub.fastgit.xyz` ❌（只留 ghproxy.net，别挨个试）

### ⚠️ hosts 提权写入的坑（当天踩两次把 hosts 清成 0 字节）

1. **`Start-Process -Verb RunAs -File <含中文的路径>.ps1` 静默失败**（PS5.1 吞中文路径实参）——脚本没跑，但你以为跑了。
2. **here-string `@'...'@` 经该路径传参可能整体为空** → `Set-Content` 写出 **0 字节**，原内容丢失且**无任何报错**。
   （实测：hosts 22:08 与 22:17 两次被清空，`LastWriteTime` 变了但 `Length=0`。）
3. **恢复默认 hosts 最稳的办法**：
   ```powershell
   Start-Process cmd -Verb RunAs -ArgumentList '/c','copy','/Y','C:\Windows\Temp\hosts_default.txt','C:\Windows\System32\drivers\etc\hosts' -Wait
   ```
   标准默认内容（803 字节纯注释块，无任何 IP 行）已存 `C:\Windows\Temp\hosts_default.txt`；
   **改 hosts 前先备份**，改完必须 `Get-Item ... | Select Length` 确认非 0。

### 分支一：只有 `github.com` 挂 + curl 能拿到码 = 单 IP / 路由抖动
2026-10-10 实测：DNS 给 `20.205.243.166` 后 443 超时，**约 10 分钟自愈**；同期 api/raw/codeload 一直通。此时才用 hosts 钉 IP 兜底。
- 确认无代理残留：`Get-NetTCPConnection -LocalPort 7892 -State Listen`（期望空）+ `Get-NetAdapter` 无 TAP/TUN/WireGuard 网卡
- **全挂** → 校园网认证掉了，去 `http://10.10.10.10` 重认证；或根本不在校园网（`curl.exe -s "http://ip-api.com/json/?lang=zh-CN"`，期望 `isp=CERNET`、IP `49.140.x.x`）

**分级探测（30 秒，全只读）——逐个端点测 TCP 443，别只测 `github.com`：**
```powershell
foreach ($h in @("github.com","api.github.com","raw.githubusercontent.com","codeload.github.com","objects.githubusercontent.com")) {
  $c = New-Object System.Net.Sockets.TcpClient
  $t = $c.BeginConnect($h,443,$null,$null)
  if ($t.AsyncWaitHandle.WaitOne(5000)) { Write-Host "OK  $h" } else { Write-Host "BAD $h" }
  $c.Close()
}
```
- **只有 `github.com` 挂、其余全通** → 单 IP / 路由抖动。2026-10-10 实测：DNS 给 `20.205.243.166` 后 443 超时，**约 10 分钟自愈**；同期 api/raw/codeload 一直通
- **全挂** → 校园网认证掉了，去 `http://10.10.10.10` 重认证；或根本不在校园网（`curl.exe -s "http://ip-api.com/json/?lang=zh-CN"`，期望 `isp=CERNET`、IP `49.140.x.x`）
- ⚠️ **TCP 连上 ≠ 能用**：`20.205.243.168` TCP 443 通、但 TLS 后返 **HTTP 400**。判定必须跑完 TLS+HTTP：
  `curl.exe -s -o NUL -w "%{http_code}" --max-time 12 --resolve "github.com:443:<IP>" https://github.com`
- 确认无代理残留：`Get-NetTCPConnection -LocalPort 7892 -State Listen`（期望空）+ `Get-NetAdapter` 无 TAP/TUN/WireGuard 网卡

- ✅ **可达（2026-10-10 无代理/无 TUN 复测）**：`github.com` / `api.github.com` / `raw.githubusercontent.com` / `codeload.github.com` / `objects.githubusercontent.com` **全部 HTTP 200**；`git clone`、`git ls-remote` **exit=0**；连测 6 次 6/6 200。另：知网/万方/超星/WoS(**用 .cn 域名**)/维普、全部吉大校内站、DeepSeek/千问等国内 API
- ❌ **真正不通的**：`export.arxiv.org`（`arxiv.org/api` 也 302 跳回它）、V2EX、36kr、PubMed；地质仿真 vge.jlu.edu.cn 疑似限内网。**`github.com` 不在不通名单里——旧版把「github.com 网页与 git push 不通」列为限制，该结论 2026-10-10 已作废**
- **兜底（按分支选，别默认 hosts）**：①**SNI 阻断**（TCP 通+curl 000）→ `git config --global url...insteadOf` 走 ghproxy（见上）；②**单 IP 抖动**（只有 github.com 挂+curl 能拿码）→ 等 5-10 分钟自愈，持续才 hosts 钉 IP `140.82.112.3 github.com`（需管理员，**改前先备份、改后验 Length≠0**，删行即回滚）；③`ghproxy.net` 前缀法通用兜底（**kgithub 已失效**；只放行 github 域名，转发 arxiv 返 403）
- 实测清单：`D:\Hermes文件库\吉林大学相关文件\校园网络\校园网资源清单（实测）.md`

## 高频知识索引（答问前先查这里）

| 主题 | 位置 |
|------|------|
| 转专业2026细则/2025对比/流动数据 | `_extracted\转专业文件_*.txt`、`zhuanzhuanye_all.txt`；**2026 实际流动数据（车辆25级计划45人100%录满、能动23人100%录满=二志愿最优兜底、交通学院24级转出38人）= `转专业文件\2026流动数据\2026转专业数据要点.md`** ⭐ |
| **多专业候选评估（车辆/机械/能源动力/仿生/仪器·电气）** ⭐ | `references/zhuanzhuanye-beixuan-zhuanye.md`（4 维评估套路 + 数据源地图 + 2026 门槛表[GPA/名额/笔试/志愿系数] + 匹配度结论 + 校区事实[仪器=朝阳校区]）；样例产物 `转专业文件\转专业备选专业分析_6专业.md` |
| **转计算机学院（新通道）** | `references/zhuan-jisuanji-2026.md`（硬条件=理科/选考物理+首考全合格+**GPA前30%**；考核=微积分AI笔试70%+面试30%，志愿系数100/90/80；97名额；`转专业文件\转计算机学院计划.md`） |
| **转专业全书扫描 + 时效核实** ⭐ | `references/zhuanzhuanye-quanshu-saomiao.md`（168页细则汇总按页切块做「各院笔试科目全表」[2026：只有人工智能考 C]；43 个细则链接批量探测判年份；jwc 正文路径 `/info/1050/<id>.htm`；特殊类型转专业公示 ≠ 集中考核通道；年份节奏=12 月中下旬出通知） |
| **软件/就业方向（转专业失败或改走计科时的备选档）** | `吉林大学相关文件\就业\`：`软件本科生就业.docx`（27届软工高霁泉《吉大软院就业实习方向生存指南》19节）+ `本科生就业经验分享_讲座纪要.md`（语音转写整理）+ `README.md`（含三条可迁移结论，**JD 倒推法同样适用于转专业笔试准备**） |
| 青马工程+思源计划（学姐郭梧曼一手信息） | `青马工程与思源计划详解.md`（大一4月报名、学院优先留本院⚠️） |
| **党内文书（入党申请书/思想汇报/转正）** | `references/dangke-wenshu.md`（黑格稿纸九页半=400格约3800字、涂改零容忍、禁止"志愿入党"只能写"申请入党"、第一段不写党章、领导人只写习近平、只写申请时间之前的事；3800字版段落配比 + 必留手填位 + 范文换肉法 + **高频重复源对照表** + 交付习惯）+ `scripts/{count_words,check_dup,gen_docx}.py` 三件套（字数核算/查重/导Word对照稿） |
| 军训进度表（9月3-18日） | `2026级军训进度表.md`（9月12日4:30拉练、9月18日开学典礼） |
| 选课互助（微积分/C语言/英语/体育老师评价） | `选课互助文档_新版.txt`（336KB，微积分10分档：宋勤生/李岩波/曹春玲/周晔/孙旭阳；避雷：从天枢/周倩） |
| 大一行动路线图 | `大一行动路线图.md`/`.docx`（时间线+优先级：绩点>入党>班干>青马>学生会） |
| 校园网 | 记忆外置库 `详细知识\jlu_campus_network.md`（20元/月、JLU.WIFI/JLU.PC、IP自动获取/禁NAT、A类IP无国际出口）；**有线接入/MAC变更/诊断/动配置铁律** → `references/campus-network-mac.md`；**DRCOM 客户端频繁断线（"老是断链"）排查** → 同文件第六节（日志 `C:\Drcom\DrUpdateClient\Log\`；先分诊"物理链路断 vs 认证会话断"，90% 是多网卡并存导致客户端路由管理选错网卡） |
| **交通学院分流（去向+成绩排名实测）** | `references/jiaotong-fenliu-2025.md`（2025级253人真实录取：汽车运用84人[名次6-125,绩点≥3.3]/低空班19人[1-34]/交通工程57/规划42/道桥50兜底≥181；**分流≠转专业，是保底**）；原档 `政策文件\交通学院分流去向与成绩排名（2025级实测）.md` + `政策文件\交通学院分流原始数据\` |
| 吉大常用网站（39站完整导航） | `吉大常用网站.md`、`wangzhan_all.txt` |
| **培养方案对比（交通/车辆/机械）+ 官方学习攻略** | `references/peiyang-fangan-duibi.md`（总学分158/160.5/169、核心课前半段全重合后半段分叉、官方教学时间、考试周2027-01-04~15上午9-11、学分绩点规则、选课规则）|
| **工程制图课程问题** | `references/engineering-drawing-course.md`（交通运输专业**不开设工程制图课程**，核心课程为工程图学；汽车运用工程方向已涵盖机械制图基础；如需补充可自学工程制图或选修相关课程）|
| **转专业学分认定/补课账（"这学期不学→转过去要补多少"）** | `references/zhuanzhuanye-xuefen-buyu.md`（三笔账框架：①门槛账=资格致命[GPA≥3.0+前30%+微积分BI笔试考的就是本学期课] ②学分账=大一上27.5学分中26.5分两边必修100%认定、仅导论1分作废[政策第二十三条(三)] ③补课账=仅~3学分[制图A~2+机械CAD1]、车辆总学分158比交运169少11分完全覆盖；含校发2024-201号第五章政策细则摘录+答话模板）|
| **2027推免新规** | `references/tuimian-2027-guize.md`（推免≤50%、复试60分合格/≥20分钟/三随机/≥5人、9/16前公布细则、GPA一石二鸟）；原档 `吉大推免文件\吉林大学2027年推免工作办法.pdf`、`政策文件\2027年推免新规要点.md` |
| 教材库（约200本PDF） | `电子教材\`（个人资料，**不入技能包**，体积+版权） |
| **每日科技日报运维** | `references/daily-report-ops.md`（代理策略=**有代理用代理/无代理直连**，删掉硬编码死代理兜底 7892；校园网无VPN各源实测：HN/GitHub/财经/配图/翻译✅、arxiv/V2EX/36kr❌但arxiv有本地兜底、**arxiv接镜像无解别折腾**；`-replace` 第2参数不能拼接；脚本 `D:\Hermes文件库\每日科技日报\`，调度走**Windows 任务计划程序**非 Hermes cron） |
| **吉大 OA 通知抓取与分级呈现** | `references/jlu-oa-notices.md`（5 个 channelId 栏目结构、相对时间「今天/昨天」归一化、关键词+降权词两级过滤、四级呈现结构；**月度复盘三步法**：oa_weekly.py N 抓清单 → `scripts/oa_detail_probe.py` 抓详情核 deadline → 分档交付；⚠️ 年份口径陷阱/落款日≠截止日/2026-10 起 179577 能拿到 25 条真实通知） |
| **通知抓取关键词表 + 日报接入脚本**（原 `jlu-campus-info`） | `references/jlu-campus-notices.md`（相关/排除关键词、`jlu_notices.py` 输出 jlu_section.txt/html、daily_pipeline.ps1 第3步、18:30 计划任务） |
| **站点与抓取配方 + 选课/转专业方案逻辑**（原 `jlu-student-affairs`） | `references/jlu-sites-and-course-planning.md` + `references/jlu-fetch-recipes.md`（oa/gongkai/学院/公众号 URL 模式、必修别退、选课学分控制、信息公开网 404、ima 知识库抓不到正文） |
| **学生事务操作手册**（原 `jlu-student-ops`）：选课分析 7 步、选课结构速查、已核实事实速查（转AI/转车辆/青马思源/竞赛/综测加分/干部决策/加分归属）、必踩坑 | `references/student-ops-playbook.md`；配套 `references/ai-college-transfer-exam.md`、`references/campus-network-diagnostics.md`、`references/screenshot-ocr-extract.md`、`scripts/link-layer-probe.ps1` |
| **站点端点 + 政策要点 + 知识库发布/路线纠结辅导**（原 `jlu-academic-ops`） | `references/jlu-academic-and-publish.md` + `references/jlu-policy-and-courses.md`、`references/jlu-publish.md`、`references/jlu-publish-gotchas.md`、`references/indecision-coaching.md`、`references/tongshi-policy-scan-ocr.md` |（5 个 channelId 栏目结构、相对时间「今天/昨天」归一化、关键词+降权词两级过滤、四级呈现结构；**月度复盘三步法**：oa_weekly.py N 抓清单 → `scripts/oa_detail_probe.py` 抓详情核 deadline → 分档交付；⚠️ 年份口径陷阱/落款日≠截止日/2026-10 起 179577 能拿到 25 条真实通知） |
| **吉甲大师/TARS-Go 战队 + RoboMaster 赛制** | `references/jijia-robomaster.md`（6组别职责、纳新5步流程、运营组志愿时长抵形策实践、战队在**南湖校区**非南岭、RMUC/RMUL分级与兵种、技术评审硬门槛、官网jijiamaster.com+规则中心wiki目录树、**2027赛季重大变更**（英雄+工程→重装机器人、飞坡→隧道、空中机器人改全自动+机库、自定义终端MQTT+ProtoBuf）+ 2026硬指标表 + 报名考核链）；原档 `吉甲大师\\*`（含 `RM官方文件\\`12份官方PDF、`_extract\\`365页文本、`吉甲大师调研.md`、`dl_rm.py`/`extract_rm.py`） |
| **吉大车队群 JLU RACING / FSC 大学生方程式** ⭐ | `references/jisu-fsae.md`（**吉大有 5 支车队不止吉速**：吉速[FSCC燃油/混动,8992粉]/吉速-孔辉电动[FSEC]/**肯赛节能**/**肯赛巴哈越野**/**吉智无人**[FSAC]｜吉速=汽车工程学院·**南岭校区**（与交通学院同校区）、2009创立、FSC创始队之一｜🏆2025七冠王·六连冠·927.61分领先161分、**四个最高权重项全第1**｜⭐**FSC总分1000=静态325[设计150/成本100/商业75]+动态675[耐久300最高/避障150/效率100/直线75/8字50]**，⇒**175分是商科分→营销/成本组也招人，技术弱可从商业报告切入**｜FSC vs RM 对比表｜硬指标轴距≥1525mm/离地≥30mm/轮辋≥203.2mm｜⭐**王达（吉速指导教师）是2026版FSC规则参编人员**｜招新节奏=10月发宣传片｜渠道：**加微信 yooberor**/B站403011009/学院官网 auto.jlu.edu.cn）｜抓取技术见 `references/fsc-official-site.md`；原档 `吉大方程式\\*`（`FSC官方文件\\`31份、`_extract\\`198页、三个调研md、`fsc_*.py`/`grab_*.py`） |
| **FSC 官网抓取技术** | `references/fsc-official-site.md`（formulastudent.com.cn **静态HTML无反爬**，`/documentation.html?doc=1~5`=通用/油车/电车/无人车/巴哈，文件在 `/news/<id>.html`，CDN=`img.sae-china.org/web/<年>/<月>/<名>`｜**必须两阶段**（爬清单落JSON → 读JSON并行下），单体脚本必超时｜**三个Windows编码坑**：urllib不自动quote中文URL/终端GBK print崩/PS重定向转UTF16｜下完必验魔数 %PDF\|PK） |

## 选课决策要点（用户视角）

- 主原则：**好拿分优先**（GPA 是转专业门槛），评价表 10 分档优先、1-2 分避雷
- ⚠️ 南岭校区限制：选课互助文档多数五星水课（宝石/西方音乐史/电影艺术）在**前卫校区**，按校区筛选
- 转专业视角：微积分是笔试科目选好老师；C语言是车辆工程课程（交通学院不上）——开车前学是投资；通识课两边认定
- 课程认定：全校统一按《吉林大学本科学生转专业工作管理办法》（校发〔2024〕201号）第五章，通识课100%认定
- 用户兴趣线（2026-09 已定）：**赛车运动**（通识核心，兴趣+转车辆对口）+**电影艺术**（美育）——用户亮出兴趣时别只推水课，兴趣课优先
- 无评价课程/老师（`选课互助文档_新版.txt` 搜不到时）处理顺序：①查教室位置选近的 ②新生群问一句 ③按课型预判（观影型轻松但翘课扣分狠；文学欣赏型作文温和但优秀率低；大班通常比小班宽松）④退补选可换班兜底
- 时间冲突排查：同一时段多教学班/课程（如电影艺术 vs 影视文学欣赏都周四9-11节）→ 只能选其一，先确认时间再推荐
- ⚠️ **必修 > 选修 取舍规则**：必修课（思政/微积分/英语等）时间与选修冲突时，**退选修保必修**（2026-09 实例：赛车运动与文化(周一晚)↔习思想概论(周一7-10节单周)冲突→退赛车；系统本身也会标冲突选不上）
- **选课定稿状态（2026-09-10 正式版，13门=27.5分）**：微积分4.5(周一+周三+周五3-4节)/综合英语2(周四)/AI导论3(周一5-6单周+周四7-8)/习思想3(周一11-12+周四9-10)/国安1(周三11-12)/军理2(周六6-8)/军训2/网球1(周三5-6)/导论1/实用英语写作2(周日5-7)/**无人驾驶2(周二9-11，核心)**/形策08(周六日1-2)/心理2(周二7-8)；核心课已4分2模块（写作+无人驾驶）；美育仍未选→**下学期必修补美育2学分**；详见 `references/xuanke-2026-final.md`
- ⚠️ **模拟→正式选课时间会变**：模拟版与正式版差异大（习思想从"周一7-10单周"变"周一11-12+周四9-10"、写作从周三班换周日班、微积分加周五、形策换班、新增无人驾驶）——**每次用户发新截图就重新核对+更新本skill reference与归档md**，旧数据立即作废，别拿模拟版答问
- "已选课程"页截图 = 唯一权威（含教学班时间地点），跨对话续接时先要用户重发最新截图或读归档md
- 学期未开放的必修（大学物理/化学/工程图学等）：系统"应选必修38.5"≠当前必修19.5，缺口属**未开放课程**，别误判为选课失误，后续学期补

## 选修课数量规则（2026-09 官方通知 + 培养方案口径）

- 每学期上限：通识核心 ≤3 门、通识非核心 ≤1、美育 ≤1、思政选择性必修 ≤1
- **毕业口径（2026级培养方案）**：通识教育课程合计 **12 学分** = 通识核心 **10-12 学分（须从 ≥2 个不同模块修读**，7大模块：经典品鉴/文化传承/当代中国/全球视野/自然科学/生态环境/沟通写作）+ 通识非核心 **0-2 学分**；核心课要跨学期慢慢攒
- **美育类课程 = 公共基础课模块内必修 2 学分**（不是可选的通识非核心！）——被抢/冲突时记入"下学期必修补"
- 大一上建议：美育1 + 通识核心1-2（每学期1-2门，4年凑满核心10-12）
- 美育推荐（南岭）：**绘画造型与设计构成实践（孙晓航）9分**（30人秒抢，周六5-7节与军事理论冲突）> 名著导读（朱震）> 电影艺术（宝怀亮 周四9-11）
- **体育课：统一 周三 5-6 节**（南岭9个班同时间，2026-09 转录确认；⚠️ 此前误记周五已修正），选轻松项目（健美操/飞盘），避开篮球足球；体育老师均无评价

## 数据交付格式（用户要求「与要求一一对应」的审阅表）

用户偏好：**重要数据统计要「与要求一一对应」的审阅表**（学分 vs 培养方案要求、条件 vs 实际值），且**关键成果需归档可跨对话接续**。落地做法：

- 学分/规则类问题 → 输出**对照表**（列：要求项 | 要求值 | 实际情况 | 状态✅🔴⚠️），末尾一句话结论 + 缺口归因（区分"本学期违约" vs "跨学期口子/未开放课程"）
- 产出的 md/xlsx 一律落进 `吉大相关文件\<分类>\`，并在回复里给路径
- 用户说"整理成excel"时 → `openpyxl` 直接生成（表头蓝底 1A56DB 加粗 + freeze_panes='A2' + auto_filter + 列宽自适应），一份多 sheet（明细 + 分类汇总）
- 用户发来「模板」xlsx 要求套用 → **先 `load_workbook` 读模板的表头行确认字段顺序**，再按模板字段重新生成，别自创列名

## 课表转换（教务导出 xlsx → 模板/第三方 App 格式）

教务导出的"我的课表.xlsx"是**合并单元格网格**（A9=第1节-第2节…A39=第11-12节 6行一组，C-I=周一~周日），单元格内是**多段换行文本**，每段形如：

```
af26931004-微积分BⅠ[30]
3-14周,星期1,第3节-第4节南岭-(一)-223
```

转换步骤：
1. 全量 dump 非空单元格 + `merged_cells.ranges`（别只看前30行，末几节在第33-44行）
2. 用正则 `^(af|ts)\w+-(.+?)(\(.*?\))?\[(.+?)\]$` 提课程名，`(\d+(?:-\d+)?)周` 提周次段，`星期(\d)` 提星期，`第(\d+)节-第(\d+)节` 提节次，剩余尾部为地点
3. **同一课程同一星期同节次的多个周次段必须合并**（如同一门课 5-7周/8周/9周/10-11周 → `5-11`），线上/线下地点用 ` / ` 合并
4. 模板字段示例（用户微信发的课表模板）：`课程名称|星期|开始节数|结束节数|老师|地点|周数`，星期用**数字**（1=周一）
5. 生成时做**冲突自检**：按 (星期, 节) 展开比对，重复即冲突
6. 时间未定的课（如"上课时间暂未确定"栏的导论/军训）**不塞进模板**，另行说明

## 发布前隐私门禁（2026-09-21 新增，强制）

技能包要发到虾评/GitHub（公开），**推送前必须过隐私审查**。用户明确要求「保护我自己隐私」。

**三类必须清零**（脚本 `D:\Hermes文件库\final_privacy_gate.py`，会打印「✅可以发布/❌禁止发布」）：
1. **本人姓名**（`王子涵`）——写进话术/笔记的正文里极易漏
2. **本机绝对路径**（`D:\Hermes文件库\...`、`C:\Users\王子涵\...`）——"来源: xxx"行最常见，泄露目录结构+用户名
3. **本人 GitHub 身份**（`StellarPython`）

**可保留**（不是隐私）：
- 学校官方信息：各学院办公电话/监督邮箱 `@jlu.edu.cn`、办公地址、QQ 群号 → **政策原文，删了知识库就废**
- 他人主动公开的联系方式（攻略作者自留微信、车队官方微信 yooberor）→ 可留，但批量出现时考虑脱敏

**标准流程**：
1. `final_privacy_gate.py` 扫描 → 有命中先 `clean_paths_in_repo.py` 清理（正则替换本机路径为相对/泛化形式）
2. 新增个人向内容（如联系话术）要走 `merge_jlu_content.py` 式脱敏：
   - 姓名 → 「我（新生本人）」泛化
   - 先 `re.subn(r'<资料库根目录>\\[^`\s\)]*?\(([^)]+)\)', r'\1')` 保留括号内文件名，再泛指剩余路径
   - ⚠️ **别在文档里写真实盘符路径当示例**——本行曾写作 `D:\Hermes文件库\...` 导致门禁自扫命中（2026-09-30 实测），改用占位符
3. 复扫到「✅ 可以发布」才推送
4. 推送后**再扫一次打包目录**（v5 源目录），两处都要干净

⚠️ 正则替换串含 `\` 时**必须用 `lambda m: rep`**，直接传 `re.subn(rep, t)` 会报 `bad escape`。

## 发布脚本（校园网可用）

### 🔴 v1.7.0 实测的三个致命坑（2026-09-30，发布前必读）

**坑 1：SKILL.md 有两个版本，别发错**

| 版本 | 路径 | name | 视角 | 能否发布 |
|------|------|------|------|----------|
| **技能库版** | `skills\research\jlu-knowledge-ops\SKILL.md` | `jlu-knowledge-ops` | **你的运维手册**（含"用户/我"、本机路径、发布流程） | ❌ 本地自用 |
| **对外版** | `_gh_jlu_repo\SKILL.md` | `jlu-baixiaosheng` | 知识库使用者视角 | ✅ **只能发这个** |

**直接复制技能库版到 v5 源 = 发布事故**。正确做法：**用 `_gh_jlu_repo\SKILL.md`（线上原版）打底**，
只追加新 reference 索引行 + 新高频问答 + 版本号（`version:` / `updated_at:` / description 触发词）。

**坑 2：新 reference 必带隐私，先脱敏再合并**

技能库 `references/*.md` 是本地写的，**含姓名和本机路径**。v1.7.0 实测 10 个文件里 7 处命中
（`xuanke-2026-final.md` 有姓名；`jiaotong-fenliu-2025.md`/`jijia-robomaster.md`/`jisu-fsae.md`/`daily-report-ops.md` 有路径）。

脱敏正则（**保留括号内文件名 → 再泛指路径 → 姓名泛化**）：
```python
RULES = [
    (re.compile(r'D:\\Hermes文件库\\[^`\s\)]*?\(([^)]+)\)'), lambda m: m.group(1)),
    (re.compile(r'C:\\Users\\王子涵[^\s`\)]*'),            lambda m: '<用户目录>'),
    (re.compile(r'D:\\Hermes文件库\\[^\s`\)]*'),           lambda m: '<本地资料库>'),
    (re.compile(r'王子涵'),                                lambda m: '我（新生本人）'),
]
```
- ⚠️ 替换串含 `\` 必须用 `lambda m: rep`（直接传会报 `bad escape`）
- ⚠️ **合并后**跑 `final_privacy_gate.py` 复扫，到「✅ 可以发布」才推
- ⚠️ **SKILL.md 自身也会命中**——讲脱敏方法的那行示例代码含 `D:\Hermes文件库\` 正则，需改成 `<资料库根目录>`

**坑 3：虾评 API key 多处存的是截断残废形态**

**坑 4：`final_privacy_gate.py` 扫的不是 v5 源（2026-10-18 实测，白扫一场）**
脚本里 `REPO = r'...\_gh_jlu_repo'` 是硬编码的，**它只扫那个旧目录**。你改完 v5 源直接跑它，
得到「✅ 可以发布」——但扫的是上次同步过去的旧内容，等于没扫。
**正确顺序**：`v5 → _gh_jlu_repo`（`os.walk` 复制全部文件）→ 再跑门禁 → 再推。
改动门禁脚本前先 `grep REPO` 确认它指向哪。

**坑 5：同步方向别搞反——v5 才是权威**
v5 里的 reference 是**已脱敏版**（`<本地资料库>` / `<用户目录>` 占位符）；技能库 `references/` 里那些
**含本机绝对路径和真实 IP/MAC**（`49.140.194.x`、`EC-1A-C3-...`），是本地自用该留的形态。
所以：
- 判「哪边新」不能只看 mtime 和字节数——本会话 4 个文件技能库更大，但差异**只是路径变回本机形态**，不是新知识
- 真有新内容（如 `campus-network-mac.md` 的 DRCOM 章节）→ **只取新章节**追加到 v5 版，再跑脱敏正则，别整文件覆盖
- 比对方法：`difflib.unified_diff(v5, skill)`，只看到路径/姓名/IP 差异 = 无新信息，跳过

- ❌ `.sh` 里 `-H "Authorization: Bearer sk_PqV...m6s7"` = **19 字符残废 key**（终端显示省略被抄进文件）
- ✅ **真 key（40 字符）在** `hermes-backup-*\skills\software-development\skill-packaging-publishing\scripts\publish_xiaping.py` 第 8 行
- 排查法：全盘 `Select-String 'sk_PqV[A-Za-z0-9]+'` 比长度——**19 字符的全是残废，40 字符的才是真 key**

### 发布顺序（v1.7.0 走通的完整链路）
1. 合并+脱敏新 reference 到 v5 源 → 用 `_gh_jlu_repo\SKILL.md` 打底重写 SKILL.md
2. `final_privacy_gate.py` 复扫 → 「✅ 可以发布」
3. **GitHub**：`push_v170.py`（Contents API）→ **读回 GET 验证 `version` + 关键词**（不能只信 PUT 200）
4. **虾评**：urllib 手拼 multipart POST `/api/upload` → 读回 `GET /api/skills/{id}` 验证
   ## 发布脚本（校园网可用）

   - **GitHub**：`D:\Hermes文件库\push_v170.py`（改 FILES/MSG/版本即复用）→ 走 Contents API（`api.github.com` 直连可达），**不用 git push**（github.com 不通 + ghproxy 凭据键不匹配）
   - **虾评**：`D:\Hermes文件库\publish_v170.py`（改 ZIP/CHANGELOG）→ `POST https://xiaping.coze.com/api/upload`，multipart，成功返回 `version` 递增
   - **验证**：`verify_v170.py`（GitHub，读回 SKILL.md 版本 + references 清单）+ `verify_xiaping.py`（虾评，读回线上最新版）

   ### ⚠️ 发布三坑（2026-09-30 v1.7.0 实战）

   **坑 1：别直接发技能库的 SKILL.md**
   技能库 `jlu-knowledge-ops/SKILL.md` 的 `name` 是 `jlu-knowledge-ops`、内容是你的**运维手册**（"用户是/我" 视角）。
   线上技能是 `jlu-baixiaosheng`、**对外知识库**视角。直接复制会毁掉对外定位。
   **正确做法**：拿线上原版打底（`_gh_jlu_repo\SKILL.md` 是 v1.6.3 副本），只**追加**新 reference 索引行 + 版本号。

   **坑 2：API key 在 publish_vXXX.sh 里是截断的**
   `publish_v164.sh` 等 .sh 里写的是 `sk_PqV...m6s7`（**19 字符，终端显示省略形态**），拿去用会 401。
   **真 key（40 字符）在 `publish_skill.py`** 第 8 行常量里：`sk_PqVP4b8so9QEOSji-Zz0KaqlJDS6m6s7`
   → 写发布脚本时**从 publish_skill.py 取**，不要从 .sh 抄。

   **坑 3：新 reference 带隐私，必须先脱敏**
   技能库 reference 里常含本人姓名/本机绝对路径。发布前跑 `merge` 脚本做两步脱敏：
   1. `D:\\Hermes文件库\\xxx\\(yyy)` → 保留 `(yyy)`（括号内是文件名，有信息量）
   2. 剩余 `D:\\Hermes文件库\\...` → `<本地资料库>`；`C:\\Users\\<用户>` → `<用户目录>`；姓名 → `我（新生本人）`
   ⚠️ **正则替换串含 `\\` 时必须用 `lambda m: rep`**（直接传字符串会 `bad escape`）。
   ⚠️ SKILL.md 正文里若**引用了本机路径的示例**（如隐私门禁章节的正则示例），也要一起泛化。

   **标准发布流程（v5 源 → 双平台）**：
   ```
   1. 扫描隐私 → 2. 脱敏合并新 reference（含 SKILL.md 用线上版打底）
   3. final_privacy_gate.py 复扫到「✅ 可以发布」
   4. push_vXXX.py → GitHub（读回验版本）
   5. publish_vXXX.py → 虾评（读回验版本，注意虾评版本号是 1.1.x 独立序列）
   6. 清理临时脚本，保留 push/publish/verify 三件套
   ```

## 坑

- ⚠️ **别用 `python`/`python3` 命令**：本机 `python` 只弹出 Microsoft Store 提示（exit 9009），且**裸 `& <exe>` 会被 terminal 当后台运算符拒绝**。正确写法 = `$env:PYTHONUTF8=1; C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe <脚本绝对路径>`
- **选课截图转录**（用户发多张截图时）：①**文件名不要猜**
- **「哪些专业转专业要考 X 科目」类问题 → 走 `references/zhuanzhuanye-quanshu-saomiao.md`**（按页切块只读含「考核方式/笔试/考试科目」的页做全表 + 2026 全表 + 时效核实动作）。要点：**全校只有人工智能学院考 C 语言**；计算机/软件笔试只是《微积分AI》不考 C（最易误判）；用户问「考 C 的专业」多是把**课程要求**和**笔试科目**混了，先点明
- **「有没有更新的政策文件 / 信息时效核实」类问题** → 同 reference 第三节：43 个细则链接并发探测看最后修改年份（2026-10-23 实测 41 个 200 仍是 2026 版、2 个 404）＋ jwc 的 `/info/1050/<id>.htm` 是正文路径（`/tzgg.htm` 全 404）＋ **看到「转专业公示」先读正文分类**：101 人那份是特殊类型（优势专长/唐敖庆/退役复学），不是集中考核通道。答法=先给结论「无更新，等 12 月中下旬」，别铺扫描过程
- **转专业有多条通道，别只盯着车辆工程**：每个学院各自出细则，条件差异极大（车辆 GPA≥3.0；计算机 **GPA前30%**+微积分AI；细则全在同一个"各学院实施细则汇总.pdf"里，按学院名逐页搜即可）。**策略=先抓共同战场保底，再按绩点排名分流主攻**：微积分 + GPA 是各通道共用指标，大一先冲 GPA+零挂科，大一下按绩点决定主攻方向，本院分流（汽车运用工程，绩点≥3.3）是最末保底。用户提"转X院"时，先查该院细则的**硬性门票**（尤其"高考选科/首考是否允许补考"这类一票否决项），别只讲考核方式。**用户问"某几个专业怎么样"时走 4 维套路（门槛/考核/培养方案匹配度/校区+降级成本），出口必须是可执行的志愿排序**，做法见 `references/zhuanzhuanye-beixuan-zhuanye.md`
- ⚡ **全库 PDF/docx/xlsx 都已提取过** → 答吉大问题先 read_file `_extracted\<分类>_<原名>.txt`，别重新跑 fitz/openpyxl。唯一权威源 = `转专业文件_吉林大学各学院2026年本科生集中考核转专业工作实施细则汇总 (1).pdf.txt`（一文件含全部学院细则，按学院名 search 行号再 read offset）
- ⚠️ **`.doc`（老二进制 Word）read_file 读不了**，会报 `Cannot read binary file`。取正文用 Word COM：`$w=New-Object -ComObject Word.Application; $w.Visible=$false; $doc=$w.Documents.Open($path,[ref]$false,[ref]$true); $t=$doc.Content.Text; $doc.Close([ref]$false); $w.Quit()`（只读打开，改 `$true`→`$false` 即为可写）
- **"GPA排名前X%"要换算成可执行名次**：交运类253人 → 前30% ≈ 前76名；用户需要这种具象数字才好判断难度，别只丢百分比
- **"转专业后要补多少课/落下多少"类问题** → 走三笔账框架（门槛账→学分账→补课账），别只算补课忽略资格风险；做法与数字见 `references/zhuanzhuanye-xuefen-buyu.md`
- **选课截图转录**（用户发多张截图时）：①**文件名不要猜**——先 `Get-ChildItem images -Filter "upload_*"` 列实际文件名（本会话猜错两次：215905 vs 215906 前缀）②**星期几/节次必须逐字段核对**——曾把习思想的"星期一"误读为"星期日"、体育"周三"误读为"周五"，被用户纠正；转录用 qwen-vl-max 脚本逐张提问，输出要求"每行一条竖线分隔字段" ③"已选课程"页可能只是一部分，用户说"之前截图里有"时**重新识别全部图片**，别凭记忆（`find_racing.py` 式逐张扫描关键词）
- **培养方案 HTML**（教务系统导出）：div+span 布局**无 table 标签**、数据在 JS 里——去 script/style 后正则提文本，按"要求学分"关键词定位模块树；对照已选课程按模块逐项
- **文件分享/微信网盘类资料**（`mp.weixin.qq.com/s/<id>` 文章）：普通抓取工具常无内容 → urllib + 浏览器 UA + `Accept-Language: zh-CN` 直取，正文在 `<div id="js_content">`；标题在 `<h1 id="activity-name">`。提取后存 `_extracted\` 并归档要点到对应分类目录
- **"我之前的记忆还有吗"类焦虑问题**（用户看到 UI 显示"暂无对话记录"）：先**实测验证**（`Test-Path`/`Get-Item` 关键文件 + 列出记忆条目）再回答，别只说"我有记忆"——用户要的是证据；同时说明「记忆分两层（系统记忆 + D盘文件），都不依赖窗口对话记录」
- **学院官网找政策/公示原文**（jt.jlu.edu.cn 等）：列表页是 JS 动态渲染、站内搜索 `ssjg.jsp` 全 404 → **改用 ID 扫页**：正文规律是 `http://jt.jlu.edu.cn/info/1062/<ID>.htm`，二分/连续扫 ID 区间取 `<title>` 匹配关键词即可定位（本次 6900-7060 扫出 6927细则/6928排名公示/6931拟录取）。**下载附件**：附件链在页面里的 `/system/_content/download.jsp?urltype=news.DownloadAttachUrl&owner=...&wbfileid=...`，带上 `Referer` 头直接 GET 拿二进制（PDF 看 `%PDF`、xlsx 看 `PK`）
- **⚠️ 关键数据一律找官方附件、别靠记忆或二手**：分流名额/排名/绩点全是官网 xlsx/pdf 附件里的，抓下来 fitz+openpyxl 解析即可得到真实"名次→去向"对照表
- ⚠️ **Bing 搜索吉大政策基本无效**（返回百度百科/景点/地图等噪声）→ 直接爬目标学院官网，别浪费时间调搜索词
- **RoboMaster 规则中心（bbs.robomaster.com/wiki/...）取正文与附件**：页面是 Vue 空壳（snapshot 只有目录标题、正文 `<p><br></p>`），别读 DOM，直接打 API：
  1. `POST /developers-server/rest/wiki/info/<wikiId>` body `{}` → `data.treeRoot`（**不是** `childs`/`children`/`nodes`），每节点字段 = `title` + `postsId`。wikiId 在 URL 里（规则中心 = `20204847`）。**必须 POST**——GET 返回 405。
  2. `POST /developers-server/rest/posts/info/<postsId>` body `{}` → `data.fileItems[].{name,src}` + `data.attachments[]`，附件在 OSS（`hz-rm-bbs-web-prod.oss-cn-hangzhou.aliyuncs.com`，直连可下）。
  ⚠️ 下载时 URL 含**空格和中文**，`urllib.request` 会报 `URL can't contain control characters` → 必须 `urllib.parse.quote(url, safe=":/%?&=#[]@!$'()*+,;~-_. ")` 再把残留空格 replace 成 `%20`。文件名 offset 用 `urllib.parse.unquote(...rsplit('/'))` 还原。
  完整节点树（96页/300+附件）与核心12份文件清单见 `references/jijia-robomaster.md`；批量下载脚本 `吉甲大师\dl_rm.py`（重跑自动跳过已存在）。
- **FSC 官网（formulastudent.com.cn）抓文件**：中国汽车工程学会主办的**静态 HTML 站，无反爬**，`urllib` 直取即可（与上面 RM 的 Vue 空壳完全相反）。资料入口 `/documentation.html?doc=1~5`（通用/油车/电车/无人车/巴哈），**附件在详情页 `/news/<id>.html` 里**，CDN 规律 `img.sae-china.org/web/<年>/<月>/<名>.pdf`。⚠️ **必须两阶段**（爬清单落 JSON → 读 JSON 并行下）：单体脚本会在重跑时重爬全站详情页，600s 超时只下到 2 个文件。完整配方+坑见 `references/fsc-official-site.md`。**可直接复用的两阶段下载器模板**：`scripts/site_batch_download.py`（`scrape` 阶段爬清单落 JSON → `download` 阶段并行增量下，已内置 enc 补码/GBK print/魔数校验三道保险；改编只需换 BASE/CATS/两条正则）
- ⚠️ **urllib 不自动 percent-encode 含中文/空格的 URL**：报 `UnicodeEncodeError: 'ascii' codec...` 或 `InvalidURL ... control characters`。修复 = `urlsplit` 后对 path/query 分别 `quote`（path `safe="/%"`、query `safe="=&%"`），**safe 里绝不能留空格**（留了等于没 quote，仍报 `found at least ' '`），或 quote 完再 `.replace(" ","%20")`。RM 附件下载同样适用（见上条）
- ⚠️ **Windows 终端 GBK，下载日志 print 中文文件名会崩** → `print(line.encode("ascii","replace").decode())`，真实文件名以落盘为准；别为终端显示折腾
- ⚠️ **URL 绝不能凭 ID 规律推断**：本会话第一次猜吉大新闻站/学院站 URL（编 `cnjiwang/202609/1449598.html` 之类）两轮全废——要么 404，要么返 200 的**空壳页（`<title>搜索</title>`，正文 0-7 字）**。**只能用搜索结果 DOM 里的真实 href**（`#b_results a[href^="http"]`）。同理吉大新闻中心/汽车学院官网正文是 JS 渲染，curl 只得导航，但 `<title>` 是服务端渲染的、常含核心事实
- **收集下载必验魔数**：错误页也返回 200，下完断言 `open(p,"rb").read(4)==b"%PDF"` / `read(2)==b"PK"`。FSC 31 份全过 0 坏文件。抽正文用 `pypdf`，⚠️ 封面页因字体嵌入抽出来是乱码，**正文页正常**，别误判文件损坏
- ⚠️ **B站空间投稿列表接口需 wbi 签名**：`/x/space/wbi/arc/search` 未登录返 `-403 访问权限不足`，裸 `/x/space/arc/search` 返 412 → **改走浏览器**。但 `/x/web-interface/view?bvid=` 可用（拿 owner/staff/pubdate），且**视频页底部会列出全部关联账号**（本次靠它挖出吉大 5 支车队）
- ⚠️ **微信公众号无公开 API**：`mp.weixin.qq.com` 链接需转发获得且带时效签名，搜狗微信搜索（唯一按号检索入口）已跳 antispider。**别承诺"去公众号扒"**，直接说明限制并给替代渠道（B站/学院官网/微博/车队公开微信）
- ⚠️ **PS 重定向 `>` 抓 Python 输出 = UTF-16 毁中文**（本次实测：`python3.14 -c "..." > "$env:TEMP\x.txt"` 写出的文件读回全是 `\u0000` 间隔的豆腐块）。要落盘中转**一律用 Python 自己 `open(...,'w',encoding='utf-8').write()`**，别经过 PowerShell 重定向；抽取脚本见 `吉甲大师\extract_rm.py`、`吉大方程式\extract_rm.py`
- `import urllib.parse` **不会**自动带上 `urllib.request` → 必须显式 `import urllib.request`，否则 `module 'urllib' has no attribute 'request'`
- ⚠️ 终端工具把 `&` 开头当后台运算符拒绝执行 → 调 Python 用**裸路径**（`C:\...\python3.14.exe script.py`），不要用 `& $py script.py`
- **PS 5.1 抓网页中文乱码**（UTF-8 被当 GBK 显示）属显示层问题，不影响 `Out-File -Encoding UTF8` 落盘；要判断内容请用 Python 解码或 `Get-Content -Raw -Encoding UTF8` 读回
- **文件整理归档标准动作**（用户说"把这个文件夹分类放好"）：①先 `os.walk` dump 现状（根目录散落文件 vs 已有子目录）②按主题归类移入子目录，**保留 `_extracted` 提取层不动**（脚本依赖）③生成 `文件清单.xlsx`（sheet1 明细：分类目录/文件名/类型/大小/修改时间；sheet2 分类汇总：文件数/总大小）④**移动后同步更新记忆指针**（路径一变，旧记忆就失效）
- **「理解归档后把文件夹删掉」型任务**（用户 2026-10-18：`最近新得到的一些东西` 161 文件）——**别按文件名判重**：这批 161 个里 130 个在归档区已有**完全相同副本**（同学/群里转来的多是旧资料再拷一遍）。标准动作：
  1. `os.walk` 全量 dump 后**先按 md5 去重**，只看文件名会把「同名不同版本」误判成已有
  2. 用 `scripts/archive_by_hash.py`（改 SRC/DST/MAP/DROP 即复用）：同名同 hash 跳过 → 同名不同 hash 落 `__新` 后缀 → 其余按目录映射复制
  3. 无法按扩展名读的**先探身份再决定**：`.doc` 走 Word COM 取正文；`.apk`/`.apk.1` 用 `System.IO.Compression.ZipFile` 读 `assets/license.html`（本次靠它认出是「掌上吉大」HandSchool，非恶意）；手机**长截图**（523×19577 这类）必须切成 3000 高的小块再 OCR，整张喂视觉 API 会 400
  4. **删源目录前跑 `--verify`**：覆盖式扫描「归档区里有没有同 hash 文件」，白名单（判定丢弃）外的文件必须全部命中才 `rmtree`
  5. 归档产出物不只是搬文件：真数据（如 2026 转专业流动数据图 → `转专业文件\2026流动数据\2026转专业数据要点.md`、讲座语音转写 → `就业\本科生就业经验分享_讲座纪要.md`）要**提炼成 md 落盘**，同时把结论追加进 `记忆外置库\详细知识\jlu_major_transfer.md`，否则下次还得重读原图
  6. 新建的分类目录（`就业\`、`公共课复习资料\`）配一份 `README.md` 说明来源与时效（多数公共课资料是 2017-2019 年的，别当今年考纲）
- **「整理整个文件夹」型任务**（用户 2026-10-18：13GB/39321 文件的 `Hermes文件库`）——整理前**先探再动**，顺序不能反：
  1. **先量体积**（`Get-ChildItem -Recurse | Measure-Object Length -Sum` 按顶层目录分组排序），先砍最大的再谈结构。本次 1.15GB 里的 70% 是四处垃圾：安装包 / 已解压过的 rar / 与活跃技能同源的副本 / 日报孤儿配图
  2. **孤儿资源靠引用扫描判，不靠文件名猜**：`assets/` 里的图要从所有 `.html/.txt/.md` 里正则抓 `assets/(文件名)` 建引用集，差集即孤儿（本次 4056 张里 2078 张没人引用、544MB）。⚠️ 正则写成 `[A-Za-z0-9_\-\.]+`，`[\w.-]` 在部分 PowerShel 环境下匹配不稳定
  3. **移动目录前先 grep 写死的绝对路径**：`Select-String -Path *.py,*.ps1,*.bat -Pattern 'Hermes文件库\' -SimpleMatch -List`。本次命中的是日报 pipeline 的 3 处 + push_wechat 2 处 + 账单脚本 2 处
  4. **改完定时任务再改脚本**：`Get-ScheduledTask` 的 `Actions[0].Arguments` 存绝对路径，不改就静默不跑
  5. **移动过程中 cwd 可能锁住目标目录**：`shutil.move` 报 `WinError 32` 先 `Set-Location` 到别处再重跑；中断后重跑脚本必须幂等（目标存在就跳过）
  6. **根目录只留分组 + 一份 `00_文件库索引.md`**，说明每组放什么、每个子目录管什么——用户下次找东西不用问
- **openpyxl 不支持 `wb[new] = wb[old]`** 重命名 sheet → 用 `create_sheet` + 逐单元格复制 + `del wb[old]`
- PowerShell 内联 python 带中文路径/引号必炸 → 写 `.py`/`.sh` 文件执行（全路径 `C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`）
- 系统时间可能漂移：日期类问题先 `curl -sI api.github.com` 的 Date 头对时（校准流程见 windows-maintenance）
- 选课/日程类问题：用户在乎"空闲连成假期"（凑周五空），选课时优先周五无课的教学班
- memory replace 的 old_text 用**单反斜杠**（传 `\\` 会匹配失败）；文档路径变更后记得同步记忆指针
