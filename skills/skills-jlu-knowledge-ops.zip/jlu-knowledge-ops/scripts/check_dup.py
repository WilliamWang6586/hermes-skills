# -*- coding: utf-8 -*-
"""党内文书长稿自检：重复内容检测 + 字数/页数换算。

用法：改稿后 `python3.14 check_dup.py`（Windows 需先 $env:PYTHONUTF8=1）。
放在文稿同目录，改 SRC 即可复用。
"""
import re
from collections import defaultdict

SRC = r"D:\Hermes文件库\入党申请书\入党申请书_王子涵.md"
WIN = 8          # 判定重复的片段长度（中文 8 字≈一个短句）
# 首尾呼应 / 格式强制要求，重复是加分项，不算缺陷
WHITELIST = ("申请加入中国共产党", "向党组织提出申请", "此致", "敬礼")
# 必要的复现：身份信息、书名、政策条款。按段落下标排除（从 0 计，跳过标题行后）
IGNORE_PAIRS = set()

paras = []
for ln in open(SRC, encoding="utf-8").read().splitlines():
    s = ln.strip()
    if not s or s.startswith((">", "#")) or set(s) <= set("-|: "):
        continue          # 跳过元信息/小标题/分隔线，不计入正文
    paras.append(re.sub(r"[^\u4e00-\u9fffA-Za-z0-9]", "", s))

seen = defaultdict(set)
for i, p in enumerate(paras):
    for j in range(len(p) - WIN + 1):
        g = p[j:j + WIN]
        if any(w in g for w in WHITELIST):
            continue
        seen[g].add(i)

merged = []
for g, ps in sorted({g: p for g, p in seen.items() if len(p) > 1}.items(),
                    key=lambda x: -len(x[1])):
    if any(g in m[0] for m in merged):        # 只报最长片段，避免一处分报十个
        continue
    if tuple(sorted(ps)) in IGNORE_PAIRS:
        continue
    merged.append((g, sorted(ps)))

if merged:
    print(f"⚠️ 发现 {len(merged)} 处重复片段：")
    for g, ps in merged:
        print(f"  段落#{ps} → 「{g}」")
else:
    print("✅ 未发现成段重复内容（≥8字片段，已排除首尾呼应/身份复述）")

tot = sum(len(p) for p in paras)
print(f"\n正文 {tot} 字符（不含小标题）| 400格/页 → {tot/400:.2f} 页 | 300格/页 → {tot/300:.2f} 页")
assert tot > 3000, "字数异常偏少"
