# -*- coding: utf-8 -*-
"""按内容哈希把「一堆新文件」归档进既有分类目录, 校验后删源目录。

用法(改顶部三个常量即可复用):
  python archive_by_hash.py            # 1) 复制归档阶段
  python archive_by_hash.py --verify   # 2) 校验+删除源目录

设计要点(踩过的坑都在这里):
  - 比对用 md5 而不是文件名: 这批资料 130/161 个文件在归档区已有完全相同副本,
    只看文件名会把「同名但旧版本」当成已有而丢内容。
  - 冲突: 同名同 hash -> 跳过; 同名不同 hash -> 落盘加 __新 后缀, 绝不覆盖。
  - DROP 白名单显式列出「判定丢弃」的文件, 校验阶段只对非白名单文件要求有副本,
    这样删源目录是有证据的, 不是凭记忆。
  - 复核用覆盖式扫描(不是单向查找): 同时抓「文件名对但内容不同」和「同内容不同名」两类。
"""
import hashlib
import os
import shutil
import sys

SRC = r"<源目录>"
DST = r"<归档根目录>"

# 文件名 -> 目标子目录(相对 DST); 未列出的走 DEFAULT_DIR
MAP = {}
DEFAULT_DIR = ""
# 明确丢弃(与用户无关/重复安装包/临时图), 不参与归档也不参与校验
DROP = set()

VERIFY = "--verify" in sys.argv


def md5(path):
    m = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            m.update(chunk)
    return m.hexdigest()


def place(src_path, dst_dir_rel, log):
    base = os.path.basename(src_path)
    dst_dir = os.path.join(DST, dst_dir_rel)
    os.makedirs(dst_dir, exist_ok=True)
    dst = os.path.join(dst_dir, base)
    if os.path.exists(dst):
        if md5(dst) == md5(src_path):
            log.append(("DUP", base, dst_dir_rel))
            return
        stem, ext = os.path.splitext(base)
        dst = os.path.join(dst_dir, stem + "__新" + ext)
        log.append(("CONFLICT->__新", base, dst_dir_rel))
    else:
        log.append(("COPY", base, dst_dir_rel))
    shutil.copy2(src_path, dst)


def walk_files(root):
    for r, _, fs in os.walk(root):
        for f in fs:
            yield os.path.join(r, f)


def do_archive():
    log = []
    for p in walk_files(SRC):
        name = os.path.basename(p)
        if name in DROP:
            log.append(("DROP", name, ""))
            continue
        place(p, MAP.get(name, DEFAULT_DIR), log)
    for a, b, c in log:
        print("{}\t{}\t{}".format(a, c, b))
    print("TOTAL", len(log))


def do_verify():
    dst_hash = {}
    for p in walk_files(DST):
        dst_hash.setdefault(md5(p), []).append(os.path.relpath(p, DST))
    missing = [os.path.relpath(p, SRC) for p in walk_files(SRC)
               if os.path.basename(p) not in DROP and md5(p) not in dst_hash]
    if missing:
        print("!! 仍有未归档文件, 中止删除:")
        for m in missing:
            print("  ", m)
        raise SystemExit(1)
    print("校验通过: 除 DROP 白名单外源文件全部有归档副本")
    shutil.rmtree(SRC)
    print("已删除:", SRC)


if VERIFY:
    do_verify()
else:
    do_archive()
