# -*- coding: utf-8 -*-
"""党内文书 md → Word 打印对照稿（用户照着抄）。

用法：`$env:PYTHONUTF8=1; python3.14 gen_docx.py`
依赖：python-docx（本机 Python 3.14 已装）。
坑：目标 docx 若正被 Word 打开会 PermissionError [Errno 13] → 换输出名（_v2）或先关 Word，
    别去 kill WINWORD（用户可能正开着别的正经文档）。
"""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

MD = r"D:\Hermes文件库\入党申请书\入党申请书_王子涵.md"
DOCX = r"D:\Hermes文件库\入党申请书\入党申请书_王子涵_对照稿.docx"

doc = Document()
sec = doc.sections[0]
sec.top_margin = sec.bottom_margin = Cm(2.2)
sec.left_margin = sec.right_margin = Cm(2.6)

st = doc.styles["Normal"]
st.font.name = "宋体"
st.font.size = Pt(12)
st._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")   # 中文字体必须单独设 eastAsia
st.paragraph_format.line_spacing = 1.5
st.paragraph_format.space_after = Pt(0)


def add(text, size=12, bold=False, align=None, indent=True):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.name = "宋体"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    if align is not None:
        p.alignment = align
    if indent:
        p.paragraph_format.first_line_indent = Pt(size * 2)   # 首行缩进 2 字符
    return p


body_chars = 0
for ln in open(MD, encoding="utf-8").read().splitlines():
    s = ln.strip()
    if not s or set(s) <= set("-|: "):
        continue
    if s.startswith(">"):                      # 交付备注 → 灰色小字居中，抄写时忽略
        add(s.lstrip("> ").strip(), size=10, align=WD_ALIGN_PARAGRAPH.CENTER, indent=False)
    elif s.startswith("## "):
        add(s[3:], size=14, bold=True, indent=False)
    elif s.startswith("# "):
        add(s[2:], size=18, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, indent=False)
    else:
        add(s, indent=not s.startswith(("此致", "敬礼", "申请入党人", "2026年9月")))
        body_chars += len(s)

doc.save(DOCX)
print(f"正文字符（含标点，不含小标题）：{body_chars}")
for cells in (300, 400):
    print(f"  {cells}格/页 → {body_chars/cells:.2f} 页")
print(f"已生成：{DOCX}")
