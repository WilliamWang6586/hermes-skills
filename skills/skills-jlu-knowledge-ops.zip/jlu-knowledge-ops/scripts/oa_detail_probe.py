# -*- coding: utf-8 -*-
"""吉大 OA 通知详情批量探针：给定 (名称, id, channelId) 列表，抽正文里含报名/截止/时间/地点等关键词的行。

用途：「总结近一个月重要 OA 信息」时，清单（oa_weekly.py 输出）只有标题，deadline 和年级口径
只在详情页正文里。改 TARGETS 即可复用。

用法：
    cmd.exe /c "C:\\Users\\<user>\\AppData\\Local\\Python\\bin\\python.exe oa_detail_probe.py"
（裸 python 在本机是 Microsoft Store 别名，必失败）

id 来源：清单 md 里链接的 `id=(\\d+)&channelId=(\\d+)`。
"""
import urllib.request, re, html as h, sys

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"}
URL = "https://oa.jlu.edu.cn/defaultroot/PortalInformation!getInformation.action?id={id}&channelId={ch}"
KEY = ["报名", "截止", "时间", "地点", "对象", "要求", "条件", "名额", "费用", "联系"]

# (显示名, 通知id, channelId) —— 只挑可能要动的那 20-25 条，别全量
TARGETS = [
    ("示例：2026级学籍信息自查", "71417857", "179577"),
]


def text_lines(t):
    """详情页正文容器不固定（TRS 编辑器），从 id=content / TRS_Editor 起截，<br>/<p> 转行。"""
    m = re.search(r'(?:id="?content|class="?content|id="?zoom|class="?TRS_Editor)', t)
    body = t[m.start():] if m else t
    body = re.sub(r'<(script|style)[^>]*>.*?</\1>', ' ', body, flags=re.S | re.I)
    body = re.sub(r'<br\s*/?>|</p>|</div>|</td>|</tr>', '\n', body, flags=re.I)
    body = h.unescape(re.sub(r'<[^>]+>', ' ', body))
    out = (re.sub(r'\s+', ' ', l).strip() for l in body.split('\n'))
    return [l for l in out if l]


def probe(name, nid, ch, limit=26):
    url = URL.format(id=nid, ch=ch)
    try:
        t = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=20).read().decode("utf-8", "ignore")
    except Exception as e:
        print(f"### {name} [{nid}] 抓取失败 {e}\n")
        return []
    keep = [l for l in text_lines(t) if len(l) > 4 and any(k in l for k in KEY)]
    print(f"### {name} [{nid}]\n{url}")
    for l in keep[:limit]:
        print("  " + l[:400])
    print()
    return keep


def main():
    for name, nid, ch in TARGETS:
        probe(name, nid, ch)
    return 0


def demo():
    """自检：正文抽取能跨过 <p>/<br> 切行，且过滤短行。"""
    html = '<div id="content"><p>报名截止：2026年10月31日 16:00</p><br>名额：30<br>ok</div>'
    lines = text_lines(html)
    assert any("报名截止" in l for l in lines), lines
    assert all(len(l) > 2 for l in lines), lines
    print("demo ok")


if __name__ == "__main__":
    if "--demo" in sys.argv:
        demo()
    else:
        sys.exit(main())
