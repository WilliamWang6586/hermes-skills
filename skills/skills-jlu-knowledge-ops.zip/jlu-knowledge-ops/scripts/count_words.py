# -*- coding: utf-8 -*-
"""党内文书正文字数核算：中文字/标点/英文数字分开数，双口径换算页数。

用法：`$env:PYTHONUTF8=1; python3.14 count_words.py`（含中文路径必须写 .py 文件跑，
别用 python3.14 -c "..."，PowerShell 会吞中文字符）。
口径：跳过空行 / `#`标题 / `>`引用 / 纯分隔线 —— markdown 标题与交付备注不算正文。
"""
import re

SRC = r"D:\Hermes文件库\入党申请书\入党申请书_王子涵.md"
# 稿纸规格未确认时两个口径都报：400格=16开20×20；300格=15×20小号
CELLS_PER_PAGE = (300, 400)

lines = open(SRC, encoding="utf-8").read().splitlines()
body = []
for ln in lines:
    s = ln.strip()
    if not s or s.startswith((">", "#")) or set(s) <= set("-|: "):
        continue
    body.append(s)

text = "".join(body)
han = len(re.findall(r"[\u4e00-\u9fff]", text))
punct = len(re.findall(r"[\u3000-\u303f\uff00-\uffef]", text))
other = len(re.findall(r"[A-Za-z0-9]", text))
total = len(text)

print(f"中文字符: {han}")
print(f"中文标点: {punct}")
print(f"字母数字: {other}")
print(f"总字符数(含标点): {total}")
print(f"段落数: {len(body)}")
for cells in CELLS_PER_PAGE:
    print(f"  {cells}格/页 → 需 {total/cells:.2f} 页")

# 自检：格式硬要求——正文必须出现"申请入党"字样，且不得出现被禁措辞
assert han > 2500, "字数异常偏少"
assert "申请加入中国共产党" in text
for bad in ("志愿入党", "希望入党"):
    assert bad not in text, f"出现被禁措辞：{bad}"
print("✅ 自检通过：含'申请入党'表述、无被禁措辞、正文完整")
