# 有线口体检（只读，不改任何配置）
# 用法: powershell -NoProfile -ExecutionPolicy Bypass -File 有线口体检.ps1
# ⚠️ 本脚本必须存为 UTF-8 **带 BOM**，否则 PS5.1 下中文注释乱码报 Unexpected token
#    校验: [System.IO.File]::ReadAllBytes($p)[0..2] 应为 239,187,191
$ErrorActionPreference = 'Continue'
$i = '以太网 3'   # USB Realtek GbE；换机器/换口需改这里

"=== 1. 物理层 ==="
$ad = Get-NetAdapter -Name $i
"链接速度: $($ad.LinkSpeed)   状态: $($ad.MediaConnectionState)"
"MAC: $($ad.MacAddress)"

"`n=== 2. 二层邻居（有真实 MAC = 对端是活的交换机）==="
$n = Get-NetNeighbor -InterfaceAlias $i -AddressFamily IPv4 |
     Where-Object { $_.LinkLayerAddress -and
                    $_.LinkLayerAddress -ne '00-00-00-00-00-00' -and
                    $_.LinkLayerAddress -ne 'FF-FF-FF-FF-FF-FF' }
if ($n) { $n | Select-Object IPAddress,LinkLayerAddress,State | Format-Table -AutoSize }
else { "❌ 无任何真实二层邻居 —— 链路对端无响应" }

"`n=== 3. IP 地址（关键判据）==="
$ip = Get-NetIPAddress -InterfaceAlias $i -AddressFamily IPv4
$ip | Select-Object IPAddress,PrefixOrigin,AddressState | Format-Table -AutoSize

$addr = $ip.IPAddress
if ($addr -like '169.254.*') {
    "❌ 拿到的是 169.254.x.x 自动私有地址 = DHCP 没应答，校园网没通"
    "`n=== 4. 抓一次 DHCP 请求，看有没有回应 ==="
    # ⚠️ 前台直跑 ipconfig /renew 无应答会阻塞 60s+，必须用 Job + Timeout
    $job = Start-Job { ipconfig /renew '以太网 3' }
    if (Wait-Job $job -Timeout 25) {
        Receive-Job $job
    } else {
        "⏱ 25秒内 DHCP 无应答（超时）—— 确认路上没有 DHCP 服务器"
        Stop-Job $job; Remove-Job $job -Force
    }
} else {
    "✅ 拿到校内地址 $addr —— 链路已通！"
    "`n=== 5. 网关连通性 ==="
    $gw = (Get-NetRoute -InterfaceAlias $i -DestinationPrefix '0.0.0.0/0').NextHop
    "网关: $gw"
    # ⚠️ 不加 -S 会走 WiFi 出去并"成功"，造成有线已通的误判
    "ping 网关(指定源): " + (Test-Connection $gw -Source $addr -Count 3 -Quiet)
    "ping DNS 10.10.10.10: " + (Test-Connection 10.10.10.10 -Count 3 -Quiet)
    "`n下一步：打开 dr.com 客户端，用【吉大邮箱账号(去掉@jlu.edu.cn)】登录"
}

"`n=== 6. 全程只读，未修改任何配置 ==="
"如需回滚/改动，先读 references/campus-network-diagnostics.md §七"
