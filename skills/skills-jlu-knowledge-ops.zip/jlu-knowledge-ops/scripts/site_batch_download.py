#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""两阶段官网文件批量下载器（模板）。

用途：抓"静态 HTML 学会/高校站"的资料板块 → 详情页 → 附件，批量下载。
实测来源：FSC 官网 formulastudent.com.cn（2026-09-19，31 份 0 坏文件）。

用法：
  python site_dl.py scrape     # 阶段1：爬清单 → 落 _docs.json
  python site_dl.py download   # 阶段2：读 JSON → 并行增量下

改编到别的站点只需改 BASE / CATS / doc_links 的正则 / pdf_of 的正则。

三个必须保留的坑处理（删掉就会踩）：
  1. enc()            urllib 不自动 percent-encode 中文/空格 URL
  2. safe_print()     Windows 终端 GBK，print 中文文件名会崩
  3. magic check      错误页也返 200，下完必须验 %PDF / PK
"""
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

# ---- 按站点改这三处 ----
BASE = "http://www.formulastudent.com.cn"
CATS = {1: "通用文档", 2: "油车", 3: "电车", 4: "无人车", 5: "巴哈"}
DEST = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloaded")
JSON_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_docs.json")
# ------------------------

ATTACH_RE = re.compile(
    r'href="(https?://[^"]+\.(?:pdf|zip|docx?|xlsx?|rar|7z))"', re.I)
LIST_RE = re.compile(r'href="(/news/\d+\.html)"[^>]*>(.*?)</a>', re.S)


def enc(url):
    """含中文/空格的 URL 转合法 ASCII。

    坑：safe 里**绝不能**留空格 —— 留了等于没 quote，仍报
        InvalidURL: ... control characters (found at least ' ')
    """
    p = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit((
        p.scheme, p.netloc,
        urllib.parse.quote(p.path, safe="/%"),
        urllib.parse.quote(p.query, safe="=&%"),
        ""))


def safe_print(s):
    """Windows 终端 GBK：中文文件名可能让 print 抛 UnicodeEncodeError。"""
    print(str(s).encode("ascii", "replace").decode())


def get(url, timeout=30):
    req = urllib.request.Request(enc(url), headers={
        "User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"})
    return urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8", "ignore")


def doc_links(cat_id, max_pages=8):
    """爬一个分类的所有分页，返回 [(标题, 详情页URL)]，自动去重。"""
    seen, out, page = set(), [], 1
    while page <= max_pages:
        url = f"{BASE}/documentation.html?doc={cat_id}&page={page}"
        try:
            html = get(url)
        except Exception as e:
            safe_print(f"  page {page} ERR {type(e).__name__}")
            break
        new = 0
        for href, raw in LIST_RE.findall(html):
            title = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", raw)).strip()
            key = (href, title)
            if key not in seen:
                seen.add(key)
                out.append((title, BASE + href))
                new += 1
        if new == 0:          # 没有新条目 = 翻到头
            break
        page += 1
        time.sleep(0.3)       # 礼貌间隔
    return out


def attach_of(detail_url):
    """详情页里取第一个附件直链。"""
    try:
        m = ATTACH_RE.findall(get(detail_url))
        return m[0] if m else None
    except Exception:
        return None


def scrape():
    docs = []
    for cid, cname in CATS.items():
        links = doc_links(cid)
        safe_print(f"### {cname}: {len(links)}")
        for title, page in links:
            f = attach_of(page)
            docs.append({"cat": cname, "title": title, "page": page, "file": f})
            safe_print(f"   {'OK' if f else '--'} {title[:70]}")
            time.sleep(0.2)
    with open(JSON_PATH, "w", encoding="utf-8") as fh:
        json.dump(docs, fh, ensure_ascii=False, indent=1)
    safe_print(f"\ntotal {len(docs)}, with file {sum(1 for d in docs if d['file'])}")
    safe_print(f"saved -> {JSON_PATH}")


def verify(path):
    """错误页也返回 200，必须验魔数。"""
    head = open(path, "rb").read(4)
    return head[:4] == b"%PDF" or head[:2] == b"PK"


def fetch(doc):
    if not doc.get("file"):
        return "SKIP (no attach)"
    name = urllib.parse.unquote(doc["file"].rsplit("/", 1)[-1])
    name = re.sub(r'[<>:"/\\|?*]', "_", name)
    path = os.path.join(DEST, name)
    if os.path.exists(path) and os.path.getsize(path) > 2048:
        return f"SKIP {name[:36]}"
    try:
        data = urllib.request.urlopen(
            urllib.request.Request(enc(doc["file"]), headers={"User-Agent": UA}),
            timeout=240).read()
        with open(path, "wb") as fh:
            fh.write(data)
        ok = verify(path)
        return f"{'OK  ' if ok else 'BAD '}{name[:36]} ({len(data)//1024}KB)"
    except Exception as e:
        return f"FAIL {name[:36]}: {type(e).__name__} {e}"


def download(filter_re=None, workers=5):
    os.makedirs(DEST, exist_ok=True)
    with open(JSON_PATH, encoding="utf-8") as fh:
        docs = json.load(fh)
    todo = [d for d in docs if d["file"]]
    if filter_re:
        keep = re.compile(filter_re, re.I)
        todo = [d for d in todo if keep.search(d["title"])]
    safe_print(f"todo {len(todo)} / all {len(docs)}\n")
    results = []
    with ThreadPoolExecutor(workers) as ex:
        for line in ex.map(fetch, todo):
            results.append(line)
            safe_print(line)
    got = [f for f in os.listdir(DEST)
           if os.path.getsize(os.path.join(DEST, f)) > 2048]
    ok = sum(1 for r in results if r.startswith(("OK", "SKIP")))
    safe_print(f"\ngot {len(got)} files, ok {ok}/{len(todo)}")
    assert len(got) >= 1, "nothing downloaded"


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "scrape"
    if cmd == "scrape":
        scrape()
    elif cmd == "download":
        # 第二个参数可选正则，只下标题匹配的（如 '规则|手册|检查表'）
        download(sys.argv[2] if len(sys.argv) > 2 else None)
    else:
        print(__doc__)
