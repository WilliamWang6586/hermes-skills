# 虾评 + GitHub 发布 gotcha（2026-09-08 v1.6.0 实测）

发布「吉林大学百晓生」知识库技能到虾评(skill_id=ff4601bb-28d7-4f45-82aa-f4621ca510a6) + GitHub(StellarPython/JLU-xinshengbaixiaosheng) 时的坑。

## 虾评（https://xiaping.coze.com）
- 版本更新：`POST /api/upload`（multipart，字段 skill_id / changelog / pledge={"agreed":true} / requires_api_key=false / file=@zip）
- ⚠️ **返回的 `version` 是虾评平台自己的版本号**（如 1.1.3），不是我们 SKILL.md 里的版本号——别误判成上传失败。
- ⚠️ **单次上传、勿连环重试**：对虾评密集请求（尤其 upload 失败后重试）会触发风控把 key 临时冻结（401 "Invalid API key"，连读接口也失效）。失败就静置 5-15 分钟再单次重试。
- ⚠️ **用 urllib multipart 上传，别用 curl -L**：curl 跟随重定向会丢 `Authorization` header 导致 401。
- ⚠️ 脚本写 key 勿用终端截断形态（如 `sk_PqV...m6s7`），用完整版否则 401。
- API_KEY 完整版在 `D:\Hermes文件库\publish_v16.py` 内。

## GitHub
- 发布包流程：git clone → 覆盖 SKILL.md/references → commit+push（`git push` 用凭据管理器 gho_ token 自动过）→ 用 token 调 `POST /repos/{owner}/{repo}/releases` 建 Release → `POST uploads.github.com/repos/{owner}/{repo}/releases/{rid}/assets?name=<url编码>` 传 zip。
- ⚠️ **Release asset 文件名含中文必须先 percent-encode**：urllib 请求行是 ascii，直接放「吉林大学百晓生_v6.zip」会 `UnicodeEncodeError`。用 `urllib.parse.quote("中文名.zip")` 构造 `name=` 参数。
- ⚠️ **Release 已存在时报 422 "already_exists"**：别再 POST 新建，改 `GET /releases/tags/<tag>` 取回 id 再 `assets` 上传。
- 取 token：`git credential fill`（stdin 传 `protocol=https\nhost=github.com\n\n`）取 `password=` 行即 gho_ token（scopes=gist,repo,workflow）。
- 网络：VPN 分流不完整时 `github.com` 超时但 `api.github.com` 可达 —— 用 api 直连绕过。

## 出版/打包
- 源目录 `D:\Hermes文件库\吉林大学百晓生v5\`，打包 `build_skill_v6.py`：追加新政策到 `references/*_all.txt`（格式 `===== 来源文件: xxx =====`），升 SKILL.md 版本，`zipfile` 打 zip。
- 参考脚本：`publish_v16.py`（虾评上传）、`gh_release.py`（GitHub release+asset）、`build_skill_v6.py`（本地打包）。
