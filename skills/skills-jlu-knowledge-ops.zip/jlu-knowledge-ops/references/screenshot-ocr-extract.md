# 选课截图逐张 OCR 提取（qwen-vl-max 脚本模式）

用户发多张选课系统截图时，**必须逐张识别**，不要凭第一印象（2026-09 实测：10 张截图第一轮漏翻"赛车运动与文化"，被用户纠正"你自己翻去""你仔细好好看看"）。

## 图片位置
- 桌面直传：`用户消息里的 [Image attached at: ...] 路径`
- Hermes 缓存：`C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\images\`（文件名 `upload_YYYYMMDD_HHMMSS_N.png`，**先 `Get-ChildItem` 列真实文件名**——猜测后缀常错，实测 215905_14 实际是 215906_14）

## 脚本骨架（Python，dashscope qwen-vl-max）
```python
import base64, json, urllib.request, os, io, sys, re
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
# key: 从 ~/.hermes/.env 读 DASHSCOPE_API_KEY
def ask(img_path, prompt):
    img = Image.open(img_path); img = img.convert('RGB')
    tmp = img_path + '.tmp.png'; img.save(tmp, 'PNG')
    b64 = base64.b64encode(open(tmp,'rb').read()).decode(); os.remove(tmp)
    payload = {"model":"qwen-vl-max","messages":[{"role":"user","content":[
        {"type":"image_url","image_url":{"url":f"data:image/png;base64,{b64}"}},
        {"type":"text","text":prompt}]}],"max_tokens":1500}
    req = urllib.request.Request("https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
        data=json.dumps(payload).encode(), headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.load(r)['choices'][0]['message']['content']
```

## 提示词要点（逐张问同一个问题，过滤无关页）
- 课程表页：`列出所有课程中名称含'X'的课程：课程全称、教师、第几周/周几/第几节、地点、容量、学分；没有就只回复"无"`
- 已选课程页：`逐行完整转录每门课程：课程名、教师、时间（周/节/周次）、地点、状态（已选/选考）、是否冲突。不要遗漏`
- 关键字段要**第几周+星期几+第几节**三项齐全（判断占不占周末需要"周六/周日"显式出现，让模型逐行转录别概括）

## 坑
- `re` 忘 import 会 NameError（写脚本先检查）；中文路径正常（Python 处理没问题）
- 识别脚本已实测可用（Hermes 内置 vision_analyze 对该 key 401，绕开直接调 dashscope）
- 每张一次 API 调用，10 张约 5-8 分钟；批量脚本最后只打印命中"无"之外的结果
