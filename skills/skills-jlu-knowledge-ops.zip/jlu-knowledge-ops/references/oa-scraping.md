# 吉大 OA 校内通知抓取细节（oa.jlu.edu.cn）

## 站点结构
- `oxxyda.jlu.edu.cn`：JS 单页站，`GET https://oxxyda.jlu.edu.cn/` 返回 **404**（浏览器也是，因为是 SPA 内路由）。别从这里爬。
- `oa.jlu.edu.cn`：吉林大学电子校务平台，服务端渲染，可爬。首页 5 个频道 channelId = `179577` / `179578` / `179579` / `179580` / `179581`。

## 列表接口
```
https://oa.jlu.edu.cn/defaultroot/PortalInformation!jldxList.action?bs=1
```
- 返回当天全部通知（约 25-27 条/页）。每条含：标题、发布部门、日期（`yyyy-MM-dd` 或 "昨天"/"N 天前"）、详情链接。
- 提取 `(id, 标题)`：
  ```python
  items = re.findall(r'getInformation\.action\?id=(\d+)[^>]*>\s*([^<]{6,90})', html)
  # 去重 by id
  ```
  （标题是 <a> 内文本；部门/日期在 a 之后的文本块里，可用 `re.sub(r"<[^>]+>"," ", tail)` 后取第一段。）

## 详情接口
```
https://oa.jlu.edu.cn/defaultroot/PortalInformation!getInformation.action?id=<NUM>&channelId=179577
```

## 与用户相关 → 关键词过滤
（见 SKILL.md 的用户画像）
- KWS 命中且 EXCLUDE 不命中才算相关。常用 KWS：
  `分级,数学竞赛,四六,英语,外语,选课,辅修,转专业,竞赛,考试,培养方案,保研,推免,奖学金,新生,教务,补考,报名`
- EXCLUDE（噪声）：`政绩观,总结大会,总结会议,学习教育,党委,党总支,党支部,座谈会,观看,展览,研究生,支教,讲座,学术会议,专题`

## 解析坑
- 详情页 `<h1>`/正文抽取常被模板/JS 干扰，关键字段（日期、地点、附件名）可能缺失或被截断。能抽到"标题+正文大意+附件列表"即可，具体时间地点让用户看原文。
- 最终相关度：拿到标题即可给用户"清单 + 链接"，不必每篇都全文抽取（除非用户点名要某篇详情）。

## 已落地
- 脚本：`D:\Hermes文件库\每日科技日报\jlu_notices.py`
  抓 `jldxList` → 过滤 → 写 `jlu_section.txt` + `jlu_section.html`。
  用 Windows Python 跑（`python.exe -u`，需 `PYTHONUTF8=1` 防 GBK 崩）。
- 集成：`daily_pipeline.ps1` 第 3 步，日报生成后跑脚本，把区段前置到摘要 txt + HTML `<body>` 后，再推送。
- 每日触发：Windows 计划任务（"Hermes每日科技日报" / "Hermes每日科技日报推送"）。
