# 吉大百晓生知识库发布配方（虾评 + GitHub）

把 百晓生 知识库（references/*_all.txt 分类文本库）更新并发到两个平台。

## 构建
- 源目录：`D:\Hermes文件库\吉林大学百晓生v5\`（SKILL.md + references/*_all.txt）
- 每个 *_all.txt 是多份原文合并，块分隔符：`===== 来源文件: xxx =====`（上下各一行 =====）
- 追加新内容 = 在文件尾加一个块；改完升 `SKILL.md` 的 `version:` / `updated_at:`
- 打包：Python zipfile 把 v5 目录打成 `D:\Hermes文件库\吉林大学百晓生_v6.zip`（参考 build_skill_v6.py）

## 虾评（xiaping.coze.com）
- 端点：`POST https://xiaping.coze.com/api/upload`
- 凭证：`Authorization: Bearer sk_PqVP4b8so9QEOSji-Zz0KaqlJDS6m6s7`、`skill_id=ff4601bb-28d7-4f45-82aa-f4621ca510a6`
- 必须 **urllib multipart**（不能 curl -L——重定向会丢 Authorization header）；字段：
  skill_id、changelog、pledge=`{"agreed": true}`、requires_api_key=`false`、file=@zip
- ⚠️ **Key 冻结**：短时间密集请求（尤其 upload 失败后连环重试）会触发风控把 key 临时作废。
  上传失败**勿连环重试**，静置 5-15 分钟再单次重试。模板参考 publish_v16.py。
- 成功返回 `{"success":true, data:{id, skill_id, version(平台内部版本号,非我方v6), file_key, ...}}`

## GitHub（StellarPython/JLU-xinshengbaixiaosheng）
- 更新走 git（克隆 D:\Hermes文件库\_gh_jlu_repo，覆盖 SKILL.md/references → commit → push origin main，
  push 用 Windows 凭据管理器自动过，无需显式 token）
- 建 Release + 传 zip 附件：从凭据管理器取 token（`git credential fill`，stdin 传 protocol=https / host=github.com，
  取 password= 开头的 gho_ token）
  - 建/查 release：`POST|GET /repos/{owner}/{repo}/releases[/tags/v1.6.0]`（tag 已存在会 422 already_exists → 改用查）
  - 传资产：`POST https://uploads.github.com/repos/.../releases/{id}/assets?name=<percent-encode>`，
    body=zip 字节，Content-Type: application/zip
  - ⚠️ 中文附件名必须 `urllib.parse.quote()` 否则 `UnicodeEncodeError: ascii can't encode`；
    已规范化后 GitHub 显示为 `_v6.zip`（中文被剥离），属正常

## 验证
- 虾评：看返回 success:true + file_size
- GitHub：`GET https://raw.githubusercontent.com/.../main/SKILL.md` 确认 version 已升

## 版本指针
- 当前最新：v1.6.0（2026-09-08，新增校转专业办法2025/学籍/学位/交通学院细则/汽院推免）
