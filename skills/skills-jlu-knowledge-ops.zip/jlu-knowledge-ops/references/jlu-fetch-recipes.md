# JLU 抓取配方（复用的 Python 片段）

统一 UA 即可（多数站点不拦普通浏览器 UA）：
```python
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"}
```

## 1. 校内通知 OA 列表 + 关键词搜索
```python
import urllib.request, urllib.parse, re, html as h
def get(u): return urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=15).read().decode("utf-8","ignore")

# 全量列表
t = get("https://oa.jlu.edu.cn/defaultroot/PortalInformation!jldxList.action?bs=1")
# 关键词搜索（分类/分级/数学竞赛 等首页可能不显示，必须用 keyword）
t = get("https://oa.jlu.edu.cn/defaultroot/PortalInformation!jldxList.action?bs=1&keyword="+urllib.parse.quote("分级"))

# 提取 id+标题
for m in re.finditer(r'getInformation\.action\?id=(\d+)[^>]*>\s*([^<]{6,90})', t):
    print(m.group(1), h.unescape(m.group(2)).strip())
```
详情页：`https://oa.jlu.edu.cn/defaultroot/PortalInformation!getInformation.action?id=<ID>&channelId=179577`

注意：`jldxList.action?bs=1` 首页只出 5 个频道(179577-179581)；新生相关(分级/数学竞赛/外研社)要靠 `&keyword=` 搜到，id 形如 70102958/70104403/70104113。

## 2. 正文提取（政策/通知）
```python
def extract(t):
    body = (re.search(r'id="vsb_content"[^>]*>(.*?)</div>',t,re.S)
            or re.search(r'class="v_news_content"[^>]*>(.*?)</div>',t,re.S)
            or re.search(r'id="content"[^>]*>(.*?)</div>',t,re.S))
    b = body.group(1) if body else t
    b = re.sub(r"<script.*?</script>","",b,flags=re.S)
    b = re.sub(r"<style.*?</style>","",b,flags=re.S)
    b = re.sub(r"<br\s*/?>","\n",b); b = re.sub(r"</p>","\n",b); b = re.sub(r"<[^>]+>","",b)
    return "\n".join([l.strip() for l in h.unescape(b).splitlines() if l.strip() and len(l.strip())>1])
```
若提取后只有几十~几百字，说明该页是**附件/大表格型**，正文在下载附件里。

## 3. 校内通知→用户相关性过滤（学生事务关键词 + 排除噪声）
```python
KWS = ["分级","数学竞赛","四六","英语","外语","选课","辅修","转专业","竞赛","考试",
       "培养方案","保研","推免","奖学金","新生","教务","补考","报名"]
EXCLUDE = ["政绩观","总结大会","总结会议","学习教育","党委","党总支","党支部",
           "座谈会","观看","展览","研究生","支教","讲座","学术会议","专题"]
rel = [it for it in items if any(k in it["title"] for k in KWS) and not any(x in it["title"] for x in EXCLUDE)]
```
不排除"政绩观/研究生/讲座"会混进学院党建和研究生事务噪声。已封装到
`D:\Hermes文件库\每日科技日报\jlu_notices.py`（每日抓取+过滤，输出 jlu_section.txt/html）。

## 4. 政策文件源（已实测可达性）
- 交通学院细则（直连可抓全文）：`https://jt.jlu.edu.cn/info/1062/6249.htm`(2023级交通运输类分流)、`6012.htm`(学年奖学金2023)、`6010.htm`(净加减分)、`5986.htm`(推免2024细则)
- 汽车工程学院：`https://auto.jlu.edu.cn/info/1566/7783.htm`(2024版培养方案含车辆工程)、`info/1114/8771.htm`(2027推免细则)、培养方案索引 `bkjx/pyfa.htm`、教学通知 `bkjx/jxtz.htm`
- **信息公开网**（学籍办法/学位要求）子页直连常 404 → 需 VPN/浏览器
- 政策文件正文已存 `D:\Hermes文件库\吉林大学相关文件\政策文件\`

## 5. 微信公众号文章 + 图片
```python
# 正文
body = re.search(r'id="js_content"[^>]*>(.*?)</div>\s*<script', t, re.S) or re.search(r'id="js_content"[^>]*>(.*)', t, re.S)
# 图片链接（data-src 优先）
imgs = re.findall(r'(?:data-src|src)=["\'](https?:[^"\']*(?:qpic\.cn|mmbiz\.qpic\.cn)[^"\']+)["\']', body.group(1))
```
图片下载后按 `img_01.jpg` 等命名存到文章标题命名的文件夹；正文存 `正文.md`。

## 6. ima 知识库（ima.qq.com/wiki/?shareId=…）
- 网页端只能用浏览器加载，`document.body.innerText` 可读 index（标题/简介/文件夹/条数）。
- 内容多是图片/PDF/公众号链接附件，**无渲染正文**可抓。
- 桌面端(ApplData\Local\ima.copilot) 只有**登录打开过**才会同步到本地缓存；未打开则 `search_files` 搜 shareId/关键词 0 命中。
- 结论：ima 只适合人浏览+导出，**要权威政策优先官方站**。
