# 吉大站点抓取端点 + 政策要点 + 知识库发布（原独立技能 jlu-academic-ops，2026-10 并入 jlu-knowledge-ops）

## 源站点地图

- 选课系统 icourses.jlu.edu.cn；教务 jwapp（需 webvpn）；智慧学工 zhxg.jlu.edu.cn
- 校内通知 **oa.jlu.edu.cn**（聚合站，服务端渲染，可直接抓）—— ⚠️ 不是 oxxyda.jlu.edu.cn
- 信息公开网 **gongkai.jlu.edu.cn**；本科生院 xsd.jlu.edu.cn
- 学院：交通学院 jt.jlu.edu.cn、汽车工程学院 auto.jlu.edu.cn、数学 math.jlu.edu.cn

## 抓取端点（2026-09 实测可用，UA 用 Chrome）

**校内通知 oa.jlu.edu.cn**（服务端渲染，urllib 直抓）：
- 列表：`/defaultroot/PortalInformation!jldxList.action?bs=1[&keyword=词]`
  （keyword 参数不精确过滤，直接抓全列表再本地筛）
- 详情：`/defaultroot/PortalInformation!getInformation.action?id=XXX&channelId=179577`
- 正文可选 id="vsb_content"/"v_news_content"/"content" 提取，抓不到就取全页文本按关键词抽段落
- ⚠️ oxxyda.jlu.edu.cn 是 JS SPA：根路径裸 404，需浏览器渲染；数据同源 oa.jlu.edu.cn

**信息公开网 gongkai.jlu.edu.cn**（政策文件）：
- ⚠️ 学籍/学位/奖学金等子页必须带 **/gksx/** 前缀（如 `/gksx/xsglfwxx/xjglbf.htm`），不带前缀直接 404。
  列表页内是相对路径，要按所在目录拼前缀再拼接。
- 政策文件真实链接：`/info/1067/XXXX.htm`（从学生管理服务信息页 xjglbf.htm 抓 href）
- 核心文件：校《本科学生转专业工作管理办法(2025)》(info/1067/9476.htm)、学籍管理规定(info/1067/9470)、
  学士学位授予细则(info/1067/9469)、辅修办法(info/1067/9474)

## 政策要点速查（全文已存 `02_吉林大学\吉林大学相关文件\政策文件\`）

- **转专业(2025)**：集中考核，春季学期初，面向全校本科一、二年级；自愿报名→转出/接收学院审核→
  接收学院考核(笔试+面试，各院定细则/科目/分数权重)→学校审批→公示 5 工作日
- **学分置换(学籍规定)**：转入后可按新专业置换；⚠️ 原专业新生研讨课/学科导论课转为无效需重修；
  无关课程可申请成绩无效或保留改选修；每生一种类型只转一次；一月适应期可退回
- **交通学院**：转专业进来的学生单独分流、单独排名、按学业成绩择优

## 选课方案（转车辆导向）— 2026-09 实战

- 学期规则与毕业口径见主 SKILL.md「选修课数量规则」；**美育2学分是公共基础课模块必修**（非可选项）
- 「应选必修38.5」含未开放课程（物理/化学/制图）——别被吓到，缺口列后续学期补
- 冲突处理：**必修 > 选修**
- 形策选班优先 3-4 节档；12-13 周转线上
- 老师评价查 `_extracted\选课互助文档_新版.txt`
- 南岭校区优先（交通+汽院同在南岭）

## 知识库发布（百晓生，skill_id=ff4601bb-...）

- 构建目录 `02_吉林大学\吉林大学百晓生v5`（references/*_all.txt 分类合并，`===== 来源文件: xxx =====` 分隔）；
  改完升 SKILL.md version → 重打 zip
- 虾评 POST `https://xiaping.coze.com/api/upload`（urllib multipart）
- GitHub：git push(main) + 建 Release + 传 zip 附件（中文附件名要 percent-encode）
- ⚠️ 虾评密集请求会冻结 Key（upload 失败勿连环重试，静置 5-15 分钟）；详见 `jlu-publish.md` /
  `jlu-publish-gotchas.md`；接口与限流实操见 `xiaping` 技能

## 每日吉大通知 → 科技日报开头（已固化）

- `jlu_notices.py` 抓 oa.jlu.edu.cn jldxList，按学生关键词过滤 + 排除党建/研究生噪声，
  输出 `jlu_section.txt/.html`；`daily_pipeline.ps1` 第3步前置到科技摘要+HTML顶部。KWS/EXCLUDE 可调
- 完整栏目结构与过滤细节见 `jlu-oa-notices.md`

## 转专业/路线纠结 → 一对一提问（不是查资料）

用户说「不知道往哪转/看不到方向/身边人都很卷/我到底该怎么弄」时，**别再去抓更多专业资料**（只会加深纠结）。
做法：一次一个问题问到底（核心 8 问）、把焦虑按时间层拆开、只动最近 6 个月那层。
完整问法+话术+必须当场推翻的错误焦虑 → `indecision-coaching.md`。
结论与问答实录外置 → `记忆外置库\详细知识\roads_and_money.md`（再谈先读）。

## 关键坑

1. **用户发课表/选课截图 → 必须用 qwen-vl-max 转录脚本逐张提取**，不可依赖对话内肉眼。
   每张独立 prompt「逐行转录：课程号[教学班]|课程名|教师|时间|地点|学分|类别|性质|校公选类别|校区|容量|状态」，
   输出存 `_extracted\课程转录\` 再汇总。见 `screenshot-ocr-extract.md`。
2. 浏览器工具对含 `=>`/正则/`\` 的多行表达式会卡壳 —— 用最简单的 `document.body.innerText`；
   含中文文件名的 URL 必须 percent-encode。
3. PowerShell 引号/`&` 后台化/BOM/GBK 乱码坑多 → 写 Python 脚本文件再跑，或走 WSL。
4. **培养方案 HTML 是 div 布局（无 table）** → 去 script/style、`</div|span>` 换行、去标签得文本树。
5. 抓 SPA 站点：先 curl 探测根路径，根路径 404 → 大概率是 SPA，改用浏览器渲染找数据。
