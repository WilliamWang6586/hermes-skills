# 校园网/客户端故障诊断（Windows 实测）

用户环境：南岭校区宿舍，USB 有线网卡（`Realtek USB GbE`，接口名"以太网 3"）。
认证客户端：dr.com 锐捷系「吉林大学校园网认证客户端 v5.2.0(D)」。

## 一、先跑这条诊断（一条命令拿全信息）

```powershell
Get-NetAdapter | Select Name,Status,LinkSpeed | ft -a          # 物理层
Get-NetIPAddress -AF IPv4 | ? {$_.IPAddress -notlike '127.*'} | Select InterfaceAlias,IPAddress,PrefixOrigin,AddressState | ft -a
Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Select InterfaceAlias,NextHop,RouteMetric | ft -a
Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" | Select ProxyEnable,ProxyServer
Get-NetAdapter | Select Name,InterfaceDescription,Status | ft -a   # 找虚拟网卡
```

## 二、错误码 → 真因对照表

| 现象 | 真因 | 处理 |
|---|---|---|
| **登录超时失败!**（客户端弹窗） | ①认证服务器不可达（IP/网关不对、走了错接口）②系统代理/虚拟网卡被客户端检测 ③账号错填学号 | 走 §一 只读诊断 → §六 逐接口判断；**别急着改 IP 配置**（见 §七） |
| 拿到 **169.254.x.x** (APIPA) | DHCP 无人应答：**MAC 未登记**/没开户/欠费/插错口 | 见第四节 |
| 一天掉几次 | 客户端检测到虚拟网卡或系统代理 → 强制下线 | 禁用 Radmin/OpenVPN 等虚拟网卡；Clash 退出 |
| 只有自己掉 | 在线设备超限（限 1 PC + 2 移动） | `ip.jlu.edu.cn/pay/` 踢设备 + 改吉大邮箱密码 |
| 室友同时掉 | 路由器 NAT 共享一个 IP（**违规会封禁**） | 路由器改 LAN 口当交换机/AP，各设备各自账号 |

## 三、静态 IP + 虚拟网卡修复（需管理员/UAC）

> 🔴 **动手前必读 §七 —— 2026-09-30 实测教训：这里的"修复"命令曾把用户能上网的配置改成断网。**
> `PrefixOrigin=Manual` **不等于故障**。用户的有线静态 IP 是他刻意设的且当时正常联网。
> **先记录原配置（§七.1）→ 问用户"这是你故意设的吗？现在能上网吗？"→ 得到同意才执行本节命令。**
> 只读诊断不需要管理员权限，先跑 §一 就够定位。

⚠️ 非管理员跑 `Set-NetIPInterface -Dhcp Enabled` 报 `拒绝访问 / Windows System Error 5`。
提权方式：脚本落盘 → `Start-Process powershell -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$script`"") -Wait`

```powershell
# ⚠️ 仅当用户明确同意「改成 DHCP」后才执行；这曾是断网事故的来源
# 管理员身份执行
Set-NetIPInterface -InterfaceAlias "以太网 3" -Dhcp Enabled
Remove-NetIPAddress -InterfaceAlias "以太网 3" -AddressFamily IPv4 -Confirm:$false -EA SilentlyContinue
Set-DnsClientServerAddress -InterfaceAlias "以太网 3" -ResetServerAddresses
Disable-NetAdapter -Name "Radmin VPN" -Confirm:$false -EA SilentlyContinue   # 虚拟网卡必禁
ipconfig /release "以太网 3"; Start-Sleep 2; ipconfig /renew "以太网 3"
```

> ⛔ **默认动作是「不改」**。用户的静态 IP 配置（§7.2）是已知良好配置；
> 除非他明确说要换成 DHCP，本节命令一律不执行。
> 要回滚用 §7.3。
>
> ⚠️ `ipconfig /renew` 无应答时会**前台阻塞 60s+**（本会话曾被工具超时切断）。
> 需要探测时放进 `Start-Job` + `Wait-Job -Timeout 25`，别前台直跑。

⚠️ **去掉静态 IP 后，`Get-NetRoute` 里旧网关可能仍残留**多条默认路由（Metric 0 的 WiFi 会抢主路由）→ 查连通性前先确认到底走哪条接口，别把 WiFi 的通当有线的通。

## 四、169.254.x.x = 这个口没被授权（2026-09-30 实测）

判定链条：
1. `LinkSpeed=1 Gbps` + `MediaConnectionState=Connected` → **物理层正常，排除网线坏**
2. 只有 APIPA 地址、无 `DHCP Server` 字段 → DHCP 请求无人应答
3. `Get-NetAdapter -Name '以太网 3' | Select MacAddress` 拿 MAC → 去 `https://ip.jlu.edu.cn/pay/`（一卡通卡号 + 身份证后6位）核对

### 4.1 ⭐ 二层活没活，看邻居表（本会话破案的关键一步）

`LinkSpeed=Connected` **只证明网卡协商上了电信号，不证明对端有交换机能转发**（"假连接"）。
真正判据是 **ARP / 邻居表**：

```powershell
# 有线口有没有真实二层邻居？网关 MAC 解析得出来吗？
Get-NetNeighbor -InterfaceAlias '以太网 3' -AddressFamily IPv4 |
  Select-Object IPAddress,LinkLayerAddress,State | ft -a

# 强制从有线口（指定源地址）ping 网关，看是不是真的出去了
$ip = (Get-NetIPAddress -InterfaceAlias '以太网 3' -AF IPv4).IPAddress
ping -n 2 -S $ip 49.140.194.254
```

判读：

| 邻居表证据 | 含义 |
|---|---|
| 网关条目 `State=Reachable` + 真实 MAC（如 `48-FD-8E-4B-85-0E`） | ✅ 二层通，对端是活交换机 → 问题在三层以上（IP 段/DHCP/认证） |
| 网关 `LinkLayerAddress=00-00-00-00-00-00` + `State=Unreachable` | ❌ 二层没通，换口/换线 |
| 只有 `169.254.x.x` 且带**别的设备真实 MAC**（如 `7C-CF-0F-1C-60-6C`） | 🔴 **铁证：同一条线上别的设备也拿不到 DHCP** → 你俩多半共同接在一个路由器 LAN 口，不是墙上带 D 的校园网口 |
| `ping -S <本机APIPA> <网关>` 回 `Destination host unreachable` | 报文根本没出去（自己回自己） |

> 实战价值：2026-09-30 用户报"登录超时"，靠邻居表里那两个 `169.254` 外带真实 MAC 的邻居，
> 直接锁定"整条线路没有校园网 DHCP"，而不是继续在客户端上瞎试。

### 4.2 有线口"能通"的误判陷阱

`Get-NetRoute` 里 WiFi 的默认路由 Metric 常比有线低（如 WLAN Metric 0 / 以太网 3 Metric 1）→
**不加 `-S` 的 `ping` 会走 WiFi 出去并成功**，让人误判"有线通了"。
**规则：判断有线是否通，必须指定源地址 `ping -S <有线口IP>`，或先禁 WiFi 再测。**

### 4.3 USB 网卡的坑

USB 网卡 MAC 不固定于主机，换转接器/换口 MAC 会变，是最常见的"昨天还好今天不通"来源。
学校按 MAC 授权，MAC 变了必须做**变更 MAC**（注意：改了 MAC 原设备立即断网，别乱改）。

## 五、账号体系（最容易搞混，用户反复卡这里）

| 用途 | 账号 | 密码 |
|---|---|---|
| 自助营业厅（缴费/改 MAC/销户） | **一卡通卡号** | 身份证后 6 位 |
| 上网认证（客户端 / Portal） | **吉大邮箱账号**（去掉 `@jlu.edu.cn`） | 邮箱密码 |

上网账号 **不是学号、不是一卡通密码**。

## 六、断线后先看"到底哪条链路在通"

WiFi 与有线可同时在线且各自独立，诊断必须**逐接口**看：
- WLAN 拿到 `10.36.x.x`（DHCP Server = `10.36.191.254`）→ WiFi 链路 DHCP 正常
- 以太网只拿到 `169.254.x.x` → 有线口未授权
- 两者都不通外网 → 认证未完成（没登客户端）

**WiFi 是通的就别死磕有线**：先确认账号填的是邮箱、系统代理已关，直接在 WiFi 上登录；有线走 MAC 登记流程并行推进。

## 七、🔴 只读优先 + 配置回滚（2026-09-30 血泪教训）

### 7.1 改任何网络配置之前：先把原配置存下来

```powershell
# 只读快照 —— 不需要管理员，改之前必跑
$i = '以太网 3'
Get-NetIPAddress -InterfaceAlias $i -AddressFamily IPv4 |
  Select-Object InterfaceAlias,IPAddress,PrefixLength,PrefixOrigin,AddressState | ft -a
Get-NetIPInterface -InterfaceAlias $i -AddressFamily IPv4 | Select-Object Dhcp | ft -a
Get-NetRoute -InterfaceAlias $i -DestinationPrefix '0.0.0.0/0' | Select-Object NextHop,RouteMetric | ft -a
Get-DnsClientServerAddress -InterfaceAlias $i -AddressFamily IPv4 | Select-Object ServerAddresses | ft -a
Get-NetAdapter -Name $i | Select-Object Status,MacAddress | ft -a
# 虚拟网卡启用/禁用状态也要记（Disable 过就得记着恢复）
Get-NetAdapter | Select-Object Name,Status | ft -a
```

### 7.2 用户当前的**已知良好配置**（勿动，除非他明确要求换）

| 项 | 值 |
|---|---|
| 接口 | `以太网 3`（USB `Realtek USB GbE`，MAC `EC-1A-C3-10-C7-CB`） |
| IP | `49.140.194.38/24`，**静态（Manual）** |
| 网关 | `49.140.194.254` |
| DNS | `10.10.10.10`, `202.98.18.3` |
| Radmin VPN | **Enabled**（正常态，别当故障禁用） |

⚠️ 这套 `49.140.194.x` 看着像公网段、像"残留"，但**是用户在用且能上网的配置**。
2026-09-30 agent 误判为"残留静态 IP 违规"改成 DHCP → 12 小时内的断网事故。

### 7.3 一键回滚（用户说"改回去"时执行，需 UAC）

```powershell
# 管理员身份；值与 7.2 表一致
Set-NetIPInterface -InterfaceAlias "以太网 3" -Dhcp Disabled
New-NetIPAddress -InterfaceAlias "以太网 3" -IPAddress '49.140.194.38' -PrefixLength 24 `
  -DefaultGateway '49.140.194.254' -EA SilentlyContinue
Set-DnsClientServerAddress -InterfaceAlias "以太网 3" -ServerAddresses @('10.10.10.10','202.98.18.3')
Enable-NetAdapter -Name 'Radmin VPN' -Confirm:$false -EA SilentlyContinue
# 验证
Get-NetIPAddress -InterfaceAlias "以太网 3" -AddressFamily IPv4 | Select IPAddress,PrefixOrigin | ft -a
Test-Connection 49.140.194.254 -Count 3 -Quiet
```

⚠️ 回滚脚本落盘后**必须补 UTF-8 BOM**（首 3 字节 `239,187,191`），否则 PS5.1 下中文注释乱码报 `Unexpected token`。

## 相关文档
- `D:\Hermes文件库\吉林大学相关文件\校园网络\校园网使用指南（南岭校区）.md`（资费/账号/WiFi/有线/红线）
- `D:\Hermes文件库\吉林大学相关文件\校园网络\校园网资源清单（实测）.md`（可达性实测）
- 本机 Clash 残留端口 `127.0.0.1:7892` 常留在注册表 `ProxyServer` 里（`ProxyEnable=0` 即已关）
