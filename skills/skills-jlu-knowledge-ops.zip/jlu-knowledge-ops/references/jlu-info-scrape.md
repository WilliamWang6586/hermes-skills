# JLU 信息/政策/公众号 抓取配方（2026-09-08 实测可用）

JLU 站多为服务端渲染或 JS SPA，直接用 urllib 抓取时要命中真实端点 + 正确路径前缀。以下为已验证的抓取配方。

## 1. 校内通知列表（OA，默认列表）
- 列表接口：`https://oa.jlu.edu.cn/defaultroot/PortalInformation!jldxList.action?bs=1`
  - 带关键词：加 `&keyword=<url编码>`（注意 keyword 搜索行为偏宽，会在默认列表上再过滤）
- 从结果提取条目：正则 `getInformation\.action\?id=(\d+)[^>]*>\s*([^<]{6,90})` 得 (id, 标题)。标题 → 详情链接为
  `https://oa.jlu.edu.cn/defaultroot/PortalInformation!getInformation.action?id=<id>&channelId=179577`
- 详情正文提取：找 `id="vsb_content"` 或 `class="v_news_content"` 的 div，去 script/style/标签后取行。公开信息：A/B/预备级、报名时间、附件名等常在正文但部分字段是图片，正文能提取到的是文本块。
- ⚠️ 页面标题 `title` 常为「吉林大学电子校务平台」，真正的通知标题要用详情里的 `<h1>` 或列表里抓到的标题。

## 2. 政策文件（信息公开网 gongkai）——路径必须带 /gksx/ 前缀
- 站点根：`https://gongkai.jlu.edu.cn/`
- ⚠️ 关键坑：子页路径必须带 `/gksx/`。直接 `/xsglfwxx/...`、`/xw_xkxx/...` 返回 404；正确是
  `/gksx/xsglfwxx/<file>.htm`（学籍/转专业/奖学金）、`/gksx/xw_xkxx/<file>.htm`（学位）、`/gksx/xsglfwxx.htm`、`/gksx/xw_xkxx.htm`(栏目索引,从根导航 href 相对路径解析时丢失 gksx 前缀)。
- **转专业政策文件列表入口**：`/gksx/xsglfwxx/xjglbf.htm` —— 列出一页政策文件（标题+日期），但**真实详情链接在 `/info/1067/XXXX.htm`**（这里的 href 是 `../../info/1067/NNNN.htm`，从 /gksx/xsglfwxx/ 上两级到根）。
  - 校《本科学生转专业工作管理办法》= `/info/1067/9476.htm`（2025-10-20，校级权威，含集中考核转专业/学分置换/每生转1次/一月适应期）
  - 学籍管理规定=`/info/1067/9470.htm`、辅修学士学位=`/info/1067/9474.htm`、学士学位授予工作细则=`/info/1067/9469.htm`
- 学院细则站点（如 jt.jlu.edu.cn 交通学院、auto.jlu.edu.cn 汽车学院）详情在 `info/10xx/NNNN.htm`，正文同样在 `id="vsb_content"`。培养方案/推免细则常为**附件型**（正文很短），需另行下载附件。

## 3. 微信公众号文章抓取（含全文 + 图片）
- URL：`https://mp.weixin.qq.com/s/<id>` 或带 `__biz=...` 的长链。WSL 下 curl 能抓到完整 HTML（3MB+）。
- 标题：`<meta property="og:title">` 或 `<h1 id="activity-name">`。
- 正文：`<div id="js_content">` 内文本（去标签）。
- 图片：`js_content` 内 `img[data-src]`（值是 `s3.mpt.qpic.cn/...`），逐个下载，`data-src` 在微信图片是惰性加载，取的是真正的图片 URL。
- 正文分页/字段：微信正文虽有富文本，文本提取可读；需保图片时把它下载到本地文件夹并改名 img_01.jpg 等。
- ⚠️ 乱码：PS 里 heredoc 写脚本易引号炸（PowerShell 5.1 BOM/引号坑）；跨 WSL 写脚本用 `[System.IO.File]::WriteAllText(...UTF8Encoding(false))` 再 `wsl python3 /mnt/d/...py` 运行，避免 PS here-string 引号错误。跑 Python 用 `$env:PYTHONUTF8="1"` 防 emoji print 崩。

## 4. 相关关键词过滤（用户=吉大2026新生→转车辆工程）
抓通知/政策时按学生事务关键词过滤，排除学院党建/研究生噪声：
- KWS（命中任一）：分级/数学竞赛/四六/英语/外语/选课/辅修/转专业/竞赛/考试/培养方案/保研/推免/奖学金/新生/教务/补考/报名
- EXCLUDE（命中任一剔除）：政绩观/总结大会/学习教育/党委/党总支/党支部/座谈会/观看/展览/研究生/支教/讲座/学术会议/专题
