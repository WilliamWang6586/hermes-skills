---
name: interactive-map-design
description: Design patterns for creating interactive maps and geographic data visualizations using HTML, CSS, and JavaScript.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [design, maps, interactive, svg, visualization, geography, data-viz]
    related_skills: [claude-design, popular-web-designs]
---

# Interactive Map Design

## Overview
Specialized design patterns for creating interactive maps and geographic data visualizations using HTML, CSS, and JavaScript. Extends the core design principles from claude-design with map-specific considerations.

## When to Use
Use this skill when creating:
- Interactive maps with clickable regions
- Geographic data visualizations
- Student distribution maps
- Regional statistics dashboards
- Location-based interactive prototypes
- Turning a static infographic/map image into an interactive HTML page
  (click region → highlight + lift + show that region's people/records)
- **Any map of China / a Chinese province** → go straight to
  `references/geojson-china-map-recipe.md` (real省界数据 + 已验证配方)

## Core Principles

### 0. NEVER hand-draw the map outline (user's hard rule)
Hand-authoring province/country paths as polygon blobs looks like "一堆色块" and **will be rejected** —
actual user words: *"你的地图给我好好弄，不要弄一堆色块糊弄我"*. Always fetch real boundary data
(GeoJSON) and project it. Hand-drawn shapes are only acceptable for a schematic/illustrative diagram
where geography is not the point.

Real boundary data + projection + the "click province, it highlights and lifts up" pattern is
documented end-to-end in **`references/geojson-china-map-recipe.md`** (DataV 数据源、坐标嵌套坑、
等经纬投影、双层浮起、锚点缩放、验证脚本). Read it before building any map of China.

### 1. SVG-First Approach
- Use SVG for map shapes and paths
- Ensure paths are clickable with proper cursor styling
- Include hover and active states for interactivity
- Make regions accessible with proper ARIA labels

### 2. Responsive Map Design
- Use viewBox for scalable SVG maps
- Implement touch gestures for mobile devices
- Ensure hit targets are at least 44px on mobile
- Use CSS transforms for smooth zooming and panning

### 3. Data-Driven Styling
- Use CSS custom properties for dynamic theming
- Implement color scales for data visualization
- Create clear visual hierarchy for different data points
- Ensure accessibility with sufficient contrast

## Implementation Patterns

### Basic Interactive Map
```html
<div class="map-container">
  <svg class="map-svg" viewBox="0 0 800 600">
    <path class="region" data-region="name" d="path-data" />
  </svg>
  <div class="info-panel" id="infoPanel">
    <!-- Dynamic content -->
  </div>
</div>
```

### CSS for Map Interactions
```css
.region {
  fill: #e3f2fd;
  stroke: #1976d2;
  stroke-width: 1;
  cursor: pointer;
  transition: all 0.3s ease;
}

.region:hover {
  fill: #bbdefb;
  stroke-width: 2;
}

.region.active {
  fill: #2196f3;
  stroke: #0d47a1;
  stroke-width: 3;
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));
}
```

### JavaScript for Map Interactions
```javascript
// Region click handling
document.querySelectorAll('.region').forEach(region => {
  region.addEventListener('click', function() {
    const regionName = this.getAttribute('data-region');
    showRegionInfo(regionName);
    
    // Remove active state from other regions
    document.querySelectorAll('.region').forEach(r => r.classList.remove('active'));
    // Add active state to clicked region
    this.classList.add('active');
  });
});

// Touch gesture support for zooming
let touchStartDistance = 0;
let touchStartZoom = 1;

document.addEventListener('touchstart', function(e) {
  if (e.touches.length === 2) {
    touchStartDistance = Math.hypot(
      e.touches[0].clientX - e.touches[1].clientX,
      e.touches[0].clientY - e.touches[1].clientY
    );
    touchStartZoom = currentZoom;
  }
});
```

## Design Patterns

### 1. Monitor Surface Maps
- **Use case**: Data dashboards, statistics displays
- **Characteristics**: High data density, glanceable hierarchy, minimal decoration
- **Layout**: Grid-based data display with map as primary visualization
- **Interaction**: Hover for details, click for detailed view

### 2. Explore Surface Maps
- **Use case**: Geographic browsing, location discovery
- **Characteristics**: Open space, filters, result grids
- **Layout**: Full-screen map with sidebar controls
- **Interaction**: Pan, zoom, filter, click for details

### 3. Decide Surface Maps
- **Use case**: Comparison tools, decision support
- **Characteristics**: Aligned comparisons, clear differentiators
- **Layout**: Side-by-side maps or layered data
- **Interaction**: Toggle layers, compare regions

## Accessibility Considerations

### Keyboard Navigation
- Ensure all regions are keyboard accessible
- Implement focus states for interactive elements
- Provide screen reader support with ARIA labels

### Color Contrast
- Ensure sufficient contrast for text and interactive elements
- Use colorblind-friendly palettes when possible
- Provide alternative visual indicators for color information

### Mobile Optimization
- Touch targets minimum 44px
- Support pinch-to-zoom gestures
- Ensure single-hand operation on mobile

## Performance Considerations

### SVG Optimization
- Simplify complex paths when possible
- Use CSS transforms instead of modifying SVG attributes
- Implement lazy loading for large maps

### Event Delegation
- Use event delegation for better performance with many regions
- Implement debouncing for rapid interactions
- Consider virtual scrolling for very large datasets

## Template Examples

### Basic Interactive Map Template
```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Map</title>
    <style>
        /* Map styling from above */
    </style>
</head>
<body>
    <div class="map-container">
        <svg class="map-svg" viewBox="0 0 800 600">
            <!-- Map regions -->
        </svg>
        <div class="info-panel" id="infoPanel">
            <button class="close-btn" onclick="closeInfo()">×</button>
            <h3 id="regionName">Region Name</h3>
            <div id="regionInfo">Information about the selected region</div>
        </div>
    </div>
    <script>
        // JavaScript interactions
    </script>
</body>
</html>
```

## Best Practices

### 1. Start Simple
- Begin with basic SVG shapes
- Add interactivity incrementally
- Test with real data early

### 2. Mobile First
- Design for mobile interactions first
- Scale up to desktop
- Ensure touch gestures work well

### 3. Performance Testing
- Test with large datasets
- Monitor memory usage
- Optimize rendering performance

### 4. User Testing
- Test with actual users
- Get feedback on interaction patterns
- Iterate based on user needs

## Common Pitfalls

### 0. Blank map with zero console errors — check GeoJSON nesting first
`MultiPolygon.coordinates` has **one more nesting level** than `Polygon.coordinates`
(`[poly[ring[[lon,lat]]]]` vs `[ring[[lon,lat]]]`). Getting it wrong throws
`.for is not iterable` *before* any element is created → the page renders empty and looks like
"data failed to load". Debug order: `browser_console` → count `path.prov` → check for uncaught
exceptions → inspect `coordinates.length` per feature. Full recipe:
`references/geojson-china-map-recipe.md`.

### 1. Over-Engineering
- Don't build complex map features unless needed
- Keep interactions simple and intuitive
- Focus on core functionality first
- Don't add d3/echarts when a ~40-line equirectangular projection does the job (native platform feature wins)

### 1b. Verify by rendering, not by `status`
"File written" proves nothing. Navigate to the file, assert element counts via `browser_console`,
screenshot via `browser_vision` to confirm the outline is *recognizable geography*, then dispatch a
synthetic click and assert the panel content. See recipe §7.

### 2. Poor Performance
- Avoid too many DOM elements
- Use efficient event handling
- Implement proper cleanup

### 3. Accessibility Issues
- Don't forget keyboard navigation
- Ensure proper contrast ratios
- Test with screen readers

## Resources

- SVG documentation for map creation
- CSS transforms for smooth animations
- JavaScript event handling for interactivity
- Accessibility guidelines for interactive maps