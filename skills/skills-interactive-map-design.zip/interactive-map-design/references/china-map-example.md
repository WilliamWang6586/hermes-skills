# China Map Example

## Implementation Example
This example shows how to create an interactive China map with clickable provinces that display student and school information.

### Key Features Implemented
- Clickable province regions with hover effects
- Information panel that slides in when a province is selected
- Responsive design for both desktop and mobile
- Touch gesture support for zooming
- Keyboard navigation support

### Technical Implementation
- Uses SVG paths for province boundaries
- CSS transitions for smooth animations
- JavaScript event handling for interactions
- CSS custom properties for theming
- Responsive viewBox for scalability

### Data Structure
```javascript
const provinceData = {
  '北京': {
    students: 156,
    schools: [
      { name: '北京大学', type: '985', students: 45 },
      { name: '清华大学', type: '985', students: 52 }
    ]
  }
};
```

### Interactive Elements
- **Province paths**: Click to select and highlight
- **Info panel**: Shows detailed information about selected province
- **Close button**: Dismisses the info panel
- **Statistics cards**: Display summary information

### Responsive Features
- Mobile-optimized touch targets (minimum 44px)
- Touch gesture support for pinch-to-zoom
- Responsive layout that adapts to screen size
- Optimized for both desktop and mobile viewing

### Performance Optimizations
- Event delegation for efficient handling
- CSS transforms for smooth animations
- Simplified SVG paths for better performance
- Proper cleanup of event listeners

### Accessibility Features
- Keyboard navigation support
- ARIA labels for screen readers
- High contrast colors for better visibility
- Focus states for interactive elements

### Usage Pattern
1. User clicks on a province region
2. Province becomes highlighted with visual feedback
3. Information panel slides in with detailed data
4. User can close panel or click another province
5. Map remains interactive with smooth transitions

This example demonstrates best practices for creating interactive geographic visualizations with modern web technologies.