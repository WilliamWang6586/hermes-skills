# 真实省级边界数据 → 单文件交互地图（实测配方）

用户拒绝"手绘色块"地图（原话：*不要弄一堆色块糊弄我*）。必须用真实行政边界。

## 1. 数据源：阿里 DataV GeoJSON（免 token、免 key）

```powershell
$ProgressPreference='SilentlyContinue'
Invoke-WebRequest -Uri "https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json" -OutFile china_geo.json
# 582KB / 35 features
```

- `100000_full.json` = 全国含省界（`_full` 后缀必须有，否则只有外轮廓）
- 单省：`areas_v3/bound/<adcode>_full.json`（如 `610000_full.json` = 陕西含市界）
- 属性字段：`name`（如"北京市""吉林省"）、`adcode`、`center`（标标签用）、`centroid`（可能缺失，用 `center || centroid` 兜底）
- 几何类型混用：大多 `MultiPolygon`，内蒙古是 `Polygon` —— 两种都要处理

## 2. 🔴 头号坑：GeoJSON 坐标嵌套层级（曾导致地图整片空白）

```js
// Polygon      -> coordinates = [ ring[[lon,lat],...], ... ]
// MultiPolygon -> coordinates = [ poly[ ring[[lon,lat],...], ... ], ... ]
//                                  ↑ 比 Polygon 多一层 poly
```

我写漏了 `poly` 那一层，`for (const [lon,lat] of ring)` 直接抛
`TypeError: .for is not iterable` —— 且异常发生在建 path 之前，**页面无任何报错、就是一片空白**。
以后遇到"数据加载了但什么都没画出来"，先看 console 有无未捕获异常。

统一遍历函数（两种类型都覆盖）：

```js
function eachPoint(g, fn){
  if (g.type === 'Polygon'){
    for (const ring of g.coordinates) for (const pt of ring) fn(pt);
  } else {
    for (const poly of g.coordinates) for (const ring of poly) for (const pt of ring) fn(pt);
  }
}
```

## 3. 投影：等经纬足够，别引 d3

```js
const W = 1000, H = 1000, K = 1.28;  // K = 纬度拉伸，抵消等经纬在中纬度的压缩
function projector([x0,y0,x1,y1]){   // bbox 来自 eachPoint 全量扫描
  const s = Math.min(W/(x1-x0), H/((y1-y0)*K));
  const ox = (W-(x1-x0)*s)/2, oy = (H-(y1-y0)*K*s)/2;
  return ([lon,lat]) => [ (lon-x0)*s+ox, ((y1-lat)*K)*s+oy ];
}
// Polygon -> 每 ring 一条 'M..L..Z' 子路径，拼成一个 d
// MultiPolygon -> 所有 ring 全部拼进同一个 d（SVG path 支持多子路径）
```

标 `ponytail:` 注明：跨境电商级精度需换 Mercator / d3-geo。

## 4. 「点击省份高亮 + 浮起」的正确做法（两层渲染）

不是改一个 path 的 CSS，而是**另画一层**：

- `gBase` 底板层：全部省份常态（底色 + hover + `.has` 有数据态）+ 承接点击
- `gLift` 浮起层（`pointer-events:none`）：选中时克隆该省 path 进来，外套
  `<g transform="translate(0,-7)">`，CSS 给 `drop-shadow(0 14px 18px rgba(0,0,0,.55))`
- `gLbl` 标签层：`paint-order:stroke; stroke:#<底色>; stroke-width:2.4px` 制造描边，避免标签被地图吞掉
- 缩放/平移时三层共用同一 transform，否则浮起层会错位

标签用 `center` 字段，人数角标画在标签下一行（`y+11`）。

## 5. 交互（一套代码同时满足鼠标 + 触摸）

```js
pointerdown / pointermove / pointerup  → 拖拽平移（移动 >3px 才算拖拽，否则算点击）
wheel (passive:false)                  → 滚轮缩放，以光标为锚点
touchstart/touchmove (2 指)            → 双指缩放，以两指中点为锚点
```

以光标/中点为锚点的缩放公式（关键，不做就会"缩放跑偏"）：

```js
const rf = nk/state.k;
state.x = mx - (mx - state.x)*rf;
state.y = my - (my - state.y)*rf;
state.k = nk;
```

`<svg>` 必须 `touch-action:none`，否则移动端浏览器抢走手势。缩放范围夹在 0.6~8。

## 6. 生成方式：Python 拼模板（不用 JS 框架）

`_gen_map.py` 读 GeoJSON → 缩字段（`{n,c,g}`）→ `json.dumps(ensure_ascii=False, separators=(",",":"))`
→ `.replace("__GEO__", ...)` 注入 HTML 模板 → 写单文件。

单文件 580KB 属正常（业内水准是 `3-8MB` / `2-3MB`，含单文件 echart）。带 `<script>` 的 HTML
注 意：geo JSON 里不能出现 `</script>`（省界坐标全是数字，天然安全）。

## 7. 验证（必须，不能只看 status）

```
browser_navigate → browser_console 查 document.querySelectorAll('path.prov').length
                 → browser_vision 看轮廓是否可辨认（不是色块）
                 → browser_console 派发 click 事件，断言浮起层 path 数 + 侧栏文本
```

派发点击的自检写法：

```js
[...document.querySelectorAll('path.prov')].find(x=>x.dataset.name.includes('吉林'))
  .dispatchEvent(new MouseEvent('click',{bubbles:true}));
// 断言: #lift path 数 === 1、panel.classList.contains('on')、pname/pcnt/列表文本
```

## 8. 变体：hover 省份 → 左侧放大 + 城市打点 + 引线连右侧卡片

用户升级需求（原话：*鼠标停留在省份上时该省份放大置于画面左侧，此时省份上面出现学校所在位置，
通过点连线方式引出右侧学生所在学校及其姓名*）。与 §4 的「原图上浮起」是**两套不同打法**：

### 8.1 放大：按省 bbox 独立投影，不要用 CSS scale

CSS `transform:scale()` 会把 stroke 一起放大（描边变粗）、且要处理反向补偿。
正确做法是**给放大层一个自己的投影**，把该省 bbox 铺满放大视口：

```js
const ZW = 620, ZH = 780, PADZ = 0.07;   // 放大视口虚拟尺寸
function projFor(name){
  const [x0,y0,x1,y1] = bboxOf(feat.g);           // 复用 eachPoint 扫该省 bbox
  const w = (x1-x0)*(1+PADZ*2), h = (y1-y0)*(1+PADZ*2);
  const s = Math.min(ZW/w, ZH/h);
  const sx0 = x0-(x1-x0)*PADZ, sy1 = y1+(y1-y0)*PADZ;
  const ox = (ZW-w*s)/2, oy = (ZH-h*s)/2;
  return ([lon,lat]) => [ (lon-sx0)*s+ox, (sy1-lat)*s+oy ];
}
// 路径生成函数要参数化投影：geomToPathP(g, pf)，主图传全局 PJ，放大层传 projFor(name)
// 每种几何只算一次 → projCache 缓存
```

放大层是**独立的第三个 `<svg>`**（`#zoom`，绝对定位在左侧、`pointer-events:none`、
自己一个 `viewBox="0 0 ZW ZH"`），不要塞进主图那个 svg —— 两套坐标系混用必错。

### 8.2 引线：跨 svg 坐标换算（最容易写错的一环）

城市点在 `#zoom` 自己的坐标系里，卡片在 DOM 里，引线画在第三个全屏 svg `#wires`。
换算链：**放大层内坐标 → 屏幕坐标 → 引线层内坐标**。

```js
function zToScreen(x, y){
  const r = zsvg.getBoundingClientRect();
  const sc = Math.min(r.width/ZW, r.height/ZH);         // 与 preserveAspectRatio 一致
  const offX = (r.width - ZW*sc)/2, offY = (r.height - ZH*sc)/2;
  return [ r.left + offX + x*sc, r.top + offY + y*sc ];
}
// 引线层每次绘制前用屏幕尺寸设 viewBox，然后就全用屏幕坐标画
wireSvg.setAttribute('viewBox', `0 0 ${r.width} ${r.height}`);
```

`preserveAspectRatio="xMidYMid meet"` 的居中留白必须用 `offX/offY` 补掉，否则线头偏移。

### 8.3 三个必须踩的坑

1. **布局打架**：放大层盖在主地图上会糊成一团。hover 时把主图 `opacity:.18` 淡出让位，
   `#zoom` 宽度 `min(46%,520px)`，右侧面板别动。图例/tooltip 同时淡出。
2. **标签重叠**：同省相邻城市（西安/咸阳只差 20px）标签会叠死。贪心避让：
   ```js
   let ly = y - 14;
   while (used.some(u => Math.abs(u.x-x) < 70 && Math.abs(u.y-ly) < 22)) ly -= 22;
   used.push({x, y:ly});
   ```
3. **绘制时机**：面板渲染完布局还没稳，须
   `requestAnimationFrame(()=>requestAnimationFrame(drawWires))`，否则卡片 `getBoundingClientRect()` 拿到旧位置。
   再挂 `window.resize` 重画。

### 8.4 hover 触发用 pointerover + 定时器防抖

```js
gBase.addEventListener('pointerover', e=>{
  const p = e.target.closest('.prov'); if (!p) return;
  if (!listFor(p.dataset.name)) return;          // 无数据省份不触发
  clearTimeout(hoverTimer); hoverTimer = setTimeout(()=>select(name), 80);
});
gBase.addEventListener('pointerout', ()=>clearTimeout(hoverTimer));
```

`pointerover`/`pointerout` 已覆盖鼠标与触摸笔，一套代码两端可用。
**注意手机无 hover**：`pointerover` 在触摸端会在 tap 时补发，但体验不等价 ——
真要手机可用需另加 `pointerdown` 分支（本次未做，用户未要求）。

### 8.5 城市坐标表

GeoJSON 只有省级 `center`，城市点位需自带经纬度表（本次内联 18 城）：

```python
CITY_TABLE = {"西安": [108.93, 34.27], "咸阳": [108.71, 34.33], "兰州": [103.83, 36.06], ...}
# JS 侧：const [x,y] = CITY[city] ? pf(CITY[city]) : pf(feat.c);   // 无坐标兜底到省中心
```

`pcas-code.json` 之类只有行政区划名、**没有坐标**，别指望它。

### 8.6 注入占位符要断言

模板里多个占位符（`__GEO__` / `__STUDENTS__` / `__CITIES__`）时，替换后加断言，
否则漏替换会静默产出坏页面：

```python
html = HTML.replace("__GEO__", GEOJS).replace("__STUDENTS__", ...).replace("__CITIES__", ...)
assert "__GEO__" not in html and "__STUDENTS__" not in html and "__CITIES__" not in html
```

### 8.7 交付前的数据自检（从产物反解，而不是信脚本）

```python
h = io.open(OUT, encoding='utf-8').read()
S = json.loads(re.search(r'const STUDENTS = (\{.*?\n\});', h, re.S).group(1))
C = json.loads(re.search(r'const CITY = (\{.*?\});', h, re.S).group(1))
assert sum(len(v) for v in S.values()) == 45
assert not ({s['city'] for v in S.values() for s in v} - set(C))   # 无缺坐标
```

## 9. 图片信息读不出来时的处理

本次 `browser_vision` 连续 3 次只回传附件本体、无文字内容（图片确实是该页面的截图/原图）。
不要硬编造名单 —— 把数据结构抽成显式 `STUDENTS` 常量（`{"省份": [{"name","school","major"}]}`），
页面里给出占位示例 + 说明"名单可在源码 STUDENTS 中增补"，并直接告诉用户把图上名单以文字发来后重跑即可。
