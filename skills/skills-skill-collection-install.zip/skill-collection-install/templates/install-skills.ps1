# 技能库一键安装脚本（模板）
# 用法：powershell -ExecutionPolicy Bypass -File install-skills.ps1
# 幂等：已存在的同名技能跳过，不覆盖。
#
# ⛔ 交付前必做（详见 SKILL.md §4c）：
#   1. 本文件必须存为 **UTF-8 with BOM**，否则 PowerShell 5.1 按 GBK 解码中文 → 假语法错误
#   2. patch 改过之后 BOM 会丢，每次都要复验首 3 字节 = 239,187,191
#   3. 语法通过后还要**实跑**关键函数，别只信语法

$ErrorActionPreference = 'Stop'
$HERMES = "$env:LOCALAPPDATA\Hermes Agent CN Desktop\data\hermes-home\skills"
$WORK   = "$env:TEMP\skill-install"
New-Item -ItemType Directory -Force -Path $HERMES, $WORK | Out-Null

# 把 $src 下每个技能目录拷进技能库（同名跳过，不覆盖）
function Sync-Skills($src) {
    if (-not (Test-Path $src)) { Write-Host "MISS: $src"; return }
    Get-ChildItem $src -Directory | ForEach-Object {
        $dst = Join-Path $HERMES $_.Name
        if (Test-Path $dst) { Write-Host "SKIP(exists): $($_.Name)" }
        else { Copy-Item $_.FullName $dst -Recurse; Write-Host "OK: $($_.Name)" }
    }
}

# clone 前验证仓库存在：不存在的仓库 clone 会挂起超时，不报错
# ⚠️ 函数名别用 Test-* 前缀（PowerShell 保留动词，与 Test-Path 冲突）
function Assert-RepoExists($slug) {
    # -L 必须加：仓库改名会返回 301，不加 -L 会误判为不存在
    $code = curl.exe -sL -o NUL -w "%{http_code}" --max-time 20 "https://api.github.com/repos/$slug"
    if ($code -ne '200') { Write-Host "!! 仓库不存在或私有: $slug (HTTP $code)"; return $false }
    return $true
}

Set-Location $WORK

# ── A. 走 npx 的技能集合 ──────────────────────────────────────
# ⚠️ npx 装到 CWD\.agents\skills\，不是技能目录，必须手动同步
npx --yes skills add addyosmani/agent-skills --yes
Sync-Skills "$WORK\.agents\skills"

# ── B. 纯复制安装的集合（mattpocock 类）───────────────────────
if (Assert-RepoExists 'mattpocock/skills') {
    git clone --depth 1 https://github.com/mattpocock/skills "$WORK\mattpocock"
    Sync-Skills "$WORK\mattpocock\skills\engineering"
}

# ── C. 独立技能仓库 ───────────────────────────────────────────
$repos = [ordered]@{
    'Nutlope/hallmark'                    = 'hallmark'
    'eze-is/web-access'                   = 'web-access'
    'op7418/Humanizer-zh'                 = 'humanizer-zh'
    'cjke84/agent-memory-system-guide'    = 'agent-memory-system-guide'
    'blader/humanizer'                    = 'humanizer'
    'peterskoett/self-improving-agent'    = 'pua-debugging'
    'hugohe3/ppt-master'                  = 'ppt-master'
    'Panniantong/Agent-Reach'             = 'agent-reach'
}
$single = @()   # 仓库根目录就是技能本体的，收集到临时容器里一起同步
foreach ($slug in $repos.Keys) {
    $name = $repos[$slug]
    if (-not (Assert-RepoExists $slug)) { continue }
    $dir = "$WORK\$name"
    if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
    git clone --depth 1 "https://github.com/$slug" $dir
    if ($LASTEXITCODE -ne 0) {
        Write-Host "GitHub 不通，改走 AtomGit 镜像: $slug"
        git clone --depth 1 "https://atomgit.com/$slug.git" $dir
    }
    if     (Test-Path "$dir\SKILL.md") { $single += [pscustomobject]@{ Slug = $slug; Path = $dir } }
    elseif (Test-Path "$dir\skills")   { Sync-Skills "$dir\skills" }
    else   { Write-Host "MANUAL: $name 结构未知，请人工检查 $dir" }
}
# 单技能仓库：在容器目录下按 <技能名> 放好再同步，保证技能名正确
if ($single.Count -gt 0) {
    $box = "$WORK\_box"
    foreach ($s in $single) {
        $dst = Join-Path $box $repos[$s.Slug]
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item "$($s.Path)\*" $dst -Recurse -Force
    }
    Sync-Skills $box
}

# ── D. 平台分发（虾评 _meta.json 标记的技能）──────────────────
# 平台 https://xiaping.coze.com ；需人工搜索下载后解压，脚本无法自动获取

# ── E. 带 Python 依赖的技能 ───────────────────────────────────
# ⚠️ 清华源对 pip 返回 403，必须用阿里云源。分两行写避免续行符：
# $req = "$HERMES\ppt-master\requirements.txt"
# python3.14 -m pip install -r $req -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com

Write-Host ""
Write-Host "==== 完成。技能目录当前有 $((Get-ChildItem $HERMES -Directory | Where-Object { $_.Name -notlike '.*' }).Count) 个技能 ===="
