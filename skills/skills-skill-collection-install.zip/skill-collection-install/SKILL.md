---
name: skill-collection-install
description: >-
  从 GitHub 技能集合（如 addyosmani/agent-skills、hugohe3/ppt-master）安装第三方技能到 Hermes，
  以及把整库技能**交接/导出给另一个 agent**（豆包/Claude Code/Codex/别的 Hermes 实例）。
  当用户贴出 `npx skills add <owner>/<repo>` 命令、说「帮我安装这个技能集合/仓库里的技能」、
  「看看这个 skill 怎么样，装上进」、「把这个技能库给/移交给 XX agent」、「总结我的 skill 发给同学/
  要下载地址」、或要从 GitHub 批量装 skill 时使用。覆盖：npx skills 的安装位置陷阱、同步到 Hermes
  skills 目录、**跨 agent 路径自适应与嵌套目录兜底**、装前安全扫描与**误报识别**、带 Python 依赖的
  技能安装、GitHub 主站不通时的国内镜像（AtomGit）走法、PyPI 镜像源 403 排错、
  PowerShell 脚本交付前的三项验收（语法/BOM/悬空调用）、**整库打包导出（单 zip / base64 合集 / 虾评）**。
version: "1.2"
updated_at: "2026-09-27"
platforms: [windows, linux, macos]
---

# GitHub 技能集合安装（npx skills）

用户贴 `npx skills add ...` 命令或要求安装 GitHub 上的技能集合时，按本流程走。
**先弄清技能装到哪里，再谈启用——npx skills 的默认安装位置不是 Hermes 的技能目录。**

> **配套文件**
> - `scripts/install-skills-portable.ps1` —— 跨 agent 路径自适应安装脚本（含嵌套兜底），实测装出 50 个技能。
> - `references/skill-install-handoff.md` —— 跨 agent 交接实录：权威数量表、对方 agent 的三点合理
>   质疑、被外部复核抓出的 2 个真 bug、交付前验收清单。
> - `references/skill-inventory-audit.md` —— **反方向：盘点/审计已装技能**（原独立技能 `skill-inventory-audit`）。
>   `.bundled_manifest` 权威分流「官方内置 vs 后天安装」、从 `_meta.json` 反查虾评来源、从 frontmatter
>   反查 GitHub 来源、`.agents/skills` 落点取证、重复技能识别、打包导出。配套 `scripts/inventory_skills.ps1`、
>   `templates/install-skills.ps1`、`references/verified-skill-sources.md`。
>   **触发补充**：列出/导出/备份技能、这些技能怎么装的、其他 agent 怎么获得同样的技能、技能太乱了合并一下、哪些是重复的。
> - `references/skill-bundle-export.md` —— **把整库技能导出给别人**（用户说「总结我的 skill 发给同学」「给它个下载地址」
>   「打包给我的另一个 agent」）：三种交付方案（单 zip / base64 合集 / 虾评）、`.archive` 与 89MB 资源的排除规则、
>   base64 段的稳健解析写法、脱敏替换顺序、实测验收。成品 `D:\Hermes文件库\03_工具与项目\skill_bundle\`。

## 核心陷阱（2026-08 实测）

`npx skills add addyosmani/agent-skills --yes` 会把技能装到 **当前工作目录（CWD）相对路径**
`./.agents/skills/`（universal 目录，给 Codex/GitHub Copilot/Amp 等用），同时 symlink 到
Claude Code。**Hermes 不会自动加载这个目录**——必须手动复制到 Hermes 的 skills 目录。

```
npx 装到:  D:\Hermes文件库\.agents\skills\<skill>\     ← CWD 相对！
Hermes 读:  C:\Users\<user>\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\skills\<skill>\
```

## 标准流程

### 1. 先浏览再装（可选）

```bash
npx skills add <owner>/<repo> --list     # 列出仓库内全部技能及用途，不安装
```

### 0. 先验证仓库存在（必做，2026-08 实测）

用户给的名字可能是错的（本会话：`huashu-design/web-access-skill` 实为虚构，真实仓库是
`eze-is/web-access`，8710 stars）。**git clone 对不存在的仓库会挂起超时而不是报错**（VPN
路由下表现尤为明显），所以先花 2 秒验证：

```powershell
# 404 = 仓库不存在或私有；200 = 存在（顺带拿 default_branch）
curl.exe -s --max-time 20 https://api.github.com/repos/<owner>/<repo> | Select-String '"default_branch"|"message"'
# 找不到时用搜索 API 找真实仓库（本会话即靠它定位 eze-is/web-access）：
curl.exe -s --max-time 20 "https://api.github.com/search/repositories?q=web-access+in:name&per_page=10"
curl.exe -s --max-time 20 "https://api.github.com/users/<owner>/repos?per_page=100" | Select-String '"name":'
```

### 0.5 方式 A2：跨 agent 批量安装脚本（路径自适应 + 嵌套兜底）

当你需要把整库技能**交付给另一个 agent**（豆包/Claude Code/Codex/别的 Hermes 实例）而不只是
装给自己时，别写死 Hermes 路径——对方读的是它自己的技能目录。2026-09 实测：写死 Hermes 路径的
脚本，在豆包那侧会装错地方。

要点（缺一不可）：
1. `param([string]$SkillsRoot)` + **自动探测**，探测顺序把目标 agent 排前面
   （豆包 `%USERPROFILE%\Doubao\skills`，Hermes `%LOCALAPPDATA%\Hermes Agent CN Desktop\data\hermes-home\skills`，
   通用 `%USERPROFILE%\.agents\skills`，Claude Code `%USERPROFILE%\.claude\skills`）。
   有内容的候选优先（说明那就是生效的技能根），全空则建第一个。
2. **clone 完对整棵工作目录做一次递归 `SKILL.md` 兜底扫描**——见下方陷阱"仓库结构判断"。
   这是唯一能覆盖所有仓库布局的做法。
3. 交付方式：**贴脚本文本，不要只给本机文件路径**。`MEDIA:D:\...` 这类附件语法只在你自己的
   客户端渲染，对方 agent 拿不到（它会去 Downloads/Desktop/%TEMP% 找，然后报"没有脚本本体"）。

可直接复用的成品脚本见 `scripts/install-skills-portable.ps1`；16 条踩坑清单与验收记录见
`references/skill-install-handoff.md`。

### 0.6 方式 B：直接复制安装（纯 SKILL.md 仓库，不用 npx）

mattpocock/skills 这类仓库本身就是 `skills/<category>/<skill>/SKILL.md` 结构，**SKILL.md
frontmatter 的 `name`/`description` 与 Hermes 兼容**，直接复制进 Hermes 技能目录即可
（新技能**当前会话**即被 skills_list 识别，无需重启）：

```powershell
$src = 'D:\...\skills\skills\engineering'   # 仓库里的技能分类目录
$dst = 'C:\Users\<user>\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\skills'
Get-ChildItem $src -Directory | ForEach-Object {
    if (Test-Path "$dst\$($_.Name)") { "SKIP(exists): $($_.Name)" }   # 同名冲突跳过，不覆盖
    else { Copy-Item $_.FullName "$dst\$($_.Name)" -Recurse; "INSTALLED: $($_.Name)" }
}
```

- 兼容性说明：`agents/openai.yaml` 只是界面元数据（display_name/short_description），
  **纯提示词技能集没有任何 API key / 模型接口配置可填**——不要浪费时间找配置项。
- 带脚本的技能（如 eze-is/web-access 的 scripts/*.mjs）整个仓库目录复制（含 scripts/、
  templates/、references/），SKILL.md 里的 `${CLAUDE_SKILL_DIR}` 变量在 Hermes 下不存在，
  手动运行时替换为实际路径。
- 装完用 `skills_list` 验证注册（本会话 17+1 个技能全部一轮识别成功）。

### 2. 装前安全扫描（必做）

所有第三方技能默认不可信。先克隆仓库（或扫描 .agents/skills 装好后的目录），用
SkillSpector 逐个技能目录扫描（详见 skill-security-scan 技能）：

```bash
git clone --depth 1 https://github.com/<owner>/<repo>.git
# 对仓库下每个技能子目录单独扫描（整目录 --recursive 扫描可能 JSON 解析失败，见下）
skillspector scan <repo>/skills/<skill> --no-llm --format json
```

### 3. 执行安装

```bash
npx skills add <owner>/<repo> --yes      # 免交互安装
# 或 --skill <name> 只装指定技能
```

### 4. 同步到 Hermes（关键步骤，常被忽略）

```powershell
$src = "D:\Hermes文件库\.agents\skills"          # npx 实际安装位置（CWD 相对）
$dst = "C:\Users\<user>\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\skills"
Get-ChildItem $src -Directory | ForEach-Object {
    $target = "$dst\$($_.Name)"
    if (-not (Test-Path $target)) { Copy-Item -Recurse $_.FullName $target }  # 不覆盖同名内置技能
}
```

### 5. 验证 Hermes 识别

`skills_list`（或 `hermes skills list`）确认新技能出现。新会话自动加载。

## 已知优质技能集合

| 集合 | 内容 | 扫描结果 |
|------|------|------------------|
| **mattpocock/skills** | **18** 个（engineering 分类）。仓库自带 `skills/<category>/<skill>/SKILL.md` 结构，**走方式 0.6 纯复制**，不用 npx。特征文件：`agents/openai.yaml` + `PHASE-BOUNDARIES.md`。**安装后目录名不带分类前缀**（源码在 `skills/engineering/code-review/`，落到 Hermes 是 `skills/code-review/`） | 纯提示词，无脚本 |
| **addyosmani/agent-skills** | **25** 个软件工程方法论技能（TDD/spec-driven/security-hardening/performance/constraint-driven-development 等）。**走 npx**（方式 3+4） | 2026-08：18 个 0-20 分 LOW；6 个 21-45 分 MEDIUM（均为方法论提示词，无恶意代码）；无 HIGH/CRITICAL。可信源 |
| **peterskoett/self-improving-agent** | 给技能起名 `pua-debugging`。**技能嵌在同名子目录里**（`仓库根/self-improving-agent/SKILL.md`），根目录无 SKILL.md 也无 skills/ —— **必须靠递归兜底扫描才能装到**，否则静默跳过 | 含 hooks/scripts/references，子文件要一起拷 |
| **hugohe3/ppt-master** | 原生可编辑 PPTX 生成工作流（真母版/原生形状/可改数据图表/OMML 公式/旁白/动画/自运行视频），v6.6.0，55.6k stars，MIT | 2026-09：skillspector 报 CRITICAL/100 分为**模板误报**（见上节）。含 83 个 Python 脚本，需装 requirements.txt。可信源，已安装 |
| **Nutlope/hallmark** | 反 AI-slop 设计技能（29.2k stars），`references/` 下 100+ 主题/版式/组件 md | 装法 `npx skills add nutlope/hallmark`。README 明确列出落点 `~/.claude/skills/hallmark/` |
| **op7418/Humanizer-zh** | 中文去 AI 味（README 注明翻译自 `blader/humanizer`） | 装法 `npx skills add https://github.com/op7418/Humanizer-zh.git` |
| **Panniantong/Agent-Reach** | 给 agent 装互联网能力（Jina Reader/B站/YouTube/V2EX/RSS 等零配置渠道） | `pip install agent-reach`（CLI 自带 yt-dlp/feedparser），技能目录含 SKILL.md |

## 多 AI 工具联动

部分安装器（如 officecli 的 `irm https://d.officecli.ai/install.ps1 | iex`）会自动装到
多个目录：`~/.hermes/skills/`、`~/.claude/skills/`、`~/.agents/skills/`、`~/.copilot/skills/`，
一次性覆盖 Hermes/Claude Code/Codex/Copilot。这类安装器无需手动同步，装完验证二进制即可
（如 `officecli --version`）。

## 陷阱

- **npx skills 装到 CWD 相对目录**：在哪个目录执行命令就装到哪里的 `.agents/skills/`。
  忘同步 = 装了但 Hermes 永远加载不到。
- **同名冲突**：同步时跳过 Hermes 已存在的同名技能（如内置 test-driven-development），
  避免覆盖官方版本。
- **PowerShell 后台下载慢**：`irm ... | iex` 类安装器可能超时，用
  `terminal(background=true, notify_on_complete=true)` 跑，完成后再验证。
- **exe 路径转换**：WSL 里调 Windows 侧安装的 exe 用 `/mnt/c/...` 全路径，Windows 侧直接命令名。
- **PowerShell 里 git clone 别用 `2>&1 | Select-Object` 管道**（2026-08 实测）：git 进度/stderr
  经管道被包装成 `NativeCommandError` 噪音，批量多仓库 clone 会疑似卡死（实际 8 分钟无进展）。
  做法：**逐仓库单独 clone（不接管道）**，`--depth 1`，前台跑；卡住就 kill 后改用
  api.zipball 兜底。
- **WSL 网络整体不可达时（curl baidu 都超时）**：全部转 Windows 侧——git clone（VPN 分流在
  Windows 上正常工作）+ `uv python install 3.12` + `uv venv --python 3.12` +
  `uv pip install -e <repo> -p ./.venv/Scripts/python.exe`；项目文件放 /mnt/d 侧共享。
  WSL 排错顺序：`wsl --shutdown` 重启 → 仍不通直接转 Windows，别耗在代理/TUN 排查上。
- **清华 PyPI 源会 403 拦住 pip**（2026-09 实测，**非网络故障，别去查代理**）：`pypi.tuna.tsinghua.edu.cn`
  对 pip 的 UA 返回 `403 Client Error: Forbidden`，curl 同 URL 却 200。症状极具误导性——
  pip 报 `ERROR: Could not find a version that satisfies the requirement X (from versions: none)`，
  看起来像"包不存在/没有适配版本"，实际是源被拒。**别靠猜，直接 -vv 看真实 HTTP 码**：
  ```powershell
  python3.14 -m pip install <pkg> -i https://pypi.tuna.tsinghua.edu.cn/simple -vv 2>&1 |
      Select-String -Pattern "GET /simple|403|Skipping"
  # 命中 `"GET /simple/xxx/ HTTP/1.1" 403 None` → 换源，不要再 debug 依赖解析
  ```
  换**阿里云源**（2026-09 实测落盘 40+ 包一次成功）：
  ```powershell
  python3.14 -m pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
  ```
  本机可用 python 解释器名是 `python3.14`（`python3`/`python` 均不存在）。
- **需求清单里有部分包在源上缺失时，整条 `pip install -r` 会整体失败**，报的却是第一个包的
  `from versions: none`，误导性极强。拆装定位：把可疑包单独 `pip install <pkg> -vv` 看 HTTP 码，
  或逐组装（先 `python-pptx XlsxWriter Pillow numpy` 这类纯轮子，再装重编译依赖）。
- **skillspector 输出落盘**：`--output <path>.json` 用对了，但 `*>` 重定向经 PowerShell 会转成
  UTF-16（首字节 `0xff`）→ `json.load` 报 `UnicodeDecodeError: invalid start byte`。
  用 `--output` 参数而不是 shell 重定向；万一手上有 UTF-16 残留，读时用 `encoding='utf-16'`。
- **JSON 解码兜底**：PowerShell 管道/重定向中转过的 JSON 可能带 BOM，`json.load` 报
  `Unexpected UTF-8 BOM`。用 Python 读时统一 `encoding='utf-8-sig'`。
- **PS 调 python 内联脚本**（`-c "..."`）读文件用 `'D:\...'` 原始字符串，别在双引号里塞
  `r'D:\...'`——反斜杠会被 PS 吃掉，报找不到文件。
- **仓库结构判断别只认"根目录有 SKILL.md"和"根目录下有 skills/"两种情况**（2026-09 实测 bug，
  最隐蔽的一个）：有些仓库把技能嵌在**同名子目录**里。实测 `peterskoett/self-improving-agent`
  布局是 `仓库根/self-improving-agent/SKILL.md`，根目录既无 `SKILL.md` 也无 `skills/`——
  两种情况都不命中 → 落到 `MANUAL` 分支**静默跳过**，你以为只是"需要人工"，实际是脚本漏装。
  **正确做法：clone 完之后，对整棵工作目录补一次递归兜底扫描**：
  ```powershell
  Get-ChildItem $WORK -Recurse -Filter 'SKILL.md' -EA SilentlyContinue |
      Where-Object { $_.FullName -notmatch '\\node_modules\\|\\\.git\\' } |
      ForEach-Object {
          $src = $_.Directory
          # 技能名优先取 name: 字段，比目录名可靠（目录名可能是仓库名）
          $n = (Select-String -Path $_.FullName -Pattern '^name:\s*(.+)$' -List -EA SilentlyContinue).Matches.Groups[1].Value.Trim()
          if (-not $n) { $n = $src.Name }
          $n = $n -replace '[\\/:*?"<>|]', ''
          $dst = Join-Path $SKILLS $n
          if (-not (Test-Path $dst)) { Copy-Item $src.FullName $dst -Recurse }
      }
  ```
- **`.ps1` 含中文必须存成 UTF-8 BOM**（2026-09 实测，报错极具误导性）：`write_file` 写出的是
  **无 BOM** 的 UTF-8，PowerShell 5.1 按 GBK 解码 → 中文字符串被撕裂 → 报**假语法错误**
  `表达式或语句中包含意外的标记"}"`，行号指向字符串所在行。
  **辨识法**：报错行附近有中文，且 `Get-Content` 读出来是乱码 → 编码问题，不是语法问题。
  修复（`$true` = 写 BOM）：
  ```powershell
  $t = [System.IO.File]::ReadAllText($p, [System.Text.UTF8Encoding]::new($false))
  [System.IO.File]::WriteAllText($p, $t, [System.Text.UTF8Encoding]::new($true))
  ```
  验证首 3 字节应为 `239,187,191`。⚠️ **每次 `patch` 之后都要复查 BOM**，可能丢失。
- **验证仓库存在性时 `curl` 必须加 `-L`**（2026-09 实测）：仓库被改名时 GitHub API 返回
  **301 重定向**，不加 `-L` 会把**有效仓库误判成不存在**而静默跳过。
  实测 `peterskoett/self-improving-agent` 返 301，加 `-L` 后 200。
  ```powershell
  curl.exe -sL -o NUL -w "%{http_code}" --max-time 20 https://api.github.com/repos/<owner>/<repo>
  ```
- **改自定义函数名必须同步改所有调用点**（2026-09 实测崩溃点）：把 `Test-RepoExists` 改名成
  `Assert-RepoExists` 时漏改 2 处调用，脚本一跑就 `CommandNotFoundException` 中止。
  另外 **PS 函数名别用 `Test-*` 前缀**（保留动词，与 `Test-Path` 冲突）。
- **PowerShell 里 `"$VAR-suffix"` 会把后缀吃进变量名**（2026-09 实测）：`"$STAGE-DESCRIPTION.md"`
  被解析成变量 `$STAGE-DESCRIPTION`（未定义 → 空）再拼 `.md`，路径变成乱码。
  **必须用 `${}` 界定边界**：`"${STAGE}-DESCRIPTION.md"`。带连字符/下划线的拼接一律这么写。
- **校验 zip 结构时注意分隔符**（2026-09 实测，差点误报）：`Compress-Archive` 产出的
  zip 条目用**反斜杠** `\` 分隔（`skill\SKILL.md`），用 `/` 的正则去匹配会全部落空，
  误判成"结构被拍平"。写检查脚本时用 `[\\/]` 或先 `-replace '\\','/'` 再匹配。
- **`.ps1` 交付前必跑三项检查，缺一不可**（只跑语法检查会漏掉真 bug）：
  ```powershell
  $e=$null;$t=$null
  $ast = [System.Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$e)
  # 1) 语法
  if($e){$e[0].Message}else{"OK"}
  # 2) 悬空函数调用（改名漏改就在这暴露）
  $defined = $ast.FindAll({$args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst]},$true) |
             ForEach-Object { $_.Name }
  $called  = $ast.FindAll({$args[0] -is [System.Management.Automation.Language.CommandAst]},$true) |
             ForEach-Object { $_.GetCommandName() } | Where-Object { $_ } | Select-Object -Unique
  $called | Where-Object { $_ -match '^(Assert|Sync|Resolve|Import)-' -and $_ -notin $defined }
  # 3) 关键函数用假数据实测（造个目标结构的临时目录跑一遍）
  ```
  实际解析出来的函数名可用 `$ast.FindAll(...)` 打印核对，比 `Select-String` 正则可靠。
- **仓库可能根本不是技能包**：`Panniantong/Agent-Reach` 是完整应用仓库（`scripts/ config/ tests/`，
  根目录无 `SKILL.md` 也无 `skills/`），需 `pip install` 后单独取 SKILL 文件，
  别指望脚本自动装——**这类应该直接告诉用户"不装"，而不是发明一套流程**。
- **仓库可能自带杂项目录**：如 ppt-master 会带进 `.claude-plugin/`（只有 `plugin.json`），不是技能。

## GitHub 被阻断时的备选下载路径（2026-08 实测）

VPN/代理**部分分流**时常见：`api.github.com` 通（200），但 `github.com` 主站超时
（git clone / `hermes plugins install` 内部 clone 都走主站 → `Connection was reset`）。
诊断方法：

```powershell
curl.exe -sL -o NUL -w "github.com: %{http_code} (%{time_total}s)" --max-time 15 https://github.com
curl.exe -sL -o NUL -w "api.github.com: %{http_code} (%{time_total}s)" --max-time 15 https://api.github.com
# 期望: api 通 + 主站 000/超时 → 走 zipball 路径
```

**zipball 手动下载工作流**（git clone 失败时的兜底，通用）：

```powershell
# 1. 下载仓库 ZIP（走 api 通道，通常通）
$out = "$env:TEMP\repo.zip"
curl.exe -sL --max-time 60 -o $out "https://api.github.com/repos/<owner>/<repo>/zipball/main"
# 2. 解压（ZIP 内是 <owner>-<repo>-<sha>/ 一层目录）
Expand-Archive -Path $out -DestinationPath "$env:TEMP\extract" -Force
# 3. 找到真实根目录，再按需复制到目标位置（skills/、plugins/ 等）
```

> 分支名不确定时先查 `https://api.github.com/repos/<owner>/<repo>` 的 `default_branch`；
> 也可用 `zipball/<tag>` 下载特定版本。

**优先查作者官方国内镜像**：`github.com` 主站 000 时，先看 README 有没有 AtomGit/Gitee 镜像
徽章，有就直接 clone 镜像（2026-09 实测 `atomgit.com` 1.5s 拉完 115MB，比 zipball 兜底快得多）：

```powershell
curl.exe -sL -o NUL -w "github.com: %{http_code}`n" --max-time 20 https://github.com
curl.exe -sL -o NUL -w "atomgit:    %{http_code}`n" --max-time 20 https://atomgit.com
# atomgit 200 且仓库是 hugohe3/xxx 这类同名映射 → git clone https://atomgit.com/<owner>/<repo>.git
```

## 安全扫描误报识别（重要，别被 CRITICAL 吓退）

**SkillSpector 对"工作流/模板密集"型技能会给出严重误报**：2026-09 实测 ppt-master
（55.6k stars / MIT）扫描报告 `score 100 / CRITICAL / DO_NOT_INSTALL`，逐条核对后**全部为误报**。
**不要因为分数就直接拒绝安装**——按类别核对证据再下结论：

| 误报模式 | 典型信号 | 真实含义 |
|---|---|---|
| **Hidden Instructions**（本项目 1042 条，占全部 HIGH 的 94%） | `finding` 是 SVG 里的 `<!-- Area Chart Template -->`、XML `<metadata>` | 模板文件的**注释和元数据**，不是提示注入。扫描器把 `.svg`/`.md` 模板里的所有注释都算了进去 |
| **Credential Access / Env Variable Harvesting** | `os.environ.get("GEMINI_API_KEY")`、代码里出现 `.env` | 技能**读自己的** API key，正常配置行为 |
| **Cloud Metadata Access / SSRF** | 出现 `169.254.169.254` | 多半是仓库**自带的安全测试用例**（专门测拦不拦），不是攻击载荷 |
| **Tool Parameter Abuse** | `--skip-validation`、`--force` | 脚本自身的合法开关 |

**核对方法**（一条命令看穿分布，别逐条读 1200 条）：
```powershell
skillspector scan <skill_dir> --no-llm --format json --output <path>.json
```
```python
import json,io,collections
d=json.load(io.open(r'<path>.json',encoding='utf-8'))
iss=d['issues']; print(d['risk_assessment'])
print('HIGH/CRIT:',sum(1 for i in iss if i['severity'] in ('HIGH','CRITICAL')))
for p,c in collections.Counter(i['pattern'] for i in iss if i['severity'] in ('HIGH','CRITICAL')).most_common(12):
    print(c,'|',p)
print(collections.Counter(i['location']['file'].split('/')[0] for i in iss).most_common(6))  # 集中在 templates/ 就是模板误报
for i in iss[:3]: print(i['location']['file'], i['location']['start_line'], i['finding'][:200])
```
判据：**命中高度集中在 `templates/` + 文件名是 `.svg`/`.md` → 模板误报**；判定真实恶意要看
是否有**出站网络 + 读取技能目录之外的凭据文件**的组合。核对完把结论写进给用户的报告
（哪些是误报、依据是什么），而不是甩一个 CRITICAL 分数。

## 装带 Python 依赖的技能（非纯提示词技能）

2026-09 实测流程（ppt-master 80MB / 83 个脚本）：

1. `git clone`（走镜像）→ `python3.14 scripts/attribution_guard.py`（若仓库自带完整性校验，
   **退出码非 0 就停，不要绕过**）
2. 依赖：`pip install -r skills/<skill>/requirements.txt`（换阿里云源，见上方陷阱）
3. 整个技能目录 `Copy-Item -Recurse` 到 Hermes skills 目录（含 `scripts/`/`references/`/
   `templates/`/`workflows/`）
4. 验证：`hermes skills list` 里出现且 `enabled`；`skills_list` 显示 `readiness_status: available`；
   跑一个核心脚本 `--help` 确认依赖装齐
5. 附带告知用户：**模型能力决定产出上限**（如 ppt-master 官方推荐 Kimi K3/Claude 长上下文），
   当前弱模型能跑通流程但质量有差距——这是使用前提，不是故障
6. 依赖里仅转换 PDF 才需要的 `PyMuPDF` 是 **AGPL-3.0**（非 MIT），介意协议时不装该项

> **装完别急着收工**：大型技能（如 ppt-master）自带强制流程和 BLOCKING 确认门，
> 用户紧接着就会让你用它干活。**使用/排障方法见 `ppt-master-ops` 技能**——
> 先看它的第 2 节（确认门）和第 3 节（项目路径带日期后缀），能省掉一轮报错。
