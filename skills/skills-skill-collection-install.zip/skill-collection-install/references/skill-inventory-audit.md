# 技能盘点与审计：内置 vs 后天安装、来源反查（原独立技能 skill-inventory-audit，2026-10 并入 skill-collection-install）

# 技能盘点与审计

反向任务：不是「装技能」，是**搞清楚现在已经装了什么、从哪来的、怎么复现**。
安装方向见 `skill-collection-install`。

## 0. 权威四要件（先读这四个，别靠猜）

| 文件 | 作用 | 注意 |
|---|---|---|
| `skills\.bundled_manifest` | **官方内置名单**（`名称:md5` 每行一条） | 权威。在这份名单里的 = 随 Hermes 发布，**不是用户装的**，无需也无法「复现安装」 |
| `skills\.hub\lock.json` | Hub 正式安装记录 | 常是 `{"version":1,"installed":{}}` → 说明**没走 `hermes skills install`**，别去 hub 找 |
| `skills\.hub\taps.json` | 注册的技能源 | 只有 14 字节，说明没配 tap |
| `skills\.hub\audit.log` | Hub 安装审计 | 常为 0 字节 |
| `skills\<skill>\_meta.json` | **虾评平台来源标记** | 有它 = 从虾评（xiaping.coze.com）装的。字段：`ownerId`/`slug`/`version`/`publishedAt` |

> ⚠️ `.hub\taps.json` 等被 Hermes 标记为内部文件，**直接读会被拦**
> （`Access denied: ... internal Hermes cache file`）。用 `skills_list` / `skill_view` 代替。

## 1. 分流：内置 vs 后天装

```powershell
$s = "$env:LOCALAPPDATA\Hermes Agent CN Desktop\data\hermes-home\skills"
$bundled = Get-Content "$s\.bundled_manifest" | ForEach-Object { ($_ -split ':')[0] }
"内置 $($bundled.Count) 个"
Get-ChildItem $s -Recurse -Filter SKILL.md | ForEach-Object {
  $n = (Select-String -Path $_.FullName -Pattern '^name:\s*(.+)$' -List).Matches.Groups[1].Value.Trim()
  if ($n -notin $bundled) { "后天: $n" }
}
```

**注意**：`CreateTime` 全是同一分钟 = 那次是**整个 skills 树被一次性写入**（版本升级/迁移），
**不能用时间戳判断「哪些是后天装的」**。必须用 `.bundled_manifest` 做集合差。

## 1.5 精简/归档闲置技能（curator 工作流，2026-10-15 实战）

**症状**：「装了一堆技能却不会被用」——根因不是模型变笨，是 **stale 技能照样进 prompt**，
大量 never-used 技能稀释触发词判断。实测：135 个自建技能里 98 个 stale 却全在列表里。

**权威工具**：`hermes curator`（**勿手删 skills 文件夹**，会破坏索引）。

```powershell
# 1) 看总体状态（agent/bundled 计数、stale 数、归档门槛）
hermes curator status
# 2) 全量使用遥测（use/view/patch/act/last_activity + origin）★最有用
hermes curator usage
# 3) 看已归档的
hermes curator list-archived
# 4) 归档单个技能（移入 .archive\，可恢复）
hermes curator archive <name>
# 5) 恢复
hermes curator restore <name>
```

**筛选策略**（按 `usage` 输出定名，别凭印象）：
- 只归档 `origin=agent` 且 `use=0 view=0 patch=0 last=never` 的（bundled 的 curator 本就不碰）
- **保留**有实际关联领域的 never 技能（如用户装了 CAD 就留 cad 类）
- 同义重复组：**保留最新版本号 / activity 最高的一份**，其余归档

**配置收紧（防再膨胀）**（键名已实测有效）：
```powershell
hermes config set curator.archive_after_days 45   # 默认90太保守
hermes config set curator.consolidate true        # 开LLM语义合并（默认false）
# 另可调 curator.stale_after_days（默认30）
```

**⚠️ PowerShell 坑**：`hermes` 是 `.cmd`，直接 `& hermes ...` 会被判后台符拒绝 →
用 `Start-Process -FilePath $hb -ArgumentList @("curator","usage") -NoNewWindow -Wait
-RedirectStandardOutput $log`，输出从 `$log` 读（`Get-Content $log -Encoding UTF8`）。

**实测战绩**：195→147（agent 123→75），归档 49 个，零误伤、全部可 restore。

## 2. 反查来源（三条独立证据链）

### 2a. frontmatter 里的显式字段（最可靠，先搜这个）

```powershell
Get-ChildItem $s -Recurse -Filter SKILL.md | ForEach-Object {
  $h = Get-Content $_.FullName -TotalCount 25 -Encoding UTF8
  $g = $h | Select-String -Pattern '^\s*(github|source|repo|homepage)\s*:\s*(\S+)'
  if ($g) { "$($_.Directory.Name) -> $($g.Matches.Groups[2].Value)" }
}
```

### 2b. 特征文件指纹（无 github 字段时的兜底）

| 指纹 | 来源 |
|---|---|
| `agents/openai.yaml` + `PHASE-BOUNDARIES.md` 同时存在 | **mattpocock/skills**（纯复制安装，目录名不带分类前缀） |
| 目录里有 `_meta.json` | **虾评平台** |
| `README.md` 内含 `npx skills add <url>` | 读 README 直接拿到官方安装命令（humanizer-zh 就是这样查到的） |
| 有 `scripts/` + `requirements.txt` + `attribution_guard.py` | ppt-master 类「带脚本的重型技能」，装法见 skill-collection-install 末节 |
| `INSTALL.md` + `manifest.toml` | **cjke84/agent-memory-system-guide**（有官方安装清单） |
| `hooks/openclaw/` + `scripts/extract-skill.sh` | self-improving-agent 系（`peterskoett/self-improving-agent`） |

### 2c. npx 落点取证

`npx skills add` 装到 **CWD 相对**的 `./.agents/skills/`，同时 symlink 到 `~/.claude/skills/`。
这个目录里的内容就是 **npx 安装过什么**的铁证：

```powershell
Get-ChildItem "D:\<workspace>\.agents\skills" -Directory | Select-Object -ExpandProperty Name
Get-ChildItem "$env:USERPROFILE\.claude\skills" -Directory -ErrorAction SilentlyContinue
```

⚠️ 只有走了 npx 的仓库会在这里留痕（本机：只有 addyosmani 那 24 个）；
mattpocock 走纯复制、agent-reach 走 pip，**都不会出现在 `.agents/skills`**——
所以这条链只能证伪、不能单独定性。

### 2d. 验证 GitHub 来源真实性（必做）

名字可能是错的或臆造的。用 API 批量验：

```powershell
# ⚠️ -L 必须加！仓库改名时 GitHub API 返回 301，不加 -L 会把有效仓库误判成不存在
function chk($u){ "$(curl.exe -sL -o NUL -w '%{http_code}' --max-time 15 $u)  $u" }
chk "https://api.github.com/repos/<owner>/<repo>"
# 404 时用搜索找真仓库（大小写也会影响，GitHub 仓库名大小写不敏感但显示保留原样）
curl.exe -s --max-time 20 "https://api.github.com/search/repositories?q=<kw>+in:name&sort=stars&per_page=5" |
    Select-String '"full_name"|"stargazers_count"'
```

**搜索要挑对关键词**：`hallmark` 直接搜 name 命中的是 `Nutlope/hallmark`(29k) 而
`obra/hallmark` 是 404；`pua-debugging` 搜仓库名搜不到，但**在 SKILL.md 正文里**能搜到
`peterskoett/self-improving-agent` —— 所以搜不到时先 grep 技能正文的 `github.com/` 全量出现，
再下「来源不可考」的结论：

```powershell
Get-ChildItem $s -Recurse -Filter SKILL.md | ForEach-Object {
  $m = Select-String -Path $_.FullName -Pattern 'github\.com/[\w\-\.]+/[\w\-\.]+' -AllMatches -Encoding UTF8 |
       ForEach-Object { $_.Matches.Value }
  if ($m) { "$($_.Directory.Name) :: " + (($m | Select-Object -Unique) -join ', ') }
}
```

> ⚠️ 这个正则会把技能正文里**引用的第三方项目**一并捞出来（如 `comfyui` 命中
> `comfyanonymous/ComfyUI` 是它调用的工具，不是技能来源）。**命中多个时要人工判断哪个是来源**，
> 别机械地取第一个。

## 3. 输出规范（用户明确要「清单 + 安装方式」时）

按**安装方式**分组，不是按目录顺序罗列——别人的 agent 要的是「照这个命令敲」。五类：

| 方式 | 适用 | 命令模板 |
|---|---|---|
| A `npx skills add` 后**必须手动同步** | 走 npx 的集合 | `npx skills add <owner>/<repo> --yes` + Copy-Item 循环 |
| B 直接复制（纯 SKILL.md 仓库） | mattpocock 类 | `git clone --depth 1` + `Copy-Item -Recurse` |
| C 单技能仓库 | web-access / hallmark / humanizer-zh | `npx skills add <owner>/<repo>` 或 clone |
| D 平台分发 | 虾评 `_meta.json` | 见 `xiaping` 技能 |
| E 官方内置 | `.bundled_manifest` 名单 | 无需安装 |

**必须附的两条坑**（别的 agent 最容易踩）：
1. `npx skills` 装到 CWD 相对目录 `.agents/skills/`，不同步 = 装了却永远加载不到。
2. 同步时**同名跳过**，别覆盖内置版（本机 `test-driven-development` 内置版与 mattpocock 版**并存**）。

**事实与推断要分开写**：本机 45 个后天技能里，能从 `_meta.json`/`github:` 字段/
`.agents` 落点**确证**来源的只有一部分；对查不到的（如 `content-multi-platform` /
`ai-text-humanizer`）用 2d 的正文 grep 再试一轮，仍查不到才标 **「来源不可考」**——
清单里要如实标注，不要为了「完整性」编造仓库地址。

> 已确证修正（2026-09）：`pua-debugging` **不是**「来源不可考」——它来自
> `peterskoett/self-improving-agent`（正文內含该仓库地址），同一仓库也是
> 虾评 `_meta.json` 标记的 `self-improving-agent` 的 GitHub 源头。

## 4. 导出给别人用

```powershell
# 单个技能导出
Compress-Archive -Path "$s\jlu-knowledge-ops" -DestinationPath "jlu-knowledge-ops.zip"
```

导出清单写成 `.md` 而非只发压缩包——**清单是跨 agent 可读的，压缩包不是**。
批量导出脚本见 `scripts/inventory_skills.ps1`（一条命令出清单，含内置/后天分流）。

> **现成素材**：
> - `references/verified-skill-sources.md` —— 本机全部第三方来源仓库（含技能集合成员名单、
>   误判纠正记录、不可迁移资产清单），**已经过 200 验证**，直接拿去生成交接清单。
> - `templates/install-skills.ps1` —— 可复制修改的幂等安装脚本骨架（含 BOM 处理、
>   仓库预验证、AtomGit 兜底、单技能仓库容器化同步）。

### 4b. 交接包（用户要「直接发给别的 agent」时）

产物三件套，缺一不可：

| 文件 | 内容 |
|---|---|
| `<topic>-handoff.md` | 来源总表 + 安装方式分组（A–E）+ 踩坑清单 + 私有资产说明 |
| `install-skills.ps1` | **幂等**一键脚本（同名跳过）、clone 前预验证仓库、AtomGit 镜像兜底 |
| 回复里的一段**可直接粘贴的指令** | 用户最终要的是「复制这段发给豆包」 |

脚本骨架：`Sync-Skills`（拷目录、同名 SKIP）+ `Assert-RepoExists`（curl -sL 验 200）+
`[ordered]@{}` 仓库表 + 镜像兜底 + 单技能仓库装进临时容器再整体同步。

### 4c. ⛔ 交付 `.ps1` 前必须过这两道验证（本会话实测踩到）

**别只做语法检查就交付——语法通过 ≠ 逻辑正确。** 两道都要跑：

```powershell
$p = "install-skills.ps1"
# ① 语法
$e=$null;$t=$null
[System.Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$e) | Out-Null
if($e){ $e|ForEach-Object{"行$($_.Extent.StartLineNumber): $($_.Message)"} } else { "语法OK" }
# ② 编码（首 3 字节必须是 239,187,191 = UTF-8 BOM）
"BOM: $(([System.IO.File]::ReadAllBytes($p))[0..2] -join ',')"
# ③ 关键函数实测（抽出来单独跑，别只信语法）
```

**坑 1：`.ps1` 含中文必须带 UTF-8 BOM。** `write_file` 产出的 UTF-8 **无 BOM**，
PowerShell 5.1 按 GBK 解码 → 中文字符串被撕裂 → 报**假语法错误**
（`表达式或语句中包含意外的标记"}"`，行号指向中文字符串所在行）。
**辨识**：报错行附近有中文 + `Get-Content` 读出来乱码 = 编码问题，不是语法问题。
修复：

```powershell
$t = [System.IO.File]::ReadAllText($p, [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText($p, $t, [System.Text.UTF8Encoding]::new($true))  # $true=写BOM
```

> `patch` 改过 `.ps1` 后 BOM 可能丢失，**每次 patch 完都要复验一次**。

**坑 2：PowerShell 函数名别用 `Test-*` 前缀**（保留动词，与 `Test-Path` 冲突），
用 `Assert-RepoExists` 这类自定义动词。

**坑 3：交付脚本前必须实跑关键函数，别只靠语法通过。** 本会话正是靠实跑才发现
`Assert-RepoExists` 因缺 `-L` 把 301 的 `peterskoett/self-improving-agent` 误判为不存在
→ 会**静默跳过安装**。实测后 10/10 仓库全部 200。**这是「status=passed 就报完成」的同类错误。**

## 5. 重复技能识别（顺手做，用户很在意）

盘点时把**同领域技能数**一并报出来并给合并建议。本机实测的高重复区：

| 领域 | 数量 | 状态 |
|---|---|---|
| Minecraft 排障 | 11 个 | 严重重叠（`minecraft-modpack-ops` / `-troubleshooting` / `-support` / `-debug` 等讲同一件事） |
| 吉大知识库 | 5 个 | 重叠（`jlu-academic-ops` / `jlu-campus-info` / `jlu-student-affairs` / `jlu-student-ops` / `jlu-knowledge-ops`） |
| 虾评平台 | 6 个 | 重叠（`xiaping` / `-ops` / `-field-notes` / `-operations` / `-practical-tips` / `-skill-ops`） |
| Hermes 运维 | 9 个 | 部分重叠 |

> 合并交给后台 curator 做，**你只需在回复里报出重叠**并用一句话问用户是否合并。
> 不要自作主张删技能。

## 陷阱

- **别用文件时间戳判断来源**：整树一次性写入会让所有 CreateTime 相同（见 1 节）。
- **`.hub\taps.json` 读不了**（Access denied），别硬读，用 skills_list/skill_view。
- **PS 读中文 SKILL.md 必须加 `-Encoding UTF8`**，否则输出乱码（本机实测
  `pua-debugging` 的中文描述全成 `涓€涓` 乱码）——乱码不是文件损坏，是读取编码错。
- **`ConvertFrom-Json` 读 `_meta.json` 直接可用**（它是标准 UTF-8 JSON）。
- **同一个 skill 名可能出现在两个目录**（内置版 + 第三方版），清单里要分别标注，
  否则用户以为只装了一份。
- **别把「内置技能」也算成用户的安装成果**——73 个内置是 Hermes 给的，用户实际
  新增的是剩余那部分。报数字时说清哪个是哪个。
