# 技能库跨 agent 交接实录（2026-09）

把本机 50 个第三方技能迁移到**豆包 agent** 的完整过程与踩坑。适用于"把技能库/知识库交给
另一个 agent"这类任务，不是单次安装。

---

## 一、交付版本（2026-09-27 最终）

| 文件 | 作用 |
|---|---|
| `scripts/install-skills-portable.ps1` | 路径自适应 + 嵌套兜底的安装脚本 |

**实测结果**：目标端装出 **50 个技能，50 个带 SKILL.md，0 残缺**。

来源分布（**权威数字，别再写错**）：

| 来源 | 数量 | 装法 |
|---|---|---|
| addyosmani/agent-skills | **25**（含 `constraint-driven-development`） | npx + 手动同步 |
| mattpocock/skills | **18**（含 `research` `wizard`） | 纯复制 `skills/engineering/` |
| 独立单技能仓库 | **7** | clone |
| 虾评平台 | 1（`self-improvement-skill`） | 人工从平台下载 |
| **合计** | **50** | |

> 早期版本注释里写的 24/16 是错的，实测按 25/18。**统计数字要么实测，要么别写。**

---

## 二、对方 agent 会提出的三点合理质疑（提前预防）

1. **"脚本没给我"** —— 只发 `MEDIA:D:\...` 这种本机附件语法是**无效交付**。
   对方 agent 会去 `Downloads/ Desktop/ %TEMP%/` 找，然后报"没有脚本本体"。
   **交付方式必须是粘贴脚本文本**（或让用户手动拖文件）。

2. **"你假设我是 Hermes"** —— 写死 Hermes 路径的脚本在别的 agent 上会装错地方。
   实测豆包的真实技能根：`C:\Users\<user>\Doubao\skills`（还有 `.agents\skills` 通用目录）。
   必须 `-SkillsRoot` 参数 + 自动探测。

3. **"先审阅再执行"** —— 对方拒绝直接 `-ExecutionPolicy Bypass -File` 跑未审阅脚本是**正确原则**。
   主动交代脚本的写操作范围（本脚本只有：`git clone`/`npx` 到 `%TEMP%` + `Copy-Item` 到技能目录，
   不碰注册表/系统目录/环境变量），能直接消除疑虑。

---

## 三、我方脚本被对方复核抓出的真 bug

**这是本次最有价值的教训：外部复核发现了我自测漏掉的 bug。**

### bug 1：嵌套子目录的技能被静默跳过

- **症状**：脚本把 `peterskoett/self-improving-agent` 报成 `MANUAL`，需要人工补装。
- **根因**：结构判断只写了两种情况 `Test-Path "$dir\SKILL.md"` 和 `Test-Path "$dir\skills"`。
  而该仓库实际布局是 `仓库根/self-improving-agent/SKILL.md`，两种情况都不命中。
  GitHub API 证实根目录只有 `.github/`、`README.md`、`self-improving-agent/`。
- **修复**：加递归兜底扫描（见脚本 C2 段）。
- **为什么自测没发现**：本机 Hermes 侧的 `pua-debugging` 是**从虾评平台装的**（目录名直接是技能名），
  **根本没走过这个仓库**。→ 教训：**验证要覆盖真实代码路径，别用另一条来源的产物冒充验证。**

### bug 2：函数改名漏改调用点

- 把 `Test-RepoExists` 改名成 `Assert-RepoExists` 时漏改 2 处调用 → 一跑就 `CommandNotFoundException`。
- 用 AST 静态检查才抓到（语法检查**查不出这个**）。

---

## 四、验收清单（交付 .ps1 前逐项跑）

```powershell
$p = "install-skills.ps1"
$e=$null;$t=$null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$e)

# 1) 语法
if($e){"❌ 行$($e[0].Extent.StartLineNumber): $($e[0].Message)"}else{"✅ 语法通过"}

# 2) 编码 BOM（中文脚本必需；patch 后要复查）
"BOM: $(([System.IO.File]::ReadAllBytes($p))[0..2] -join ',')"   # 期望 239,187,191

# 3) 悬空函数调用（改名漏改在这暴露）
$defined = $ast.FindAll({$args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst]},$true) |
           ForEach-Object { $_.Name }
$called  = $ast.FindAll({$args[0] -is [System.Management.Automation.Language.CommandAst]},$true) |
           ForEach-Object { $_.GetCommandName() } | Where-Object { $_ } | Select-Object -Unique
"自定义函数: $($defined -join ', ')"
$called | Where-Object { $_ -match '^(Assert|Sync|Resolve|Import)-' -and $_ -notin $defined }   # 应为空

# 4) 关键函数假数据实测（造个模仿目标结构的临时目录）
```

**仓库可达性批量验证**（10 个目标仓库一次查完）：

```powershell
$repos = 'Nutlope/hallmark','eze-is/web-access','op7418/Humanizer-zh',
         'cjke84/agent-memory-system-guide','blader/humanizer',
         'peterskoett/self-improving-agent','hugohe3/ppt-master',
         'Panniantong/Agent-Reach','mattpocock/skills','addyosmani/agent-skills'
foreach($s in $repos){
  $c = curl.exe -sL -o NUL -w "%{http_code}" --max-time 20 "https://api.github.com/repos/$s"
  "$(if($c -eq '200'){'✅'}else{'❌'}) $c  $s"
}
```

---

## 五、不要动的仓库

| 仓库 | 原因 |
|---|---|
| `Panniantong/Agent-Reach` | 完整应用仓库（`scripts/ config/ tests/`），**不是技能包**。需 `pip install` 后单独取 SKILL 文件。**直接告诉用户"不装"比发明流程好** |
| `ppt-master` 带出的 `.claude-plugin/` | 只有 `plugin.json`，不是技能，可清掉 |

---

## 六、非 Hermes 端的验收方式

对方没有 `skills_list` 命令时，**直接列目录 + 逐个验证 `SKILL.md` 存在性**比命令更硬：

```powershell
$d = "<技能根>"
$dirs = Get-ChildItem $d -Directory
"总数: $($dirs.Count)  带 SKILL.md: $(($dirs | Where-Object { Test-Path "$($_.FullName)\SKILL.md" }).Count)"
$dirs | Where-Object { -not (Test-Path "$($_.FullName)\SKILL.md") } | ForEach-Object { "❌ $($_.Name)" }
```

---

## 七、没进脚本的部分（必须口头交代）

**用户自制的技能无法迁移**——它们是本机会话产物，没有公开仓库，对方 clone 不到：

- 吉大知识库 5 个、Minecraft 11 个、本机运维（`hermes-*`/`windows-*`）、
  交付类、抓取类、虾评运营类、发布类等，合计约 40 个。

迁移方式：`Compress-Archive -Path "$HERMES\<skill>" -DestinationPath "<skill>.zip"`，
由用户手动把 zip 拖给对方。
