# 已验证的第三方技能来源仓库（2026-09-27 实测）

本机 45 个后天安装技能的来源反查结果。**全部仓库经 `curl -sL` 验证为 HTTP 200**，
可直接用于生成给别的 agent 的安装清单。

## 技能集合（走 npx 或纯复制）

| 集合 | 数量 | 装法 | 落点证据 |
|---|---|---|---|
| `addyosmani/agent-skills` | 24 | `npx skills add addyosmani/agent-skills --yes` → **必须手动同步** | `D:\Hermes文件库\.agents\skills\` 里 24 个目录一个不少 |
| `mattpocock/skills` | 16 | `git clone --depth 1` → 拷 `skills/engineering/*` | 特征文件 `agents/openai.yaml` + `PHASE-BOUNDARIES.md` |

mattpocock 全部成员：
`ask-matt` `code-review` `codebase-design` `diagnosing-bugs` `domain-modeling`
`grill-with-docs` `implement` `improve-codebase-architecture` `prototype`
`resolving-merge-conflicts` `setup-matt-pocock-skills` `tdd` `to-spec` `to-tickets`
`triage` `wayfinder`

addyosmani 全部成员：
`api-and-interface-design` `browser-testing-with-devtools` `ci-cd-and-automation`
`code-review-and-quality` `code-simplification` `context-engineering`
`debugging-and-error-recovery` `deprecation-and-migration` `documentation-and-adrs`
`doubt-driven-development` `frontend-ui-engineering` `git-workflow-and-versioning`
`idea-refine` `incremental-implementation` `interview-me`
`observability-and-instrumentation` `performance-optimization`
`planning-and-task-breakdown` `security-and-hardening` `shipping-and-launch`
`source-driven-development` `spec-driven-development` `test-driven-development`
`using-agent-skills`

## 独立仓库（全部 200 验证通过）

| 技能目录名 | 仓库 slug | 装法 |
|---|---|---|
| `hallmark` | `Nutlope/hallmark` | `npx skills add nutlope/hallmark`（README 注明落点 `~/.claude/skills/hallmark/`） |
| `web-access` | `eze-is/web-access` | `npx skills add eze-is/web-access`；frontmatter 自带 `github:` 字段 |
| `humanizer-zh` | `op7418/Humanizer-zh` | `npx skills add https://github.com/op7418/Humanizer-zh.git`；README 直接给了命令 |
| `humanizer` | `blader/humanizer` | clone（humanizer-zh 注明翻译自此仓库） |
| `agent-memory-system-guide` | `cjke84/agent-memory-system-guide` | clone（仓库含 `INSTALL.md` + `manifest.toml`） |
| `pua-debugging` | `peterskoett/self-improving-agent` | clone |
| `ppt-master` | `hugohe3/ppt-master` | clone（AtomGit 镜像同名可用）+ pip 装 requirements |
| `agent-reach` | `Panniantong/Agent-Reach` | `pip install agent-reach`（CLI 自带 yt-dlp/feedparser）+ 拷 SKILL.md |

## 误判纠正记录

| 现象 | 真相 |
|---|---|
| `obra/hallmark` / `Panniantong/hallmark` 均 404 | 真实仓库是 **`Nutlope/hallmark`**（29.2k stars）。搜 `hallmark in:name` 时前几位还有 `vweevers/hallmark` 等无关项目，别取错 |
| `peterskoett/self-improving-agent` 首测报"不存在"(HTTP 301) | **是 301 重定向不是 404**——仓库改名了。curl **必须加 `-L`**，否则把有效仓库误判为不存在并静默跳过安装 |
| 搜 `pua-debugging` 仓库名无结果 | 它不叫这个名。用正文 `github.com/` grep 才查到 `peterskoett/self-improving-agent` |
| `_meta.json` 里有 `ownerId`/`slug` | 这是**虾评平台**标记。本机仅 `self-improvement-skill`（slug=`self-improving-agent`, v1.0.11）带此文件 |

## 不可迁移的本机私有资产

以下为历次会话生成，**无公开仓库**，外部 agent 拿不到，只能 zip 导出：

- 吉大知识库：`jlu-academic-ops` `jlu-campus-info` `jlu-student-affairs` `jlu-student-ops` `jlu-knowledge-ops` `hainan-university-baixiaosheng`
- Minecraft：`minecraft-*`（11 个）
- 本机运维：`hermes-*`（9 个）`windows-*`（5 个）`devops/*`
- 交付类：`document-generation` `manuscript-length-fitting` `ppt-master-ops` `c-native-cli-programs` `document-variant-respin`
- 抓取类：`china-university-web-research` `china-web-research` `cn-web-scraping-windows` `powershell-web-scraping-windows` `web-scraping` `web-scraping-ops`
- 虾评运营：`xiaping` `xiaping-ops` `xiaping-operations` `xiaping-field-notes` `xiaping-practical-tips` `xiaping-skill-ops`
- 发布类：`skill-publishing` `skill-packaging-publishing` `skill-marketplace-ops` `agent-skill-publishing` `knowledge-skill-publisher`
- 媒体：`tech-daily-report` `content-multi-platform` `ai-text-humanizer`
