# 把自己整库技能导出/打包交给别人（distribute side）

> 与 `references/skill-inventory-audit.md` 互补：那边是**盘点**，这是**导出交付**。
> 2026-10-28 实测：43 个技能 → 44 个单技能 zip + 一个合集（11.5MB zip / 15.4MB base64），
> 换目录实测还原成功。

## 0. 先给用户一个选择，别自行发明方案

用户的原始诉求常常是「给出下载地址」。**先把现实讲清楚**：

| 方案 | 对方怎么装 | 适用 |
|---|---|---|
| A 单个 `skills-<name>.zip` | 发过去，agent 解压到自己的 skills 目录 | 挑几个 |
| B 合集（一个 md 里带 base64） | 发一个文件，一句「还原」全装 | 全套体验，**最快取证** |
| C 发布到虾评 | 对方 agent `curl` 即装，**这才是真·下载地址** | 长期更新、可搜索 |

- GitHub 上游**只有**能对上的才有地址（`hermes skills install owner/repo`）；自攒技能（`jlu-knowledge-ops`、`hermes-cn-desktop-ops`、`memory-library-ops`）不存在上游。
- `hermes skills install` 支持 3 种 identifier：`owner/repo/skill`、**直链 SKILL.md**（一次只装单文件，会丢 references/scripts）、本地 zip 不行。
- 虾评下载：`GET https://xiaping.coze.com/api/skills/{id}/download`（需鉴权）。
- 本机自带的 `hermes skills list` 命令没有一个「导出成 zip」的子命令 → **别找，自己打**。

## 1. 打包规则（踩过的坑都在这里）

- 目录 = Hermes skills 根；**顶层 `.archive/` 必须排除**（curator 归档的 140 个技能就在这里，不排除会把整个库打包进去）。
  注意 `.archive` 是子目录前缀，用 `os.walk` 手动剪枝，别用 glob。
- 单个 zip 里**顶层目录 = 技能名**（`hallmark/SKILL.md`），解压即生效。
- 剔除：`__pycache__`/`node_modules`/`.git`、`.pyc`、图片/音频、>512KB 的文件。
  不剔除时 43 个技能 = **405MB**；剔除后 = **11.5MB**（ppt-master 从 89MB → 10.4MB）。
  ppt-master 另有 12193 个 `.svg` 和 186 个 `.wav` 演示素材，再加一层扩展名白名单
  （`.py .md .json .js .css .html .txt .yaml .xml .svg`）。
- **体积审计要分开算**：`SKILL.md` 总量（842KB）≠ 目录总量（405MB）。给用户报数时报目录总量。

## 2. 二进制交付：只给 zip 路径等于白给

对方 agent 拿不到你的 `D:\...` 路径（`MEDIA:` 只在你自己客户端渲染）。所以合集 md 里
**把 zip base64 塞进代码块**（`SKILLBUNDLE-B64` … `ENDBUNDLE`），11.5MB → 15.4MB 纯文本，可微信传。

### 解析 base64 段的稳定写法（连续踩了 3 次）

坑：md 里本身就有很多 ``` 代码块（安装说明那里的），按「遇到 ``` 就停」解析会停在描述行，
得到 34 字符的假 base64，报 `UnicodeEncodeError: 'ascii' codec ...` —— 看着像编码问题，
实际是**切错段落**。

```python
blocks = re.findall(r"```[a-zA-Z]*\n(.+?)```", text, re.S)   # 先切所有代码块
b64 = next(("".join(b.split()) for b in blocks if len("".join(b.split())) > 1000), None)
```
判据：长度 > 1000 才可能是数据块。解析后 `base64.b64decode(b64)` 成功、zip 条目数对得上（13116）即通过。

## 3. 脱敏（必做，别裸发）

个人技能里必然带机器路径和人名。体检脚本：正则扫 `[A-Za-z]:[\\/](Users|Hermes…)\S*`、`sk_[A-Za-z0-9_-]{10,}`、用户名。

替换顺序（**长模式在前**，否则整路径先被吃掉、文件名丢失）：
1. 带文件名的整路径 → `<你的工作目录>/<file.py>`（保留文件名，读起来还能懂）
2. 其余整路径 → `<你的工作目录>`
3. `C:\Users\<名>` → `<你的用户目录>`
4. 姓名 → `用户`

实测替换量：hermes-cn-desktop-ops 48 处、jlu-knowledge-ops 55 处、python-beginner-teaching 31 处。
**脱敏在副本上做**（`dist/.hold_<name>/`），原件不动；打包脚本加 `--src` 参数从副本读。

## 4. 实测验收（交付前必跑）

```powershell
py install_bundle.py dist\skills-bundle.md --list                                  # 技能列表对得上？
py install_bundle.py dist\skills-bundle.md humanizer-zh --dir D:\tmp\skilltest      # 空目录实测落盘
```
第二次成功 = 4 个文件落地、`Remove-Item` 清理。别只报「打包完成」。

## 5. 成品位置

`D:\Hermes文件库\03_工具与项目\skill_bundle\`

| 文件 | 作用 |
|---|---|
| `bundle_skills.py` | 盘点+打包；`--only <名>` 选技能，`--src <名>` 从 `.hold_` 脱敏副本打包，`--no-bundle` 只出单 zip |
| `install_bundle.py` | 对方跑：`py install_bundle.py skills-bundle.md [技能名...] [--list] [--dir]` |
| `scrub.py` | 对 `dist/.hold_*` 做路径/姓名脱敏 |
| `dist/` | 44 个 `skills-*.zip` + `skills-bundle.zip` + `skills-bundle.md` + `skills_manifest.json` |

分发包里给用户的分类建议：联网与调研 / 文档与办公 / 写作与内容 / 编程与教学 / 设计制图 / 系统环境 / 记忆与Agent。分类名按**用途**，不按目录名（Hermes 的目录分层对同学没意义）。
