# Hermes 技能盘点：内置/后天分流 + 来源指纹（只读，不改任何东西）
# 用法: powershell -File inventory_skills.ps1
#       powershell -File inventory_skills.ps1 -SkillsDir "D:\其他\hermes-home\skills"
param(
    [string]$SkillsDir = "$env:LOCALAPPDATA\Hermes Agent CN Desktop\data\hermes-home\skills"
)

if (-not (Test-Path $SkillsDir)) { Write-Error "技能目录不存在: $SkillsDir"; exit 1 }
Write-Host "技能目录: $SkillsDir" -ForegroundColor Cyan

# --- 1. 官方内置名单（权威） ---
$bundled = @()
$mf = Join-Path $SkillsDir ".bundled_manifest"
if (Test-Path $mf) {
    $bundled = Get-Content $mf -Encoding UTF8 | ForEach-Object { ($_ -split ':')[0].Trim() } | Where-Object { $_ }
}
Write-Host "内置技能: $($bundled.Count) 个" -ForegroundColor Yellow

# --- 2. 遍历所有 SKILL.md，收集 name + 来源指纹 ---
$rows = @()
Get-ChildItem $SkillsDir -Recurse -Filter "SKILL.md" -ErrorAction SilentlyContinue | ForEach-Object {
    $f = $_.FullName
    $dir = $_.Directory
    if ($dir.Name -in @('.curator_backups', '.hub')) { return }

    $head = Get-Content $f -TotalCount 30 -Encoding UTF8 -ErrorAction SilentlyContinue
    $name = ($head | Select-String -Pattern '^name:\s*(.+)$' | Select-Object -First 1).Matches.Groups[1].Value
    if (-not $name) { $name = $dir.Name }
    $name = $name.Trim().Trim('"').Trim("'")

    # 显式来源字段
    $src = ($head | Select-String -Pattern '^\s*(github|source|repo|homepage)\s*:\s*(\S+)' |
            Select-Object -First 1).Matches.Groups[2].Value
    $src = ($src -replace '^["'']|["'']$', '').Trim()

    # 指纹判断
    $fp = @()
    if (Test-Path (Join-Path $dir.FullName "_meta.json")) {
        $slug = ""
        try { $slug = (Get-Content (Join-Path $dir.FullName "_meta.json") -Raw -Encoding UTF8 | ConvertFrom-Json).slug } catch {}
        $fp += "XiaPing($slug)"
    }
    if ((Test-Path (Join-Path $dir.FullName "agents\openai.yaml")) -or
        (Test-Path (Join-Path $dir.FullName "PHASE-BOUNDARIES.md"))) { $fp += "mattpocock-fp" }
    if (Test-Path (Join-Path $dir.FullName "requirements.txt")) { $fp += "has-deps" }

    $isBundled = $name -in $bundled
    $rows += [pscustomobject]@{
        Name     = $name
        Bundled  = $isBundled
        Source   = $src
        Fingerp  = ($fp -join ",")
        RelPath  = $f.Replace("$SkillsDir\", "") -replace '\\SKILL.md$', ''
    }
}

# --- 3. 输出 ---
$after = $rows | Where-Object { -not $_.Bundled }
Write-Host "`n=== 后天安装 / 非内置 ($($after.Count) 个) ===" -ForegroundColor Green
$after | Sort-Object Name |
    Format-Table Name, Source, Fingerp, RelPath -AutoSize | Out-String -Width 200 | Write-Host

Write-Host "`n=== 有显式来源链接的 ($(($rows | Where-Object Source).Count) 个) ===" -ForegroundColor Green
$rows | Where-Object Source | Sort-Object Name |
    Format-Table Name, Source -AutoSize | Out-String -Width 200 | Write-Host

# --- 4. 名字重复检测（内置版 + 第三方版并存） ---
$dup = $rows | Group-Object Name | Where-Object { $_.Count -gt 1 }
if ($dup) {
    Write-Host "`n=== 同名并存 (需在清单里分别标注) ===" -ForegroundColor Yellow
    $dup | ForEach-Object { "$($_.Name) x$($_.Count): " + (($_.Group | ForEach-Object { $_.RelPath }) -join ' | ') }
}

# --- 5. 领域重叠提示（粗粒度，供人工判断合并） ---
Write-Host "`n=== 领域集中度 (前 15 前缀) ===" -ForegroundColor Yellow
$rows | ForEach-Object { ($_.Name -split '[-_]')[0] } |
    Group-Object | Where-Object { $_.Count -ge 3 } |
    Sort-Object Count -Descending | Select-Object -First 15 Count, Name |
    Format-Table -AutoSize | Out-String | Write-Host

Write-Host "`n合计: $($rows.Count) 个 SKILL.md；内置 $($bundled.Count) 个；后天 $($after.Count) 个" -ForegroundColor Cyan
