# 技能库跨 agent 安装脚本（路径自适应 + 嵌套兜底）
# 用法：powershell -ExecutionPolicy Bypass -File install-skills-portable.ps1
#      可选参数 -SkillsRoot <技能目录>，不传则自动探测
# 幂等：已存在的同名技能跳过，不覆盖。只做"下载 + 拷贝到技能目录"，不碰系统其他位置。
#
# ⚠️ 本文件必须存成 UTF-8 **带 BOM**，否则 PS 5.1 按 GBK 解码中文 → 假语法错误。
#    校验首 3 字节应为 239,187,191。

param(
    [string]$SkillsRoot = ""      # 技能安装目标目录；留空则自动探测
)

$ErrorActionPreference = 'Stop'
$WORK = "$env:TEMP\skill-install"
New-Item -ItemType Directory -Force -Path $WORK | Out-Null

# ── 0. 自动探测技能目录（顺序即优先级，目标 agent 排前面）──
function Resolve-SkillsRoot($explicit) {
    if ($explicit) { New-Item -ItemType Directory -Force -Path $explicit | Out-Null; return $explicit }
    $candidates = @(
        "$env:USERPROFILE\Doubao\skills"                                                    # 豆包
        "$env:USERPROFILE\.doubao\skills"
        "$env:LOCALAPPDATA\Doubao\skills"
        "$env:LOCALAPPDATA\Hermes Agent CN Desktop\data\hermes-home\skills"                 # Hermes CN Desktop
        "$env:USERPROFILE\.hermes\skills"
        "$env:USERPROFILE\.agents\skills"                                                   # 通用 Codex/Copilot/Amp
        "$env:USERPROFILE\.claude\skills"                                                   # Claude Code
        "$env:USERPROFILE\.cursor\skills"
    )
    # 已有内容的目录优先（说明这就是当前生效的技能根）
    foreach ($c in $candidates) {
        if (Test-Path $c) {
            $n = (Get-ChildItem $c -Directory -ErrorAction SilentlyContinue).Count
            if ($n -gt 0) { Write-Host "探测到技能目录: $c ($n 个技能)"; return $c }
        }
    }
    foreach ($c in $candidates) {
        if (Test-Path $c) { Write-Host "技能目录为空，使用: $c"; return $c }
    }
    $fallback = "$env:USERPROFILE\Doubao\skills"
    New-Item -ItemType Directory -Force -Path $fallback | Out-Null
    Write-Host "未探测到技能目录，已创建: $fallback"
    return $fallback
}

$SKILLS = Resolve-SkillsRoot $SkillsRoot
Write-Host "安装目标: $SKILLS`n"

# 把 $src 下每个技能目录拷进技能库（同名跳过，不覆盖）
function Sync-Skills($src) {
    if (-not (Test-Path $src)) { Write-Host "MISS: $src"; return }
    Get-ChildItem $src -Directory | ForEach-Object {
        $dst = Join-Path $SKILLS $_.Name
        if (Test-Path $dst) { Write-Host "SKIP(exists): $($_.Name)" }
        else { Copy-Item $_.FullName $dst -Recurse; Write-Host "OK: $($_.Name)" }
    }
}

# clone 前验证仓库存在：不存在的仓库 clone 会挂起超时，不报错
function Assert-RepoExists($slug) {
    # -L 必须加：仓库改名会返回 301，不加 -L 会误判为不存在
    # 函数名不要用 Test-* 前缀（保留动词，与 Test-Path 冲突）
    $code = curl.exe -sL -o NUL -w "%{http_code}" --max-time 20 "https://api.github.com/repos/$slug"
    if ($code -ne '200') { Write-Host "!! 仓库不存在或私有: $slug (HTTP $code)"; return $false }
    return $true
}

Set-Location $WORK

# ── A. Addy Osmani 软件工程集合（25 个，走 npx）──
# ⚠️ npx 装到 CWD\.agents\skills\，不是技能目录，必须手动同步
npx --yes skills add addyosmani/agent-skills --yes
Sync-Skills "$WORK\.agents\skills"

# ── B. Matt Pocock 工程集合（18 个，纯复制，不用 npx）──
if (Assert-RepoExists 'mattpocock/skills') {
    git clone --depth 1 https://github.com/mattpocock/skills "$WORK\mattpocock"
    Sync-Skills "$WORK\mattpocock\skills\engineering"
}

# ── C. 独立技能仓库 ──
$repos = [ordered]@{
    'Nutlope/hallmark'                    = 'hallmark'
    'eze-is/web-access'                   = 'web-access'
    'op7418/Humanizer-zh'                 = 'humanizer-zh'
    'cjke84/agent-memory-system-guide'    = 'agent-memory-system-guide'
    'blader/humanizer'                    = 'humanizer'
    'peterskoett/self-improving-agent'    = 'pua-debugging'
    'hugohe3/ppt-master'                  = 'ppt-master'
}
# 注意：Panniantong/Agent-Reach 是完整应用仓库不是技能包，故意不列入，需 pip install + 单独取 SKILL。
$single = @()
foreach ($slug in $repos.Keys) {
    $name = $repos[$slug]
    if (-not (Assert-RepoExists $slug)) { continue }
    $dir = "$WORK\$name"
    if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
    git clone --depth 1 "https://github.com/$slug" $dir
    if ($LASTEXITCODE -ne 0) {
        Write-Host "GitHub 不通，改走 AtomGit 镜像: $slug"
        git clone --depth 1 "https://atomgit.com/$slug.git" $dir
    }
    if     (Test-Path "$dir\SKILL.md") { $single += [pscustomobject]@{ Slug = $slug; Path = $dir } }
    elseif (Test-Path "$dir\skills")   { Sync-Skills "$dir\skills" }
    else   { Write-Host "MANUAL: $name 结构未知，交给兜底扫描处理" }
}
# 单技能仓库：在容器目录下按 <技能名> 放好再同步
if ($single.Count -gt 0) {
    $box = "$WORK\_box"
    foreach ($s in $single) {
        $dst = Join-Path $box $repos[$s.Slug]
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item "$($s.Path)\*" $dst -Recurse -Force
    }
    Sync-Skills $box
}

# ── C2. 兜底：递归扫描，捞出嵌在子目录里、上面两种判断都没命中的技能 ──
# 必须有这一步：peterskoett/self-improving-agent 的技能就在同名子目录里，
# 只按"根目录 SKILL.md"和"根目录 skills/"判断会静默跳过。
function Import-NestedSkills($root) {
    Get-ChildItem $root -Recurse -Filter 'SKILL.md' -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch '\\node_modules\\|\\\.git\\' } |
        ForEach-Object {
            $src = $_.Directory
            $n = (Select-String -Path $_.FullName -Pattern '^name:\s*(.+)$' -List -ErrorAction SilentlyContinue).Matches.Groups[1].Value.Trim()
            if (-not $n) { $n = $src.Name }
            $n = $n -replace '[\\/:*?"<>|]', ''
            $dst = Join-Path $SKILLS $n
            if (Test-Path $dst) { Write-Host "SKIP(exists): $n" }
            else { Copy-Item $src.FullName $dst -Recurse; Write-Host "OK(nested): $n" }
        }
}
$before = (Get-ChildItem $SKILLS -Directory -EA SilentlyContinue).Count
Import-NestedSkills $WORK
$after  = (Get-ChildItem $SKILLS -Directory -EA SilentlyContinue).Count
if ($after -gt $before) { Write-Host "兜底扫描补装 $($after - $before) 个" } else { Write-Host "兜底扫描: 无遗漏" }

# ── D. 虾评平台（self-improvement-skill）──
# 平台 https://xiaping.coze.com  slug: self-improving-agent
# 需人工在平台搜索下载后解压到技能目录，脚本无法自动获取

# ── E. ppt-master Python 依赖（可选，仅生成 PPTX 时需要）──
# ⚠️ 清华源对 pip 返回 403，必须用阿里云源
# $req = "$SKILLS\ppt-master\requirements.txt"
# python3.14 -m pip install -r $req -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com

Write-Host ""
$final = (Get-ChildItem $SKILLS -Directory | Where-Object { $_.Name -notlike '.*' }).Count
Write-Host "==== 完成。$SKILLS 现有 $final 个技能 ===="
