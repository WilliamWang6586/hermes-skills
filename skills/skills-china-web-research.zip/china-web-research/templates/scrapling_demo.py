#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Scrapling 抓取模板: 改 TARGET_URL 和选择器即可复用
运行: .venv/Scripts/python.exe scrapling_demo.py  (在 Scrapling 仓库目录)
"""
from scrapling.fetchers import StealthyFetcher

StealthyFetcher.adaptive = True  # 站点改版后 css(..., adaptive=True) 可自动重定位

TARGET_URL = "https://books.toscrape.com/"  # 公开沙箱，先在这验证
SELECTOR = "article.product_pod"            # 要抓的条目选择器

p = StealthyFetcher.fetch(TARGET_URL, headless=True, network_idle=True)
print(f"status: {p.status} | title: {p.css('title::text').get()}")

items = p.css(SELECTOR)
print(f"items: {len(items)}")
for it in items[:5]:
    # 单元素: .css(...).get(); 属性: ::attr(...); class: ::attr(class)
    name = it.css("h3 a::attr(title)").get()
    price = it.css("p.price_color::text").get()
    print(f"- {name} | {price}")

assert p.status == 200 and len(items) > 0, "反爬拦截或页面结构变化"
print("OK")
