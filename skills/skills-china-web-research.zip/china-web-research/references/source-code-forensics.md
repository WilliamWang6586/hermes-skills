# 源码取证：研究「某个服务/网关的真实行为」

适用：需要回答「X 到底怎么算账 / 到底支持不支持 Y / 为什么会 Z」这类**行为验证**问题。

## 核心原则：源码是权威依据，issues 只是现象描述

- **issues / 论坛帖子** = 用户观察到的症状。零散、可能过时、可能误判根因。
- **源码** = 实际行为。唯一能给出"为什么会这样"的地方。

先看源码定位机制，再用 issues 补充「用户实际遇到了什么」。

## 步骤

1. **定位仓库**，直接 `git clone --depth 1`（别用 GitHub 搜索 API，见
   `references/powershell-curl-and-python.md` 第 5 节）。
2. **从计费/核心逻辑的入口文件开始搜**，不要从 README 开始。关键词选**领域名词**：
   - 计费：`quota` / `billing` / `charge` / `ratio` / `price`
   - 缓存/透传：具体字段名，如 `prompt_cache_hit_tokens`、`cached_tokens`
3. **读整个函数，不要只读匹配行。** 关键约束常在分支的**另一侧**（比如"什么条件下不减缓存"）。
4. **确认数据流的两端**：字段从哪解析进来 → 计费时读的是哪个变量。如果两者不是同一个东西，
   中间的赋值代码就是 bug 的高发区。
5. 用 issues 补充真实现象，但**结论必须能指到具体文件+行号**。

## 实测案例：中转平台是否透传 DeepSeek 前缀缓存

问题：为什么有些 OpenAI 兼容中转站会让 DeepSeek 缓存失效 / 计费翻倍？

**证据链（全部来自 new-api 源码，原 `Calcium-Ion/new-api` → 现 `QuantumNous/new-api`）：**

1. `service/text_quota.go` — 计费是**减法模型**：
   ```
   费用 = (prompt_tokens − cached_tokens) × 全价 + cached_tokens × 折扣价
   ```
   `if !dCacheTokens.IsZero() { baseTokens = baseTokens.Sub(dCacheTokens) }`
   → **`cached_tokens == 0` 时减法不执行，全部 prompt_tokens 按全价。**
   网关不需要"故意坑人"，字段没填就自动全价。

2. `relay/channel/openai/usage.go` — 字段搬运是**按渠道类型 `switch` 分支**的：
   ```go
   switch info.ChannelType {
   case constant.ChannelTypeDeepSeek:
       if usage.PromptTokensDetails.CachedTokens == 0 && usage.PromptCacheHitTokens != 0 {
           usage.PromptTokensDetails.CachedTokens = usage.PromptCacheHitTokens
       }
   case constant.ChannelTypeOpenAI:   // ← 通用渠道：不处理 deepseek 字段
   }
   ```
   计费读的是 `PromptTokensDetails.CachedTokens`，而**唯一给它赋值的地方在这个分支内**。
   中转把 DeepSeek 上游配成通用 OpenAI 渠道（转卖多模型的常见做法）→ 分支不匹配 →
   `CachedTokens` 保持 0 → JSON 里字段还在，但按全价计费。

3. `setting/ratio_setting/cache_ratio.go` — `DefaultCacheRatio = 1.0`。
   **模型名不在映射表里（用了别名/前缀）→ 缓存折扣静默归零。**

**通用教训**：回答"透传/支持吗"这类问题时，
「响应 JSON 里有没有这个字段」**不等于**「计费时用了这个字段」。
字段可能只是原样转发，而计费路径完全忽略它。
要验证一个东西是否**真正生效**，看它在**产生后果的那条代码路径**上是否被读取 —— 不是看它是否出现在输出里。

## 报告写法

- 结论先行（表格：问题 / 答案）。
- 每条技术论断附**文件路径 + 行号**。
- 明确区分「服务端行为」与「网关计费行为」这类容易混淆的两层。
- 给**可执行的判定方法**，不只是解释原理。理想判据直接测量结果（如对比两次请求的实际扣费），
  而不是检查响应格式 —— 后者可以被网关伪造。
