# 单文件 HTML 的动态效果配方（纯 CSS，零依赖）

场景：地图/图谱/看板类单文件 HTML，用户说「再加一些动态效果」。
全部是 CSS animation，**不要引 JS 动画库**（GSAP/anime.js 在这里是纯粹的复杂度）。

## 1. 面板/卡片弹性进入（缓动是重点）

```css
#panel{
  transform:translateX(100%);
  transition:transform .32s cubic-bezier(.34,1.4,.5,1);   /* 过冲回弹 */
}
#panel.on{transform:none}

.card{
  animation:cardIn .34s cubic-bezier(.34,1.4,.5,1) backwards;
  animation-delay:calc(var(--i,0) * 32ms);               /* 逐张错峰 */
}
@keyframes cardIn{
  from{opacity:0;transform:translateX(14px) scale(.97)}
  to  {opacity:1;transform:none}
}
```

**关键**：`--i` 由 JS 写进 style（`d.style.setProperty('--i', i)`），
`backwards` 保证延迟期间保持 `from` 态（否则会先闪一下原态）。

`cubic-bezier(.34,1.4,.5,1)` 的 y 超过 1 → 过冲回弹。比 `ease-out` 有质感得多，
一个数字的代价。

## 2. 轮廓「流光绘制」（SVG 描边动画）

放大后的省份轮廓、流程图连线，用 dashoffset 做「画出来」的效果：

```css
.zprov{
  stroke-dasharray:1600;      /* 必须 >= 路径长度，宁大勿小 */
  stroke-dashoffset:1600;
  animation:draw 1s ease forwards;
}
@keyframes draw{to{stroke-dashoffset:0}}
```

`stroke-dasharray` 设成大于实际周长即可（周长算不准就别算）；
设小了会在动画中出现「重复虚线」的破绽。

## 3. 数据点脉冲（双层，不是缩放单个圆）

一个圆做 scale 会连边框一起变形，正确做法是**内外两层**：

```css
.zdot{fill:#ffd166;stroke:#0d1526;stroke-width:2}
.zdot-pulse{
  fill:none;stroke:#ffd166;stroke-width:1.5;
  transform-origin:center;            /* 不写会绕 SVG 原点缩放，点会飞走 */
  animation:pulse 1.8s ease-out infinite;
}
@keyframes pulse{
  0%  {transform:scale(.6);opacity:.9}
  100%{transform:scale(2.2);opacity:0}
}
```

⚠️ `transform-origin:center` 在 SVG 元素上**必须显式写**，
否则默认参考 SVG 用户坐标系原点，脉冲圈会往左上角飞。

## 4. 引线流动 + 逐条生长

```css
.wire{
  fill:none;stroke:rgba(120,180,255,.5);stroke-width:1;
  stroke-dasharray:4 3;
  animation:wireIn .5s ease backwards,     /* ① 逐条生长 */
            wf .6s linear infinite;        /* ② 从头流动 */
  animation-delay:calc(var(--wi,0) * 28ms), 0s;
}
@keyframes wireIn{from{opacity:0;stroke-dashoffset:-160} to{opacity:1;stroke-dashoffset:0}}
@keyframes wf{to{stroke-dashoffset:-7}}    /* -7 = dasharray 周期(4+3)，保证无缝循环 */
```

**两个动画可以共存**，逗号分隔；`animation-delay` 也要对应写两个值
（第一个给入场、第二个给循环——循环延迟必须是 0s，否则流动会停）。

`wf` 的偏移量必须等于 `dasharray` 的周期（4+3=7），否则循环处会跳一下。

## 5. 让位（hover 时主图淡出）

```css
svg#map{transition:opacity .28s ease}
body.zooming svg#map{opacity:.18}
```

比重新布局便宜得多，视觉上「放大层接管」的感觉也更强。

## 6. 照片背景层（用户给一张图说「把这个作为整个网页的背景」）

实测场景：用户甩来一张 7659×4085 的全班毕业合影（2.1MB），要求当整页背景。
**别直接 `<body style="background:url(...)">`** —— 照片会盖过内容、地图完全读不出来。

三层结构（`::before` 放图 + `filter`，`::after` 放遮罩），**照片层必须负 z-index**：

```css
body{background:#070b14}                    /* 兜底色，图挂了也不白屏 */

body::before{                               /* 照片层 */
  content:"";position:fixed;inset:0;z-index:-2;
  background:url(__BG__) center/cover no-repeat;
  filter:blur(1.5px) brightness(.62) saturate(.9);
  transform:scale(1.04);                    /* blur 会在边缘留透明缝，放大 4% 遮住 */
}
body::after{                                /* 遮罩层，保地图对比度 */
  content:"";position:fixed;inset:0;z-index:-1;
  background:radial-gradient(1200px 800px at 50% 0%,
    rgba(27,43,75,.62) 0%,rgba(13,21,38,.86) 60%,rgba(7,11,20,.94) 100%);
}
```

要点：

- **`transform:scale(1.04)` 不是可选项**：`filter:blur()` 会把图边缘「吃掉」一圈，
  不放大就会在四周露出底色细缝。
- **压暗在 CSS 里做，不在 Python 里做**：`brightness(.62)` 是一个可调旋钮，
  用户嫌暗/嫌亮时改一个数就行，不用重新压图。Python 侧只做**降采样**。
- **降采样再内联**：7659px 原图 base64 会撑爆单文件。缩到 1920 宽 + `quality=72`
  → 300KB 左右（实测 2.1MB → 299KB）。`Image.LANCZOS`，JPEG `progressive=True`。
- `#app` 是 `position:fixed` 且**无自己的背景色**时，照片能正常透出来；
  若给 `#app` 加了实心背景，整层背景就废了。
- 验证方法（console 读伪元素，截图看不出是不是真生效）：
  ```js
  var cs = getComputedStyle(document.body, '::before');
  return {bg: cs.backgroundImage.slice(0,60), filter: cs.filter};
  ```

⚠️ 只有 `html,body{height:100%}` 不够 —— `::before{position:fixed}` 才能铺满视口，
用 `absolute` 在滚动页面上会只盖第一屏。

## 收尾自查

启用 `prefers-reduced-motion` 兜底（无障碍基线，不是可选项）：

```css
@media(prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.01ms !important;animation-iteration-count:1 !important}
}
```
