# 中国大陆站点抓取：Windows 执行环境 + SPA/登录墙（原独立技能 cn-web-scraping-windows，2026-10 并入）

定价页/文档站类目标（阿里云/火山/硅基流动）实战：curl -L、shell 壳判定、登录墙、结构化取行。结构化取行脚本见 scripts/extract-rows.js。


# 中国大陆站点抓取：Windows 执行环境 + SPA/登录墙绕行

适用：需要在 Windows 主机上用 shell 抓国内站点结构化数据（定价表、文档站、
控制台页面）的任何任务。

## 一、PowerShell 执行环境（必读，先踩先省 10 分钟）

### 1. `curl` 是别名，不是 curl

PowerShell 里 `curl` → `Invoke-WebRequest`，`-s -m 25` 直接报：

```
参数名称"m"具有二义性。可能的匹配项包括: -MaximumRedirection -Method
```

**永远用 `curl.exe` 全名**，模板：

```powershell
$UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0 Safari/537.36"
curl.exe -sL -m 30 -A $UA -o "$env:TEMP\p.html" -w "%{http_code}|%{size_download}|%{url_effective}`n" "<url>"
```

`%{url_effective}` 是排查跳转神器——它直接告诉你最终落在哪个 URL。

### 2. `-L` 几乎总是必需

国内大厂站点普遍 301/307。不加 `-L` 只拿到几十字节跳转体，
容易误判成「页面是空的/被墙了」。

| 站点 | 不加 -L | 加 -L |
|---|---|---|
| volcengine.com | 301 (160B) | 200 |
| cloud.siliconflow.cn | 307 (92B) | 200（落到登录页） |
| docs.volcengine.com | 301 | 200 |

### 3. Python 在 Windows 上常常不存在

`python` / `python3` 可能是 Microsoft Store 占位符，执行返回
**exit code 9009** + `Python was not found; run without arguments to install from the Microsoft Store`。

探测顺序：

```powershell
foreach($c in @('py','python3','uv','node')){ $p=Get-Command $c -ErrorAction SilentlyContinue; if($p){"$c => $($p.Source)"}else{"$c => MISSING"} }
```

有 `uv` 可用 `uv run`；但**解析 HTML/JSON 最快的路径是 `node`**——
本机通常已有，无需装任何东西。

### 4. 别在 `-e` / heredoc 里内联复杂正则

两层转义（PowerShell → node → regex）会互相吃掉反斜杠，结果是
`rows found 0` 这种静默失败。**用 `write_file` 落盘成 `.js` 再 `node file.js`**。

同理，`browser_console` 的 `expression` 参数：
- **带中文会被 shell 撕裂**，报 `'缓存存储' 不是内部或外部命令`
- **裸单引号同样致命**：`split('')` 会被当成命令分隔
- **多行表达式报 `SyntaxError: Unexpected end of input`**

→ browser_console 里只用**单行**、**双引号**、**不写中文**的表达式。
需要中文或复杂逻辑时，改成对 `document.body.innerText` 做
`JSON.stringify(...)` 返回，或直接 curl 拿 HTML 用 node 解析。

## 二、SPA 与登录墙的绕行阶梯

按顺序试，命中即停：

1. **Raw HTML 里就有数据？** 很多 Next.js 站把数据塞在
   `self.__next_f.push([1,"..."])` 的内联 payload 里（转义成 `\"`）。
   直接 curl 原始 HTML 再 split 解析，比开浏览器快得多。
   - 硅基流动 `www.siliconflow.cn/pricing` 就是这么拿到全表的。

2. **换到公开域名**。控制台域名常挂登录墙，但同公司的**官网/营销域名
   往往是公开的**：
   - ❌ `cloud.siliconflow.cn/models` → 307 跳 `account.siliconflow.cn/zh/login`
   - ✅ `www.siliconflow.cn/pricing` → 200，728KB，全表可解析
   - 同源内部 API（`/api/v1/model/list` 等）在登录墙后**同样 401/302**，
     不要浪费轮次去猜端点；从渲染后的页面取。

3. **文档站：先看正文是不是在 iframe 里，再考虑开浏览器**。不少文档站外壳是 SPA、
   正文却挂在 iframe —— 例如书生 `internlm.intern-ai.org.cn/doc/docs/Chat`
   的正文在 `<iframe src="/doc/docs/Chat/index.html?v=1.0">`。
   **`curl` 那个 iframe 的 src 就直接拿到纯静态正文**，比开浏览器快得多；
   用 `browser_console` 跑
   `[...document.querySelectorAll('iframe')].map(f=>f.src)` 抠 src 即可。
   - ⚠️**同站在未知路径下会回退成同一个默认页** —— 正文「看起来拿到了」其实是错的。
     真路径以**侧边栏的 `href="/doc/docs/..."`** 为准，别信当前渲染出的正文。
   - ⚠️**含中文的路径必须 URL 编码**（`模型列表` → `%E6%A8%A1%E5%9E%8B%E5%88%97%E8%A1%A8`），
     且末尾要补 `/index.html`，否则只拿到 `301 Moved Permanently`。
   - 侧边栏 href 在 PowerShell 里可能显示成 GBK 乱码（`妯″瀷鍒楄〃`）—— 按 §三 处理，
     把中文原文编码后即可用，别以为抓错了。
   确实没有静态正文时（`docs.siliconflow.cn` / `docs.volcengine.com` 是纯客户端渲染，
   curl 只得到 `<noscript>You need to enable JavaScript</noscript>` 的壳），
   才用 `browser_navigate` 渲染后：
   - 表格数据用 `document.querySelectorAll('table tr')` 提取
   - 超长 snapshot 会被截断，但**完整快照会落盘**，
     路径在返回值的 `full snapshot: read_file path="..."` 里，用 read_file 翻页
   - 官方文档 API（如 `volcengine.com/api/doccenter/doc/detail`）
     返回 `UnauthorizedAccess`，别指望

4. **找不到文档 URL 时，去渲染页里 grep 链接**。404 页面照样能提供线索：
   在帮助中心 404 页执行
   `Array.from(document.querySelectorAll("a")).filter(x=>/关键词/.test(x.innerText)).map(x=>x.href)`
   就能捞出真实入口（本次靠这招从 help.aliyun.com 404 页找到了
   `qianwenai.com/benefits/tokenplan`）。

5. **猜测路径时用「响应体大小」当信号**。阿里云帮助中心
   404 页 = 24893B，真页面 = 40KB~1.9MB。批量探测时打印 size 即可一眼分辨：

```powershell
foreach($p in @("zh/model-studio/token-plan-overview","zh/model-studio/token-plan")){
  curl.exe -sL -m 25 -A $UA -o "$env:TEMP\p.html" -w "$p => %{http_code}|%{size_download}`n" "https://help.aliyun.com/$p"
}
```

## 三、输出编码坑（不是抓取失败，别误判）

PowerShell 控制台里 `Get-Content -Raw` 打出的中文变成
`澶ц璁烘枃妗ｄ腑蹇?` 这类乱码，只影响**显示**，`$a.Length` 和正则匹配
（`$a -match 'deepseek'`）全部正常。

**不要因为看到乱码就以为抓错了**，更不要重抓一遍。
需要看中文时用 `write_file` 落盘再 `read_file`，或在 node 脚本里
`fs.writeFileSync(...,'utf8')` 后读文件。

## 四、解析表格的稳健写法

不要赌 `<table>` 标签——很多站用 `<div>` + CSS grid 假装表格。

**先确认列顺序**（从 header 文本定位），再解析行：

```js
// 从 header 反推列顺序，避免把「输出价」当成「缓存价」
const hi = h.indexOf('输入价格');
console.log(JSON.stringify(h.slice(hi-300, hi+900)));
```

**按 marker split 而不是写大正则**（转义地狱的根治）：

```js
const parts = h.split('pricing-row-text-').slice(1);
for (const p of parts) {
  const chunk = p.slice(0, 6000);            // 切窗口，避免跨行污染
  const name = (chunk.match(/title=(?:\\?")?([^"\\>]+?)(?:\\?")?>/)?.[1] || '?').trim();
  const prices = [...chunk.matchAll(/(?:¥|￥)\s*([\d.]+)/g)].map(m => '¥' + m[1]);
  const seen = new Set();                     // 去重：一个模型可能出现在多个分区
  if (seen.has(name)) continue;
  seen.add(name);
  console.log(name, prices.join(' / '));
}
```

要点：
- **`slice(0, N)` 窗口**防止一个「行」吃到下一个模型的数据
- **`seen` Set 去重**，同模型在多档推理/多分区出现时只输出一次
- **分时价格**要连同 `费用发生时段: ...` 一起抓，单看数字会漏掉折扣条件
- **翻页/折叠内容**（「展开更多 N 个模型」）点击后再抓，或直接去内联
  payload 里找完整列表

## 五、汇报要求（本用户偏好）

- **每一项都标来源 URL**，并注明该 URL 是否公开可达
- **抓不到的项单列一节「未找到」，明确说明原因**（登录墙 / 未渲染 / FAQ 需展开），
  **绝不编造或用记忆补数**
- 价格类数据标注清楚**单位**（元/百万 token）和**计费条件**
  （分时、按输入长度分档、缓存命中价 vs 普通输入价）
- 给一个落盘的产物文件（`.md`）而不是只在对话里贴表

## 自检

抓完一个平台后跑这个断言集（能挡住最常见的三类错）：

```js
// assert-based self check
const assert = require('assert');
assert(prices.length >= 3, '每行应有 输入/输出/缓存 三列，列顺序可能变了');
assert(!/undefined|NaN/.test(out), '有字段没解析出来，marker 或正则失效');
assert(rows.length > 0, 'split marker 不对，返回 0 行说明标记文本已变');
```

`rows found 0` 是最高频的静默失败——**先查 marker 字符串是否还存在**，
再查转义层数。不要在 0 行的情况下继续往下写报告。

## Pitfall: https 全站卡死 ≈15s → 先查 schannel 吊销检查（不是墙）

症状：`curl.exe https://<任何国外站>` 卡 15s 后 exit 35 / HTTP 000；但 `https://baidu.com` 正常。
日志：`schannel: next InitializeSecurityContext failed: CRYPT_E_REVOCATION_OFFLINE (0x80092013)`。

根因：Windows schannel 握手时要连证书吊销服务器（CRL/OCSP），国内连不上 → TLS 直接失败，
**表现得像被墙，实际与目标站无关**。误判成"SNI 阻断"会一路白追 IP。

一次性修复：

```powershell
# curl：%USERPROFILE%\_curlrc 写一行
ssl-no-revoke
# git：换 openssl 后端（http.schannelCheckRevoke=false 对 schannel 无效，别试）
git config --global http.sslBackend openssl
```

验证：`curl.exe -s -o NUL -w "%{http_code}\n" https://github.com/` 应得 200。

⚠️ **`Test-NetConnection <host> -Port 443` 会返回 True（TCP 假通）——不能作判据。**
只有 curl 拿到 HTTP 码才算通。诊断顺序：先 `--ssl-no-revoke` 排除吊销检查，再谈墙。

## Pitfall: 写 C:\Windows\System32\drivers\etc\hosts

1. **含中文路径的 .ps1 用 `Start-Process -Verb RunAs -File` 会静默失败**（PS5.1 吞字符），
   here-string 传参可能整体为空 → `Set-Content` 写出 **0 字节**，原文件内容丢失且无报错。
2. 稳的做法：`write_file` 写到 `C:\Windows\Temp\xxx.txt`（纯 ASCII 路径），再
   `Start-Process cmd -Verb RunAs -ArgumentList '/c','copy','/Y','<src>','<hosts>' -Wait` + `ipconfig /flushdns`。
3. **不要在 hosts 里写中文注释**：UTF-8 无 BOM 被 GBK 解码后换行丢失，
   后面的 IP 表项被拼进注释 → **静默失效**。
4. 恢复出厂 hosts = 803 字节标准注释块，先备份模板再改。

## 相关技能

- `china-web-research` — 更广的中国网络环境调研经验（B 站 API、Bing 中文检索坑）
- `web-scraping` — 通用数据采集任务入口
- `web-access` — 联网操作总入口
