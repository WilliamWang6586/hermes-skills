# PowerShell 抓取本机执行层（原独立技能 powershell-web-scraping-windows，2026-10 并入）

从 Windows 抓好字节的类级指南：curl.exe 别名坑、-OutFile 乱码坑、ASCII 锚点定位、node 当 JSON/HTML 解析器、SSR vs SPA 取数策略。


# PowerShell Web Scraping on this Windows host

Class-level guide for fetching and parsing web pages **from this machine**.
Sibling skills (`china-web-research`, `web-scraping`) cover *where* to look for
data; this one covers *how to actually get bytes into the agent on Windows*.

## The two traps that cost the most retries

### 1. `curl` is aliased to `Invoke-WebRequest`, not curl.exe

```powershell
curl -s -m 25 "https://example.com"   # FAILS: 参数名称"m"具有二义性
```

`-m` collides with `Invoke-WebRequest`'s `-Method` / `-MaximumRedirection`.
**Use `curl.exe` explicitly for real curl:**

```powershell
curl.exe -s -m 30 -A "Mozilla/5.0" -o out.html -w "HTTP=%{http_code} SIZE=%{size_download}" $url
```

**Counter-intuitive, verify both:** some sites block `curl.exe` (returns a ~432-byte
301/challenge stub) while `Invoke-WebRequest -UseBasicParsing` gets the full SSR HTML.
Don't trust one client — try both before declaring a page unscrapable.

```powershell
Invoke-WebRequest -Uri $url -UserAgent "Mozilla/5.0" -UseBasicParsing -TimeoutSec 30 -OutFile out.html
```

### 2. Never `-OutFile` then `Get-Content` + `-replace` for Chinese text

Double-escaping corrupts CJK (`模型` → `妯″瀷`) and changes the string length, so a
later `Substring` throws `索引和长度必须引用该字符串内的位置`.

**Process `$response.Content` in memory, write once, read with `read_file`:**

```powershell
$r = Invoke-WebRequest -Uri $url -UserAgent "Mozilla/5.0" -UseBasicParsing -TimeoutSec 30
$t = $r.Content -replace '</(tr|td|th|p|li|div|h1|h2|h3)>', "`n" -replace '<[^>]+>','' -replace '&nbsp;',' '
$t | Out-File -Encoding utf8 out.txt
```

Then use `read_file` on `out.txt` — that sidesteps PowerShell's CJK index handling entirely.

## Other rules

- **ASCII anchors only for `IndexOf`.** Chinese literals in a PS string often won't match
  (`IndexOf('模型')` → -1). Anchor on table/model identifiers like `MODEL` or `deepseek-flash`.
- **`python`/`python3`/`py` are Microsoft Store alias shims** (exit 9009). Use **`node`**
  (`C:\Users\<user>\AppData\Local\hermes\node\node.exe`) for `node -e` HTML/JSON parsing.
- **SSR docs sites (Docusaurus, MkDocs, GitBook) embed `<table>` in the static HTML.**
  Scrape the HTML, don't open a browser. Reserve the browser for real SPAs and logged-in flows.
- **Non-zero exit codes on PowerShell one-liners are often noise** — check whether the side
  effect actually happened (file size, output text) before retrying. A "failed" call that wrote
  the right file is a success.
- **Structured tables → regex-strip tags**, don't fight the DOM:
  `</(tr|td|th)>` → ` | ` then strip `<[^>]+>`.

## JS 盾 + SPA 平台（洛谷 / luogu.com.cn 一类）

症状：`curl.exe` 和 `Invoke-WebRequest` 都拿到**死循环 302**（响应头 `ws-action: cc`，
set-cookie `C3VK=xxxx`），带着这个 cookie 重试**仍然 302**；SPA 外壳 HTML 里也搜不到
`js-initialData` / `currentData` / 任何内嵌 JSON（列表页、题目页都只是空壳，数据由客户端 JS 再拉）。
这时候别继续换 HTTP 客户端硬刚，也别自己去解 DOM。

修法 —— 让浏览器过盾，然后**拦截站点自带的导出功能**：

1. `browser_navigate` 打开页面（浏览器执行 JS 挑战，盾自然过）。
2. `browser_console` 打补丁：
   `navigator.clipboard.writeText=(t)=>{window.__cap=t;return Promise.resolve();}`
   —— `navigator.clipboard.readText()` 在无头环境是 permission denied，所以拦 write 不拦 read。
3. `browser_click` 站点自己的「复制 Markdown」按钮（ref 每页不同，从 navigate 返回的快照里取）。
4. `browser_console` 读 `window.__cap` —— 完整 Markdown，含 KaTeX `$...$` 公式。
   **a11y 快照会丢公式**（`输入两个整数 ，输出它们的和` 这种空档），所以这是唯一保真的来源。

⚠️ 补丁活在该页 JS 上下文，**每次 `browser_navigate` 都会失效** → 每页/每题都要重新 patch 再点击。
忘了 patch 的症状就是 `window.__cap` 读到 null。

交付前把题面里的广告、多语言程序范例段落删掉，只留题面本体。
同族站点（AtCoder 教程页、OI Wiki 等带「复制 Markdown」的）同样适用。

洛谷取题流程、题单 ID（【入门1】=/training/100）、入门题库号清单、以及 C 练习交付
布局（task<题号>.c 空白 + 题目.md + run.cmd）见 `references/online-judge-scraping.md`。

## 本机 host 坑（会毁掉 `browser_console` / `terminal`）

- **`browser_console` 的表达式保持纯 ASCII，且别写 `||`。** PS 5.1 会把表达式串里的
  中文字面量搞成乱码（GBK），又把 `||` 当命令分隔符吞掉，于是 JS 到你手里已被截断，
  报错却是 `'X' 不是内部或外部命令` —— 极误导，会让人以为是工具坏了。
  过滤一律用 href / slug / ASCII 锚点；正则用 `/re/.test()` 代替 `.includes('中文')`。
- **`workdir` 不能含非 ASCII 字符** —— terminal 工具直接拒
  （`Blocked: workdir contains disallowed character`）。省略 `workdir`，命令里用
  绝对路径，或在命令内部 `cd`。
- **`&` 调用运算符会被当成后台符拦下。** 用变量/数组路径跑 exe 走
  `Start-Process -FilePath ... -ArgumentList @(...) -Wait -NoNewWindow`，配
  `-RedirectStandardInput` / `-RedirectStandardOutput` 喂 stdin、收 stdout；
  更省事的是写个 3 行 `.cmd` 包装，一次写好反复用。
- **验证工具链要跑真流程**：写一个临时文件 → 编译 → 喂 stdin → 读 stdout →
  清理。中文目录下能否编译是真实风险点，别只看 `where.exe gcc` 就宣布可用。

## Deliverable format for captured data

When the user asks for scraped data (pricing, tables, specs):

1. Write a markdown file with a clear path and report it.
2. State the **source URL** and the **capture date**.
3. State **gaps explicitly** — if a requested item no longer exists upstream, say
   "未找到 / not listed" rather than omitting it or guessing.
4. Prefer the **official source over third-party roundups**, and say so — it removes the
   need for cross-validation disclaimers.
