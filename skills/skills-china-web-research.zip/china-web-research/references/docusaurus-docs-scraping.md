# Docusaurus 文档站抓取 — 可复制配方

实测于 `api-docs.deepseek.com`（Docusaurus v3.1.0），2026-09-21。

## 工作配方（已验证可跑）

```powershell
# 1) 抓 SSR HTML（curl.exe 被挡时用这个）
$url = "https://api-docs.deepseek.com/zh-cn/quick_start/pricing"
$r = Invoke-WebRequest -Uri $url -UserAgent "Mozilla/5.0" -UseBasicParsing -TimeoutSec 30

# 2) 剥标签：表格单元格 -> " | "，其余标签删除
$t = $r.Content `
  -replace '</(tr|td|th|p|li|div|h1|h2|h3)>', "`n" `
  -replace '<[^>]+>','' `
  -replace '&nbsp;',' '

# 3) 落盘 utf8，交给 read_file 读（绕开 PS 中文索引崩溃）
$t | Out-File -Encoding utf8 "$env:TEMP\page.txt"
```

## 关键数字/事实核对法

判断某模型/条目**是否仍在售**，不要只看价目页，交叉三处：

| 来源 | 端点 | 作用 |
|---|---|---|
| 价目表 | `/quick_start/pricing` | 在售项的价格 |
| 模型清单 API 文档 | `/api/list-models` | **权威在售列表** |
| 新闻/更新日志 | `/news` | 下线/退役公告 |

实测 DeepSeek 模型清单只返回：

```json
{"object":"list","data":[
  {"id":"deepseek-flash","object":"model","owned_by":"deepseek"},
  {"id":"deepseek-v4-pro","object":"model","owned_by":"deepseek"}
]}
```

→ 清单里没有的 = 已不在售。这是**比价目页更强的证据**。

## 中英双语站点技巧

- 英文页给 **USD**，中文页（`/zh-cn/...`）给 **人民币** 元价。要哪个币种就抓对应语言版本。
- 中文页剥离后中文标签会乱码（`妯″瀷`），但**阿拉伯数字永远干净**——
  只要数字对得上，直接读数字即可，不用强求标签可读。
- 跨语言对齐：用同一行的数字顺序（缓存命中 / 未命中 / 输出）交叉印证。

## 抓取结果示例（DeepSeek，2026-09-21）

现役仅 `deepseek-flash` + `deepseek-v4-pro`；`deepseek-chat` / `deepseek-reasoner` 已下线。
`deepseek-v4-flash` 已退役 → 旧名仍可调用但由 DeepSeek-V4.1-Flash 承接，按 Flash 价计费。

元/百万 tokens：

| 模型 | 输入(缓存命中) | 输入(缓存未命中) | 输出 |
|---|---|---|---|
| deepseek-flash 空闲 | 0.02 | 1 | 4 |
| deepseek-flash 高峰 | 0.04 | 2 | 8 |
| deepseek-v4-pro 空闲 | 0.15 | 4.5 | 13.5 |
| deepseek-v4-pro 高峰 | 0.30 | 9.0 | 27.0 |

规则：空闲价 = 高峰价一半；高峰 = 北京时间周一至五 9:00–12:00、14:00–18:00（法定节假日除外）。
