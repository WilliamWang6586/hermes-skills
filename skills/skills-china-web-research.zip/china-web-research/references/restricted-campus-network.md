# 受限校园网访问境外站点（吉大实测）

> 类问题：中国高校网无国际出口 + 禁代理/VPN 时，如何合规访问 Steam / GitHub 等境外站。
> 完整吉大校园网资料（资费/账号/有线网/红线）在用户工作区：
> `D:\Hermes文件库\记忆外置库\详细知识\jlu_campus_network.md`
> 吉大校内资源访问清单：`D:\Hermes文件库\吉林大学相关文件\校园网络\校园网资源清单（实测）.md`

## 关键约束（吉大）

- 校园网 A 类学生 IP **无国际出口**——改 hosts 指向境外 IP 也没用，包出不去。
- 锐捷检测虚拟网卡/系统代理 → 强制下线；禁路由器 NAT、禁改 MAC。
- 唯一合规思路：**把流量导向国内可达的镜像/CDN**，而不是"翻出去"。

## GitHub 访问（2026-09-13 无 VPN 实测）

| 方式 | 实测结果 |
|------|----------|
| `github.com` 直连 | ❌ 超时（无国际出口） |
| `kgithub.com` | ❌ **已失效**（旧方案，勿再用） |
| **`ghproxy.net`** | ✅ **可用，最快（~1.1s）** |
| `gh-proxy.com` | ✅ 可用 |
| `ghfast.top` | ✅ 可用 |
| `mirror.ghproxy.com` | ❌ 超时 |

**用法**：任意 `https://github.com/...` 链接前面拼 `https://ghproxy.net/`。

```powershell
# clone（完整实测通过）
git clone https://ghproxy.net/https://github.com/<owner>/<repo>.git

# Release 下载
https://ghproxy.net/https://github.com/<o>/<r>/releases/download/v1.0/x.zip

# raw 文件
https://ghproxy.net/https://raw.githubusercontent.com/<o>/<r>/<branch>/<path>
```

- 想省事可全局改写：`git config --global url."https://ghproxy.net/https://github.com/".insteadOf "https://github.com/"`（会污染所有 github 操作，按需）
- ⚠️ 镜像可用性会变——方案失效时按上表顺序换下一家即可，别认定"GitHub 用不了"

## 「GitHub 又连不上了」——先跑这条分诊，别急着改 hosts（2026-10-19 血泪）

**我这次连踩三个坑**：①把证书吊销检查误判成 SNI 阻断 ②钉了一堆 IP 全在漂移 ③把
hosts 写坏两次。全都是因为**没先看症状指纹**。按顺序跑：

```powershell
# ① 三通道指纹：只有 github.com 挂、api/raw 正常 = 域名级阻断（不是网络全断）
foreach ($u in "https://github.com/","https://api.github.com/","https://codeload.github.com/") {
  curl.exe -s -o NUL --max-time 12 -w "$u -> %{http_code}`n" $u }

# ② hosts 被 Watt 接管了吗（有 127.0.0.1 github.com 就是它干的，别去手改）
Get-Content C:\Windows\System32\drivers\etc\hosts | Select-String 'github'

# ③ DNS 是不是被投毒（返回 198.51.44.x 这类 RFC5737 保留网段 = 劫持，说明域名级封锁）
(Resolve-DnsName github.com -Type A).IPAddress
```

**判读表**：

| 指纹 | 结论 | 动作 |
|------|------|------|
| 只有 `github.com` 000，api/raw/codeload 200 | 域名级拦截，且**IP 在漂移** | **别钉 IP**（钉了就时通时不通，比不钉更差）；走镜像或 Watt |
| hosts 里有 `127.0.0.1 github.com` | Watt 装过但**没加速** | 开 Watt 点「一键加速」，不要去手改 hosts（会被它覆盖） |
| 任何 https 都卡 ~15s 后 exit 35，但 baidu 200 | **schannel 证书吊销检查** | 见下节，跟墙无关 |
| 公共 DNS（8.8.8.8/1.1.1.1）全返空 | 校园网劫持 DNS | 只能信校内 DNS，别指望换 DNS 解决 |
| `Test-NetConnection github.com -Port 443` 返 True 但 curl 000 | **假通**，不可作判据 | 只认 curl 的 HTTP 码 |

**schannel 吊销检查（`CRYPT_E_REVOCATION_OFFLINE`）**：不是墙。Windows 做 TLS 时要连
微软吊销服务器，国内连不上 → 整个握手卡死 ~15s，看着像被封。
```powershell
# 永久修：curl 免吊销检查（写 %USERPROFILE%\_curlrc 一行）
"ssl-no-revoke" | Set-Content "$env:USERPROFILE\_curlrc"
# git 换 openssl 后端（http.schannelCheckRevoke 对 schannel 无效，别配那个）
git config --global http.sslBackend openssl
```
验证：`curl.exe -s -o NUL -w "%{http_code}" https://github.com/` 应立刻出码。

**「抖动自愈」是真的，但别拿它当结论**：曾出现 github.com 挂 10 分钟后自己好；
但 2026-10-19 那次是**持续封锁**，等再久也没用。判断法：隔 10 分钟重测一次，
**两次都 000 就走镜像/Watt，别继续等**。

**⚠️ 不要因为"连不上"就去挂 VPN**（用户明确禁止，2026-10-16 纠正过两次）。
也不要为了验证一个猜测去改 `C:\Windows\System32\drivers\etc\hosts`——那文件写坏会让
**所有域名**解析异常，而收益往往为零。改 hosts 只许用下面这个原子写法：

```powershell
# 纯 ASCII 路径 + cmd copy，避开 PS5.1 here-string 与中文路径把文件写成 0 字节的坑
# 步骤：write_file 到 C:\Windows\Temp\hosts_new.txt → 提权 copy /Y 覆盖 → ipconfig /flushdns
Start-Process cmd -Verb RunAs -ArgumentList '/c','copy','/Y','C:\Windows\Temp\hosts_new.txt','C:\Windows\System32\drivers\etc\hosts' -Wait
```
改前务必备份原文件到 `C:\Windows\Temp\hosts_default.txt`（803 字节标准版）。

## 其他境外源可达性（2026-09-13 无 VPN 实测，供日报/爬虫选题）

| 源 | 无 VPN | 备注 |
|----|--------|------|
| Hacker News / hn.algolia | ✅ 200 | 日报主力源，直连可用 |
| api.github.com | ✅ 200 | API 段有国内节点 |
| Bing 图片 / pexels | ✅ | 配图源正常 |
| MyMemory 翻译 | ✅ | 中译正常 |
| 东方财富 / 财经快讯 | ✅ | |
| arxiv（学术） | ❌ 超时 | **校园网拿不到**（2026-09-13 实测） |
| V2EX | ❌ 超时 | |
| 36kr | ❌ 超时 | |
| PubMed | ❌ 超时 | 查医学文献改用知网/万方 |
| 新浪行情 hq.sinajs.cn | ⚠️ 403 | 需带 Referer |
| 维普期刊 qikan.cqvip.com | ⚠️ 403 | 反爬，浏览器可开 |

**结论**：无 VPN 不等于"什么都抓不到"——HN/GitHub/财经/翻译/配图都直连可用。
写抓取脚本时**每个源都要有 try/except + 短超时**，让死源跳过而不是拖垮整个任务。

### arxiv 专项：校园网无解，别浪费时间（2026-09-13 逐一实测）

| 尝试 | 结果 |
|------|------|
| `export.arxiv.org/api/query`（官方 API 域名） | ❌ 000 超时 |
| `arxiv.org/api/query`（主站域名） | ⚠️ 302 → 跳回 export.arxiv.org → 超时 |
| `ghproxy.net/https://export.arxiv.org/...` | ❌ **403**（ghproxy 只放行 github 域名） |
| `gh-proxy.com` / `ghfast.top` 转发 | ❌ 000 / 403 |
| `r.jina.ai/https://export.arxiv.org/...` | ❌ 000 |
| x-mol.com（国内学术站） | ⚠️ 429 限流 |

**教训**：ghproxy 系镜像**只代理 github.com 域名**，拿它转发任意境外站（arxiv/其他）必然 403。
境外非 GitHub 站要另找方案，别默认 ghproxy 万能。arxiv 在校园网下就是拿不到——
写日报/抓取脚本时**给它留本地兜底数据或直接降级跳过**。

## 校内资源（校园网直连全部可达，实测）

吉大校内站 + 国内学术库在校园网下**直连畅通**（含 301/302 跳登录页）：

- 学术库：知网 cnki.net、万方、超星发现 zhizhen.com、超星图书馆、维普考试、WoS（用 **`.cn` 域名** `webofscience.clarivate.cn`，国际版 .com 不通）
- 校内系统：办事大厅 ehall.jlu.edu.cn、研究生 yjs、论文提交 xwlw、OA oa、图书馆 lib、国际交流 oge、心理 xgpsy、评教 ievaluate、创新创业 jdcxcy、开放创新 oep
- ⚠️ **优先从图书馆入口**（lib.jlu.edu.cn）进各数据库，比直连更容易通过校园 IP 授权
- 例外不通：PubMed（境外）、vge.jlu.edu.cn（疑限内网）、入党培训 10.100.66.31（纯内网 IP）

## 抓取脚本的代理策略（写完 VPN 时代脚本后必查）

定时任务/流水线脚本若在 VPN 时代写死过代理兜底，**关 VPN 后会整体挂**——不是部分失败，
是所有源都被导向死端口。检查并改成"有代理用代理、没代理走直连"：

```powershell
# ✅ 正确：只继承/读取，读不到就不设（走直连）
if (-not $env:HTTP_PROXY) {
    $reg = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -EA SilentlyContinue
    if ($reg.ProxyEnable -eq 1 -and $reg.ProxyServer) {
        $env:HTTP_PROXY = "http://$($reg.ProxyServer)"; $env:HTTPS_PROXY = $env:HTTP_PROXY
    }
}
# ❌ 错误：硬编码兜底（关 VPN 后 7892 已死，所有请求全被导向死端口）
# if (-not $env:HTTP_PROXY) { $env:HTTP_PROXY = "http://127.0.0.1:7892" }

if ($env:HTTP_PROXY) { Write-Host "[pipeline] 代理: $env:HTTP_PROXY" } else { Write-Host "[pipeline] 直连" }
```

配套：PowerShell `-replace` 第二参数**不能拼接**——`-replace 'a', '$1' + "x"` 报
"allows only two elements to follow it"；必须用双引号插值 `-replace 'a', "`$1`nx"`。

## 用户常问「不挂 VPN 访问 GitHub 要装什么软件」——先给零安装方案

**先分清两条路，别默认用户要装东西**：

| 需求 | 方案 | 装东西吗 |
|------|------|----------|
| 只是要 clone / 下 Release / 拉 raw | **ghproxy.net 前缀法**（见上） | ❌ 零安装，立刻可用 |
| 要 Steam 加速 + 图形界面托管加速 | Watt Toolkit（steampp.net），只开 **Hosts 加速** | ✅ 需安装 |

用户说"要个软件"时，**先把 ghproxy 前缀法给他**（今天就能用），再补 Watt Toolkit 作为可选增强。
很多人以为"访问 GitHub 必须装软件"——其实校园网场景下前缀法覆盖了绝大部分需求。

**Watt Toolkit 自启配方**（装完后；务必先确认已安装，别假设）：

⚠️ **先搞懂它的 hosts 加速机制，否则会把用户网络搞死**（2026-10-19 实测）：

1. 它把 `github.com` 等**全部**域名写进 hosts 指向 `127.0.0.1`，
   再由 `Steam++.Accelerator` 进程**监听本机 80/443** 接管转发。
   → 验证：`Get-NetTCPConnection -State Listen -LocalPort 80,443` 的 OwningProcess 是加速器进程。
2. **未加速状态下 hosts 里已经是 `127.0.0.1 github.com`**（不是没有表项！）。
   此时**所有 GitHub 域名全挂，比不装它更糟**。所以「装了但没点加速」是最坏状态。
3. **只有点过「一键加速」才生效**。`一键加速` 是 Electron 渲染层按钮，
   UIA 拿不到（`ControlType.Button` 查出来 0 个），只能截图算坐标 + SendInput 模拟点击。
4. 进程以管理员权限运行（要改 hosts、要绑 80/443）→ **非提权的 `Stop-Process` 杀不掉它**，
   会误以为"杀完了还在"。别据此判断状态，看 pid + StartTime。

**开机自启 ≠ 自动加速（2026-10-19 实测，别再猜）**：

```powershell
# 提权 + 登录触发，RunLevel=HighestAvailable（必须提权，否则改不了 hosts/绑不了端口）
$action  = New-ScheduledTaskAction -Execute "$env:LOCALAPPDATA\Programs\WattToolkit\Steam++.exe"
$trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERNAME"
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" `
  -LogonType Interactive -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName "WattToolkit_AutoStart" -Action $action -Trigger $trigger `
  -Principal $principal -Settings $settings -Force
```

**实测结论（杀进程 → 触发任务 → 每 3s 轮询 90s）**：
```
procs=3（起来了）  listen443=0（加速器没绑端口）  github=000（一直不通）
```
→ **自启只拉起 GUI，加速不会自动开，必须人手点一次「一键加速」。**
给用户的正确说法是"要刷网页就点一下"，别承诺"开机即直连"。

**raw.githubusercontent.com 不在它的加速范围**：hosts 里同样被写成 `127.0.0.1` 且无对应转发，
恒 000。替代：`codeload.github.com/<o>/<r>/zip/refs/heads/<branch>`（✅ 通）；
`github.com/<o>/<r>/raw/<branch>/<path>` 会 302 跳回 raw 域 → 死路。

⚠️ 没装就先老实说"没找到，需要先装"，给出官网 https://steampp.net/ —— 别硬编造路径。

**装它自己要先把安装包弄下来**（GitHub releases 域名也挂）：走镜像，实测 **`ghfast.top` 5.76MB/s**，
`ghproxy.net` 只有 ~240KB/s（差 20 倍，别默认 ghproxy 最快）：

```powershell
curl.exe -L -o $out "https://ghfast.top/https://github.com/<o>/<r>/releases/download/<tag>/<file>.exe"
# 校验：首 2 字节==MZ 且 Get-AuthenticodeSignature .Status -eq 'Valid'
```
NSIS 静默装：`Start-Process <exe> -ArgumentList '/S','/D=<目标目录>' -Wait`
（`/D=` 必须最后且不能加引号；Watt Toolkit 装到 `%LOCALAPPDATA%\Programs\WattToolkit\Steam++.exe`）。

## Steam

| 目标 | 方案 |
|------|------|
| Steam | Watt Toolkit（Steam++）**只开 Hosts 加速** —— Steam 有国内 CDN，hosts 指过去即可 |
| 兜底 | 手机热点（仅小流量：clone、登录验证） |

## 踩坑

1. **Watt Toolkit 与本地 Clash 系代理（夜煞云 127.0.0.1:7892）不能共存**：
   同开会扰乱网络路径，导致依赖该代理的应用（如 Hermes）立即断连。
   → 有代理的环境（在家）不开 Watt Toolkit；开之前先停代理。
2. **Watt Toolkit 的"系统代理"模式在校内等于自杀**（触发锐捷下线），只许用 Hosts 加速模式。
3. 离校/回家前点"停止加速"还原 hosts，否则正常网络反而变慢。
4. **关掉 VPN 后应用仍卡死 ≠ 网络问题**：见 `hermes-cn-desktop-ops` 技能的
   `references/proxy-residue-disconnect.md` —— 系统代理注册表 + 环境变量 + 进程继承
   三层残留，代理端口一死就把请求导向死端口。清代理不能只清环境变量。

## 代理清理（完整版，含最易漏的注册表层）

```powershell
# ① 会话级 + 用户级环境变量
Remove-Item Env:HTTP_PROXY,Env:HTTPS_PROXY,Env:ALL_PROXY -ErrorAction SilentlyContinue
[Environment]::SetEnvironmentVariable('HTTP_PROXY',$null,'User')
[Environment]::SetEnvironmentVariable('HTTPS_PROXY',$null,'User')

# ② 系统代理注册表（VPN 客户端的"系统代理"开关写这里；Python 每次请求实时读）
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable -Value 0
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyServer -Value ""

# ③ git
git config --global --unset http.proxy
git config --global --unset https.proxy

# 验证：应为空
python -c "import urllib.request; print(urllib.request.getproxies())"
```
