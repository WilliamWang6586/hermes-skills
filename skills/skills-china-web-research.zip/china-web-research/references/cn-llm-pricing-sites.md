# 中国大模型厂商定价页：可达 URL 与陷阱

抓取时间 2026-09-21。**URL 会变，但「哪个域名公开、哪个挂登录墙」的模式很稳定。**

## URL 路由表（最有价值的部分）

| 想要的数据 | 看似正确的 URL | 实际结果 | 真正可用的 URL |
|---|---|---|---|
| 硅基流动全模型定价 | `cloud.siliconflow.cn/pricing` | ❌ 307 → `account.siliconflow.cn/zh/login` | ✅ `www.siliconflow.cn/pricing` |
| 硅基流动模型广场 | `cloud.siliconflow.cn/models` | ❌ 307 → 登录页 | ✅ 同上（含表格） |
| 硅基流动 API 模型表 | `api.siliconflow.cn/v1/models` | ❌ 401 | ✅ `www.siliconflow.cn/pricing` |
| 千问 Token Plan | `help.aliyun.com/zh/model-studio/token-plan` | ❌ 404 | ✅ `qianwenai.com/benefits/tokenplan` |
| 千问 Token Plan 文档 | — | — | ✅ `help.aliyun.com/zh/model-studio/token-plan-overview` |
| 豆包模型价格 | `www.volcengine.com/docs/82379/1099320` | ⚠️ 301 | ✅ `docs.volcengine.com/docs/ark/model-pricing?redirect=1&lang=zh` |
| 豆包上下文缓存说明 | — | — | ✅ `docs.volcengine.com/docs/ark/context-cache?lang=zh` |

**规律**：厂商的**控制台域名**（`cloud.*`）挂登录墙且同源 API 也 401；
**官网/营销域名**（`www.*`）通常公开。先在官网域名上找一遍，再去开浏览器。

## 各站具体特征

### 硅基流动 `www.siliconflow.cn/pricing`

- 200，约 728KB。**无需登录**。
- 表格是 `<div>` + CSS grid，**不是 `<table>`** —— `querySelectorAll('table tr')` 返回空。
- 数据同时在 raw HTML 的行块里（marker `pricing-row-text-`）和
  Next.js 内联 payload 里，curl 一次就够，不用开浏览器。
- **列顺序（务必确认）**：厂商 | 模型 | 输入价格 | 输出价格 | 缓存价格 → 模型行内只有 3 列。
  本次靠 grep `输入价格` 定位 header 才确认，否则会把输出价当缓存价。
- 部分模型有**分时价**：如 DeepSeek-V4-Flash 低谷 2点～8点，高峰为其余时段。
  行内会带 `费用发生时段: ...`，**必须一起抓**，否则丢掉条件。
- 有「展开更多 N 个模型」折叠；折叠区的模型不在首屏行块里，
  但可在 payload 的 `modelName` / `price` 字段找到（`price` 是 **base price**，非输入价）。
- 缓存命中价与「缓存存储」是两回事：存储另按 ~0.017 元/百万token/小时。

### 阿里云 / 千问

- 帮助中心 **404 页 = 24893 B**，真文档 = 40KB ~ 1.9MB。
  **用响应体大小快速判真假**，比读内容快。
- `help.aliyun.com` 页面是**服务端渲染**的，curl 原始 HTML 就能解析出正文表格
  （Token Plan 四档套餐、团队版座席、Harness 权益比对表全是 curl 拿到的）。
- 文档里嵌了**跨域营销页链接**：本次从 404 页的 `<a>` 里捞出了
  `qianwenai.com/benefits/tokenplan` 这个真正的套餐页。
- 套餐页有 tab（个人版/团队版）和 月付/季付/年付 切换，
  默认渲染「个人版 + 月付」；团队版数据在 DOM 里但需切 tab 或从帮助中心文档取。
- 乱码预警：PowerShell 显示中文会变 `澶ц璁?`，但**正则匹配和长度全正常**，
  不要因此重抓。

### 火山引擎 / 豆包

- `docs.volcengine.com` 是**纯客户端渲染**，curl 只得到
  `<noscript>You need to enable JavaScript to run this app.</noscript>` 的壳。
  **必须开浏览器**。
- 文档 API 不可用：`www.volcengine.com/api/doccenter/doc/detail?docId=...`
  返回 `UnauthorizedAccess`。
- 页面有大量 SDK/埋点 script，snapshot 很长会被截断，
  但完整版落盘，路径在返回值 `full snapshot: read_file path="..."` 里。
- 表格是**真 `<table>`**，`document.querySelectorAll('table')` 一把全出。
  用 `Array.from(t.querySelectorAll('tr')).map(r=>Array.from(r.querySelectorAll('th,td')).map(c=>c.innerText.trim()))`
  注意 `innerText` 尾随 `\u200b`（零宽空格），`.trim()` 后仍需留意比较。
- **三档推理价格并存**：在线推理（常规）/（低延迟）/（低优）。
  只抓第一张表会漏掉另外两档；低延迟档通常是常规档的 ~2 倍，低优档 ~0.5 倍。
- 缓存列有 4 个：缓存存储（元/百万token/小时）、缓存命中(非音频)、缓存命中(音频)。

## 豆包缓存策略要点（易答错的业务规则）

- **隐式缓存**：自动开启、不可关闭、**缓存存储不计费**。不保证命中。
- **显式缓存**：需手动创建、支持确定性命中、**缓存存储计费**。
- 用显式缓存时隐式缓存不生效。
- 计费：命中输入按**缓存命中单价**；未命中输入按**正常输入单价**；
  输出按**正常输出单价**。
- 缓存命中单价**随输入长度区间变化**（Seed 2.0 系列分 [0,32k]/(32k,128k]/(128k,256k]）。
- 支持范围：在线推理下 `doubao-seed-code`、`doubao-seed-2.0` 及之后系列支持隐式缓存。
- 最小缓存门槛：默认 1024 token，部分模型 2048 / 8960 / 256。

## 千问 Token Plan 要点

- **Credits 制**，四档个人版全部按 **7 天固定窗口**刷新，**额度不结转**，
  窗口内耗尽即暂停服务。
- 超额自动 **88 折（8.8折）** 结算，不是按原价。
- 必须用套餐专属 API Key（格式 `sk-sp-xxxxx`）+ 专属 Base URL，
  **通用 API Key 不抵扣套餐额度** —— 这是个高频踩坑点。
- 仅支持**华北 2（北京）** 地域。
- Credits → token 的换算比例在需展开的 FAQ 里，**默认抓不到**。

## 汇报纪律

抓不到就写「未找到 + 原因」，不要用记忆补数。本次列了 5 项明确的未找到：
硅基流动控制台登录墙、独立的 DeepSeek-R1/非 Pro V3 价格行、
`Pro/DeepSeek-V3` 的完整三列、Credits 换算比例、Token Plan 各模型原价表。
