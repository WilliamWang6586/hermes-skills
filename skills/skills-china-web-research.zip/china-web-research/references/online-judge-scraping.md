# Scraping 洛谷 (Luogu) problem statements → C practice sets

Verified 2026-10-08 on this host. Use with the parent skill's clipboard-capture recipe.

## The shield

`curl.exe`/`curl` on any `www.luogu.com.cn` URL → **HTTP 302, body 138 bytes, no usable
data**, header `ws-action: cc`, and it sets `C3VK=<hex>`. Replaying that cookie does NOT
get through. Same for `fetch()` inside the page: you get the 41 KB HTML shell back, with
neither `js-initialData` nor `currentData` in it. Only the real browser passes.

## Getting one problem statement (clean markdown)

1. `browser_navigate` → `https://www.luogu.com.cn/problem/<PID>` (e.g. `P1001`).
2. `browser_console`: patch `navigator.clipboard.writeText` (see parent skill).
3. `browser_click` the `复制 Markdown` link (usually ref `@e35`–`@e39`, right above the
   题目描述 heading — read it off the navigate snapshot, it moves per page).
4. `browser_console` → `window.__cap` — full statement as markdown with `$...$` math.

Strip before delivering: the 广告 block and the **「本题各种语言的程序范例：」** section
(15 language snippets, ~3 KB of noise). Keep 题目背景 core, 题目描述, 输入/输出格式,
样例, 说明/提示/数据范围.

## Picking problems

- List: `https://www.luogu.com.cn/problem/list?difficulty=1&page=1` — `difficulty=1` is
  **入门**; page 1 alone is a full menu of beginner problems.
- Training 题单 (the actual zero-base curriculum): `https://www.luogu.com.cn/training/list`
  → 洛谷官方 → 【入门1】顺序结构 … 【入门6】函数与结构体.
  **【入门1】顺序结构 = `/training/100`** (verified). 入门2–6 are presumably 101–105 but
  that was NOT verified — read the link off the list page instead of guessing.
- Beginner IDs seen in the 入门 list (good raw material, all difficulty 入门):
  P1000 超级玛丽游戏 · P1001 A+B Problem · P1046 陶陶摘苹果 · P1047 校门外的树 ·
  P1085 不高兴的津津 · P1150 Peter 的烟 · P1179 数字统计 · P1307 数字反转 ·
  P1421 小玉买文具 · P1424 小鱼的航程 · P1425 小鱼的游泳时间 · P1427 小鱼的数字游戏 ·
  P1554 梦中的统计 · P1567 统计天数 · P1634 禽兽的传染病.

## Deliverable layout (C practice set for this user)

`D:\Hermes文件库\洛谷C语言练习\`

- `task<题号>.c` — one **truly blank** (0-byte) file per problem, e.g. `task1001.c`.
  User asked for blank; a skeleton is NOT wanted.
- `题目.md` — all statements in one file, ordered by difficulty progression, with a
  leading table (顺序 / 题号 / 题目 / 考察点) and a `> 题目链接：` line per problem.
- `run.cmd` — 3-line compile+run wrapper, called as `run 1001`:
  `gcc "task%~1.c" -o "task%~1.exe" || exit /b 1` then `"task%~1.exe"`.

Toolchain: `gcc` already on PATH at `D:\mingw64\bin\gcc.exe` (MinGW-w64), and it compiles
fine **from the Chinese-named directory** — verified with a real compile+stdin+stdout
round trip. No setup needed; don't reinstall anything.

Progression to reuse: IO → 整除/取余 → 时间计算 → 数组计数 → 数组标记(区间).
