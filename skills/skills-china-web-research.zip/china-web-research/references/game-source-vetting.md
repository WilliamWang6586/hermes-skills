# 游戏/网盘资源获取与安全验证（2026-08 实测）

## novelgame.jp（ノベルゲームコレクション）——日文免费网页游戏官方源

ティラノスクリプト（TyranoScript）官方平台，作者自行上传、免费、无需登录。找日系免费文字冒险游戏时优先查这里。

- 作品页：`https://novelgame.jp/games/show/<id>`（带 Language 切换下拉，平台级翻译，游戏本体仍日文）
- 下载两层：作品页 → `https://novelgame.jp/games/download/win/<id>`（R-15 确认页）→ 真实 CDN 直链在确认页按钮的 href：
  `https://<id>.sv02.novelgame.jp/game/<id>/<文件名>_win.zip?v=0`
- 用浏览器 console `[...document.querySelectorAll('a')].map(a=>({href:a.href,text:a.textContent}))` 直接挖真实直链，绕开点击。
- 中文名定位：中文圈常给游戏起中文名（如「欠損娘を慰める」=《残缺少女的安慰》），
  Bing 搜中文名常被同名电影/词条污染——**B 站 search.bilibili.com 页面搜索最准**（api.bilibili.com 搜索接口已风控），
  视频简介里通常有"个人汉化"和网盘链接（汉化版说明放简介正文）。
- 游戏结构（NW.js 打包）：`<game>.exe`(81MB) + `nw.pak` + `icudtl.dat` + libEGL/libGLESv2/d3dcompiler/ffmpegsumo DLL + `readme.txt`(TyranoScript 引擎说明) + `ゲームを始める前に.txt`(Shift-JIS 作者说明，用 Python `decode('shift_jis')` 读)。

## CDN 下载中断的处理

novelgame CDN 长连接会中途断（curl 56 schannel），**curl `-C -` 续传也失败（SSL）**。
可靠做法：Python urllib + Range 头断点续传 + 重试循环（`.part` 文件累积，8 次重试，最终按 Content-Length 校验大小，达 50MB+ 才算完成）。脚本模式见本次 `dl_game.py`（模板已删，按此重写即可）：`headers["Range"]=f"bytes={exist}-"`，mode="ab"，`os.replace(part, dest)`。

## 下载后安全验证四步（任何下载物通用）

1. `Get-FileHash -Algorithm SHA256` 记录指纹
2. Defender 扫描：`& "C:\Program Files\Windows Defender\MpCmdRun.exe" -Scan -ScanType 3 -File <路径>`（退出码 0 = 无威胁；对 CLI 直接扫 zip 和解压后目录各一次）
3. 内容审计：`[System.IO.Compression.ZipFile]::OpenRead` 列条目，确认无异常文件（.scr/.vbs/双扩展名等）
4. 试运行行为验证：`Start-Process` 运行 12 秒 → `Get-NetTCPConnection -OwningProcess` 查外连 → `Stop-Process`。无外连+进程活着 = 正常（免费 NW.js 游戏 exe 通常无签名、无版本信息，属正常，不算风险信号）

## 百度网盘分享下载的自动化限制（实测结论）

分享页要素：`shareid` / `uk`（从页面 HTML 正则 `shareid:"(\d+)"` 提取）、文件 58.6M、提取码可带 URL `?pwd=` 自动填入。
未登录态全部走不通（别在未登录上浪费时间）：
- `pan.baidu.com/share/list?uk=..&shareid=..` → `errno 9019 need verify`（风控）
- 网页版「下载」按钮未登录无反应（需登录）；`baidupan://link?shareid=..&uk=..&extractcode=..` 协议会弹系统「打开方式」确认框，**默认焦点是「取消」**，自动化确认不可靠
- 客户端带参启动 `BaiduNetdisk.exe "<链接>"` 进程不保持；运行中客户端主窗口可能只显示为 **`GDI+ Window (BaiduNetdiskUnite.exe)` 隐藏窗口**——EnumWindows 找到它也没用，别当主界面
- 正解：**让用户用自己的登录态点「下载」**（客户端粘贴链接或网页版），agent 负责下载后的扫描验证。用户已在电脑前时，把链接+提取码直接给用户是最短路径。
