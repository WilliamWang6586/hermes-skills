# Windows 抓取执行坑（PowerShell 5.1 环境实测）

本机（Chinese Windows 11 + PowerShell 5.1 + `python3.14.exe`）跑抓取/解析脚本时，
以下 4 个坑**每次都会踩**，且每个都表现为"看起来像网络问题"的假象。逐条避开。

---

## 1. 禁止 `python -c "..."` 内联脚本（引号必炸）

**症状**：整段 Python 被 PowerShell 当 PS 代码解析，报
`"[" 后面缺少类型名称` / `"<"运算符是为将来使用而保留的` / `字符串缺少终止符`
之类**语法错误**，而不是 Python 的 Traceback。

原因：PS 会剥一层引号，Python 里的 `"` `'` `[` `<` `>` 全被 PS 抢先解释。
含正则 `r"href=\"(http[^\"]+)\""` 这类写法必炸。

**正解**：一律 `write_file` 写成 `.py` 文件再 `python3.14 x.py`。
（这也是本技能 SKILL.md「执行规范」里已经写的规则，实测再次确认。）

---

## 2. 禁用 PowerShell 重定向抓中文输出（UTF-16 毁中文）

**症状**：`python x.py > out.txt` 之后 `read_file` 看到
`\u0000h� \u00003\u0000-\u00001\u0000` —— **每个字符间夹 NUL**，中文全成豆腐块，
只有数字/ASCII 能读。

原因：PS 5.1 的 `>` 重定向用 **UTF-16LE** 写文件，而脚本里是 UTF-8。

**代价**：本次因此把 19 页 PDF 重新抽取了一遍（第一遍的 423 行输出基本作废）。

**正解**：让 **Python 自己写文件**，不经 PS 管道：
```python
open(out_path, "w", encoding="utf-8").write(text)
```
再看就正常了。**永远不要把中文输出交给 PS 重定向。**

---

## 3. `import urllib.parse` 不等于 `urllib.request` 可用

**症状**：`module 'urllib' has no attribute 'request'`。

原因：`import os, sys, urllib.parse` 只绑了 `urllib` 包名，`urllib.request`
子模块没被导入。

**正解**：显式写全 `import urllib.request, urllib.parse`。

---

## 4. 下载 URL 必须 `quote()`（空格 + 中文 + 括号）

**症状**：`URL can't contain control characters. '.../RoboMaster 2026 手册（20260807）.pdf'
(found at least ' ')`

原因：OSS 直链的文件名部分是**未编码的中文 + 空格 + 全角括号**，
`urllib.request.Request(url)` 直接拒绝。

**正解**（保留路径结构、只编码非法字符）：
```python
safe = urllib.parse.quote(url, safe=":/%?&=#[]@!$'()*+,;~-_. ")
safe = safe.replace(" ", "%20")
req = urllib.request.Request(safe, headers={"User-Agent": "Mozilla/5.0"})
```
注意 `safe` 参数里**不能留空格**（要手动换 `%20`），但斜杠、冒号要留在 safe 里，
否则会把 `https://` 也编码掉。

---

## 5. 每轮必带 assert 自检（本次两次救场）

抓取/下载脚本末尾加一条最小断言，**本次两次直接拦住静默失败**：

- 下载脚本：`assert any(os.path.exists(p) for p in first_three_paths), "核心文件全失败!"`
  → 第一次跑因 `urllib.request` 未导入而全 FAIL，断言让它**显式报错**而不是留下 0 字节文件。
- 抽取脚本：`assert os.path.getsize(f) > 5000, f"{f} 抽取过短，可能是扫描版"`
  → 防止 PDF 是扫描版导致抽出空文本却"看起来成功"。

另：下载完**验文件魔数**比看大小可靠 —— PDF = `25504446`（`%PDF`），
DOCX/XLSX = `504B0304`（ZIP 头）。1 行 PowerShell 循环即可全量校验，能立刻发现
"返 200 但内容是错误页"的假成功。

---

## 6. 站点可达性三件套（区分"被墙"vs"本地代理残留"）

排查顺序（**先看数据再动手清代理**，本次实测代理是干净的）：

```powershell
# a) Python 视角的代理
python3.14 -c "import urllib.request;print(urllib.request.getproxies())"
# b) 注册表环境变量层
Get-ItemProperty 'HKCU:\Environment' -Name HTTP_PROXY,HTTPS_PROXY -ErrorAction SilentlyContinue
# c) 系统代理开关
Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable,ProxyServer
```

若三处**全空 / ProxyEnable=0**，而某站仍报 `WinError 10061` → **是那个站被墙，
不是代理残留**，换站或换通道即可（本次 `r.jina.ai` 即如此，
`baidu.com`/`cn.bing.com`/`github.com` 同时 200）。

批量可达性探针：
```python
import urllib.request, socket
socket.setdefaulttimeout(25)
for u in ["https://www.baidu.com", "https://cn.bing.com", "https://github.com"]:
    try:
        r = urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=25)
        print("OK  ", r.status, u)
    except Exception as e:
        print("FAIL", u, "|", type(e).__name__, e)
```

---

## 7. JS 渲染站：HTML 抓取拿不到正文，别硬啃

本次两类站都踩了：

- **新闻站正文**（`news.jlu.edu.cn/info/...`）：curl/urllib 拿到 600 字，
  全是导航 + 评论表单 + 友情链接，**正文一个字没有**。
  但 `<title>` **是**服务端渲染的 —— 标题里往往已含核心事实
  （本次靠标题确认了"冠军卫冕 七星吉大——荣膺七冠王"、"冠军+1！又双叒叕夺冠"）。
- **百度百科**：直接 `403 Forbidden`（反爬），换 UA 无效。
- **企业官网 WordPress**（`jluracing.com`）：`about-us` 页服务端渲染的正文其实在
  HTML 里，只是 `.txt` 抓取时被 nav/header 噪声淹没 —— 清洗时把
  `<nav|header|footer|form>` 整块删掉就能露出正文。

**判断与对策**：
1. 抓完先看**字数**。`len(text) < 50` → 是空壳，别当成"站点没内容"。
2. 字数正常但**全是菜单项** → 加强清洗正则，删 `nav/header/footer/form` 区块。
3. 确实空白 → 上 `browser_navigate` + `browser_console`
   （`document.body.innerText` 常能绕过懒加载拿到全文），或找该站的 JSON API
   （在 `browser_console` 里读 `performance.getEntriesByType('resource')`
   过滤 `/api/|rest/|json` 往往能挖到真接口 —— 本次 RM 论坛就是这样从
   `developers-server/rest/...` 挖出全站 96 页目录树 + 300+ 附件直链的）。
