# B站 API 限流实战笔记（2026-08 实测）

官方备份文档（agent-reach 内）只说 `sleep(1.5)` 防 412 —— **实测不够**。搜索 API 对
burst 很敏感：连续 5 个查询（即使间隔 2s）也会吃 412；之后进入冷却期，短则 50s，长则几分钟。

## 端点可用性速查（按抗限流排序）

| 端点 | 用途 | 限流表现 |
|------|------|----------|
| `/x/web-interface/view?bvid=` | 视频详情（含 owner.mid、ugc_season 合集） | 最稳，几乎不 412 |
| `/x/web-interface/card?mid=` | 账号卡片（粉丝/签名/等级） | 稳 |
| `/x/web-interface/search/type` | 视频/用户搜索 | 最易 412，burst 后需长冷却 |
| `/x/space/wbi/arc/search?mid=` | UP 主投稿列表 | -352 风控（需 wbi 签名）/ -403 / -799 |
| `/x/polymer/web-dynamic/v1/feed/space` | 动态流 | 412 常见 |
| space.bilibili.com HTML | 抓 __INITIAL_STATE__ | JS 空壳 ~10KB 无视频数据，放弃 |

## 抗限流打法

1. 把搜索次数压到最少：先想清楚 1-2 个最可能命中的关键词再打，别批量试探。
2. burst 后冷却 50-90s 再打下一轮；请求间 sleep ≥2s。
3. 优先免搜索端点：已知任一 bvid → view API 拿 UID → card API 查账号状态
   （粉丝数、签名里常有商务联系方式/粉丝群线索）。
4. 空间投稿列表拿不到时，退路 = 搜索 API 分页 + `author==目标名` 过滤；但搜索按标题
   匹配，按 UP 名搜**不一定**返回该 UP 的视频，命中率低。

## Bing 兜底的坑（中国大陆）

`cn.bing.com/search?q=脏小豆 虚无世界` 会把中文名字拆词成字典页（脏→新华字典）。
**中文人名/UP 主名检索 Bing 基本废**，别浪费次数，直接回 B站。

## 实战案例：脏小豆 UID 溯源（2026-08）

- 目标：找 UP 主"脏小豆"公开的虚无世界3存档（用户记得是"私信才给"）。
- 路径：搜索 API 里搜到其视频 BV1bg4y187fE（虚无世界02）→ view API 拿
  `owner.mid=5836069` → card API 确认账号活跃（132.9万粉，签名含商务微信）。
- 结论：存档走"关注+私信"封闭分发，公开渠道无下载链接是设计如此；给用户私信话术
  + 替代整合包（SoA3，curseforge/quark 链接）收尾，不无限重试搜索。
- 通用教训：**"搜不到"先判断是限流、索引缺失，还是资源本来就是私密分发**，三者
  处理方式完全不同。

## 执行教训

- 不要在 PowerShell 管道里内联 `python -c`（引号转义必炸）；嵌套 bash -c heredoc 也炸。
  脚本写文件后 `wsl -d Ubuntu-24.04 -- python3 /mnt/d/.../x.py` 执行。
- B站返回 title/description 带 `<em class="keyword">` 标签，用 `re.sub(r'<[^>]+>','')` 清洗。
- 示例脚本骨架（冷却 + 降级端点）见本技能 SKILL.md 规范，直接照抄结构即可。
