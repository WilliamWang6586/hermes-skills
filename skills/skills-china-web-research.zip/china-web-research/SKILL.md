---
name: china-web-research
description: >-
  中国大陆网络环境下的调研与数据抓取实战经验——B站（API 限流/端点选择）、Bing
  中文检索的坑、中文 UP 主/资源溯源；以及受限网络（校园网/无国际出口）下访问
  Steam/GitHub 的合规方案。当 agent-reach 的零配置渠道被限流
  （HTTP 412）、搜索结果为空或异常、需要查 B站 UP 主/视频/动态/存档资源、
  或在校园网内访问境外站点（Steam 打不开、GitHub clone 失败）时使用。
  触发词：B站 412、bilibili 限流、搜不到、UP主主页、视频合集、存档下载链接、
  中文人名搜索、Bing 搜索乱、**事实核查、核实一下X的日期/数字、法条什么时候施行、
  360搜索、so.com、视频下载/yt-dlp/央视视频高清、B站视频合集下载**、校园网、Watt Toolkit、Steam 打不开、GitHub 连不上、
  抓取XX平台价格、扒一下定价、从XX官网取数据、curl 报参数二义性、python 找不到、
  页面抓到是登录页/空壳、Docusaurus 文档站、题库/在线判题站。
  同时是本机 Windows 上「怎么把网页字节抓进 agent」的类级执行手册（curl 别名坑、
  -OutFile 乱码坑、node 解析、SSR vs SPA）。
---

# 中国网络调研（B站/中文源）

agent-reach（保护技能，不可改）管平台路由；本技能补它在**中国大陆实测**的缺口：
B站搜索 API 限流远比其文档描述的严重，需要端点降级阶梯 + 冷却打法。

## 核心规则

0. **境外站连不上时，先分诊再动手**（2026-10-19 教训）：跑三通道指纹（github / api / codeload
   各测一次 curl）→ 查 hosts 是否被 Watt 接管 → 查 DNS 是否返 198.51.44.x 保留网段。
   **不要**上来就钉 IP（IP 在漂移，钉了时通时不通，比不钉更差）、**不要**手改 hosts
   （写坏会连累全部域名解析）、**不要**挂 VPN（用户明确禁止）。
   完整分诊表与修法见 `references/restricted-campus-network.md` 开头。

1. **B站搜索 API（`/x/web-interface/search/type`）burst 敏感**：连续 3-5 次查询   即使间隔 2s 也会 HTTP 412；命中后需冷却 **50-90s** 再打。批量试探词 = 自杀。
2. **能不走搜索就不走搜索**：已知任一 bvid → `/x/web-interface/view?bvid=` 拿
   `data.owner.mid`（UID）→ `/x/web-interface/card?mid=` 查账号状态（粉丝/签名/商务
   联系方式/活跃度）。这两个端点几乎不限流。
3. **UP 主投稿列表**（`/x/space/wbi/arc/search`）需 wbi 签名，无签名返回 -352/-403/-799；
   space 页 HTML 是 JS 空壳（~10KB 无视频数据）。退路只有搜索分页 + author 过滤，
   但按 UP 名搜不一定返回该 UP 的视频，命中率低。
4. **Bing（cn.bing.com）分场景**：**中文人名检索基本废**（会把"脏小豆"拆成新华字典
   词条，别浪费次数，回 B站）；但**技术/产品/英文关键词检索可用**，是查工具/框架/
   库一手来源的可靠入口（见下「搜索兜底」）。**但中文"关键词堆砌"式查询同样基本废**
（如「2026年 AI Agent 盘点 排行」「通用 AI 智能体 2026 好用 推荐」返回日历/词典/
汽车公司等噪声，命中率≈0）——查技术/产品/工具/生态一律**改用英文自然查询**
（如「best AI coding agents 2026 comparison」返回的全是正经榜单文），差距天差地别
（2026-09 实测）。命中榜单/对比类文章后，直接 curl 原文 + 去标签 + 统计候选产品名词频，
比停在搜索摘要准得多。
5. **资源"私信才给"是常态**：UP 主公开存档常走"关注+私信自动回复"封闭分发，
   公开搜不到 ≠ 没搜对，不要无限重试搜索；直接给用户私信话术 + 账号线索。
6. **中式公文/范文类检索（入党申请书/公文/作文/心得/总结）= 短词 + 指定范文站**
   （2026-09 实测）：**长串检索词必被"流程/百科/新闻"类结果霸屏**。
   - 反例：`入党申请书范文 大学生 入党动机 本人基本情况 家庭成员 主要社会关系
     怎样积极争取入党`（7 个词全进 query）→ 22.9 万结果里全是百度百科/入党流程/
     12371 官网，**一条范文都没有**；Bing 只抓 query 的前 4-6 词，尾部词形同不存在。
   - 正解：**只留核心短词** `入党申请书范文` → 立刻返回知乎范文合集、第一范文网
     （diyifanwen.com）、百度文库、hao86 等范文站。
   - **点名范文站比堆词有效**：diyifanwen.com / hao86.com 等站一篇页面就挂着
     20-33 篇范文，**1 次浏览器抓取胜过 10 次搜索**，还省 token。
   - ⚠️ **百度直连会跳 `wappass.baidu.com/static/captcha`**（自动化必被拦）→ 用 Bing 或直接就范文站。
     通用规律：百度直连（`urllib`/`curl`）几乎必返 `<title>百度安全验证</title>` 的 1.4KB 页，
     **不是**网络问题也不是 UA 问题，别再换 UA 重试 —— 直接换 Bing 或绕到目标站。
   - 范文站结构：`<h2>xx范文 篇N</h2>` + 段落 p，快照可直接读；正文常含"第一范文网"
     落款等站方水印，抄用前必须清掉。
7. **`r.jina.ai` 国内已直连不通**（2026-09 实测，`WinError 10061` 目标计算机积极拒绝）。
   记忆与其他技能里把 Jina Reader 当零配置主力通道 —— 在**国内网络**上它已经废了，
   别再把它当第一选择。替代顺序：Bing curl → 浏览器直连目标站 → 目标站自身 API。
   （判断口径：`baidu.com`/`cn.bing.com`/`github.com` 同时返 200 而只有 `r.jina.ai` 拒连
   = 站点被墙，**不是**本地代理残留；别去反复清代理。）
8. **不要构造 URL，只从搜索结果里取真实链接**（2026-09 血泪）。
   新闻站 ID 是 `/info/1211/59952.htm` 这种随机数字，**猜必 404**（或更糟：返 200 但
   `<title>搜索</title>` 的空壳页，静默骗过成功判断）。
   正解：Bing 搜到目标 → 用 `browser_console` 抓
   `document.querySelectorAll('#b_results a[href^="http"]')` 拿真实 href → 再抓。
9. **Bing RSS 端点可解析但会"吞尾部关键词"**：`cn.bing.com/search?format=rss&q=<词>`
   返回干净的 `<item><title>/<link>/<description>`，比正则啃 HTML 省事；
   **但它做粗粒度匹配** —— 长查询只认前几个词，**不同查询返回完全相同的结果集**
   （实测「吉林大学方程式赛车队」「吉林大学 FSAE 车队」「吉林大学 大学生方程式汽车大赛 车队名」
   三次结果逐条一致，全被"吉林"劫持成吉林省）。
   **用 RSS 必须自检**：换一个词再查，若结果集与上次逐条相同 → 该查询无效，改法见下。
   另：**引号包住核心实体能显著提纯**（`"吉林大学" 方程式赛车队 招新` → 立刻从 0 命中
   变成 6700 条且首条即目标新闻），这是长尾中文实体检索的通用解法，优先于换搜索引擎。

10. **360 搜索（`www.so.com/s?q=`）是中文事实核查最稳的入口**（2026-10 实测，Bing 全废时）：
   `browser_navigate` 直连即可，无验证码、无 antispider。**中文长查询不拆词**，返回
   央视/新华社/人民网/华商网等真原文摘要，摘要里直接带日期和数字 —— 通常**一次
   SERP 就够写一条可核对事实**，比点进原文快。
   - 本次实测对比（同一批查询）：Bing 把「鳌太线」认成「鳄太线/鳄目」，把「王永康」拆成
     新华字典词条，返回 0 相关；搜狗跳 `antispider`；百度跳 `wappass` 图形验证。
     **360 三家全过，首屏即命中。**
   - 用法：`https://www.so.com/s?q=<中文长查询>`，query 里**保留完整实体名 + 年份 + 数字**
     （和 Bing 的"短词"策略相反）。快照里 `heading level=3` 是标题，其下 `StaticText`
     就是带日期的摘要，够用。
   - 360 自带的「AI智能回答」块可当**线索**（它常直接给出正确年份），但**不可当证据**，
     一律回到它下方列出的真原文标题核对。
   - 中文专名（尤其生僻字、人名、地名）**必须先做一次 SERP 验证再相信自己的记忆**：
     本次记忆里「1月1日施行」被官网原文纠正为「8月15日施行」。
   - ⚠️ **连打会跳 `qcaptcha.so.com` 验证码**（IP 级短时限流，不是搜错）：每类查询最多 2 次，
     凑够候选就停；换说法的第二次查询**先从对口部门站站内搜索找**（零验证码，见下条）。
     已命中的 SERP 用 `browser_back` 回去复用，但中间若点开过新标签的链接，back 会退到验证码页。
   - ⚠️ **`browser_console` 里不要写中文正则/字面量**：PS 层会把 `/峪口|徒步/` 和
     `\u5cea\u53e3` 一起吃掉（报 `'ͽ��' 不是内部或外部命令`，乱码且指向 shell 不是 JS）。
     只写 ASCII：`document.links` + `function(){}.indexOf('/202')>-1`，中文筛选交给眼睛看结果。

   **对标口政府站（`<主题>管理局/保护局/生态环境厅` 官网）的站内搜索优先于 360**——
   纪实类图文报道一条不缺，图是直出大原图。搜索 URL 形如
   `https://<host>/search.html?keywords=<urlencode>&size=15&tab=all&scope=title,resourceSummary`，
   **关键词必须 urlencode**，直接拼中文会被丢掉、返回全站热文（症状：结果数几千条全是首页头条）。

11. **法条/政策类事实只能回一手源，搜索摘要不算数**：正面清单——
   - 生态环境部官网法律库 `mee.gov.cn/ywgz/fgbz/fl/`（页脚"国务院部门"下拉里直接列法名）
   - 全国人大网 `npc.gov.cn`、中国政府网 `gov.cn`
   取到全文页后，用 `browser_console` 跑正则**直接抽施行条款**，别肉眼翻 17 万字：
   ```js
   const t = document.body.innerText;
   t.match(/[^。\n]{0,120}自20\d\d年[^。]{0,60}起施行[^。]{0,20}。/g)
   ```
   开头再抽一次 `（20XX年X月X日…会议通过）` 拿通过日期与**会议届次**。
   **通过日期 ≠ 施行日期，且会议届次容易记错**（本次：十四届全国人大**四次**会议,
   2026-03-12 通过 / 2026-08-15 施行）。两句话讲错一句，课上会被当场纠正。

12. **DeepSeek 官方 API 没有联网搜索**（2026-10 实测）：`api.deepseek.com/chat/completions`
   的 `tools` 只认 `{"type":"function"}`，传 `{"type":"web_search"}` 直接
   **HTTP 422 `unknown variant web_search`**。网页搜索只在 DeepSeek 网页版/App 里，
   没有对外 API。**"用 DeepSeek 的搜索工具"= 让 agent 自己用浏览器搜**，不要为此
   写 API 探针脚本浪费 turn。本机 Hermes 也未配置 search backend
   （`config.yaml` 里无 tavily/serper/exa 项），所以搜索一律走 browser 实打实访问 SERP。

## 视频源与画质核验（央视 / B 站）

- **`yt-dlp -F` 报 480p ≠ 只有 480p，但也 ≠ 一定有高清**。央视可扒
  `hls.cntv.lxdns.com/asp/hls/1200/0303000a/3/default/<guid>/1200.m3u8`
  （**必须带 `-e https://tv.cctv.com/`**，否则 403），能下完、
  **但 `ffprobe` 量出来可能还是 480×270**——新闻短片母带本身就是标清。
  → **铁律：每次下载完跑 `ffprobe` 量 width/height**。「`-F` 有这条格式」和「下载成功」
  都不算验证（2026-10 实测踩过，翻了两轮才量）。
- `pid` 抓法：视频页 HTML 正则 `guid\s*[:=]\s*['\"]([a-f0-9]{20,40})['\"]`，
  再查 `vdn.apps.cntv.cn/api/getHttpVideoInfo.do?pid=<pid>` 拿 `hls_url`
  （`maxbr=2048` 只是**上限参数**，不是分辨率承诺）。`yt-dlp -f <URL>` 是错的
  （`-f` 是格式选择器），直接给 URL。
- **中文纪录片先找 B 站搬运版**，清晰度常高于官网（央视《律动的秦岭》B 站 720P，
  带中文字幕 + CCTV 台标；《美丽中国》有 1080P60 版本但**英配，课堂不可用**）。
  `yt-dlp -F` 对合集只列最后一 P，正常。合集分集的 `title`/`duration` 是**异步加载**的，
  `--flat-playlist --print` 拿不到（`__INITIAL_STATE__` 里也没有 `part`/`duration` 对），
  **别在解析分集标题上耗 turn**，直接抽一集看内容更快。
- 选片素材铁律：**中文配音 + 中文字幕**才算能用；英配即使 1080P60 也只能当封面背景。
- 嵌进 PPT 的编码要求见 `ppt-master-ops` → `references/fix-existing-pptx-media.md`。

## 搜索兜底：Bing curl + b_algo 解析（主渠道不通时）

Google 与 r.jina.ai 往往直连不通（有代理时另说），Bing 是最稳的兜底搜索。

1. **先探出口**（一眼看清哪些站可达，别在不通的站上耗 turn）：
   `curl.exe -s -o NUL -w "%{http_code}" --max-time 12 <url>`
   分别打 `baidu.com`(应 200)、`cn.bing.com`(302)、`google.com`(000=不通)、
   `api.deepseek.com`(401=通，说明国内 API 正常)。
2. **取结果页**（必须带浏览器 UA，否则返 JS 空壳）：
   `curl.exe -s --max-time 30 -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36" "https://cn.bing.com/search?q=<词>&setlang=zh-CN" -o s.html`
3. **解析**：正则抓 `<li class="b_algo".*?</li>` 块 → 块内 `<h2>`=标题、`<p>`=摘要、
   `href="http..."`=链接（结果页约 10 条/页，够用）。

**拿到目标后查一手源，别停在摘要**（尤其工具/框架/库）：
- GitHub：`curl.exe -sL https://api.github.com/repos/<owner>/<repo>` 直接拿
  `default_branch` / `stars` / `license` / `description`（比读网页稳）。
- README/文档：`raw.githubusercontent.com/<owner>/<repo>/<default_branch>/<path>`。
  ⚠️ 分支写错（main vs master）只返 14 字节 `404: Not Found` → 先取 API 的 default_branch 再拼。
- 目录结构：`api.github.com/repos/<o>/<r>/contents/<dir>` 拿文件名列表（省得瞎猜路径）。

## 执行规范（本用户机器）

- 脚本写文件后统一 `wsl -d Ubuntu-24.04 -- python3 /mnt/d/<路径>/x.py` 执行。
- **禁止在 PowerShell 管道内联 `python -c`**（引号转义必炸）；嵌套 bash -c heredoc
  同样易炸，一律写成 .py 文件。
- B站响应里 title/description 带 `<em class="keyword">` 标签，用
  `re.sub(r'<[^>]+>', '', s)` 清洗。
- 请求间 sleep ≥2s，冷却期脚本内 `time.sleep(50-90)`。

## 参考

- `references/bilibili-api-field-notes.md` — 端点可用性速查表 + 完整实战案例
  （脏小豆 UID 溯源：5836069 / 虚无世界系列 BV1bg4y187fE）
- `references/university-website-scraping.md` — 高校官网批量抓取（webplus 系
  分页/附件/OCR 兜底，吉大 16 学院验证）：tzgg.htm 翻页、download.jsp 附件、
  Content-Type 不可信、搜狗微信搜公众号
- `references/restricted-campus-network.md` — 无国际出口校园网访问境外站点。
  **开头有「GitHub 又连不上了」分诊表**（先看指纹再动手：域名级拦截 vs DNS 投毒
  vs schannel 吊销检查 vs Watt 未加速），**别钉 IP、别手改 hosts、别挂 VPN**。
  含 ghfast.top 5.76MB/s（比 ghproxy 快 20 倍）/ Watt Toolkit 加速机制与自启
  （实测：自启只拉 GUI，**加速必须手点**）/ 吉大校内资源直连清单 / 代理清理注册表层
- `references/windows-scraping-execution-pitfalls.md` — **执行层 7 坑**（每次必踩）：
  `python -c` 内联引号必炸、PS `>` 重定向把中文写成 UTF-16 豆腐块、
  `urllib.request` 未导入、下载 URL 需 `quote()`、末尾 assert 自检 + PDF 魔数校验、
  「三件套」区分被墙 vs 代理残留、JS 渲染站取正文的对策（含从 performance entries 挖 JSON API）
- `references/powershell-fetch-and-parse.md` — **本机取字节的类级指南**（原
  `powershell-web-scraping-windows`）：`curl` 别名坑、`-OutFile`→`Get-Content` 中文乱码坑、
  ASCII 锚点定位、node 当 JSON/HTML 解析器、SSR-vs-SPA 策略。curl 与
  `Invoke-WebRequest` 都要试（有的站只拦其中一个）。
- `references/cn-site-scraping-environment.md` — **国内大厂站抓取**（原
  `cn-web-scraping-windows`）：`curl.exe -sL` 必备（301/307 壳）、`%{url_effective}` 判跳转、
  登录墙/空壳判定、定价表结构化取行（脚本 `scripts/extract-rows.js`）。
- `references/cn-llm-pricing-sites.md` — 各家大模型厂商定价页 URL 与字段速查，直接喂给
  hermes-cn-desktop-ops 的 `references/llm-platform-pricing.md` 做比价。
- `references/docusaurus-docs-scraping.md` / `references/online-judge-scraping.md` — 文档站与题库类站点的取数细节。
- `references/web-scraping-tooling.md` — **工具选型 + 通用抓取模型**（原独立技能 `web-scraping`）：
  用户偏好「要数据优先爬，不要手工复制」；Jina Reader 快速提取 vs Scrapling 反爬强解析 vs
  agent-reach 搜索 vs web-access CDP 登录态的选型表；Scrapling 安装与 API 要点。
- `references/game-source-vetting.md` — 游戏/软件下载源可信度甄别（配合 `download-and-verify`）。
- `references/html-dynamic-effects.md` — 动态 HTML/动效页面结构与内容提取。
- `references/image-asset-harvesting.md` — 图片素材批量采集、清洗与规整（配 `scripts/convert_user_image.py`、
  `scripts/normalize_image_set.py`）。找的是**徽章/logo**，可用留白比率等几何判据程序化过滤。
- `references/news-photo-harvesting.md` — **新闻纪实配图采集**（PPT 找 N 类纪实新闻图、要求逐张
  vision 核验 + 像素清单）：对口政府站站内搜索优先、**去掉 `?x-oss-process=image/resize` 拿原图**、
  尺寸写在路径里的 CDN 拼不出原图、vision 必须问"读出标识牌文字"、360 验证码冷却打法、
  PS 层吃中文字面量的 console 写法、交付清单格式。
- `references/isbn-search-guide.md` — ISBN/书目查询（配 `scripts/isbn_search.py`）。
- `templates/scrapling_demo.py` — Scrapling 起手模板（改 URL + 选择器即可跑）。
