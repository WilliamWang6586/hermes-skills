#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ISBN图书信息搜索脚本
支持多平台搜索，处理中国大陆网络环境限制
"""

import re
import json
import sys
from urllib.parse import quote

def search_isbn_bing(isbn):
    """使用必应搜索ISBN"""
    try:
        import subprocess
        import os
        
        # 构建搜索URL
        search_url = f"https://cn.bing.com/search?q={isbn}"
        
        # 执行curl命令
        cmd = ['curl.exe', '-s', search_url, '-H', 'User-Agent: Mozilla/5.0']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            return result.stdout
        else:
            return None
    except Exception as e:
        print(f"必应搜索失败: {e}")
        return None

def search_isbn_douban(isbn):
    """使用豆瓣搜索ISBN"""
    try:
        import subprocess
        
        # 构建搜索URL
        search_url = f"https://www.douban.com/search?q={isbn}"
        
        # 执行curl命令
        cmd = ['curl.exe', '-s', search_url, '-H', 'User-Agent: Mozilla/5.0']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            return result.stdout
        else:
            return None
    except Exception as e:
        print(f"豆瓣搜索失败: {e}")
        return None

def extract_book_info(html_content, isbn):
    """从HTML内容中提取图书信息"""
    results = []
    
    # 搜索模式
    patterns = [
        rf'{isbn}[^<]*',
        rf'ISBN[^<]*{isbn}[^<]*',
        r'书名[^<]*',
        r'作者[^<]*',
        r'出版社[^<]*',
        r'出版时间[^<]*',
        r'价格[^<]*'
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, html_content, re.IGNORECASE)
        for match in matches:
            # 清理HTML标签
            clean_match = re.sub(r'<[^>]+>', '', match).strip()
            if clean_match and len(clean_match) > 2:
                results.append(clean_match)
    
    return results

def analyze_isbn_structure(isbn):
    """分析ISBN结构"""
    if len(isbn) == 13:
        return {
            'prefix': isbn[:3],
            'publisher_code': isbn[3:7],
            'publication_info': isbn[7:9],
            'book_number': isbn[9:],
            'type': '13-digit ISBN'
        }
    return None

def main():
    if len(sys.argv) != 2:
        print("用法: python isbn_search.py <ISBN>")
        print("示例: python isbn_search.py 9787564094577")
        sys.exit(1)
    
    isbn = sys.argv[1]
    
    print(f"正在搜索ISBN: {isbn}")
    print("=" * 50)
    
    # 分析ISBN结构
    structure = analyze_isbn_structure(isbn)
    if structure:
        print("ISBN结构分析:")
        for key, value in structure.items():
            print(f"  {key}: {value}")
        print()
    
    # 多平台搜索
    search_results = []
    
    # 1. 必应搜索
    print("1. 正在使用必应搜索...")
    bing_result = search_isbn_bing(isbn)
    if bing_result:
        bing_info = extract_book_info(bing_result, isbn)
        if bing_info:
            search_results.append(("必应搜索", bing_info))
            print("   ✓ 找到相关信息")
        else:
            print("   - 未找到具体信息，但有搜索结果")
    else:
        print("   ✗ 搜索失败")
    
    # 2. 豆瓣搜索
    print("2. 正在使用豆瓣搜索...")
    douban_result = search_isbn_douban(isbn)
    if douban_result:
        douban_info = extract_book_info(douban_result, isbn)
        if douban_info:
            search_results.append(("豆瓣搜索", douban_info))
            print("   ✓ 找到相关信息")
        else:
            print("   - 未找到具体信息，但有搜索结果")
    else:
        print("   ✗ 搜索失败")
    
    # 输出结果
    print("\n" + "=" * 50)
    print("搜索结果汇总:")
    
    for source, info in search_results:
        print(f"\n{source}:")
        for item in info:
            print(f"  - {item}")
    
    # 建议
    if not search_results:
        print("\n建议:")
        print("1. 检查网络连接，可能需要使用代理")
        print("2. 尝试搜索ISBN的部分数字")
        print("3. 提供更多图书信息（书名、作者等）")
        print("4. 在有网络访问权限的环境下手动搜索")
    else:
        print(f"\n找到 {len(search_results)} 个搜索结果")

if __name__ == "__main__":
    main()