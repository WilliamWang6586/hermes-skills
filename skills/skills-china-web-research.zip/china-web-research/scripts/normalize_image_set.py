# -*- coding: utf-8 -*-
"""图片素材批归一化：裁到内容边界 -> 居中 -> 等比填满内框 -> 统一尺寸。

用途：一批 logo/校徽/头像/产品图下载下来后，尺寸与「内容填充率」参差不齐
（实测同批 32 枚全存 128px，内容长边占比 0.68~1.00，用户一眼看出大小不一）。
本脚本只做「量内容 bbox + 重排」，**幂等**：已是标准规格的再跑一次结果不变，
所以可以在每次补图后安全重跑。

顺带输出体检表：每枚的内容 W/H + 锐度 + KB，按锐度升序，
一眼就能看到哪几张是低清小图放大（外圈文字会糊）。

用法：
    $env:PYTHONUTF8=1; py -3 normalize_image_set.py <dir> [size] [pad]

注意（本机铁律）：一律 write_file 写 .py 再跑，别用 py -3 -c 内联
（PS5.1 会吞掉正则/引号里的字符）。
"""
import os
import sys
import glob
from PIL import Image

DEFAULT_DIR = r"D:\Hermes文件库\logos"


def content_bbox(im):
    """非白、非透明的外接矩形；全白图直接断言失败（说明源图有问题）"""
    W, H = im.size
    px = im.load()

    def ink(x, y):
        r, g, b, a = px[x, y]
        return a > 40 and not (r > 232 and g > 232 and b > 232)

    xs = [x for x in range(W) if any(ink(x, y) for y in range(H))]
    ys = [y for y in range(H) if any(ink(x, y) for x in range(W))]
    assert xs and ys, "全白图，无内容"
    return (min(xs), min(ys), max(xs) + 1, max(ys) + 1)


def sharpness(im):
    """相邻像素灰度差均值：越低越糊，用来判断外圈小字是否可辨"""
    g = im.convert("L")
    W, H = g.size
    px = g.load()
    s = c = 0
    for y in range(0, H - 1, 2):
        for x in range(0, W - 1, 2):
            s += abs(px[x, y] - px[x + 1, y])
            c += 1
    return s / max(c, 1)


def normalize(path, size, pad):
    inner = size - pad * 2
    im = Image.open(path).convert("RGBA")
    core = im.crop(content_bbox(im))
    w, h = core.size
    k = inner / max(w, h)                       # 等比，长边填满内框
    nw, nh = max(1, round(w * k)), max(1, round(h * k))
    core = core.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.paste(core, ((size - nw) // 2, (size - nh) // 2), core)
    canvas.save(path, "PNG")
    return nw, nh


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_DIR
    size = int(sys.argv[2]) if len(sys.argv) > 2 else 128
    pad = int(sys.argv[3]) if len(sys.argv) > 3 else 6

    rows = []
    for p in sorted(glob.glob(os.path.join(d, "*.png"))):
        name = os.path.basename(p)[:-4]
        try:
            nw, nh = normalize(p, size, pad)
        except AssertionError as e:
            print("SKIP %-22s %s" % (name, e))
            continue
        rows.append((name, nw, nh, sharpness(Image.open(p)), os.path.getsize(p) // 1024))

    print("\n%-24s %-8s %-8s %-7s %s" % ("素材", "内容W", "内容H", "锐度", "KB"))
    for name, nw, nh, sh, kb in sorted(rows, key=lambda r: r[3]):
        flag = "  <-- 低清" if sh < 8 else ""
        print("%-24s %-8d %-8d %-7.1f %d%s" % (name, nw, nh, sh, kb, flag))
    print("\n共 %d 枚，统一为 %dx%d，内容长边 %d px" % (len(rows), size, size, size - pad * 2))

    # 自查：全部内容长边必须等于 inner（幂等性证明）
    inner = size - pad * 2
    bad = [n for n, nw, nh, _, _ in rows if max(nw, nh) != inner]
    assert not bad, "归一化后仍有未填满的: %s" % bad


if __name__ == "__main__":
    main()
