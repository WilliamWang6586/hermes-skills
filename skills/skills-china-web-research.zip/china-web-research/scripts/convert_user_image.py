# -*- coding: utf-8 -*-
"""把「用户提供的图片」转成与其它素材统一规格的 PNG（裁边 -> 居中 -> 补正方形 -> resize）

场景：批量素材（校徽/logo/头像）里有一部分是用户直接上传的正确原图，需要
     塞进同一批内联产物，尺寸/底色/留白必须和抓来的那批完全一致。

用法：
    1. 改 SRC / OUT / SIZE
    2. 改 JOBS： (源文件名, 目标名, 左边裁掉几像素)
    3. py -3 convert_user_image.py
输出会打印每张的「内容 bbox 尺寸」——若尺寸≈正方形，说明源图本身就是整枚徽章，
没有多余边框可裁，这是正常结果（不用怀疑脚本出错）。

只在 Windows PowerShell 下用 py -3 跑（本机 python 不在 PATH）。
"""
import os
from PIL import Image

SRC = r"C:\Users\<用户>\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\images"
OUT = r"D:\Hermes文件库\logos"
SIZE = 128           # 与同批其它素材保持一致

# (源文件名, 目标名, 左边要裁掉的像素)  —— 例：源图左缘有一条深蓝竖线时填 9
JOBS = [
    # ("upload_xxxx.png", "西安电子科技大学", 9),
    # ("upload_yyyy.png", "兰州大学", 0),
]


def blank(p):
    """白 or 透明都算留白（与抓取脚本同一判据，保证规格一致）"""
    r, g, b, a = p
    return a < 40 or (r > 232 and g > 232 and b > 232)


def convert(src, school, left_crop):
    im = Image.open(src).convert("RGBA")
    if left_crop:
        im = im.crop((left_crop, 0, im.size[0], im.size[1]))
    W, H = im.size
    px = im.load()
    xs = [x for x in range(W) if any(not blank(px[x, y]) for y in range(0, H, 2))]
    ys = [y for y in range(H) if any(not blank(px[x, y]) for x in range(0, W, 2))]
    assert xs and ys, school + ": 全白，源图有问题（或 left_crop 裁多了）"
    core = im.crop((min(xs), min(ys), max(xs) + 1, max(ys) + 1))
    w, h = core.size
    n = max(w, h)
    bg = Image.new("RGBA", (n, n), (0, 0, 0, 0))     # 透明底，不用白底
    bg.paste(core, ((n - w) // 2, (n - h) // 2), core)
    dst = os.path.join(OUT, school + ".png")
    bg.resize((SIZE, SIZE), Image.LANCZOS).save(dst, "PNG")
    return dst, (w, h), os.path.getsize(dst)


def dominant(im, topn=3):
    """主色统计——用于回答「配色是不是被改过」这类质疑（别只看截图印象）"""
    from collections import Counter
    px = im.convert("RGBA").load()
    W, H = im.size
    c = Counter()
    for y in range(0, H, 2):
        for x in range(0, W, 2):
            r, g, b, a = px[x, y]
            if a > 60 and max(r, g, b) - min(r, g, b) > 18:      # 只统计有彩度的像素
                c[(r // 40 * 40, g // 40 * 40, b // 40 * 40)] += 1
    return c.most_common(topn)


if __name__ == "__main__":
    assert JOBS, "先在 JOBS 里填要转换的图"
    for fn, school, lc in JOBS:
        p = os.path.join(SRC, fn)
        assert os.path.exists(p), "缺源图: " + p
        dst, wh, sz = convert(p, school, lc)
        im = Image.open(dst)
        print("OK %-8s 内容%dx%d -> %s (%d bytes)  主色%s"
              % (school, wh[0], wh[1], dst, sz, dominant(im)))
