#!/usr/bin/env node
// Extract repeated "row" blocks from a server-rendered HTML page (or from a
// Next.js inline payload) by splitting on a row marker.
//
// Usage:
//   node extract-rows.js <file.html> <marker> [--price-re <re>] [--win <n>] [--label-re <re>]
//
// Examples:
//   # SiliconFlow pricing page
//   node extract-rows.js sf.html 'pricing-row-text-'
//
//   # generic 4-column table rows
//   node extract-rows.js page.html 'class="row-' --price-re '(?:¥|￥)\s*([\d.]+)'
//
// Why split instead of one big regex: nested escaping through
// PowerShell -> node -> regex eats backslashes and silently yields 0 rows.
// Splitting on a literal marker string needs no escaping at all.

const fs = require('fs');

function arg(flag, dflt) {
  const i = process.argv.indexOf(flag);
  return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : dflt;
}

const file = process.argv[2];
const marker = process.argv[3];
if (!file || !marker) {
  console.error('usage: node extract-rows.js <file.html> <marker> [--price-re <re>] [--win <n>] [--label-re <re>]');
  process.exit(2);
}

const priceRe = new RegExp(arg('--price-re', '(?:¥|￥)\\s*([\\d.]+)'), 'g');
const win = parseInt(arg('--win', '6000'), 10);
const labelRe = new RegExp(arg('--label-re', 'title=(?:\\\\?")?([^"\\\\>]+?)(?:\\\\?")?>'));

let h = fs.readFileSync(file, 'utf8');

const parts = h.split(marker).slice(1);
console.log('# file=' + file + ' marker=' + JSON.stringify(marker) + ' chunks=' + parts.length);

if (parts.length === 0) {
  console.error('!! 0 chunks — marker not found. Check the marker string still exists in the HTML.');
  console.error('!! The page may have changed, or you may have fetched a JS shell instead of rendered HTML.');
  process.exit(1);
}

const seen = new Set();
let emitted = 0;
for (const p of parts) {
  const chunk = p.slice(0, win); // window: stop one row leaking into the next
  const lm = chunk.match(labelRe);
  const name = (lm ? lm[1] : '?').trim();
  if (seen.has(name)) continue;
  seen.add(name);

  const prices = [...chunk.matchAll(priceRe)].map((m) => '¥' + (m[1] || ''));
  const periods = [...chunk.matchAll(/费用发生时段: ([^<\\]+)/g)].map((m) => m[1].trim());
  const free = /免费/.test(chunk) ? ['免费'] : [];

  const priceCol = prices.length ? prices.join(' / ') : free.join('') || '-';
  console.log(name.padEnd(44), '||', priceCol.padEnd(30), '||', periods.join(' ; '));
  emitted++;
}

// --- self check ---------------------------------------------------------
const assert = require('assert');
assert(parts.length > 0, 'no chunks parsed');
assert(emitted > 0, 'chunks found but no rows emitted');
console.log('# rows=' + emitted);
console.log('# NOTE: verify column order against the page header before trusting labels.');
console.log('#       Grep the raw HTML for the header text (e.g. 输入价格) and read the surrounding markup.');
