#!/usr/bin/env python3
"""正向扫 exe 里的可打印 ASCII 串 —— 用来看启动器/破解补丁怎么找本体、有什么已知路径。

用法:
    python3.14.exe probe_exe_strings.py <exe路径> [关键词1 关键词2 ...]

不传关键词时默认输出：路径模板 / 版本样式串 / 注册表线索 / DLL 引用。
实测有效案例（剪映 JianyingPro.exe 启动器）: 扫出
    D:\\code\\bytedance\\installer\\LVInstaller\\...\\JianyingLauncher.pdb
    GetDefInstallDirEx  /  JianyingPro_{AB736139-...}  /  realExePath  /  join_UE_program
"""
import re
import sys

DEFAULT_KW = [
    # 路径/进程
    ".exe", ".dll", ".lnk", ".reg", "http", "Program", "Temp", "AppData",
    "CreateProcess", "ShellExecute", "LoadLibrary", "run", "start",
    # 安装器/版本线索
    "Install", "version", "current", "last_version", "realexepath",
    "RunApp", "join_UE", "patch", "load", "inject", "dir=",
    # 注册表
    "SOFTWARE", "Jianying", "ByteDance", "lveditor",
]

STR_RE = re.compile(rb"[\x20-\x7e]{5,300}")


def probe(path, keywords):
    data = open(path, "rb").read()
    print("=== %s ===" % path)
    print("size: %d bytes (%.2f MB)" % (len(data), len(data) / 1048576))

    strings = [(m.start(), m.group(0).decode("ascii", "replace"))
               for m in STR_RE.finditer(data)]
    print("可打印字符串数: %d" % len(strings))

    # 版本样式串（判断真实版本 vs 伪造 1.0.0.000000）
    vers = sorted(set(m.group(0).decode()
                      for m in re.finditer(rb"[0-9]{1,2}\.[0-9]{1,3}\.[0-9]{1,5}", data)))
    print("\n--- 版本样式串 (%d) ---" % len(vers))
    print(", ".join(vers[:60]))

    # 全部 DLL 引用（启动器=只有系统 dll；本体=自家 dll 一堆）
    dlls = sorted(set(m.group(0).decode("ascii", "replace")
                      for m in re.finditer(rb"[A-Za-z0-9_\-]{3,40}\.dll", data)))
    print("\n--- PE/字符串内 DLL 引用 (%d) ---" % len(dlls))
    for d in dlls:
        print("  ", d)

    # 含关键词的字符串
    pat = re.compile("|".join(re.escape(k) for k in keywords), re.IGNORECASE)
    print("\n--- 含关键词的字符串 ---")
    hits = 0
    for off, s in strings:
        if pat.search(s):
            print("[%08x] %s" % (off, s))
            hits += 1
    print("(命中 %d 条)" % hits)

    # PDB/源码路径 —— 直接暴露编译来源，判断是不是官方组件最有效
    pdbs = sorted(set(s for _, s in strings
                      if s.lower().endswith(".pdb") or s.lower().endswith(".cpp")
                      or s.lower().endswith(".cc")))
    if pdbs:
        print("\n--- PDB/源码路径（可判官方 vs 改造） ---")
        for p in pdbs[:25]:
            print("  ", p)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    probe(sys.argv[1], sys.argv[2:] or DEFAULT_KW)
