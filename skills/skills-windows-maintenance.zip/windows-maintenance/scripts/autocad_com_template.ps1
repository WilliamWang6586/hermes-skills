# Verified 2026-10-03 on AutoCAD 2027 (D:\autocad\AutoCAD 2027\acad.exe), Win11 + PS 5.1.
# ASCII-only on purpose: PS 5.1 reads BOM-less UTF-8 scripts as ANSI/GBK -> CJK strings get
# mangled; and COM SaveAs to a CJK path fails even with clean runtime strings (see SKILL.md).
# Demo draws a flange plate: 3 concentric circles + 6 bolt holes + centerlines + 2 dims.
$ErrorActionPreference = 'Stop'
try { $app = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application') } # reuse running instance
catch { $app = New-Object -ComObject AutoCAD.Application }                               # or launch
$app.Visible = $true

$doc = $app.Documents.Add()
$ms = $doc.ModelSpace

# --- Layers ---
$doc.Layers.Add('Centerline').Color = 1          # red
$doc.Layers.Add('Dims').Color = 3                # green
try { $doc.Linetypes.Load('CENTER','acad.lin') } catch {}
$doc.Layers.Item('Centerline').Linetype = 'CENTER'

# --- Flange body (coords MUST be [double[]]; see SKILL.md pitfall) ---
$ms.AddCircle([double[]]@(0,0,0), 50) | Out-Null
$ms.AddCircle([double[]]@(0,0,0), 20) | Out-Null
$bc = $ms.AddCircle([double[]]@(0,0,0), 35); $bc.Layer = 'Centerline'
for ($k=0; $k -lt 6; $k++) {
  $a = $k * [math]::PI / 3
  $ms.AddCircle([double[]]@((35*[math]::Cos($a)),(35*[math]::Sin($a)),0), 5) | Out-Null
}

# --- Centerlines ---
$cl1 = $ms.AddLine([double[]]@(-60,0,0), [double[]]@(60,0,0)); $cl1.Layer = 'Centerline'
$cl2 = $ms.AddLine([double[]]@(0,-60,0), [double[]]@(0,60,0)); $cl2.Layer = 'Centerline'

# --- Dimensions ---
$ms.AddDimRadial([double[]]@(0,0,0), [double[]]@((50*[math]::Cos(0.7854)),(50*[math]::Sin(0.7854)),0), 15) | Out-Null
$ms.AddDimDiametric([double[]]@(-20,0,0), [double[]]@(20,0,0), 12) | Out-Null

$app.ZoomExtents()
$doc.SaveAs('D:\flange_demo.dwg')                # ASCII path only

# --- Bring window to front + full-screen screenshot so the user SEES the result ---
$sig = '[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);'
$t = Add-Type -MemberDefinition $sig -Name Win32FG -Namespace W -PassThru
$t::SetForegroundWindow([IntPtr]($app.HWND)) | Out-Null
Start-Sleep -Seconds 3

Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size)
$g.Dispose()
$bmp.Save('D:\flange_screenshot.png',[System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

Write-Output ("entities=" + $doc.ModelSpace.Count + " dwg=" + (Test-Path 'D:\flange_demo.dwg') + " png=" + (Test-Path 'D:\flange_screenshot.png'))
