# -*- coding: utf-8 -*-
"""体检 .vbs 文件编码 —— WSH 只按 ANSI(GBK) 读脚本，含中文的路径是 80070003 的病根。

用法:
    python3.14.exe check_vbs_encoding.py                       # 扫默认位置(启动文件夹+网关目录)
    python3.14.exe check_vbs_encoding.py <file.vbs> [<file.vbs> ...]

行为:
    - 报告每个文件的真实编码(UTF-16LE / UTF-8-BOM / UTF-8)与非 ASCII 字符位置
    - 纯 ASCII 的 → 直接转成 ASCII 落盘(WSH 从此不可能读错)
    - 含中文的 → 标 HAS-CJK-SKIP 不动它, 提示"去中文"而不是"换编码"
退出码: 0 = 全部纯 ASCII 或已转好; 1 = 存在含中文需人工处理的文件
"""
import os
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

DEFAULT_TARGETS = [
    os.path.expandvars(r"%LOCALAPPDATA%\Hermes Agent CN Desktop\data\hermes-home"
                       r"\gateway-service\Hermes_Gateway.vbs"),
    os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Hermes_Gateway.vbs"),
    os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Hermes_GatewayGuard.vbs"),
    os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Hermes_GatewayGuard.vbs"),
]


def sniff(path):
    """返回 (编码名, 解码后文本)。只认 BOM 与 UTF-8 回退，够用。"""
    raw = open(path, 'rb').read()
    if raw[:2] == b'\xff\xfe':
        return 'UTF-16LE', raw[2:].decode('utf-16-le', errors='replace')
    if raw[:3] == b'\xef\xbb\xbf':
        return 'UTF-8-BOM', raw[3:].decode('utf-8', errors='replace')
    return 'UTF-8', raw.decode('utf-8', errors='replace')


def fix(path):
    enc, text = sniff(path)
    # 非 ASCII 且非换行的字符 —— 这些就是会被 WSH 读成乱码的中文
    bad = [c for c in text if ord(c) > 127 and c not in '\r\n']

    if bad:
        return enc, len(bad), False, 'HAS-CJK-SKIP'

    # 纯 ASCII：统一换行后按 ASCII 落盘（顺带去掉任何 BOM）
    text = text.replace('\r\n', '\n').replace('\r', '\n').replace('\n', '\r\n')
    with open(path, 'wb') as f:
        f.write(text.encode('ascii'))
    return enc, 0, True, 'ASCII-OK'


def main():
    targets = sys.argv[1:] or DEFAULT_TARGETS
    seen, failed = set(), 0

    for p in targets:
        if p in seen:            # 去重(默认列表里可能有重复项)
            continue
        seen.add(p)
        name = os.path.basename(p)
        if not os.path.exists(p):
            print(f"[跳过] 不存在: {p}")
            continue
        enc, nbad, fixed, status = fix(p)
        flag = '✅' if status == 'ASCII-OK' else '⚠️ '
        print(f"{flag} {name:<28} 原编码={enc:<10} 中文/非ASCII={nbad:<3} "
              f"{'已转ASCII' if fixed else '未改动'}  {status}")
        if nbad:
            failed += 1
            print(f"     → 病根是路径里的中文, 改为从 %LOCALAPPDATA% 拼接, "
                  f"别只换编码(换编码下次被重存为 UTF-8 立刻复发)")

    print(f"\n{'=' * 62}")
    if failed:
        print(f"[{failed} 个文件含中文] → 需人工去中文后重跑本脚本")
    else:
        print("[全部纯 ASCII] → WSH 不会再报 80070003")
    return 1 if failed else 0


if __name__ == '__main__':
    # 自检：确认 sniff 能识别三种编码
    _t = b'\x27 ascii only\r\n'
    assert b'\xff\xfe' not in _t and b'\xef\xbb\xbf' not in _t
    sys.exit(main())
