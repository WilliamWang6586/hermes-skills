param([string]$ProcName = "QQ")
# 枚举指定进程名的全部可见顶层窗口（标题 + RECT），用于定位独立面板窗口（如 QQ 群文件）。
# 用法: powershell -File win_enum_windows.ps1 -ProcName QQ
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class WinEnum {
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
}
"@
$script:pids = @(Get-Process -Name $ProcName* -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
if (-not $script:pids) { Write-Host "NO_PROCESS: $ProcName"; exit 1 }
$script:results = @()
$cb = [WinEnum+EnumWindowsProc]{ param($h, $l)
    $pid2 = 0
    [WinEnum]::GetWindowThreadProcessId($h, [ref]$pid2) | Out-Null
    if ($script:pids -contains $pid2 -and [WinEnum]::IsWindowVisible($h)) {
        $sb = New-Object System.Text.StringBuilder 512
        [WinEnum]::GetWindowText($h, $sb, 512) | Out-Null
        $r = New-Object WinEnum+RECT
        [WinEnum]::GetWindowRect($h, [ref]$r) | Out-Null
        $script:results += "HWND=$h TITLE='$($sb.ToString())' RECT=($($r.Left),$($r.Top)) $($r.Right-$r.Left)x$($r.Bottom-$r.Top)"
    }
    return $true
}
[WinEnum]::EnumWindows($cb, [IntPtr]::Zero) | Out-Null
$results | ForEach-Object { Write-Host "  $_" }
