param([double]$PX, [double]$PY, [string]$Label = "click")
# 窗口内百分比坐标点击 + 截图一体脚本。
# 用法: win_gui_step.ps1 -PX 20 -PY 50 -Label "click item"
# 前置: 调用方先 MoveWindow 固定目标窗口位置（否则窗口漂移导致坐标全错）。
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class GuiWin {
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    public const uint LEFTDOWN = 0x02; public const uint LEFTUP = 0x04;
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    public static void Click(int x, int y) { SetCursorPos(x, y); System.Threading.Thread.Sleep(120); mouse_event(LEFTDOWN, 0, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(80); mouse_event(LEFTUP, 0, 0, 0, UIntPtr.Zero); }
}
"@

# 进程名匹配规则改为参数/可配置；QQ 例：$_.ProcessName -match "QQ"
$procName = "QQ"
$qqProc = Get-Process | Where-Object { $_.ProcessName -match $procName -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if (-not $qqProc) { Write-Host "NO_TARGET_PROC"; exit 1 }
$hwnd = $qqProc.MainWindowHandle
[GuiWin]::SetForegroundWindow($hwnd) | Out-Null
[GuiWin]::ShowWindow($hwnd, 9) | Out-Null  # SW_RESTORE（最小化窗口 GetWindowRect 返回负坐标）
Start-Sleep -Milliseconds 500
$rect = New-Object GuiWin+RECT
[GuiWin]::GetWindowRect($hwnd, [ref]$rect) | Out-Null
$w = $rect.Right - $rect.Left; $h = $rect.Bottom - $rect.Top
$sx = [int]($rect.Left + $w * $PX / 100.0)
$sy = [int]($rect.Top + $h * $PY / 100.0)
Write-Host "STEP[$Label] win=($($rect.Left),$($rect.Top) ${w}x${h}) click=($sx,$sy)"
[GuiWin]::Click($sx, $sy)
Start-Sleep -Seconds 2

# 截图（保存到 ASCII 路径；中文路径在 PS5.1 会乱码）
$rect2 = New-Object GuiWin+RECT
[GuiWin]::GetWindowRect($hwnd, [ref]$rect2) | Out-Null
$w2 = $rect2.Right - $rect2.Left; $h2 = $rect2.Bottom - $rect2.Top
$bmp = New-Object System.Drawing.Bitmap($w2, $h2)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($rect2.Left, $rect2.Top, 0, 0, $bmp.Size)
$bmp.Save("D:\mc\gui_screen.png", [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Host "SHOT win=($($rect2.Left),$($rect2.Top) ${w2}x${h2}) -> D:\mc\gui_screen.png"
