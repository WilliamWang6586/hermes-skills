---
name: windows-maintenance
description: Windows 系统维护与自动化——垃圾文件清理、大目录归档/整库重组（md5 去重、搬迁后修计划任务与写死路径）、进程管理（含权限坑）、计划任务、开机自启（启动文件夹/.vbs/.bat）、WSH 脚本报错(80070003 路径乱码)、Edge headless 转 PDF/截图、PowerShell 5.1 中文编码坑。触发场景：清理垃圾/磁盘空间、整理文件夹/归档/删文件夹、退出程序、创建定时任务、开机弹 Windows Script Host 报错、设置开机自启、HTML转PDF、PS脚本中文乱码。
---

# Windows 系统维护与自动化

## 垃圾文件清理（安全步骤）

**先扫描汇总再动手**，展示给用户确认，下载文件夹等含个人文件的位置需单独确认。

| 位置 | 说明 |
|:-----|:-----|
| `%TEMP%`（`C:\Users\<user>\AppData\Local\Temp`） | 大头，本机实测 860 文件 ≈ 2.6GB |
| `C:\Windows\Temp` | 需管理员权限，常为空 |
| `C:\Windows\Prefetch` | 需管理员 |
| `%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache` + `Code Cache` | Edge 缓存 |
| Chrome 同路径 | Chrome 缓存 |
| `%LOCALAPPDATA%\CrashDumps` | 崩溃转储，实测 182MB |
| `%LOCALAPPDATA%\Microsoft\Windows\Explorer\thumbcache_*.db` + `iconcache_*.db` | 缩略图缓存，先 `Stop-Process explorer` |
| `%APPDATA%\Microsoft\Windows\Recent` | 最近文档快捷方式 |
| 回收站 | 用 `Get-CimInstance Win32_LogicalDisk` 查可用空间 |

删除命令：`Remove-Item -Path <path>\* -Recurse -Force -ErrorAction SilentlyContinue`（单条批处理，逐项 try/catch）。

## D 盘/大目录扫描与清理（2026-08 实测）

**先扫大小再删**，按目录从大到小列出让用户确认（`Get-ChildItem D:\ -Directory` 逐目录
`Measure-Object Length -Sum`，Sort 降序）。本机 D 盘实测可安全清理项：

| 目录 | 大小 | 内容 | 判定 |
|:-----|:-----|:-----|:-----|
| `D:\LeStoreDownload` | ~2.4GB | 联想应用商店安装包缓存（40+ .exe） | ✅ 安全删（装完无用的安装包） |
| `D:\KuGou\Temp` | 少量 | 酷狗音乐临时缓存 | ✅ 安全删 |
| `D:\biubiu_temp_` | 0 | 加速器临时（常为空） | ✅ 安全删 |
| `D:\6.0.1.11779` | ~1.4GB | **剪映专业版 6.0.1.11779 本体（破解版，无安装记录）** | ❌ **不删**（用户明示：是破解版，剪映靠它运行） |
| `D:\BaiduNetdiskDownload` | 1.6GB | 百度网盘下载（可能含 MC 整合包等有用文件） | ⚠️ 逐项确认 |
| `D:\STEAM` / `摄影` / `mc` / `Tencent` / `Adobe` | 合计 360GB+ | 游戏/照片/聊天记录 | ❌ 不删 |

删除前 `$before = (Get-PSDrive D).Free` 记录，删后对比算释放量（实测一次释放 2.4GB）。
`Remove-Item` 前先 `Get-ChildItem` 计数给用户看删了多少项。

### ⚠️ 目录被 ACL 拒绝权限锁死（2026-09-19 实测，LeStoreDownload 连管理员都删不掉）

**症状**：`Remove-Item -Force` 报「对路径的访问被拒绝」，**提权（RunAs）后同样失败**。
`Rename-Item` 也失败。文件属性只是 `Archive`，无只读/系统属性。

**诊断**（关键一步，一眼定性）：
```powershell
(Get-Acl 'D:\path\file.exe').Access | Select IdentityReference, FileSystemRights, AccessControlType
```
若出现 `BUILTIN\Users  Write,Delete  **Deny**` → 是程序故意设置的**显式 Deny ACE**。
Windows 里 **Deny 优先级高于 Allow**，所以即使用户在 Administrators 组且提权，Deny 依然拦死
（除非以 SYSTEM/TrustedInstaller 身份跑，或用 SeBackupPrivilege）。
典型来源：联想电脑管家/LeStore 下载目录、部分安全软件的保护目录。

**标准破解三步（写 .ps1 提权跑）**：
```powershell
# 1. 夺取所有权（Administrators 已是 Owner 也行，重设一次确保）
$acl = Get-Acl $f.FullName
$acl.SetOwner([System.Security.Principal.NTAccount]'BUILTIN\Administrators')
Set-Acl -Path $f.FullName -AclObject $acl
# 2. 移除全部 Deny 规则（RemoveAccessRuleSpecific，不能用 RemoveAccessRule 全家桶删）
$acl = Get-Acl $f.FullName
$acl.Access | Where-Object { $_.AccessControlType -eq 'Deny' } | ForEach-Object { [void]$acl.RemoveAccessRuleSpecific($_) }
Set-Acl -Path $f.FullName -AclObject $acl
# 3. 删除
Remove-Item $f.FullName -Force
```
- 目录本身也有 Deny 时同样处理；处理完后该目录可正常写入（联想不会再拦，除非它重新加）。
- 每一项都 try/catch 单独记录，别让一个失败中断整批。
- 提权脚本编排：`Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',$p`，
  脚本内 `Out-File -Encoding UTF8` 写 ASCII 或已知路径日志，主会话 `Start-Sleep 25~30` 后读日志验证。

## 破解版/绿色版软件的启动器路径解析（2026-09-19 实测，剪映 6.0.1.11779）

用户症状常被描述成"我把这些文件挪到一个文件夹，软件就打不开了"。**先还原真相，别急着修。**

### 铁证一：快捷方式 ≠ 程序本体

```powershell
$shell = New-Object -ComObject WScript.Shell
Get-ChildItem "$env:USERPROFILE\Desktop","$env:PUBLIC\Desktop","$env:APPDATA\Microsoft\Windows\Start Menu\Programs" -Recurse -Filter *.lnk |
  ForEach-Object { $l=$shell.CreateShortcut($_.FullName); if($l.TargetPath -match '关键词'){ "$($_.Name) -> $($l.TargetPath)  工作目录:$($l.WorkingDirectory)" } }
```
实测：`桌面\剪映专业版.lnk -> D:\JianyingPro.exe`，**工作目录 `D:\`**；而本体在
`D:\6.0.1.11779\JianyingPro.exe`。**两者不是一个东西，这是整个问题的钥匙。**

### 铁证二：判定启动器 vs 本体（三指标）

| 指标 | 启动器 | 本体 |
|:--|:--|:--|
| 体积 | 约 1.8MB（偏大） | 0.5MB（真产品 exe 常很小，大头在 dll） |
| `VersionInfo.FileVersion` | **伪造（如 `1.0.0.000000`）** | 真实版本号（如 `6.0.1.11779`） |
| PE 导入表 DLL | **只有系统 dll**（KERNEL32/SHELL32/SETUPAPI/USER32/PSAPI…） | 一堆自家 dll |

**「只引用系统 dll + 体积偏大 + 版本号假」= 启动器/Launcher，不是本体。**

### 铁证三：从二进制字符串还原启动器逻辑（不用反编译）

用 Python 正向扫可打印 ASCII 串（脚本见 `scripts/probe_exe_strings.py`，
用法 `python3.14.exe scripts/probe_exe_strings.py <exe路径>`）。实测 `D:\JianyingPro.exe` 内嵌：

```
D:\code\bytedance\installer\LVInstaller\VideofusionInstaller\build\Release\JianyingLauncher.pdb
JianyingLauncher.exe
GetDefInstallDirEx                                    ← 读注册表拿安装目录
JianyingPro_{AB736139-EF24-44DA-9D11-B254D10AD156}    ← 要查的 GUID 键
join_UE_program / realExePath=%ws / assembler.getExePath failed
```
→ 定位顺序：**①注册表 GUID 键 → ②同目录配置文件（`D:\Configure.ini` 的 `last_version=`）→ ③相对自身位置**。

本机实测：①不存在（破解版没跑安装程序）、②`last_version=` 为空、只剩③ ——
**所以它能跑纯属"Launcher 恰好躺在 `D:\` 根、本体恰好也在 `D:\` 下"的位置巧合。**
用户把两者一起挪进子文件夹 → 相对位置变了 → `getExePath failed` → 打不开。

**这是绿色版/破解版的通病，不是用户"装乱了"**（同理：Adobe 绿色版、网盘下的绿色游戏）。
排查顺序也别搞反：**先看注册表有没有安装记录**（Uninstall 项 + 厂商键），
`Get-ItemProperty HKLM:\...\Uninstall\*,\...\WOW6432Node\...,HKCU:\...\Uninstall\* | ?{$_.DisplayName -match '剪映|Jianying'}`
—— 卸载记录为空 = 绿色版，直接走上面的推论，别去修"安装"。

### 修法：绕过启动器（推荐）

本体 exe 通常**不需要启动器也能独立运行**（启动器只做版本检查/更新，破解版不需要）：

1. 先验证：`Start-Process '<本体目录>\<App>.exe' -WorkingDirectory '<本体目录>'`
2. 起来了 → 改快捷方式 `TargetPath=<本体exe全路径>`、`WorkingDirectory=<本体目录>`（旧 .lnk 先备份）
3. 之后目录随便挪，只要快捷方式指对本体

**别去补注册表 GUID 键**——不知道值的格式，补错更糟。绕过是最短的正确路径。

## 进程管理

- 查询：`Get-Process | Where-Object {$_.ProcessName -match "steam|biubiu"}`
- **正常退出优先**：Steam 用 `steam.exe -shutdown`（路径从注册表 `HKLM:\SOFTWARE\WOW6432Node\Valve\Steam` 或 `HKCU:\SOFTWARE\Valve\Steam` 读），优雅退出。
- **权限不足（Access denied）→ WMI Terminate**：`Stop-Process -Force` 和 `taskkill /F` 对管理员权限进程都报 Access is denied，但 `Get-WmiObject Win32_Process -Filter "Name='x.exe'" | ForEach-Object {$_.Terminate()}` 可以结束主进程（返回值 0=成功，2=拒绝/不存在），子进程随主进程退出。本机 Biubiu 加速器（6 个进程，主 PID 返回 0 即全退）。
- 特例：`taskkill` 对 `biubiu.exe` 报 "ERROR: Access is denied" 且 `-IM` 全失败 → 直接上 WMI。

## 计划任务（Task Scheduler）

```powershell
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"D:\path\script.ps1`""
$trigger = New-ScheduledTaskTrigger -Daily -At "18:35"
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
Register-ScheduledTask -TaskName "任务名" -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "..."
```
- 查看/验证：`Get-ScheduledTask -TaskName *`、`Get-ScheduledTaskInfo -TaskName`（LastRunTime/NextRunTime）、`Export-ScheduledTask`（XML）、`Start-ScheduledTask`（手动触发测试）。

## Edge headless（无头浏览器转换）

HTML → PDF：`msedge.exe --headless --disable-gpu --print-to-pdf="D:\out.pdf" --no-pdf-header-footer "D:\in.html"`
截图：`--screenshot="D:\out.png" --window-size=800,600 <url或文件>`
- Edge 路径：`${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe`（x86 优先，回退 ProgramFiles）
- **PowerShell 里用 `Start-Process -Wait` 调用，不要用 `&` 前缀**（`&` 会被 Hermes terminal 误判为 background 语法直接拒绝）。
- 大 HTML 转 PDF 实测 ~60 秒内完成，3.8MB PDF；`--print-to-pdf` 后等待 2-3 秒再检查文件存在。
- 失败时的 stderr 有 QQBrowser/GetUpdates 报错属正常噪音，以输出文件是否生成判断成功。

## DISM 组件清理（WinSxS）—— 本机不可用（2026-09-19 实测）

`Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase` 在本机（26100.8972）
跑到 **90.5% 后报「错误: 5 拒绝访问」**，且过程中 C 盘临时占用 ~900MB，**净效果是负的**。
不要在本机浪费 3 分钟跑它；`C:\Windows\Installer` 的 2.2GB 也别手动删（卸载/修复会坏）。
真要回收 WinSxS 空间，让用户走「设置 → 系统 → 存储 → 临时文件」或磁盘清理工具。

## PowerShell 5.1 中文编码坑（反复踩）

- **PS 5.1 读无 BOM 的 UTF-8 .ps1 脚本 → 中文字符串全乱码**（`Hermes文件库` 变 `Hermes鏂囦欢搴�`），导致路径写错、脚本报语法错。
- 两条出路：
  1. 脚本存 **UTF-8 with BOM**（PowerShell 5.1 正确识别）
  2. **直接改用 Python 处理中文路径**（更稳，推荐）：`.py` 源码默认 UTF-8，`os.path` 原生支持中文。
- write_file 写出的 .ps1 是无 BOM UTF-8 → 执行前先加 BOM：
  `$c=[IO.File]::ReadAllText($p,[Text.Encoding]::UTF8); [IO.File]::WriteAllText($p,$c,(New-Object Text.UTF8Encoding $true))`
- 中文正则也要避开：ps1 里 `-match "中文"` 同样乱码 → 用英文匹配（`baidu|Baidu` 代替 `百度`）。
- 本机 python：`C:\Users\王子涵\AppData\Local\Python\bin\python3.14.exe`（`python`/`py` 别名可能失效，用全路径）。
- 终端输出中文也可能乱码（console 编码），验证文件内容/存在性用 Python `os.listdir` 而非 PS `Get-ChildItem` 中文路径。
- **PS 报"找不到路径"但文件夹确实存在**：PS 5.1 的 .NET 路径 API 对含非 ASCII 字符的目录名解析失败（不是权限问题），Python `os.scandir`/`os.listdir` 正常 → 一律用 Python 处理中文路径。

### .vbs 脚本：根治法是【去中文】而不是换编码（2026-09-21 修正，前一版建议是错的）

**症状**：开机弹 Windows Script Host 报错 —— `脚本: ...\Hermes_Gateway.vbs`、`行: 24`、
`错误: 系统找不到指定的路径。`、`代码: 80070003`（ERROR_PATH_NOT_FOUND）。

**根因**：WSH（`cscript`/`wscript`）按**系统 ANSI 代码页（中文机=GBK）**读 `.vbs`。
脚本里若**硬编码了含中文用户名的路径**（`C:\Users\王子涵\...`），一旦文件编码与 WSH 的
预期不一致，中文就被解码成乱码路径 → 任何引用它的行（`sh.CurrentDirectory`、
`WScript.Shell.Run` 的 exe 路径）全报 80070003。

> ⚠️ **前一版本技能写\"整篇重写为 UTF-16LE 才根治\"——这条是错的，且它本身制造了本次故障。**
> 用 UTF-16LE 存只治了当次，下次任何工具把它重存为 UTF-8（`write_file` 默认就是）立刻复发，
> 而且 UTF-16 文件含 BOM 时 `read_file` 会判为二进制读不出来，排查更绕。
> **正确认知：病根是「路径里带了中文」，不是「编码选错了」。编码只是症状的触发器。**

**根治修法：让脚本一个中文字都不带**——路径全部从环境变量在运行时拼：

```vbs
Dim base
base = sh.Environment("PROCESS").Item("LOCALAPPDATA") & "\Hermes Agent CN Desktop\data"
hermesHome = base & "\hermes-home"
runtimeExe = base & "\versions\0.19.0-cn.7\hermes-agent-cn-runtime-win32-x64.exe"
```

这样文件是**纯 ASCII**，无论存成 UTF-8 / ANSI / UTF-16LE，WSH 都读不出错。
本机实测（`LOCALAPPDATA` 展开后即 `C:\Users\王子涵\AppData\Local`），启动器 `cscript //nologo` 退出码 0。

**启动前先做存在性检查**（安装目录被改动时静默退出，而不是弹报错框）：
```vbs
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FileExists(runtimeExe) Then WScript.Quit 1
```

**验证方式**（两段式，别只看\"没报错\"）：
```powershell
# ① 语法+路径：退出码 0 = 无错（比看有没有弹窗可靠，弹窗可能被已点掉）
Start-Process cscript.exe -ArgumentList "//nologo","`"$vbs`"" -Wait -PassThru -WindowStyle Hidden
# ② 副作用：确认它真把目标进程拉起来了
@(Get-CimInstance Win32_Process | ? { $_.CommandLine -like '*gateway run*' -and $_.Name -like '*hermes*' }).Count
```
⚠️ 含 `WScript.Sleep 180000` 的自检类脚本**别用 `-Wait` 干等**：会卡满 3 分钟触发命令超时，
看起来像失败其实是设计行为。要么跳过实跑只做编码/语法检查，要么后台跑。

**批量体检脚本**：`scripts/check_vbs_encoding.py`（扫多个 .vbs，报编码/非 ASCII 字符位置，
对纯 ASCII 的都转成 ASCII 落盘，含中文的标 `HAS-CJK-SKIP` 提示需人工去中文）。

**排查顺序别搞反**：先 `([System.IO.File]::ReadAllBytes($p))[0..1]` 看前两字节定编码
（`FF FE`=UTF-16LE、`EF BB BF`=UTF-8 BOM、其他=UTF-8/ANSI），再搜有没有非 ASCII 字符，
**不是先怀疑语法**。�error 里的 `行: N` 通常落在 `sh.CurrentDirectory` 或 `sh.Run` 那两行上。

**别被无关教程带偏**：用户可能拿\"Microsoft Application Compatibility Toolkit 加白名单绕 UAC\"
之类的老教程（Win7 时代、针对别的 exe）来问。80070003 是**路径不存在**，跟 UAC 权限弹窗无关，
装 ACT 是拿大炮打蚊子——直接说清病根并修，别照着跑。

## 桌面 GUI 自动化（截图/UIAutomation/窗口置顶）

- **全屏截图 + vision_analyze 检查窗口状态**（看用户屏幕上有什么窗口、弹窗、按钮）：
  `Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $b=[System.Windows.Forms.SystemInformation]::VirtualScreen; $bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Left,$b.Top,0,0,$bmp.Size); $bmp.Save("D:\path.png")`
- **枚举窗口**：UIAutomation（`Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes`；`RootElement.FindAll(Children, TrueCondition)` 遍历 `Current.Name/ClassName/ProcessId`）或 Win32 `EnumWindows`+`GetWindowText`。窗口 class 参考：`Chrome_WidgetWin_1`=Edge/Chromium、`Tauri Window`=Hermes 桌面版。
- **点按钮**：窗口内 `FindAll(Descendants, PropertyCondition(Name,"按钮名"))` → `GetCurrentPattern([InvokePattern]::Pattern).Invoke()`；列表项用 `SelectionItemPattern.Select()`。
- **置顶窗口的坑**：后台进程调 `SetForegroundWindow` 常被 Windows 前台锁拒绝；`ShowWindow(9/5)` 对最小化/隐藏窗口有效，但 **`GDI+ Window (某某.exe)` 类是隐藏渲染窗口不是主界面**（BaiduNetdiskUnite.exe 实测）——先 UIAutomation 列窗口标题判断哪个是真正 UI 窗口，不行就让用户 Alt+Tab，别硬刚。
- 系统级「打开方式」弹窗（选应用打开 https: 链接）默认焦点是「取消」，SendKeys ENTER 会取消；正确做法是 UIAutomation 找到选项后 Invoke/Select。

## Electron 应用（QQNT/微信等）GUI 自动化（2026-08-31 实测）

**UIA 路线不可用**：QQNT 是 Electron，UIAutomation 树只有 `Window > Pane` 一个节点，无子控件——UIA 点击/查找全废。微信（xwechat）同理。正确路线是**截图 + 视觉识别 + 模拟点击**：

1. **EnumWindows 按 PID 找目标窗口**：QQNT 的「群文件」等面板是**独立顶层窗口**（标题=“群文件”，如 561x641），`MainWindowHandle` 只给主壳窗口（1300x900 那个）——必须 `EnumWindows` + `GetWindowThreadProcessId` + `IsWindowVisible` + `GetWindowText` 枚举该进程全部可见窗口，按标题挑目标 HWND。
2. **按句柄截图**：`GetWindowRect(hwnd)` → `CopyFromScreen(Left, Top, 0, 0, Size)` 存 **ASCII 路径**（PS5.1 中文路径乱码）。别截主窗口——面板是独立窗口，截主窗口区域看不到。
3. **视觉识别定位**：vision_ocr.py（qwen-vl-max）问控件位置（给窗口内百分比）→ 换算屏幕坐标 → `SetCursorPos + mouse_event` 点击。
4. **每轮操作前重新 GetWindowRect**：Electron 窗口位置会漂移（移动/最小化恢复后都变），基于旧坐标点击必歪；稳妥先 `MoveWindow(hwnd, 60, 60, 1300, 900)` 固定。
5. **QQ 已下载群文件缓存**：`Documents\Tencent Files\<QQ号>\nt_qq\nt_data\File\`（含 Thumb 子目录）；`flashfransfer\` 是闪传缓存。

**坑（都实测踩过）**：
- 点击坐标基于旧窗口位置 → 点错会话/误触屏幕其他程序（曾截到用户微信医疗页面）→ **每步前截图确认当前前台状态**，别连点。
- `CopyFromScreen` 截的是**屏幕区域**不是窗口内容：目标面板被其他窗口遮挡时截到遮挡物 → 先 `SetForegroundWindow`，还不行就让用户移开遮挡/手动截图。
- 视觉模型对 UI 小图标、文件名字体误判率高（把文件列表当聊天记录、文件夹名全读不出）→ 截图**放大 2x**（Graphics DrawImage HighQualityBicubic）再识别；识别结果用 MEDIA 发用户确认。
- 全屏截图/区域截图命令在 Hermes terminal 会触发用户批准（BLOCKED）——先征得同意再跑，或只截目标窗口。
- 模拟点击会真的动用户鼠标——**用户正用电脑时别盲操作**，让用户配合打开目标面板（如群文件）再截图，交互成本最低。
- PowerShell 内联 `& "py.exe" -c "带中文/嵌套引号的代码"` 必炸（`&` 被误判 background、引号被吞）→ 一律写成 .ps1/.py 文件再执行。

## RDP 远程桌面只读运维（2026-09-01 实测，MC 服务器运维场景）

给物理 Windows 服务器做只读体检的标准流程（不装任何软件、不落明文凭证、不改远端文件）：

1. **测通道**：`Test-NetConnection <host> -Port <port>`（RDP 常改非默认端口）；`Test-WSMan` 测 WinRM 5985/5986——**默认不开**，别指望 PowerShell 远程，走 RDP GUI。
2. **存凭证**：`cmdkey /generic:TERMSRV/<host> /user:<账号> /pass:"<密码>"`（存 Windows 凭据管理器，不写明文文件）。
3. **写 .rdp 配置**（关键行）：
   ```
   full address:s:<host>:<port>
   username:s:<账号>
   drivestoredirect:s:D:\本地目录\rdp_share   # 磁盘映射：本地目录出现在远端会话
   authentication level:i:0
   prompt for credentials:i:0
   ```
   `Start-Process mstsc -ArgumentList "<path>.rdp"` 启动；连接窗口标题 = `<host>:<port> - 远程桌面连接`。
4. **远程执行只读脚本**：
   - 检查脚本放本地映射目录（如 `rdp_share\check.ps1`），输出写 `Join-Path $PSScriptRoot 'result.txt'` → 自动回写本地映射盘。
   - **映射盘符未知**时远端命令遍历找脚本：
     `powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem [A-Z]:\check.ps1 -ErrorAction SilentlyContinue | ForEach-Object { & powershell -NoProfile -ExecutionPolicy Bypass -File $_.FullName }"`
   - 键盘注入：`SetForegroundWindow(hwnd)` + `SendMessage(hwnd, WM_SYSKEYDOWN=0x0104, 0x52, 0)`（模拟 Win+R）+ 剪贴板粘贴 + `{ENTER}`（SendKeys 方式，见 Electron 章节）。
5. **验证**：本地读 `rdp_share\result.txt`；远程窗口用截图确认状态（见 GUI 自动化章节）。

**只读原则**：脚本里只允许 `Get-*`/`netstat`/`powercfg /a`/读日志/列目录，禁止任何写/删/改；改动类操作必须回本地由用户确认后另出脚本。

**坑（实测）**：
- **Win10 单交互式 RDP 会话**：新登录会把当前会话顶掉——操作前必须让用户/服主知情（约时间）。
- 登录可见：事件 4624、`qwinsta` 能查到会话；远端屏幕/控制台操作在物理机前可见。无法隐身。
- 模拟键盘注入命令在 Hermes terminal 会触发用户批准（BLOCKED）——**先说明要做什么再执行**。
- mstsc 首连可能弹证书验证（`.rdp` 里 `authentication level:i:0` 可跳过）；截图确认已进桌面（有任务管理器/桌面图标=成功）。

## 默认应用/文件关联被 WPS 等套件劫持（2026-08 实测）

**症状**：用户说"双击 Office 文档不是用 Office 打开"。诊断三步：

1. 看系统类型关联是否已指向 Office —— `cmd /c assoc .docx`（应输出 `Word.Document.12`）、`cmd /c ftype Word.Document.12`（应指向 `WINWORD.EXE`）。
2. **再看 Windows 实际默认（UserChoice）** —— `Get-ItemProperty "HKCU:\...\Explorer\FileExts\.docx\UserChoice" -Name ProgId`。若 UserChoice 是 `WPS.Docx.6` / `ET.Xlsx.6` / `WPP.PPTX.6`，就是被 WPS 劫持了（assoc 指向 Office 但 UserChoice 指向 WPS，两者不一致，Win11 以 UserChoice 为准）。
3. 查 WPS 是否在跑：`Get-Process -Name wps,et,wpp,wpscenter,wpscloudsvr`（WPS 可能装在 `%LOCALAPPDATA%\Kingsoft`，Program Files 下找不到）。

**根因**：WPS 后台守护进程（尤其 `wpscloudsvr`）持续把 UserChoice 重置回 WPS —— 所以直接改/删 UserChoice 会被"自愈"回 WPS。

**修复顺序（必须先停守护，否则白改）**：
1. 结束 WPS 进程（`wps`,`et`,`wpp`,`wpscenter`,`wpscloudsvr`），`Stop-Process -Force` 失败则 WMI `Terminate()`（见"进程管理"节）。
2. 清除 UserChoice + OpenWithProgids 里的 WPS ProgId —— **用 Python `winreg`**（`winreg.DeleteKey(HKCU, ...\FileExts\.docx\UserChoice)`）。⚠️ PowerShell `Remove-Item -Recurse` 和 `reg delete` 在此键上报"子项不存在/无法删除子目录树"且会被守护重置；Python `winreg.DeleteKey` 可靠。
3. `taskkill /F /IM explorer.exe` + `Popen(['explorer.exe'])` 刷新，系统回落到 assoc(Office)。
4. 用 Python winreg 重新读 UserChoice 验证（已删则系统用 ftype=Office）。

**注意**：只停进程不卸 WPS 的话，WPS 后台重启后又可能抢回默认。要长效得卸 WPS 或让用户"设置→默认应用"手动锁。

## WSL 调用的 PS 5.1 输出噪音（2026-08 实测）

`wsl -d Ubuntu-24.04 -- bash -c "..."` 在 PS 5.1 里执行时，**输出前缀会带 UTF-16 空字符乱码**
（`w\u0000s\u0000l\u0000: \u0000...localhost...NAT...`，即 WSL 的 localhost NAT 警告被按 UTF-16 显示）
以及 PowerShell 红字 `NativeCommandError` 噪音。**这些都是正常噪音**：

- 判断成功看 **`exit_code`/`$LASTEXITCODE`**（0 = 成功）和**实际输出内容**（JSON/结果在噪音之后正常出现），不要被红字 `CategoryInfo: NotSpecified` 吓到。
- 内联 `bash -c '...'` 带 JSON/引号嵌套必炸（PS 5.1 引号规则），**写成 `.sh` 文件再 `wsl -d Ubuntu-24.04 -- bash /mnt/d/.../script.sh`**。
- WSL 内访问 Windows 文件用 `/mnt/c/...`、`/mnt/d/...` 路径；调用 Windows 侧 exe 也在 WSL 里用 `/mnt/c/...` 全路径（如 `/mnt/c/Users/<user>/.local/bin/skillspector.exe`）。
- **Windows 原生 TLS(schannel) 对个别主机握手失败时的兜底**：Windows 侧 `urllib`/`curl.exe` 报 `SSL handshake failed` / `UNEXPECTED_EOF_WHILE_READING`（`exit_code 35` / `Errno 10054`），且同环境其他主机（baidu、学校官网）正常 → 是该主机到本机的 TLS 路径问题，不是断网。用 `curl.exe -o /dev/null -w "%{http_code}"` 分别测百度/目标主机区分。**兜底：走 WSL 的 OpenSSL** —— `wsl -d Ubuntu-24.04 -- curl -sS ...`（同参数），已实测对同主机 `200` 成功。发布类 multipart POST（含中文 changelog）写成 `.sh` 文件再 `wsl ... bash /mnt/d/.../x.sh`，避免 PS 引号/中文编码炸。上传成功看返回 JSON 里的 `{"success":true,data:{version:...}}`。

## 系统时间校准 + 当前日期核对（2026-09 实测）

**什么时候需要**：任何涉及「今天/明天/几点起床/某个日期周几」的问答，或发现文件时间戳/定时任务异常时。Windows 本机时间可能**滞后/超前**（时钟漂移、电池 CMOS、时区错），会直接导致 agent 答错日期。

**先核对再答**：用联网时间做基准，别信 `Get-Date`。
`curl.exe -sI --connect-timeout 10 --max-time 15 "https://api.github.com" 2>&1 | findstr /i date`（GMT，北京时间 +8）。或 `curl.exe -s https://worldtimeapi.org/api/ip`。

**校准（需管理员，普通终端报 Access denied 0x80070005）**：
1. 写一个 `.ps1`（内含 `net stop w32time; w32tm /config /manualpeerlist:"time.windows.com,0x9" /syncfromflags:manual /reliable:yes /update; net start w32time; w32tm /resync /force`），结果 `Out-File` 到 ASCII 路径日志。
2. 提权运行：`Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','D:\...\calib.ps1'`。**注意**：`-Wait` 时若用户取消 UAC 会报 `The operation was canceled by the user`，别在 `-Wait` 后立即读结果——先 `Start-Sleep` 几秒。
3. **UAC 必须用户点"是"**，agent 无法绕过；用户点"否"/没看到弹窗则失败，需再次发起并提醒用户留意弹窗。
4. 校准后验证：`Get-Date -Format 'yyyy-MM-dd HH:mm:ss'` 对比联网时间（差 <1 分钟即成功）。若日志文件没写出但时间已对，以 `Get-Date` 实测为准。

**坑**：
- `w32tm /resync` 在非管理员下直接 Access denied，别浪费时间，直接走提权。
- PS 内联 `Start-Process powershell -Verb RunAs -ArgumentList '带嵌套引号的命令'` 会因引号拆分失败 → 命令写进 `.ps1` 文件再 `-File` 调用（同 WSL/`&` 的坑）。
- 校准后如果用户本机时间依然错（UAC 被拒），**回答日期类问题一律以联网时间为准**，并把偏差告诉用户。

## 虾评平台发布要点（2026-09 实测）

衔接上文 WSL TLS 兜底 —— 虾评（xiaping.coze.com）发布/更新技能的真实规则：

- **更新技能用 `POST /api/upload`**（multipart：`skill_id`+`changelog`+`pledge={"agreed": true}`+`requires_api_key=false`+`file=@zip`），**不是** `POST /api/skills/{id}/versions`（那个是查版本历史，POST 会 409）。
- ⚠️ **评测（好评）限流实测 3 条/小时**：平台错误原文"每小时最多发布3条评测"，不是某些文档写的 5 条。批量发好评要预留等待。
- 429 重试的坑：脚本用 `while code==429` 循环时，**遇到网络异常（`err`）会跳出** 429 循环直接失败——把 429 和网络异常合在一个循环里分别等待（429 等 60s、网络错等 30s）才能撑到限流窗口滚动。
- 发布成功看返回 JSON：`{"success":true,"data":{"version":"1.x.x",...}}`；续传/重发看 `version` 递增。

## 开机自启（本机非管理员，只能用启动文件夹）

**本机账户非管理员** → 加不了防火墙规则；`Register-ScheduledTask` 会因权限失败。
**能用且够用的机制 = 启动文件夹**：`%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup`
（用户级，无需提权；`shell:startup` 可直达）。

- `.exe`/`.cmd`/`.bat` 直接丢进去就行；需要**静默无窗口**的用 `.vbs` 包一层
  （`sh.Run "<cmd>", 0, False`，第二参 0 = 隐藏窗口）。
- `.vbs` 的自启包装器**只转发、不干活**：真正逻辑放 `hermes-home\gateway-service\`，
  包装器用 `%LOCALAPPDATA%` 拼路径后 `wscript.exe "<target>"` —— 这样安装目录变了只改一处。
- 拉起长驻进程前先**清代理变量**，否则开机时会连上残留代理：
  `env.Item("HTTP_PROXY") = ""`（同理 HTTPS_PROXY / ALL_PROXY / 小写变体 / NO_PROXY）。
  ⚠️ 只清 `PROCESS` 级（仅影响本进程），**别去动 `USER`/系统级**——那会把用户自己的
  正常上网代理一并清掉，用户开 VPN 后就上不了外网了。
- 只有\"单实例锁\"的守护进程（如 Hermes gateway）**重复拉起是安全的**：第二次会被锁挡掉，
  不会起双实例。所以自启脚本和 180s 自检脚本可以并存，不必互斥。
- 验证两段式：① `cscript //nologo <vbs>` 退出码 0；② 数目标进程是否在跑（见上文 .vbs 章节）。

## 大目录归档 / 整库重组（2026-10-18 实测）

用户说「把这批东西理解归档后删掉」「整个文件夹整理一下」→ 读
`references/bulk-archive-and-reorganize.md`。要点：

- **先算 md5 再判断**：一整批"新资料"里多数可能已有逐字节相同的副本（实测 161 个里 130 个）。
- **只删能证明有副本的**：删除脚本内置「源哈希 ∈ 归档哈希集合」校验，白名单（明确判定丢弃的）除外，不通过就中止。
- **搬目录先修计划任务和写死的绝对路径**，否则定时任务静默失败；改任务用 `Set-ScheduledTask -Action`，别删了重建。
- **`shutil.move` WinError 32** = 当前工作目录在被搬的目录里，先 `Set-Location` 出来。
- **拆脚本目录时 assets 必须跟着脚本走**（`OUTPUT_ROOT = dirname(__file__)/assets`），拆完用 importlib 冒烟验证。

## 参考

- **GUI / RDP 全量手册**（原独立技能，2026-10 并入）：
  - `references/gui-automation.md` — 决策顺序（能让人配合就别盲点）、UIA 探测、截图+视觉+SendInput 脚手架、
    窗口固定与坐标换算、Electron 坑（UIA 空树 / 壳与内容窗口分离 / 坐标漂移）、误触风险控制。
    配套脚本 `scripts/win_enum_windows.ps1`、`scripts/win_gui_step.ps1`、`scripts/autocad_com_template.ps1`。
  - `references/rdp-remote-ops.md` — cmdkey + `.rdp` 磁盘映射、只读检查脚本回传、Win10 单会话限制、
    mstsc 窗口遮挡/焦点坑、服务器体检清单（Mohist/Java）。配套 `templates/rdp_check.ps1`
    （拷到映射盘执行，结果回写 `result.txt`）、`references/rdp-ops-20260901.md`（RoseMC 实战记录）。
- 本技能覆盖 Hermes 相关运维见 `hermes-cn-desktop-ops` 技能（config/微信网关/视觉/语音/记忆外置）。
