# 只读检查脚本模板（放 mstsc 磁盘映射目录，输出写回 $PSScriptRoot\result.txt）
# 远程触发：powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem [A-Z]:\check.ps1 -ErrorAction SilentlyContinue | ForEach-Object { & powershell -NoProfile -ExecutionPolicy Bypass -File $_.FullName }"
# ⚠️ 全只读：不改任何文件/进程/设置。中文输出在 PS5.1 有编码坑，用英文标签。
$ErrorActionPreference = 'Continue'
$out = @()
function L($s) { $script:out += $s }
function Sec($t) { L "`n===== $t =====" }

try {
    Sec 'SYSTEM'
    L "host: $env:COMPUTERNAME"
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    L "os: $($os.Caption) build $($os.BuildNumber)"
    L "ram_total_gb: {0:N1}  ram_free_gb: {1:N1}" -f ($cs.TotalPhysicalMemory/1GB), ($os.FreePhysicalMemory/1MB)
    L "cpu_logical: $($cs.NumberOfLogicalProcessors)"
    L "uptime: $((Get-Date) - $os.LastBootUpTime)"

    Sec 'DISK'
    Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { L "  $($_.DeviceID) free={0:N1}GB total={1:N1}GB" -f ($_.FreeSpace/1GB), ($_.Size/1GB) }

    Sec 'POWER'
    L "active_scheme: $(powercfg /getactivescheme)"
    powercfg /a | ForEach-Object { L "  $_" }

    Sec 'JAVA'
    $jc = Get-Command java -ErrorAction SilentlyContinue
    L "java_path: $(if ($jc) { $jc.Source } else { 'NOT in PATH' })"
    java -version 2>&1 | ForEach-Object { L "  $_" }

    Sec 'MC PROCESS'
    $jp = Get-Process java -ErrorAction SilentlyContinue
    if ($jp) { $jp | ForEach-Object { L "  pid=$($_.Id) mem={0:N0}MB" -f ($_.WorkingSet64/1MB) } } else { L "  no java process (server down?)" }

    Sec 'SERVER FILES (search)'
    # 按需改根目录
    Get-ChildItem C:\ -Recurse -Depth 3 -Include mohist*.jar,forge*.jar,start.bat,server.properties -ErrorAction SilentlyContinue |
        Select-Object -First 15 | ForEach-Object { L "  $($_.FullName)" }

    Sec 'LOGS (latest.log tail + errors)'
    $lg = Get-ChildItem C:\ -Recurse -Filter latest.log -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($lg) {
        L "path: $($lg.FullName) size_kb: {0:N0}" -f ($lg.Length/1KB)
        Get-Content $lg.FullName -Tail 30 | ForEach-Object { L "  $_" }
        $err = Select-String -Path $lg.FullName -Pattern ' ERROR | FATAL ' -ErrorAction SilentlyContinue
        L "error_count: $($err.Count)"
        $err | Select-Object -Last 5 | ForEach-Object { L "  E: $($_.Line.Trim().Substring(0, [Math]::Min(140, $_.Line.Trim().Length)))" }
    }

    Sec 'CRASH REPORTS'
    Get-ChildItem C:\ -Recurse -Directory -Filter crash-reports -ErrorAction SilentlyContinue |
        Select-Object -First 1 | ForEach-Object { Get-ChildItem $_.FullName -File | Sort-Object LastWriteTime -Descending | Select-Object -First 5 | ForEach-Object { L "  $($_.Name) ($($_.LastWriteTime))" } }

    Sec 'PLUGINS / MODS / SCRIPTS'
    foreach ($d in @('plugins', 'mods', 'scripts')) {
        $dir = Get-ChildItem C:\ -Recurse -Directory -Filter $d -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($dir) { L "  [$d] $($dir.FullName)"; Get-ChildItem $dir.FullName -File | Select-Object -First 20 | ForEach-Object { L "    $($_.Name)" } }
    }

    Sec 'NETWORK'
    netstat -ano | Select-String ':25565|:19984' | ForEach-Object { L "  $_" }
    Get-Process frpc,frp,SakuraFrp* -ErrorAction SilentlyContinue | ForEach-Object { L "  tunnel: $($_.ProcessName) pid=$($_.Id)" }

    Sec 'AUTOSTART / DEFENDER / SESSIONS'
    Get-ChildItem "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup" -ErrorAction SilentlyContinue | ForEach-Object { L "  startup: $($_.Name)" }
    Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match 'mc|mine|server|keepalive' } | ForEach-Object { L "  task: $($_.TaskName) state=$($_.State)" }
    try { (Get-MpPreference).ExclusionPath | ForEach-Object { L "  def-excl: $_" } } catch { }
    qwinsta 2>&1 | ForEach-Object { L "  $_" }
} catch {
    L "SCRIPT ERROR: $_"
}
$out | Out-File -FilePath (Join-Path $PSScriptRoot 'result.txt') -Encoding UTF8
Write-Host "DONE lines=$($out.Count)"
