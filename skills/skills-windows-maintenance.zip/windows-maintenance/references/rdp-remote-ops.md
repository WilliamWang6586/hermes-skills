# RDP 远程运维 Windows 主机（原独立技能 windows-remote-ops，2026-10 并入 windows-maintenance）

# Windows 主机 RDP 远程运维

实战经验（2026-09-01，RoseMC 玫瑰花园服务器：Win10 物理机 + Mohist 1.12.2 服务端 + RDP mc45.starmc.cn:19984）。

## 触发场景

- 用户提供 RDP 凭证（IP/端口/账号/密码），要求"连上后台检查"
- 远程 Win10 上跑 MC 服务端/其他服务，需要只读摸底：日志、配置、资源占用
- 用户约定："你就光看，啥都别改，检查完后给我说"——**只读优先，改前确认**是本类任务铁律

## 核心工作流（mstsc 自动化）

### 1. 连通性先测
```powershell
Test-NetConnection <host> -Port <rdp端口>   # RDP 通常是 3389 或自定义（如 19984）
Test-WSMan <host> -Port 5985                # 顺带测 WinRM——通了就直接 Invoke-Command，不用碰 GUI
```
WinRM 通了优先走远程命令（Invoke-Command 输出直接回本地，无需 GUI 操作）；没通才走 mstsc。

### 2. 存凭证 + .rdp 配置（带磁盘映射）
```powershell
cmdkey /generic:TERMSRV/<host> /user:<账号> /pass:"<密码>"   # 存 Windows 凭据，不落明文文件
```
`.rdp` 文件（磁盘映射把本地目录挂进远程会话，结果回传的关键）：
```
full address:s:<host>:<port>
username:s:<账号>
screen mode id:i:2
drivestoredirect:s:D:\本地\rdp_share     # 磁盘映射：远程会话里出现新盘符（字母序分配，不一定是 Z:）
redirectclipboard:i:1
authentication level:i:0
```
启动：`Start-Process mstsc -ArgumentList "路径.rdp"`。

### 3. 只读检查脚本 + 结果回传
- check.ps1 放映射目录，**输出写到 `$PSScriptRoot\result.txt`**（脚本在哪个盘就写哪个盘 → 自动落到本地映射目录，不依赖固定盘符）
- 远程触发命令（Win+R 粘贴，遍历盘符自动找脚本）：
```
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem [A-Z]:\check.ps1 -ErrorAction SilentlyContinue | ForEach-Object { & powershell -NoProfile -ExecutionPolicy Bypass -File $_.FullName }"
```
- 脚本**全只读**：java -version、Get-Process java、netstat、powercfg、读 logs 尾部/统计 ERROR、列 crash-reports/plugins/mods/scripts 目录名、磁盘剩余、内存、开机自启、Defender 排除、qwinsta 会话。

### 4. 检查结果输出（本地读）
```powershell
Get-Content "D:\本地\rdp_share\result.txt" -Encoding UTF8
```

## 关键坑（全部实测）

0. **先查目标是不是"家庭版"**：`(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').EditionID` —— `CoreCountrySpecific`/`Core` = **家庭版(Home)，没有 RDP 服务端，无法当主机**（`Terminal Server\fDenyTSConnections` 也改不动）。想远程访问**自己这台** PC（而非连别人）→ 只能第三方：ToDesk / RustDesk / 向日葵 / Parsec，或走 Hermes 自带 `hermes dashboard` + 组网（见 hermes-desktop-ops 技能）。另：**Radmin VPN 无手机端**（只 Windows），跨设备组网别指望它。
1. **Win10 RDP 单会话限制**：非 Server 版同一时间只允许 1 个交互式 RDP 会话——你登录会把正在用的人**顶下线**。动手前必须让用户跟对方（服主）打招呼，约好时间。
2. **mstsc 窗口遮挡/焦点**：截图按窗口句柄 GetWindowRect 区域截，但**该区域可能被本机其他窗口（如 Hermes）覆盖**，截到的是别的界面；SetForegroundWindow + SendKeys 按键也可能发错窗口。**最稳：让用户自己把远程桌面点到前台，或让用户自己在远程桌面里操作（给命令，用户跑），你只负责读结果**。
3. **PowerShell 5.1 中文路径乱码**：UTF-8 无 BOM 的 .ps1 被 PS5.1 按 ANSI 读，中文路径变乱码（文件存到乱码目录）。**脚本一律 ASCII-only 输出/路径，或写 UTF-8 BOM**。
4. **内联 python -c 引号地狱**：PowerShell 里 `python -c "..."` 多层引号必炸 → 写 .py 文件执行。
5. **屏幕操作触发用户批准（BLOCKED）**：任何模拟点击/按键注入类命令都可能被 Hermes 批准机制拦截。**执行前先说明"我要在远程桌面里输入命令、会占用会话焦点"**，用户批准再跑。
6. **凭证安全**：RDP 凭证 = 整机控制权。提醒用户别明文发群；建议对方开专用低权限账号；操作留痕（检查了什么记什么）。
7. **远程 GUI 小字识别不稳**（Electron 客户端/任务管理器小字）：qwen-vl 对远程桌面截图的小字识别率低 → **优先命令行文本输出**，截图只用于看大格局（桌面图标、任务管理器性能页的大数字）。

## 服务端自建运维体系（识别与兼容，改前必读）

成熟的服主常自建脚本体系，摸底时先识别再动手，**改动 mods/config 时不得破坏**：
- 典型链：`start.bat → start_server.ps1（转发）→ scripts\ops\start.ps1 → keepalive.ps1（后台保活）`
- keepalive 常见要素：`server.pid`、`keepalive.lock`、`STOP_SERVER.flag`（优雅停服）、心跳文件、
  崩溃重试 20/60/120s 递增（`crash_restart_history.txt`）、boot Hook 分阶段（PreJava/PostJava/Guard）、
  标准输出重定向 `logs\console_stdout/stderr.log`、端口探测确认启动（如 90s 超时提示 stop）
- 服务端端口未必是 25565（本案例游戏端口 41464、RCON 25575）；JVM 参数看 keepalive 或 start.ps1（本案例 -Xmx12G G1GC）
- **改文件的正确姿势**：只替换 mods/config/scripts 内容，不碰脚本本体；改前跑对方自带的 backup_server.ps1

## 单 RDP 会话下的合作模式（Win10 非 Server）

会话互斥（一人上另人掉）时的协作方案，按优先级：
1. **文件级协作**（主力）：服务端文件夹打包↔本地改→打包回传替换，几乎不进后台
2. **错峰**：约时间窗（如"今晚 8-10 点我处理"），干完即退
3. **服主当手我当脑**：给精确命令/路径，对方执行+截图反馈
4. **双通道**（长期最顺）：对方装向日葵/ToDesk（不占 RDP 会话），你继续用 RDP——两人并行不顶号

## 服务器运维检查速查（Mohist 1.12.2 专用）

- **Java 版本**：Mohist/Forge 1.12.2 = **Java 8**（不是 17-21！那是 1.20.1+）；版本错直接崩
- TPS/MSPT：控制台 `/tps`、`/forge tps`（健康 TPS≥19、MSPT<50ms）
- 日志：`logs/latest.log`（ERROR 统计）、`crash-reports/`
- 网络：`netstat -ano | findstr 25565`、frp/SakuraFrp 进程（校园网主机常需内网穿透）、`Resolve-DnsName join.xxx.top`
- 系统：`powercfg /getactivescheme`（高性能）、`powercfg /a`（睡眠）、Defender 排除、计划任务/启动文件夹自启
- 修复对照：TPS 低→清实体/掉落物+调刷怪+GC 参数（-XX:+UseG1GC -XX:MaxGCPauseMillis=100）；内存泄漏→定位 mod+**每天定时重启**兜底；磁盘满→清 logs/旧备份+计划任务

## 支持文件

- `references/rdp-ops-20260901.md` — 2026-09-01 RoseMC 服务器摸底实录（凭证处理、check.ps1 模板、踩坑细节）
- `templates/check.ps1` — 只读检查脚本模板（可直接改服务器路径复用）
