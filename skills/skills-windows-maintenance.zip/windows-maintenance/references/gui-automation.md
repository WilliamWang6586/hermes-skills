# Windows GUI 自动化：截图+视觉+模拟点击（原独立技能 windows-gui-automation，2026-10 并入 windows-maintenance）

# Windows GUI 自动化（截图+视觉+模拟点击）

实战经验（2026-08-31，QQNT 群文件读取任务）。

## 决策顺序（先问：这活真的需要模拟点击吗？）

1. **能让用户配合就配合**：Electron 应用（QQNT/微信）自动化成本高、风险大——
   让用户打开目标面板（2 次点击）后你截图识别，比盲操作稳 10 倍且不打扰用户。
2. **UIA 探测**：先试 `AutomationElement.FromHandle` 枚举控件树。
   - 原生应用（资源管理器/控制面板类）树完整 → 可直接 Invoke/Find
   - **Electron 应用（QQNT 等）树基本为空**（只有 Window > Pane 壳）→ 走路线 3
3. **截图 + 视觉识别 + SendInput**：见下。

## 路线 3 完整脚手架

### 前提（必须满足，否则误触）

- **窗口先固定**：`MoveWindow(hwnd, X, Y, W, H)` 到固定坐标，否则每次截图窗口位置漂移，
  百分比坐标换算全错（本次 QQ 窗口从 (350,82)→(636,68)→(358,59) 漂了三次）。
- **确认目标窗口在前台且无遮挡**：盲点击会点到用户正在用的其他窗口（本次点到微信表单页）。
  操作前 `EnumWindows` 列可见顶层窗口，确认屏幕状态。
- **操作前告知用户**：模拟鼠标会接管用户屏幕，用户忙别的时先停手。
- **截屏/全屏会触发用户确认**：本环境 CopyFromScreen 命令可能被 BLOCKED（用户未批准）。
  被拒就别重试也别换命令绕过；先问"可以截图吗"，用户说"可以"再截。只截目标窗口，
  别截全屏（用户对全屏更敏感）。

### 脚本模式（见 scripts/win_gui_step.ps1）

```
1. 定位进程 MainWindowHandle → SetForegroundWindow + ShowWindow(SW_RESTORE=9)
   （最小化窗口 GetWindowRect 返回负坐标 -21333，必须先恢复）
2. GetWindowRect 拿当前窗口位置尺寸
3. 目标 = 窗口内百分比坐标 → 屏幕坐标 = left + w*pct/100, top + h*pct/100
4. SetCursorPos + mouse_event(LEFTDOWN/LEFTUP) 点击
5. CopyFromScreen 截窗口区域 → 保存 PNG → 视觉模型识别确认结果
6. 每步都截图确认，不要连点
```

### 独立面板窗口定位（关键：别只信 MainWindowHandle）

QQNT 的群文件/相册等面板是**独立窗口**（标题"群文件"，与主窗口"QQ"并列），
`Get-Process.MainWindowHandle` 只给主窗口——按它截图会截到主窗口甚至被遮挡的别的窗口。
正确做法：**EnumWindows 枚举目标进程的全部可见窗口**，逐个读标题 + RECT，找目标面板：
```powershell
# EnumWindows + GetWindowThreadProcessId(过滤目标PID) + IsWindowVisible + GetWindowText + GetWindowRect
# 实测输出：HWND=329594 TITLE='群文件' RECT=(1018,194) 561x641  ← 面板是独立小窗
```
找到 HWND 后**按指定 HWND 截图**（GetWindowRect(hwnd) + CopyFromScreen），
不要用 MainWindowHandle。面板被其他窗口遮挡时截图内容是遮挡窗——先视觉确认内容再继续。

### 视觉识别的坑

- 视觉模型给的是"估算百分比"，经常漂 5-10% → 点不中。点击后**必须截图验证结果**，
  错了基于新截图重算坐标，不要连续盲点（越点越乱）。
- 小图标（文件夹/更多按钮）识别不可靠，让模型描述"某区域所有图标"比"有没有X图标"可靠。
- **问法用"逐行转录所有文字"**比"描述这个界面"可靠——模型擅长读文字，描述会胡编元素。
  转录结果若含别的应用内容（如 Hermes 会话文本），说明截错窗口，先修窗口定位。

## ⭐ 编辑器/IDE：别做 GUI 自动化，用「文件系统 + CLI 唤起」同步

用户问「你能不能直接打开 VSCode 写代码，还能让我在页面上看到」——这是**最高频的一类请求**，
正解**不是**模拟键盘在编辑器里敲字（脆弱、且用户改过的内容你根本不知道），而是：

```
Hermes write_file / patch  →  文件落盘  →  VSCode 侦测文件变化, 编辑器内容自动刷新
用户在 VSCode 里改并保存   →  Hermes read_file 读盘  →  拿到最新内容
```

效果上等同「共享一个编辑器」，底层却只是磁盘 IO + 窗口唤起，**零漂移零误触**。
GitHub Copilot / Cursor 等同样适用：只要目标够不到 IDE 内部 API，就走文件系统这一层。

**VSCode 三个关键命令**（记住要传**数组** `-ArgumentList @(...)`，别拼字符串）：

```powershell
$code = "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe"
Start-Process -FilePath $code -ArgumentList @('-n', $dir)                      # 新窗口打开目录
Start-Process -FilePath $code -ArgumentList @('-r', '-g', "$file:5")           # 复用窗口, 打开并跳到第5行
Start-Process -FilePath $code -ArgumentList @('--install-extension','ms-python.python')  # 装扩展
```

- `-r` = reuse window（不加就每次狂开新窗口）；`-g file:line` = goto，**这一条是「让我看到」的关键**，
  写完文件立刻跳过去，用户不用自己找。
- **`code` 走 `bin\code.cmd`，但 `code.cmd` 是批处理** → `Start-Process` 直接给 `Code.exe` 更省事，
  免掉一层 cmd 引号。路径优先 `Get-Command code` 探，别硬编码（装在 Program Files 的机器不同）。
- **命令里别用 `&` 调用**（会被判为 backgrounding 拒绝）→ `Start-Process` 是正解，不是 `cmd /c` 绕过。
- **判定启动成功**：`Get-Process -Name Code | Where-Object { $_.MainWindowTitle -ne '' }`，
  标题会含当前打开的文件/文件夹名。Electron 应用会**派生一堆无标题的辅助进程**，别把
  `MainWindowTitle` 全空的那几个当失败。

**验证链路（向用户证明真的通了，而不是声称）**：写文件 → `-r -g` 唤起 → 读回进程标题确认 →
`gcc/python 真跑一次` → 把**真实输出**贴给用户。用户在意「你有没有真的做到」。

## ⭐ 有 COM 接口的软件：直接驱动，连文件系统同步都跳过

比模拟点击高两级、比文件同步更进一步的路线：很多桌面软件暴露 COM 自动化接口
（AutoCAD/Office/Adobe 全家桶等）。先查 `New-Object -ComObject <App>.Application` 能不能通——
能通就直接 API 画图/改文档/保存，**实体级精确操作**（坐标/尺寸/图层），零误触零漂移。
2026-10-03 实战（AutoCAD 2027）：用户问「能不能打开 CAD 直接画图」，COM 全程通——
`$app.Documents.Add()` → `$ms.AddCircle/AddLine/AddDimRadial/AddDimDiametric` → `$doc.SaveAs()`。

```powershell
try { $app = [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application') }  # 复用已开的实例
catch { $app = New-Object -ComObject AutoCAD.Application }                                # 没开就拉起
$app.Visible = $true
$ms = $app.ActiveDocument.ModelSpace
$ms.AddCircle([double[]]@(0,0,0), 50) | Out-Null     # ⚠️ 点坐标必须 [double[]]@(x,y,0) 强转,
                                                     #    函数返回数组会被展开成 object[] 报
                                                     #    "Value does not fall within expected range"
$app.ZoomExtents(); $app.ActiveDocument.SaveAs('D:\out.dwg')
```

- 方法调用用**逗号传参** `$ms.AddCircle($pt, 50)`，不能用命令式空格传参（PS 解析直接炸）。
- **给用户看效果**：画完 `$app.HWND` + `SetForegroundWindow` 提到前台，再 CopyFromScreen 全屏截图
  （贴给用户看，比自己描述强）。
- 已验证可用的完整模板：`scripts/autocad_com_template.ps1`。

## 陷阱

- **PS 5.1 中文编码**：UTF-8 无 BOM 的 .ps1 含中文会被按 ANSI 读 → 乱码/引号断裂/解析错误。
  脚本一律用**纯 ASCII 输出**（Write-Host 英文），文件名用 ASCII；路径中文由参数传入。
- 内联 `python -c` 在 PowerShell 引号嵌套必炸（含 `$_`、中文、多层引号时）→ 写 .py 文件执行。
- 内联 PowerShell 的 `$_` 在双引号字符串里会被外层展开为空 → 用脚本文件不用 -Command。
- **PowerShell 调用 exe 的 `&` 前缀会被 Hermes 误判为 backgrounding** → 用 `cmd /c` 包装。
- Electron 壳窗口：`MoveWindow`/`GetWindowRect` 作用于外层壳，内容渲染窗口位置可能不一致；
  若截图内容与预期不符，检查是否截到了壳位置的其他窗口。
- 中文路径在 PS 脚本内 `Copy-Item` 会保存到乱码目录 → 统一用 ASCII 输出路径再复制。
- **COM SaveAs 也怕中文路径**（2026-10-03 AutoCAD 实测）：脚本是干净 ASCII、路径以正常 PS
  字符串传入，`SaveAs('D:\中文目录\x.dwg')` 仍报「保存文档时出错」；换 ASCII 路径秒过。
  → COM 文件操作一律纯 ASCII 路径，保存后再从**脚本外的独立命令** `Test-Path` 验真——
  脚本内部用同一个（可能被搅乱的）字符串验证是假阳性。

## 何时放弃

- Electron 应用 + 窗口漂移 + 用户在用电脑 = 三重风险 → 直接请求用户配合：
  "请打开 XX 面板后告诉我，我截图识别"（本次 QQ 群文件最终走此路线）。
- 连续 2 次点击验证失败后停止盲操作，改为请求配合，不要消耗轮次硬试。

## 支持文件

- `scripts/win_gui_step.ps1` — 窗口固定+百分比坐标点击+截图一体脚本（参数：-PX -PY -Label）
- `scripts/win_enum_windows.ps1` — 按进程名枚举全部可见窗口（标题+RECT），定位独立面板窗口（如 QQ 群文件）
- `scripts/autocad_com_template.ps1` — AutoCAD COM 驱动完整模板：图层/圆/线/标注/保存/前台+截图（实测可跑）
