# 大目录归档/重组工作流（Hermes 文件库 2026-10-18 实测）

适用：用户说「把这个文件夹理解归档后删掉」「整个文件夹整理一下」。目标是**理解内容 → 归位 → 校验 → 才删**，
而不是按名字瞎搬或直接清空。

## 核心原则

1. **先算哈希再判断**。同名 ≠ 同内容，同内容 ≠ 同名。整批搬迁前先算 md5，
   实测一整批 161 个"新资料"里 130 个在归档区已有逐字节相同的副本。
   不先算哈希，会造出 130 份重复。
2. **只删能证明有副本的东西**。删除前最后跑一次「源文件哈希 ∈ 归档哈希集合」，
   不在集合里的必须列出来白名单（明确判定丢弃）+ 理由，否则中止。
3. **搬完不删，删完再核**。分两段脚本：`--apply` 搬 → 校验脚本 → 删除脚本（内置同一校验）。
4. **不要用 shell 拼中文路径**。全部逻辑写成 `.py` 文件（`PYTHONUTF8=1`），
   用 `os.scandir`/`os.listdir`；PS 5.1 内联中文路径会吞字符/乱码。

## 标准脚本结构

```python
import hashlib, os, shutil

def h(p):
    m = hashlib.md5()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            m.update(c)
    return m.hexdigest()

def place(src, dst_dir):          # 同名同内容=跳过; 同名不同内容=加 __新 后缀; 绝不覆盖
    dst = os.path.join(dst_dir, os.path.basename(src))
    if os.path.exists(dst):
        if h(dst) == h(src):
            log(("DUP", src)); return
        dst = dst.replace(".", "__新.", 1)
    shutil.copy2(src, dst)
```

- 用 `shutil.copy2` 而不是 `move`：搬错还能回滚，校验通过后再删源。
- 日志表头三列 `动作 \t 目标目录 \t 文件名`，最后 `TOTAL n`。用户能直接扫出异常。
- 需要"整目录一律进 X，只有少数几个文件另有归属"时，**先处理逐文件映射，再整目录兜底**；
  反过来写会让特例被目录规则吃掉（本次 `一些干货` 就踩了）。

## 校验（删除前必跑）

```python
dst_hash = set()
for r, _, fs in os.walk(DST):
    for f in fs: dst_hash.add(h(os.path.join(r, f)))
unverified = [f for f in src_files
              if os.path.basename(f) not in WHITELIST_NAMES
              and not os.path.basename(f).startswith(WHITELIST_PREFIX)
              and h(f) not in dst_hash]
if unverified: raise SystemExit("中止删除，仍有未归档文件")
shutil.rmtree(SRC)   # 只有走到这里才删
```

## 重组（目录搬家）的连带修复清单

搬目录之前先做，否则定时任务会静默失败（本次差点让日报断掉）：

```
Get-ScheduledTask | ? {$_.TaskName -match '...'} | % { $_.Actions[0].Arguments }   # 计划任务里的绝对路径
```

改计划任务（不要删了重建，保留触发器/设置）：
```powershell
$t = Get-ScheduledTask -TaskName "X"; $a = $t.Actions[0]
$a.Arguments = $a.Arguments.Replace("旧路径","新路径")
Set-ScheduledTask -TaskName "X" -Action $a
```

再全盘搜写死的路径（排除 node_modules/.venv/site-packages/备份目录）：
```powershell
Get-ChildItem $root -Recurse -File -Include *.ps1,*.bat,*.cmd,*.py |
  ? { $_.FullName -notmatch 'node_modules|\.venv|site-packages' } |
  Select-String -Pattern '根路径\' -SimpleMatch -List
```
逐个判断「真执行路径」vs「注释/记忆文本」——`记忆外置库` 里的 md 提到旧路径不用改。

## 可用空间清理的判定表（可重生成性 > 大小）

| 类型 | 处理 |
|---|---|
| 安装包 exe/msi（官方可重下） | 删 |
| 已解压的 rar/zip（同内容目录还在） | 删压缩包，留目录 |
| 与活跃目录逐字节相同的备份副本（如备份里的某个 skill） | 删副本 |
| 已安装完成的 wheel 缓存 | 删 |
| 一次性调试转储（request_dump*.json） | 删 |
| git 仓库的 .git（源可重 clone） | 可删；被占用报 WinError 5 就跳过，小损失 |
| __pycache__ / .pytest_cache | 删 |

**孤儿资源检测**（本次日报 assets 4056 张里 2078 张没人引用，544MB）：
```python
used = set()
for f in html/txt/md 文件:
    used |= {m.group(1).rsplit(".",1)[0] for m in re.finditer(r"assets/([A-Za-z0-9_.\-]+)", text)}
orphan = [f for f in os.listdir(assets) if f.rsplit(".",1)[0] not in used]
```
先看几个孤儿样本是否真的没人引用（`theme_*.jpg` 可能是运行时兜底图，要留下）。

## 拆「活跃脚本」与「历史产物」时的红线

`每日科技日报` 有 4273 个文件（100 个日期目录 + assets）。按 pipeline 真实调用链拆：
```python
called = set(re.findall(r"([A-Za-z_0-9]+\.(?:py|ps1|bat))", open("daily_pipeline.ps1").read()))
```
但 **assets 目录必须留在脚本旁边**：脚本里是 `OUTPUT_ROOT = dirname(__file__) + "/assets"`，
搬走 assets 图片全断。拆完必须冒烟：
```python
spec = importlib.util.spec_from_file_location("r", "main.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
assert os.path.isdir(os.path.join(m.OUTPUT_ROOT, "assets"))
```

## 坑（都实测踩过）

- **`shutil.move` 报 WinError 32「另一个程序正在使用」**：当前工作目录就在被搬的文件夹里
  （前面 `Set-Location` 进去过）。先 `Set-Location` 出来再搬；搬失败会留下半成品，
  重跑前先确认 `父目录/名字` 是否已存在（脚本里判 `exists` 就跳过）。
- **归错类**：文件名带"2019-2020"不代表是教材，公选课计划表被当成复习资料扔进了教材目录。
  落位后抽查新增文件清单，别信 `COPY` 计数。
- **先打包再检查引用**：手机长截图/语音转写这类无文件名线索的东西，先切块识别内容再定归属，
  别按 jpg 一把丢进垃圾桶。
