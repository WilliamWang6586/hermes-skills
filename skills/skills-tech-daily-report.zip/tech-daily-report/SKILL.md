---
name: tech-daily-report
description: 生成「科技观察报」HTML 报纸（米色纸张+衬线字体+深度内容+全中文+可点击链接），覆盖 AI·半导体·智能汽车·摄影器材·机器人·量子·政策 七大板块。当用户说"做日报""生成日报""今日科技""补X号的日报"时使用。
category: productivity
---

# 科技观察报 — 日报生成技能

## 触发条件
- 用户说"做日报""生成日报""今日科技日报""把X号的补了"
- 用户说"日报内容扩充""增加条目深度"
- 检查/更新 Windows 定时任务

## 批量补跑多天（2026-08-08 实测）

缺多天时（如"把这几天的补了"）：
1. **生成**：后台跑 `powershell.exe -File backfill.ps1`——foreach 日期循环 `& python daily_tech_report_v2.py --date $d *> backfill_$d.log`，7 天约 30 分钟，`notify_on_complete=true`
2. **发送**：`send_backfill.ps1`——foreach 日期循环 `python qq_send_file.py <当日html>`
3. 两个 ps1 都存 `D:\Hermes文件库\每日科技日报\`，**write_file 后必须转 UTF8 BOM**（见 Pitfall 6），否则中文文件名路径 Test-Path 全失败

## 执行命令（唯一可靠方式）

```powershell
cmd.exe /c "C:\Users\王子涵\AppData\Local\Python\bin\python.exe D:\Hermes文件库\每日科技日报\daily_tech_report_v2.py"
```

指定日期：
```powershell
cmd.exe /c "C:\Users\王子涵\AppData\Local\Python\bin\python.exe D:\Hermes文件库\每日科技日报\daily_tech_report_v2.py --date 2026-07-02"
```

**为什么优先 `cmd.exe /c`？**
- 定时任务/正式跑走 Windows 原生 Python（VPN 在 Windows 层生效，翻译 API 最稳）
- `cmd.exe /c` 无需用户审批
- **WSL python3 也能跑通**（2026-08-09 实测两次成功，含配图抓取，约 8 分钟）——临时补跑某天日报可用 WSL，不必强求 Windows
- ⚠️ 旧记录"WSL 翻译慢 5-10 倍/会超时"已被实测推翻，勿再引用

## 脚本架构（8 步流水线）

| 步骤 | 内容 | 数据源 |
|------|------|--------|
| 1/8 | HN 头条 Top 25 | `hacker-news.firebaseio.com` |
| 2/8 | GitHub Trending 15 | `api.github.com` |
| 3/8 | HN 分类搜索（AI/半导体/能源/机器人/量子/中国） | `hn.algolia.com` |
| 4/8 | V2EX 热门 12 | `v2ex.com/api` (尽力而为) |
| 5/8 | 36氪热榜 10 | `36kr.com/api` (尽力而为) |
| 5b/8 | **arXiv 最新论文 4 篇**（2026-08-16 起） | `export.arxiv.org/api/query`（semiconductor/transistor/chiplet/HBM/quantum，按 submittedDate 倒序），标题经翻译层中文化，插入半导体板块"每日最新论文（arXiv 实时）"子块；失败静默降级为无（不影响版面） |
| 5c/8 | **财经数据**（2026-08-21 起） | `fetch_finance_data()`：①指数=新浪 hq（sh000001/sz399001/sz399006 + gb_$dji/$ixic/$inx，GBK 解码，A股算涨跌幅，美股直接用第 2/3 字段）②涨幅榜=新浪 Market_Center.getHQNodeData（sort=changepercent，JSONP 兼容裸数组/括号包裹）③快讯=东财 getFastNewsList（**必须带 req_trace=uuid 参数**否则报错）|
| 6/8 | **翻译英文→中文** | MyMemory API (3s 超时，需 VPN) |
| 7/8 | **抓取全板块配图** | `fetch_article_images`：逐条抓原文 og:image → 失败按标题关键词搜图（loremflickr）→ 再失败主题 fallback（8 线程并行，85 条约 2-3 分钟） |
| 8/8 | 生成 HTML 报纸 | 本地渲染 |

## 嵌入式数据的「去 AI 味」规范

用户明确要求日报内容读起来像人写的，不要 AI 宣传腔。以下词汇和句式 **在嵌入式数据（半导体/汽车/编辑点评）中必须避免**：

### 禁用词汇（AI-flavored / Hallmark 式）

| 禁用 | 原因 | 替代 |
|------|------|------|
| 标志着、见证了、象征了 | 夸大意义 | 直接说事实 |
| 进一步甩开/拉开差距 | 宣传腔 | "差距继续拉大" |
| 巩固...霸权/地位 | 夸张 | "产能被订满" |
| 改写...规则/格局 | 空洞 | "路线不同，客户选择变多" |
| 竞争白热化 | 陈词滥调 | 不写，事实自明 |
| 巨头争抢/告急 | 耸动 | "产能被苹果高通英伟达AMD分掉了" |
| 迈入...时代 | 宣传 | "万卡规模集群" |
| 有望拿下X%份额 | 模糊预测 | "今年可能占到一半" |
| 实现...超越/突破 | 宣传 | "搞了""做到了" |
| 画了饼 / 将信将疑 | 口语化✅ 反而好 | 用！ |

### 编辑点评规范

- 口语化："这期比较大的事" > "本期重点关注"
- 带观点不中立："这事搁两年前没人信"
- 承认不确定性："外界将信将疑"
- 短句为主，避免"不仅...而且..."排比
- 参考 humanizer-zh 技能的全部规则

### Hallmark 式写法

Hallmark 频道电影以其公式化、可预测、过度煽情的写作风格著称——"标志着新时代""见证了爱的力量"。这正是 AI 文本最常模仿的模式。如果你写的摘要读起来像 Hallmark 电影旁白，重写。

| 板块 | 条目数 | 覆盖内容 |
|------|--------|----------|
| 💎 半导体 | 19 篇 | 前沿论文 4 + 存储芯片 4 + 应用芯片 5 + 制程工艺 3 + 设备/材料 3 |
| 📷 摄影器材 | 14 款 | 索尼/佳能/尼康/富士/大疆，京东/港水/闲鱼三平台比价 |
| 🚗 智能汽车 | 6 篇 | 电池技术 3 + 智能驾驶 3（不含价格罗列） |
| 🔬 名词释义 | 6 个 | GAA/HBM/800V/端到端/N2/麒麟电池通俗解释 |

## 翻译层（2026-08-21 升级：专业名词保护 + DeepSeek 备用）

- **API 主通道**: MyMemory (`api.mymemory.translated.net`)，免费无密钥，3s 超时
- **⚠️ MyMemory 免费版会 429 限流**（实测批量翻几百条后触发）——429 时等 1.5s 重试一次
- **备用通道**: MyMemory 失败自动切 **DeepSeek**（`_translate_deepseek`，读 hermes-home\.env 的 DEEPSEEK_API_KEY，deepseek-chat，system prompt 要求保留英文专业名词）——实测翻译质量更高
- **专业名词保护**：`PROTECTED_TERMS`（130+ 词：NVIDIA/HBM4/TSMC/GPU/GAA/EUV/LLM/OpenAI…），`_protect_terms` 翻译前替换占位符（\x01n\x02）→ 翻译后 `_restore_terms` 还原；DeepSeek 通道靠 system prompt 保留（不占位）
- **缓存**: `TRANSLATE_CACHE` 内存缓存，同日重复文本不重复请求
- **要求**: VPN 开启（MyMemory 海外；DeepSeek 国内可达）
- **跳过**: 已含 30% 以上中文的文本自动跳过翻译

## 相机价格可点击（2026-08-21 加）

`cam_row_html` 三平台价格均带链接：京东→`item["url"]`（京东搜索）、港水→`https://www.price.com.hk/search.php?g=A&q=<品牌型号>`、闲鱼→`https://s.goofish.com/search?q=<品牌型号>`，关键词 URL 编码，`target="_blank"` + title 提示。

## 板块结构（当前生效版本）

自 2026-08-08 Hallmark 重构后，板块结构为（布局类型不同 = 结构多样性，不要改回统一卡片网格）：

| # | 板块 | 布局 | 说明 |
|---|------|------|------|
| 头版 | 今日头版 | `.feat-grid` 三栏不等宽 | 热度 Top3（头版/要闻/要闻），每条卡内嵌原文 og:image thumb（头条0 大图 150px） |
| 1 | AI 人工智能 | `.r-list` 编号列表行 | HN + GitHub 分类，`01 02 03...` 编号 + 标题 + 摘要 + meta |
| 2 | 开发工具与计算 | `.r-list` 编号列表行 | 同上 |
| 3 | 半导体产业深度 | `.semi-grid` 双栏 | 5 子类 19 篇嵌入式 + 子标题分隔 |
| 4 | 智能汽车·新能源 | `.band-grid` 深色 band | 电池技术 3 + 智驾分析 3（不含车型价格罗列） |
| 5 | 摄影器材·多平台比价 | `.cam-wrap` 表格行 | 14 款，表头行 + 数据行（京东/港水/闲鱼） |
| 6 | 前沿视野 | `.mini-grid` 三列迷你卡 | **机器人+量子+政策合并**（原三个独立板块） |
| 7 | 中文科技社区 | `.r-list` | V2EX + 36氪 |
| — | 侧栏 | 名词速查 / 编辑点评 / HN 热度榜 / 快捷导航 | `.side` 290px |

**已删除的板块**（用户明确要求）：
- ❌ 笔记本价格罗列专区（2026-07-19 删除）
- ❌ 新能源车型价格罗列（2026-07-19 删除，保留电池和智驾）

## Hallmark 设计规范（2026-08-21 第二次重构：Bento Grid + Vercel 极简）

**当前宏结构：Bento Grid**（stamp：`/* Hallmark · macrostructure: Bento Grid · theme: Vercel Mono */`），设计语言来自 popular-web-designs 技能的 `templates/vercel.md`（Geist 字体 + #171717 黑 + shadow-as-border + 三种字重）。**不再有米色报纸风**。

### 页面结构（v3）
- **topbar**（sticky + backdrop-blur）：品牌 + 9 个 tab 按钮（全部/头版/AI/开发/半导体/汽车/摄影/前沿/社区）+ 搜索框 + 主题切换
- **hero**：居中大标题 + mono 字体 meta 行
- **bento**：4 列网格 11 个 cell（span-2x2 头条 / span-2x1 AI、半导体、摄影 / span-1x1 其余），每个 cell 是独立卡片（shadow-card 圆角 8px）
- **交互（原生 JS，无依赖）**：① tab 过滤板块（display 切换）② 实时搜索过滤（textContent 匹配）③ 深色/浅色切换（`[data-theme="dark"]` CSS 变量 + localStorage 'techdaily-theme'）
- **跑马灯已删除**（简约化）；侧栏内容（名词/点评/热度榜）折叠为独立 cell

### 改版注意事项
1. 所有 section 构建函数只返回内部内容（`<div class="r-list">` / `<div class="semi-grid">` 等），**外层 `<section class="rail">` 包装已移除**，由 bento cell 提供标题
2. CSS/JS 在 f-string 里**所有花括号必须双写**——改完 CSS/JS 后必须跑 `fix_braces.py`（处理 <style> 和 <script> 块）+ py_compile 验证
3. 宏结构每大改一次要换（Ecosystem Index → Bento Grid 已用两次，下次换 Long Document/Index-First 等）
4. 深色模式变量在 `:root[data-theme="dark"]`，颜色全部 token 化

## 配图系统（2026-08-08 四次修订：og:image → 关键词搜图 → 主题兜底）

已安装 `hallmark` 技能（Nutlope/hallmark v1.1.0，22.6k stars，反 AI 味设计）。日报页面按 **Ecosystem Index** 宏结构重构，CSS 顶部有 stamp：`/* Hallmark · macrostructure: Ecosystem Index · theme: Newspaper */`。

### 重构要点（改页面时保持，不要回退）

1. **CSS token 化**：所有颜色/字体走 `var(--token)`（--paper/--ink/--accent/--rule/--font-display/--font-body），禁止 inline hex
2. **字体配对**：标题 `Noto Sans SC`（黑体）+ 正文 `Noto Serif SC`（宋体）——真实报纸排印逻辑
3. **禁 emoji 图标**：板块标题不用 🧠💎🚗 之类，纯文字 + rail-count
4. **禁渐变 hero / 禁卡片 hover 上浮 / 禁左侧红条卡**（这些是 AI 味 tell）
5. **结构多样性**：每板块不同布局（列表/双栏/band/表格/迷你卡），禁止全部同一种卡片网格
6. **移动端**：320/375/414/768 无横向滚动（`overflow-x:clip` + `minmax(0,1fr)`）
7. **宏结构 diversification rule**：下次大重构必须换一个宏结构（Bento Grid/Long Document 等），不能再用 Ecosystem Index——看 CSS 顶部 stamp 判断
8. **编辑点评/摘要去 AI 味**：见上方"去 AI 味规范"，口语化表达

### 重构对照（旧 → 新）

| 旧（AI 味） | 新（Hallmark） |
|------|------|
| 深蓝渐变封面 `.cvl` | 纯文字报头 `.mh` |
| 每板块 emoji 图标 | 纯文字 rail 标题 |
| 统一卡片网格 | 7 种布局 |
| 卡片 hover 上浮+阴影 | 仅下划线 hover |
| 半导体左侧 4px 红条卡 | 四周 hairline 边框 |
| inline hex 散色 | 全套 CSS token |
| 红底 BREAKING 横幅 | 并入今日头版三栏 |
| 衬线全场 | 黑体标题+宋体正文 |

## 配图系统（2026-08-08 四次修订：og:image → 关键词搜图 → 主题兜底）

用户偏好演变：先要"有图片就附上，错落有致又有整齐度" → 纠正**"不要配无关的图"**（随机 Pexels 板块图被拒）→ "帮我多配一点，找不到就自己去网上找符合的配图" → 最后**"还是有大量重复图片，根据相应词条自己搜索对应插图"**（主题兜底图被多条复用，用户嫌重复）。最终三级方案：

**`fetch_article_images(all_items)` — 并行抓全部条目的配图：**
1. **优先**：抓每条新闻原文页面的 `og:image`（文章自带图，最相关；正则需兼容 `og:image` / `og:image:secure_url` / `twitter:image` / `name=` / `<link rel="image_src">` 五种写法，2026-08-08 扩宽，此前只认两种属性顺序漏掉很多站）
2. **其次**：og:image 失败 → **按标题关键词 Bing 图片搜索**（`_fetch_kw_image`：`www.bing.com/images/search?q=<关键词>` 返回大 HTML，正则 `"murl":"(https?://[^"]+)"` 取直链逐个下载，需浏览器 UA + `Referer: https://www.bing.com/`）——**loremflickr 已弃用**（2026-08-08 用户实测反馈"驴头不对马嘴"：loremflickr 按关键词返回 Flickr 随机照片，词条与图毫无关联）
3. **兜底**：都失败 → `THEME_POOL` 主题图（Pexels CDN 直链，已验证 ID），嵌入式数据用 `_theme` 标记指定主题，动态新闻用 `classify()` 分类
4. **提速**：`ThreadPoolExecutor(max_workers=8)` 并行抓，85 条约 2-3 分钟完成
5. 全部下载到 `assets/`（`art_{hash}.jpg` 原文/搜索图 + `theme_{x}.jpg` 主题图），返回 `{url: 相对路径}`，渲染时按 url 查图
6. 失败静默跳过（无 og:image / 403 / 超时），版面不破

**关键词搜索实现（2026-08-21 三次修订，图文匹配）:**
- `_keywords_from_title`：**TITLE_STRONG_KW 专业名词优先**（NVIDIA/TSMC/台积电/芯片/HBM/固态电池等 90+ 强相关词，最长匹配优先如 "SK Hynix"）→ 英文词（STOPWORDS 扩充到 100+ 含 show/time/day 等弱词，过滤纯数字）→ 中文词组（过滤泛词"科技/技术/公司/市场"等）——保证搜出来的图和词条强相关
- `_img_quality_ok`：**图片质量过滤**（PIL 检查：>8KB、≥100×60、宽高比 0.4~3.0）——过滤图标/横幅广告/损坏图
- **主题图兜底仅限嵌入式数据**（`it.get("_theme")` 才允许）——动态新闻宁缺毋滥，杜绝"牛头不对马嘴"（2026-08-21 用户明确反馈后修复）
- `_fetch_kw_image`：Bing 新版 `m="{...JSON...}"` 实体块解析 → unescape → `"murl"` 原图，逐个质量检查，第一个合格即返回

**图源可用性实测（本机网络，2026-08-08）：**
- ✅ Pexels CDN 直链 `images.pexels.com/photos/{id}/pexels-photo-{id}.jpeg?auto=compress&cs=tinysrgb&w=800`
- ✅ Bing 图片搜索 `www.bing.com/images/search?q=`（国内可达，200 + 186KB HTML，`"murl":"<直链>"` 正则取图）
- ✅ 文章页 og:image（多数科技站有）
- ❌ Wikipedia（en/zh）API：`Network is unreachable`（被墙，勿作图源）
- ❌ loremflickr：可达但图与词条无关（随机），已弃用

**关键实现细节：**
- og:image 正则要兼容两种 meta 属性顺序（`property` 在前 / `content` 在前）
- `//` 开头的 og:image URL 补 `https:` 前缀
- **必须 `ssl._create_unverified_context()`**——很多站点证书校验失败会误杀
- `_fetch_theme` 幂等：`theme_{x}.jpg` 已存在且 >5KB 直接复用，不重复下载
- ⚠️ **Bing 图片搜索 2026-08 改版**：HTML 里不再有 `"murl":"..."` 明文，改为 `m="{...JSON...}"` HTML 实体块——必须 `re.findall(r'm="([^"]+)"', html)` → `html.unescape` → 再 `re.search(r'"murl":"(https?://[^"]+)"')` 取原图（测试于 2026-08-21，若再失效需重新抓页面格式）
- **配图去重**（2026-08-21 加）：`seen_hashes`（md5 前 16 位）指纹集合；Bing 搜索命中但重复 → 换下一组关键词（`kws[:2]→kws[1:3]→kws[:1]`）重试；fallback 主题英文词搜索（THEME_SEARCH_KW 每主题多组词）每条独立配图，主题图只作最后兜底且同主题只缓存一张——实测 theme 引用 29→0、唯一率 42%→87%
- HTML 内同主题图被多条复用，最终 `<img>` 数 < 下载文件数，正常

- **配图相关性自查（2026-08-08 用户投诉"驴头不对马嘴"后新增）**：生成后解析 HTML 抽取 `标题→img` 对（r-row with-img / band-card 结构：`<img class="r-thumb|band-thumb" src=...>` 后跟 `<h3><a>标题</a></h3>`）→ 随机抽 3-6 条跑 `D:\Hermes文件库\vision_ocr.py <img绝对路径> "<词条标题>与这张图相关吗？一句话回答"`（qwen-vl-max，Windows python3.14 执行）→ 判定相关后再发用户
- **配图覆盖目标**：≥90% 条目有图（2026-08-08 修复后 78/82=95%）

**布局（错落+整齐）**：
- 头条三条卡内嵌 thumb：头条0 `.feat-thumb-lg`（150px），另两条 110px——同宽不同高
- 列表行 `.r-row.with-img`：72×54 缩略图替换编号位，`grid-template-columns:72px 1fr auto`
- 半导体卡 `.semi-thumb`（全宽 96px）、汽车 band `.band-thumb`（全宽 88px）
- 统一细边框 + `object-fit:cover` 保证整齐；有图无图自然交错

## 定时任务失败排查（2026-08-23 实测流程，2026-08-26 定位根因）

定时任务偶尔静默失败（用户问"X号没跑？"时按此排查）：

1. **查上次运行结果**：`Get-ScheduledTaskInfo -TaskName "Hermes每日科技日报"` → `LastRunTime` / `LastTaskResult`（1=失败） / `NextRunTime`；连续多天 1 = 环境问题不是偶发
2. **看 pipeline_log.txt**（`每日科技日报\pipeline_log.txt`）：**只写开头几行就断** —— 两个可能：① VPN 没开/断网采集卡死 ② **stdout 重定向全缓冲假象**（python 输出被 ps1 的 `*>` 重定向后块缓冲，进程被杀时丢失，日志停在 banner 不代表卡在第一步）
3. **手动补跑**：`cmd.exe /c "python.exe daily_tech_report_v2.py --date <缺失日期>"`——成功则确认是定时任务环境问题
4. **缺哪天**：`Get-ChildItem -Directory | Where Name -match 日期正则` 对比日期循环找出；今天实际日期以 `Get-Date` 为准（脚本输出日期≠系统日期时容易被误导）

### 🔴 根因：定时任务不继承 Clash 代理环境变量（2026-08-26 确认）

**症状**：手动跑 ps1/脚本完全正常（生成+发 QQ 都成功），定时任务连续 4 天 exit 1、日志只有 banner。

**根因**：Windows 任务计划程序拉起的进程**不继承用户交互会话里的临时环境变量**。Clash/VPN 的 `HTTP_PROXY/HTTPS_PROXY=http://127.0.0.1:7892` 是启动时注入当前会话的（不是持久环境变量）→ 定时任务里的 python urllib 拿不到代理 → 直连海外（HN/GitHub）卡死 → 任务失败。

**验证方法**：
```powershell
# 手动会话看代理（有 = 代理在会话环境变量里）
python -c "import urllib.request; print(urllib.request.getproxies())"
# 期望: {'all': 'http://127.0.0.1:7892', 'https': '...', 'http': '...'}
```

**修复（已过时，见下方 2026-09-13）**：daily_pipeline.ps1 开头显式设置：
```powershell
$env:HTTP_PROXY = "http://127.0.0.1:7892"
$env:HTTPS_PROXY = "http://127.0.0.1:7892"
```
⚠️ **这套写死代理的修复现已废弃**——用户永久关 VPN 后它就是毒药（见「根因二」）。正确形态见下方。

**其他坑**：ps1 无 BOM 中文乱码导致脚本不执行（写新 ps1 后必须转 UTF8 BOM）；`Start-ScheduledTask` 触发后 LastTaskResult 是上次结果，别急判，先确认任务是否仍在运行。

### 🔴 根因二：硬编码代理兜底 + 关 VPN 后失效（2026-09-13 发现）

`daily_pipeline.ps1` 的代理获取逻辑（第 4-19 行）有三级：继承 env → 读系统代理注册表（ProxyEnable=1 时）→ **硬编码兜底 7892**。一旦用户永久关 VPN（ProxyEnable=0），脚本掉进兜底，把已死的 7892 设给 Python，导致**全部源**（含直连可达的 HN/GitHub/翻译）都被导向死端口。**修复**：删掉兜底块，让无代理时直连。

## 定时任务（单任务流水线，2026-08-26 修复两个致命根因）

**`Hermes每日科技日报`** — 每天 18:30，执行 `daily_pipeline.ps1`（PowerShell，**必须 UTF8 BOM** 编码）：

```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "D:\Hermes文件库\每日科技日报\daily_pipeline.ps1"
```

**⚠️⚠️ 定时任务两个致命坑（2026-08-26 排查 4 天失败日志后定位，均已修复）：**
1. **代理环境变量不继承**（2026-08-26 定位）：手动终端有 `HTTP_PROXY/HTTPS_PROXY=http://127.0.0.1:7892`（Clash），但任务计划程序拉起的进程**没有**→ python 直连海外卡死。当时的修复是写死 7892，**现已废弃**——改为「有 env 用 env，有系统代理用系统代理，都没有就直连」（见「根因二」，2026-09-13）
2. **emoji print 崩溃**：定时任务无控制台 → python stdout 编码=GBK → `print("📡 ...")` UnicodeEncodeError 崩溃（日志只留 banner）。**修复**：ps1 设 `$env:PYTHONUTF8 = "1"`（PEP 540 UTF-8 模式）
3. **全流程约 12 分钟**（翻译步骤 MyMemory 429 时逐条 fallback DeepSeek 8s 超时）——**查任务结果要等 12 分钟以上**，5 分钟内查会误判"卡死"；中途重复触发会杀旧实例（0xC000013A Ctrl+C）

**诊断技巧**：`pipeline_log.txt` 是 PS `*>` 重定向写的 **UTF-16**（PowerShell 默认编码），用 `python -c "open(..., encoding='utf-16')"` 读；ps1 里 python 加 `-u` 无缓冲保证卡死时日志可见；最小验证=诊断版 ps1 里跑 `python -c` 测 getproxies() + HN urlopen。

**流水线（daily_pipeline.ps1）**：python 生成日报+摘要 → 失败则 hermes send 告警 → 成功则 `qq_send_file.py` 发 HTML + `hermes send --to qqbot --file` 发摘要
- ❌ **hermes send CLI 的 MEDIA 对 qqbot 不可靠**：纯附件必报错（白名单不含 qqbot），混合消息"文本 MEDIA:path"存在静默吞附件的实测记录——**不要用**，一律 qq_send_file.py
- hermes CLI：`C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\desktop-bin\hermes.cmd`（`& "..." send --to qqbot ...`）
- ⚠️ **不要用 .bat 写流水线**——cmd 用 GBK 解析中文路径必乱码（已实测两次失败），必须 .ps1 + UTF8 BOM
- 旧的双任务（微信推送 push_wechat.py）已废弃，微信媒体通道受限不再推送

## 微信文字版推送（push_wechat.py）

- 路径：`D:\Hermes文件库\每日科技日报\push_wechat.py`
- 流程：读最新 HTML（优先 `~\.hermes\cron\output\tech_daily_latest.html`）→ 正则提取 8 大板块标题（section-title / h3 a / semi-card / cam-brand）→ 拼文字摘要（每板块最多 6 条）→ 写临时 txt → `hermes send --to weixin:<chat_id> --file <tmp.txt>`
- **必须用 `--file` 传文本**，不要把中文消息塞进命令行参数（编码坑），也避免引号转义
- 脚本里 `HERMES_CMD` 用全路径 `desktop-bin\hermes.cmd`，`CHAT_ID` 用 `weixin:o9cq808CKNrAgBSHkl6Er7JazfSg@im.wechat`
- 微信目标可随时用 `hermes send --list` 确认

## 文件路径

| 文件 | 路径 |
|------|------|
| v2 脚本 | `D:\Hermes文件库\每日科技日报\daily_tech_report_v2.py` |
| v1 脚本（旧） | `D:\Hermes文件库\每日科技日报\daily_tech_report.py` |
| 微信推送脚本 | `D:\Hermes文件库\每日科技日报\push_wechat.py` |
| QQ 发文件脚本 | `D:\Hermes文件库\每日科技日报\qq_send_file.py`（官方 API 直推，见定时任务章节） |
| 旧推送脚本（已弃用） | `D:\Hermes文件库\每日科技日报\deliver_report.ps1`（PS 中文乱码，弃用） |
| 日报输出 | `D:\Hermes文件库\每日科技日报\YYYY-MM-DD\科技日报_YYYY-MM-DD.html` |
| cron 推送副本 | `~\.hermes\cron\output\tech_daily_latest.html` + `tech_daily_deliver.json`（脚本生成，供 push_wechat 读取） |

## Pitfalls

1. **正式跑用 `cmd.exe /c` + Windows Python**（定时任务路径）；**WSL python3 补跑也可以**（2026-08-09 实测两次成功：`wsl -d Ubuntu-24.04 -- python3 /mnt/d/Hermes文件库/每日科技日报/daily_tech_report_v2.py --date YYYY-MM-DD`，含配图抓取约 8 分钟；V2EX/36kr 在 WSL 下 Network unreachable 属正常，Windows 下也常超时）。旧结论"WSL 会超时（300 秒不够）"已过时
2. **VPN 不必开（2026-09-13 修正）**——用户已永久关掉夜煞云 VPN，校园网 A 类 IP 下多数源直连可达（见下）。⚠️ 但 `daily_pipeline.ps1` 第 16-18 行有**硬编码兜底 `$env:HTTP_PROXY="http://127.0.0.1:7892"`**：VPN 关掉后（注册表 ProxyEnable=0）脚本读不到代理就掉进这个兜底，把死端口设给 Python → 原本直连可达的源也全被导向死代理 → **日报整体挂**。修复 = 删掉这个兜底块，让无代理时走直连（学术/V2EX 等少数境外源再单独补）。

### 无 VPN 校园网源可达性（2026-09-13 实测，`--noproxy "*"`）

| 直连 ✅ | 超时 ❌ |
|---------|---------|
| hacker-news / hn-algolia / github-api / 东方财富 / bing图片 / pexels图 / mymemory翻译 / deepseek | arxiv(学术) / v2ex / 36kr / 新浪行情 |

结论：**主流水线（HN+GitHub+财经+翻译+配图）裸连能跑**；只有学术、V2EX、36kr、新浪这几个板块会缺数据。

### 无 VPN 实测结果：日报质量无损（2026-09-13 亲测）

改完兜底后跑了一次完整 pipeline，与有 VPN 那期对比：**头版/AI/开发工具/智能汽车/半导体全有内容，质量相当**（甚至智能汽车从 1 条变 3 条）。原因：日报主力源是 HN + GitHub + 嵌入式数据，全在直连可达列。

- ❌ **arxiv 板块不要去修**：脚本第 393 行 `fetch_arxiv_papers` 失败会静默返回 `[]`（有 try/except），而半导体板块有 `SEMICONDUCTOR_DATA` 本地兜底数据，arxiv 挂了版面不破。
  - 别再试 ghproxy 转发：ghproxy 系镜像**只放行 github.com 域名**，转发 arxiv 返回 **403**；gh-proxy/ghfast/jina/x-mol 全不通（2026-09-13 逐一实测）。
- ⚠️ 顺手修过一个 bug：pipeline 第 61 行 `$h -replace '(<body[^>]*>)', '$1' + "`n" + $jluHtml` 语法错（PS 报 "allows only two elements"）→ 导致**吉大通知插不进 HTML**。正确写法 `-replace '(<body[^>]*>)', "`$1`n$jluHtml"`（双引号插值，不要用 `+` 拼接）。
3. **`process` 工具不可用**——不要用 `process(action='wait')`，改用 `notify_on_complete=true` + 后台模式
4. **翻译约需 2 分钟**——50+ 条 × 3 秒超时，实际成功约 1-2 秒/条
5. **V2EX 和 36氪经常超时**——这是正常的，嵌入式数据可以弥补
6. **脚本类优先用 Python 写**；必须用 .ps1 时（定时任务/批量发送载体如 daily_pipeline.ps1、send_backfill.ps1），**write_file 后必须转 UTF8 BOM**：`$c=Get-Content <file> -Raw -Encoding UTF8; [IO.File]::WriteAllText(<file>,$c,(New-Object Text.UTF8Encoding($true)))`——PS5.1 读无 BOM 的 UTF-8 中文乱码，Test-Path 中文路径全失败（2026-08-08 实测 send_backfill.ps1 因此 7 份全报"文件缺失"）
7. **Python f-string 生成 HTML/CSS：所有花括号必须双写 `{{ }}`**——CSS 里每个 `{`/`}` 都要转义成 `{{`/`}}`，漏一个就 SyntaxError。写完后先 `py_compile.compile(doraise=True)` 验证再跑
