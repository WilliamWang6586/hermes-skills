# 可靠执行命令参考

## Linux / WSL 路径执行模式

### ✅ 唯一可靠：cmd.exe /c + Windows 原生 Python

```powershell
cmd.exe /c "C:\Users\王子涵\AppData\Local\Python\bin\python.exe D:\Hermes文件库\每日科技日报\daily_tech_report_v2.py"
cmd.exe /c "C:\Users\王子涵\AppData\Local\Python\bin\python.exe D:\Hermes文件库\每日科技日报\daily_tech_report_v2.py --date 2026-07-20"
```

**原理**：`cmd.exe` 是 Windows 原生 shell，不受 terminal 的 WSL/PowerShell 路由影响。Python 进程在 Windows 层运行，直接使用 VPN 网络栈。

### ❌ 不可靠的方式

| 方式 | 问题 |
|------|------|
| `python3 /mnt/d/...` | 有时被路由到 WSL，翻译 API 超时 |
| `wsl -d Ubuntu-24.04 -- python3 ...` | 需要用户逐条审批 `-c` 参数 |
| `C:\Users\...\python.exe D:\...` 直接调用 | terminal 可能把它送到 WSL 导致 "command not found" |
| `/mnt/c/Windows/System32/cmd.exe /c ...` | 从 PowerShell 调用时路径不可达 |

## 为什么 WSL Python 不适合网络密集型任务

测试数据（同一条 HN 翻译管道）：
- Windows 原生 Python + cmd.exe /c：~120 秒完成 50+ 条翻译
- WSL Python + python3 /mnt/d/...：300 秒超时未完成

原因：WSL 的网络栈通过虚拟化层翻译系统调用，对短连接密集型任务（50 次独立 HTTP 请求）开销显著。
