---
name: ppt-master-ops
description: >-
  使用 ppt-master 技能生成原生可编辑 PPTX（中文汇报/竞选/答辩场景）。当用户说「做一份 PPT」
  「生成演示文稿」「这个 PDF 转成 PPT」「套用我的 PPT 模板」「加动画/旁白」
  「**把照片放进去**」「**删几页/改成 N 页**」且本机已装
  ppt-master 时使用。覆盖：路由选择（Default vs Quick）、两条强制确认门与用户可见的
  代替做法、项目路径带日期后缀的坑、中文排版栈（思源宋体→SimSun / 微软雅黑）、
  华丽动效的正确开启方式与实测边界、SVG 质检器硬规则与
  一次成型页头模板、加用户照片的三条契约、逐页让用户看到进展的做法、
  **中文讲稿去「装」与「履历复述」的判别表**（爱好页只作展示、
  删时间轴/证据回扣页、只写做法不评价意义）、
  **「只改页码/几个字/统一动效/换张图，别的别动」时直接改用户的 .pptx 而不是重导源**，
  以及换图前必须先算目标框宽高比（否则长卷被 slice 砍掉一半）。
  安装/升级 ppt-master 本身 → 见 skill-collection-install 技能。
version: "1.4"
updated_at: "2026-09-21"
platforms: [windows, linux, macos]
---

# ppt-master 使用运维（生成原生可编辑 PPTX）

`ppt-master` 是一个 80MB / 83 个脚本的大型技能，**它本身带强制流程**，不是"给个主题就出图"。
本技能记录实际驱动它的方法与坑。安装/升级见 `skill-collection-install`。

## 0. 最短路径（先看这个）

```
读 SKILL.md → 按路由选 Default/Quick → 读 routing.md → 读 plan-core.md
→ 建项目 → 写 design_spec.md → 画 SVG 到 svg_output/ → 质检 → 导出 PPTX
```

**能省的一步都别省不掉的就是「确认门」**——见第 2 节，这是最容易翻车的地方。

## 1. 路由选择：Default vs Quick

| | Default | Quick（快速模式） |
|---|---|---|
| 入口 | `workflows/generate-pptx.md` | `workflows/profiles/quick-generate.md` |
| 交互 | ⛔ **两轮强制用户确认** | 不问，直接出 |
| 产物 | spec + lock + SVG + PPTX + 预览 | SVG + PPTX |
| 适用 | 用户对**画面/动效/风格有具体要求**（"华丽""高级感""3分钟"） | 用户说"快速生成""不用跟我确认" |

**判断规则**：用户提了具体视觉/节奏要求 → Default；只说"做个PPT" 且赶时间 → Quick。
**Default 与 Quick 互斥**，选定后不要再加载另一个的文档（技能内明确禁止）。

其他路线：`create-template`（从已有 PPTX 提炼可复用模板）、`edit-native-pptx`（保留原设计填充新内容）。
**已有一份 .pptx 想复用 → `edit-native-pptx`，不是 Generate。**

## 2. ⛔ 两条强制确认门（Default 流程的核心坑）

Default 流程有两条 **BLOCKING** 门，**技能明文规定不许 agent 替用户确认**：

1. **Stage 1** — 沟通契约（受众/意图/成果/核心信息/场景/画布）+ 模板 or 自由设计
2. **Stage 2** — 完整方案（叙事模式、视觉风格、页数、配色、字体、图标、图片源、动效、讲稿开关）

技能提供 UI 界面（`confirm_ui/server.py --daemon`）和 chat 两种形态。

### 推荐做法：用 chat 分支 + 结构化 markdown 表格代替 UI

**本会话实测有效**：把 Stage 1 和 Stage 2 打包成一次「你可直接看的确认」回复——

```
## 🚧 最终确认门（Stage 2）——请你看完点确认
### 一、三个设计方向（表格对比，标出推荐及理由）
### 二、核心叙事（页序表：页号/标题/打哪个评分点/秒数）
### 三、技术规格（画布/字体/配色/字号/图标/动效/讲稿）
### 四、需要澄清的点
## ⛔ 请你确认（回「确认」或「确认，但要改 XX」）
```

**为什么这样好**：用户说"想全程看到你的工作过程"时，UI 弹窗反而挡住了过程；
chat 表格既能展示方案让用户把关，又满足 BLOCKING 门"必须用户本人确认"的硬要求。

### 硬规则

- **绝不自问自答**：`result.json` / `template_selection.json` 是**用户回执**，agent 不能代写、
  不能合成 payload、不能自动化提交。用户沉默 = 未确认。
- 用户明确授权代理决策时（"你看着自己选方案"），才走 delegated 分支：agent 决定 + 装模板 +
  出一个完整摘要，但**不要伪造 UI 回执**。
- 门未通过前的跨阶段打包是违规（`no cross-phase bundling`）。

## 3. 项目路径带日期后缀（高频踩坑）

```powershell
python3.14 scripts/project_manager.py init <name>
# 实际创建： <hermes-home>/projects/<name>_<YYYYMMDD>/    ← 带日期！
```

**后续每条命令都要用带日期的真实路径**，否则报项目不存在。先落盘再引用：

```powershell
$P = "C:\Users\王子涵\AppData\Local\Hermes Agent CN Desktop\data\hermes-home\projects\jtuanzhishu_20260921"
```

`$SKILL_DIR` 同理：技能要求**每次工具调用都展开绝对路径**，禁止 `cd`、禁止依赖 CWD、
禁止假设是仓库 checkout。

## 4. 材料入库（PDF/DOCX/XLSX → Markdown）

```powershell
$SK = "...\skills\ppt-master"
python3.14 $SK\scripts\source_to_md.py <源文件> -o $P\sources
python3.14 $SK\scripts\project_manager.py import-sources $P "$P\sources\<名>.md" <源文件>
```

- **`import-sources` 同类文件要「md + 原件」一起传**：只传原件会重新转换；
  只传 md 会丢失归档。两边都传时脚本会打印 `skipped PDF auto-conversion`
  并跳过重复转换，这是**正常行为不是报错**。
- PowerShell 里 python 的 **stderr 会被包成 `NativeCommandError`**，那些 `note:`/`[OK]`
  其实都在 stderr 上——`exit_code: 1` 不代表失败，**看输出内容判断**。
- PDF 是压缩流时 `read_file` 只能看到二进制。**要么用 `source_to_md.py`（首选），
  要么用 PyMuPDF 直接抽文本**（见 `references/pdf-text-extraction.md`）。

## 5. 中文排版栈（决定"高级感"）

| 角色 | 推荐 | 理由 |
|---|---|---|
| 标题 | `SimSun`（思源宋体落地面 / 宋体） | **宋体标题 = 高级感的关键**，比全雅黑高一个档次 |
| 正文 | `Microsoft YaHei` | 屏显清晰 |
| 数字/公式 | `Cambria Math` / `Consolas` | 公式预览、编号 |
| 等宽/编号 | `Consolas` | 档案编号、代码 |

- 默认字身 24px（`balanced`）；`presentation` 用 32px；`text` 用 20px（`ppt169`）。
- 字号比例：标题 1.5–2×body、副标 1.2–1.5×、注释 0.7–0.85×。
- **宋黑对比配对**是技能要求的"across the direction set include both a concord and a
  contrast pairing"——标题宋体 + 正文雅黑正好满足。
- 在 Windows 上 `python3`/`python` 都不存在，**用 `python3.14`**（对齐 memory 里的环境事实）。

## 6. 华丽动效怎么开（用户的"动效要华丽"）

技能里的动效有几层，**必须开对开关**：

| 层次 | 开关 | 说明 |
|---|---|---|
| 对象级动画 / Morph 跨页 | `design_spec.md §I` **Custom Animations = enabled** | §IX 的 `Motion suggestion` 只是建议，**不会触发**执行 |
| 已有的 `animations.json` | 自动走 `customize-animations` | 导出时保留 sidecar |
| 整册动效设置 | `animations.md` 的 Step 7.3 flags | 转场/自动换片 |
| 关掉全部 | `-a none` / `--no-animations` | |

**关键**：用户要"华丽"时，光写 §IX 的 Motion suggestion 是**没效果的**——
必须把 §I 的 Custom Animations 置 `enabled`，并在导出的 §IX 里为**跨页延续的单元**
（编号、图形、数字）显式写 Morph candidate。

### ⚠️ 实测警告：真正能保证"华丽"的是**转场**，不是对象动画

2026-09 实测：写了 `animations.json` 的 `groups.effects[]`（46 行，含 fly/wipe/zoom/rise_up），
`validate` 通过、导出 `POSTFLIGHT status=passed`，**但解包 PPTX 一看：27 个对象动画 filter 全是 `fade`**。
试了 4 轮（补 `order`、补 `version`、补 slide 级 `animation`、按官方 scaffold 重建）**全部失败**，
其中一轮还把动画搞少（27→15）。

| 层次 | 实测状态 |
|---|---|
| 页面转场（每页不同效果 + 各自时长） | ✅ **完全有效**，10 种效果全落盘 |
| 对象级动画（每块不同效果） | ❌ **未跑通**，一律 fade |

**所以**：
- 承诺"动效华丽"时，**靠转场兑现**（`drape`/`cube`/`dissolve`/`gallery`/`peel_off`…），对象动画当 bonus
- **不要对用户承诺"逐条飞入/擦除"**——先做，解包验证，做到了再说
- `validate` 通过 + `status=passed` **不等于动效生效**，唯一可信验证是解包 PPTX 看 `filter=`
- 详见 **`references/animations-sidecar-findings.md`**（含字段单位坑、失败假设清单、回退策略）

配套（本会话验证的设计选择）：
- **Morph 连续 + 编号滚动** 是"华丽但不像 AI 乱堆"的组合——母题延续比满屏粒子高级。
- **不用 AI 生图**反而更"去 AI 味"：原生形状 + 精细排版撑画面。前提是用户没提供自己的照片。

## 6b. 画 SVG 页：质检器硬规则（**最容易卡死的一步**）

`svg_quality_checker.py` 报错直接**阻塞导出**。本会话为把一个中文档案体系列修到 0 错，
迭代了 5 轮（11 错 → 0 错）。**完整规则 + 一次成型页头模板见
`references/svg-authoring-checker-rules.md`**——画第一页前先读它。

必须先建立的 6 条标准（否则每页都会重复犯）：

1. 根级 `<g>` 的 `data-pptx-bounds` **互不重叠**；全屏框线用**直挂 `<rect>`**
   + `data-pptx-role="decoration"`，**包 `<g>` 就会与所有块重叠报错**
2. bounds 要包住实际渲染范围：**无 transform 的文本垂直占位 = `y − 0.85×字号` 到 `y + 0.35×字号`**
3. **禁用内嵌 `<tspan>` 做行内上色**（技能文档说支持，实测质检器判阻塞）→ 拆成同 y 的多个 `<text>`
4. 用到的字号**先在 `spec_lock.md` 声明成具名角色**；未声明字号全册最多出现 2 次
5. 根 `<svg>` 设默认 `font-family`，子元素只写覆盖
6. 每个根 `<g>` 必须有唯一 `id`——否则 **Morph/对象动画无法引用**（动效做不出来）

**节奏（关键）**：先画 **4-5 页** → 跑早期门 `--stage early --json` → 把方法级问题修对 →
再往下画。一口气画完 11 页再质检 = 把同一个错误复制 11 遍。

```powershell
# 早期门（第 5 页后；报告在 validation/svg_quality_early_report.json）
python3.14 $SK\scripts\svg_quality_checker.py $P --canonical-authoring --stage early --json
# 最终门（全部页画完后；--json 必加，否则导出被拒）
python3.14 $SK\scripts\svg_quality_checker.py $P --canonical-authoring --stage final --json
```

**别猜报错**：`--json` 落盘的报告里 `categories.blocking.issues` 直接给出
`content (x1,y1)-(x2,y2)` 与 `container (...)` 数值，**照抄改 bounds**。

## 7. 让用户"全程看到工作过程"

技能自带 **Live Preview**（强制在画第一页前启动）：

```powershell
python3.14 $SK\scripts\svg_editor\server.py $P --live --daemon
# 端口从 6060 起自动找空闲，URL 在 $P\live_preview\lock.json
```

- 启动后**把 URL 报给用户**，这是"看过程"最直接的方式；它不阻塞。
- 保持运行到 Step 7 结束，用户点 Exit 或明说才关。
- 画页阶段逐页产出到 `svg_output/`，预览会跟着刷新。

## 8. 内容质量：中文竞选/汇报类 PPT 的写法

从本会话（班委竞选）提炼的通用规则：

1. **先找"评分表"**：把官方文件里的职责条目转成"评委在打什么分"的表，每页打在具体条目上，
   **不要写放之四海皆准的漂亮话**。
2. **必须是用户真实经历，且要主动追问**：讲优势前**先问清素材**。本会话有效问法是
   **4 个编号问题 + 每题给例子**（做过什么事务？政治面貌？有无可量化数据？→ 让用户编号回答），
   比开放式"说说你的优势"有效得多。**绝不编造用户经历**——没有素材就明确说
   「PPT 会写成空话」，然后给两条路：等他答完 / 先出"通用强模板"留占位符。
   用户答完还可能**追加要求**（本会话："自我介绍部分拓展几页，到时我一笔带过"）——
   这是 `presentation` 阅读模式的正当用法（**PPT 承载信息、口头 5 秒扫过**），加页不是违背页数约束。
3. **政治身份类内容的写法（用户明确要求"不要假大空"）**：不喊口号，写
   **「我理解的 X 不是背下来的条文，而是……」+ 一句具体到能记住的理解 + 落到可检验的行动**。
   本会话结构：现状（团员/已递交申请）→ 我对马克思主义的具体理解（"一个人的价值要放到
   他和别人的关系里衡量"）→ 所以我要做的（三条可量化承诺）。**忌**用"热爱""坚决拥护"
   这类形容词撑段落。
3. **一页一个杀招**：找出全场唯一的"组合拳"（如"技术 + 组织"）做成核心页，其余页做支撑。
4. **承诺要可量化**："不漏一条通知""档案随取随有""每月一次谈心"，比"尽力服务"强十倍。
5. **不写具体工具名**（除非确认过正式名称）：用户提到不确定的内部系统时，模糊成能力描述
   （"搭建班级信息数据库"），避免答辩被追问时卡壳。
6. **忌**：首尾复述、罗列课程名、空喊口号（与 memory 里的内容偏好一致）。
7. **不要反复讲经历——用户会明确嫌烦**。本会话用户原话：
   > 「不要太过着重说我的经历，尤其想那种**画个数轴**纯属多此一举」

   踩法：把**同一段履历**用不同页型讲三遍（档案卡 → 时间轴 → 证据支撑页）。
   用户要的是**一次讲清 + 其余只写"我会怎么做"**。具体动作：
   - **删掉时间轴/数轴页**（履历按年份铺开 = 最典型的"多此一举"）
   - **删掉"我的底气来自哪里"类的证据回扣页**（它的每一项都是前面几页的重述）
   - **收束页只写做法，不复述履历**：左栏放官方职责原文、右栏直接写"我会怎么做"，
     不要把"中学至今的班干部经历"再抄一遍
   - 加页 ≠ 讲更多经历。用户说"自我介绍拓展几页，到时我一笔带过"时，
     加的是**版面**（照片、排版），讲稿对应段落要**更短**（本会话压到 8 秒/页）
8. **用户自己提供的照片＝最有力的素材，优先级高于任何 AI 生图或图标堆砌**。
   「我都备注好了，就在你的文件库里」这类指路要**真的去搜**（`search_files` 全盘找图片），
   别只看项目目录就回"没找到备注"。**找不到备注就直接问用户指哪个**，
   同时给出"照我的默认方案做"这条退路，别空等。
9. **爱好页只作展示，绝不拿来佐证能力**（用户明确要求）。
   本会话用户原话：「**爱好不需要佐证我的能力，只作展示**」。

   爱好（摄影/书法/运动…）页面的**唯一职责是让人看到这个人有生活**，
   不是借它论证"我适合这个岗位"。**每一条"爱好 → 能力"的映射都要删掉**：

   | ✗ 删掉 | 理由 |
   |---|---|
   | 「摄影教会我的，是先把人和事看清楚再动手」 | 把爱好拔高成方法论 |
   | 「这和做班级工作一样：先弄明白同学需要什么」 | 强行映射到岗位 |
   | 「写字要求耐心与结构感，恰好是做班级材料最需要的」 | 最典型的"佐证能力" |
   | 「好的结果来自反复打磨」类收尾金句 | 硬凑升华 |

   **正确写法**：两幅作品 + 一句大白话说明。
   ```
   平时喜欢拍点东西。这是两张。
   闲下来会写写字。这是两张。
   ```

   **同一页只放一个爱好**（两幅作品并排），别两个爱好挤一页——用户要求"分别放两张 PPT"。
10. **「不要写得太装」的通用判别法**（用户反馈「不要写的太装了」）。
   逐条自检这些模式，命中就改：

   | 装的特征 | 改法 |
   |---|---|
   | 三段排比收尾（"记在心上、落在纸上、办到实处"） | 砍成一句 |
   | 表态句（"该我扛的责任我不会往后躲"） | 删，或改成具体做法 |
   | 书面腔升华（"一个人的价值最终要放到他和别人的关系里才能衡量"） | 口语化：一个人光顾自己是走不远的 |
   | 论证自己为什么重要（"为什么重要"整段） | 删，只留"做了什么"+"结果" |
   | 煽情假设（"可能就是一个同学一整年的努力白费"） | 删 |

   **规律**：**只陈述事实和做法，不评价事实的意义**。
   用户要的是"我做了 A，结果是 B"和"我打算做 C"，不是"A 说明我具有…品质"。
11. **版块重复＝必须合并或删除**。本会话同一职责在 3 页各讲一遍
   （职责对照表 → 时间轴 → 证据回扣页）。**判断法**：把每页标题连起来读，
   如果两页回答的是同一个问题，删一页。
   本会话删掉"职责对照表"与"底气"两页后，页数 11 → 9，信息密度反而上升。
12. **自我介绍页：只列事实，不评价**（用户主动要求「单独专门页的自我介绍，
   包括我来自西安等等，在**所有演讲之前**，后面跟着作品展示」）。

   | 项 | 写法 |
   |---|---|
   | 位置 | **封面之后、所有内容之前**（第 2 页）；作品展示紧跟其后 |
   | 字段 | 姓名 / 籍贯（省+市，如"陕西西安"）/ 专业 + 年级 / 政治身份 |
   | 版式 | 左侧四行「小标签 + 内容」+ 行间发丝细线，右侧人物照片竖幅 |
   | 照片 | 复用封面那张（同图多页引用**不会重复占体积**，导出只存 1 份 media） |

   **忌**：加"我性格开朗""我热爱…"这类评价性描述、写中学经历（用户要求经历不写细）、
   写"我的优势是…"。**只有可核对的事实**。
   讲稿对应段落 ~20 秒：籍贯专业一句带过，照片本身就在说明"我在做事"，不用解释。

## 8b. ⚠️ 用户在 PowerPoint 里手改过 → 改不回去

**这是最容易白忙一场的场景**。本会话用户说「我改了一些，现在先把页码改好」——
他在 PowerPoint 里**拖动调整了幻灯片顺序**（把摄影/书法两页提到了岗位职责前）。

| | 事实 |
|---|---|
| 手改可回灌吗 | ❌ **不能**。ppt-master 是 SVG → PPTX 单向生成，没有 PPTX → SVG 回灌 |
| 下次导出的顺序 | **按 `svg_output/` 的文件名字母序**，用户在 PPT 里拖的顺序**全部丢失** |
| 所以 | **改文件名让顺序变成你的顺序**，而不是试图"保住"他的拖动 |

### 标准处置流程

1. **先测量，别猜**：解包他手上的 `.pptx`，读每页的首段文本，还原真实页序。

   ```python
   z = zipfile.ZipFile(pptx)
   slides = sorted((n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                   key=lambda n: int(re.search(r"(\d+)", os.path.basename(n)).group(1)))
   for n in slides:
       texts = re.findall(r"<a:t>([^<]*)</a:t>", z.read(n).decode("utf-8", "ignore"))
       print(n, texts[0][:20] if texts else "")
   ```

   **不要靠"他说改了页码"推断他改了什么**——先读出来。

2. **改 SVG 文件名的数字前缀**匹配他的页序（两阶段重命名，见
   `references/images-and-page-roster-ops.md`）。

3. **同步四处**：`animations.json` 的 `slides` keys（按语义后缀 remap，别按编号）、
   `spec_lock.md` 的 `page_rhythm`、`design_spec.md §IX` 的 Slide 编号、
   每页内的页码文本。

4. **重导** → 解包验证页码严格递增 → 用新文件名交付。

### 声明边界（重要）

如果你的改动**在用户手改之后**才导出，那么**他的手动调整会被覆盖**。
交付时要明确说清：「我按你说的顺序重排了源文件并重导，**新文件里请不要再手动拖顺序**，
否则下次导出会丢」。**不要让用户在两个方向上反复改**。

### ⚠️⚠️ 但先问一句：他只要改几个字，还是要改整个源？

**本会话最大的翻车点**：用户说「**V3 的内容我都改好了，就光让你再改个页码和左上角的数字，
你咋听不明白？别的先别动**」——我却去改 `svg_output/` 源文件、重命名、重排、重导，
把他手改的正本当成了\"需要同步的旧版\"。

**判别法（改之前必问自己）**：

| 用户的话 | 正确动作 |
|---|---|
| 「改页码」「改这几个字」「左上角数字」+ 说\"别的别动\" | **直接改他手上那份 `.pptx`**（解包改 XML，见下）。**源文件一个字都别碰** |
| 「顺序不对」「重排一下」+ 有源目录概念 | 改 SVG 文件名 + 同步四处 + 重导（上一节流程） |
| 用户已手改过且你要改的是**内容/顺序** | 先**明说冲突**（改源会让他的手改失效），让他选：改他手上那份 / 让我按源重做 |

**核心原则**：**用户的 `.pptx` 就是正本**。ppt-master 的 SVG 目录只是**生成它的一次性中间物**，
不是\"source of truth\"。他手改过的文件，源目录已经**过期**了——拿过期的源去\"修正\"他的正本，
等于回滚他的劳动。这与第 8b 节不矛盾：8b 是\"他要重排顺序\"，本节是\"他只要改几个字\"。
**分辨不清就问，一句话的成本远低于重做。**

### 直接改 `.pptx` 里几个字符串（最省事做法）

只改文字、不动结构时**不要**走源→重导，直接改写 zip 内的 slide XML：

```python
import re, zipfile
SRC = r"...\王子涵_竞选团支书_v3.pptx"      # 用户手改的正本
DST = r"...\王子涵_竞选团支书_v5.pptx"      # 新建文件名，别覆盖（他可能开着 v3/v4）

zin = zipfile.ZipFile(SRC)
patched = {}
for i, want in {3: "03", 4: "04", 5: "05"}.items():     # slide 序号 -> 新值
    part = f"ppt/slides/slide{i}.xml"
    x = zin.read(part).decode("utf-8")
    m = re.search(r"<a:t>(\d{2})\s*/\s*10</a:t>", x)     # 精确定位那一个 run
    assert m, f"slide{i}: no 'NN / 10' run found"
    old = m.group(1)
    x = x[:m.start()] + f"<a:t>{want} / 10</a:t>" + x[m.end():]
    assert x.count(f"<a:t>{want} / 10</a:t>") == 1       # 只替换了一处
    patched[part] = x
    print(f"slide{i}: {old} -> {want}")

with zipfile.ZipFile(DST, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        d = patched.get(item.filename)
        zout.writestr(item, d.encode("utf-8") if d is not None else zin.read(item.filename))
```

要点：
- **只替换那一个 `<a:t>` run**，其余字节原样搬过去 —— 版式/图片/备注/动效全不动
- **精确定位**：`<a:t>06 / 10</a:t>` 这种整段匹配，不要用裸 `\d{2} / \d{2}`（会误伤 ARCHIVE 条）
- **输出到新文件名**，别覆盖他正在看的文件（本会话 `PermissionError: [Errno 13]` 就是因为他开着）
- 改完**读回来验证**页码严格递增

### 页码 vs 档案编号：别擅自改后者

页码是**排版定位**（跟着页序走）；`档案 001`／左上角大号 `001` 是**内容语义**（第几份档案）。
把后者改成页序会变成「第六份档案」，语义就怪了。
**用户说\"改左上角的数字\"时先确认他指哪一类**，别默认全改。
不确定时：**只改页码，把语义编号问题单独提出来问**。

### 在用户的 `.pptx` 上做「统一动效」和「换图」（同一模式的延伸）

用户手改过的 deck 上，除了改字**还可以直接改动效和图片**，同样别碰源目录。

**统一动效**——把每页不同的转场换成同一种，直接正则替换 `p:transition` 块：

```python
P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
def unify_transition(xml_text):
    new = (f'<p:transition xmlns:p14="{P14}" spd="med" p14:dur="700">'
           f'<p:dissolve/></p:transition>')
    m = re.search(r"<p:transition\b[^>]*/>", xml_text)          # 自闭合形态
    if m:  return xml_text[:m.start()] + new + xml_text[m.end():]
    m = re.search(r"<p:transition\b.*?</p:transition>", xml_text, re.S)   # 成对形态
    if m:  return xml_text[:m.start()] + new + xml_text[m.end():]
    return xml_text.replace("</p:sld>", new + "\n</p:sld>")    # 本来没有就插一个
```

⚠️ **转场效果名藏在子元素里**，不在 `<p:transition>` 开标签上——验证时必须读子节点，
否则 push/cover/wipe/prism/… 全被当成同一个：

```python
kids = [e for e in re.findall(r"<((?:p|p14):\w+)\b", block) if e != "p:transition"]
effect = kids[0] if kids else "(p14-bare)"   # 封面/封底是 p14 形态，子节点可能为空
```

**换图**——只改 media part 的字节，不动 slide XML：

```python
s4    = zin.read("ppt/slides/slide4.xml").decode("utf-8")
rels  = zin.read("ppt/slides/_rels/slide4.xml.rels").decode("utf-8")
embeds = re.findall(r'r:embed="([^"]+)"', s4)          # 按出现顺序 = 左图、右图
target = {rid: re.search(rf'Id="{rid}"[^>]*Target="([^"]+)"', rels).group(1)
          for rid in embeds}
right_part = target[embeds[-1]].replace("../", "ppt/") # 右图 = 最后一个
```

#### ⚠️ 换图的第一原则：先算目标框的宽高比，再挑图

**本会话差点翻车**：用户说\"把第 4 页书法右边的照片换一张\"，我第一反应挑\"最好看的那张\"，
结果它是 3218×968（比例 **3.3**）的长卷，而目标框是 **1.84** ——
`preserveAspectRatio="slice"` 会**砍掉 45% 宽度**，作品直接断成两半。

**正确顺序**：

1. **先量目标框比例**（从原 SVG 的 `x/y/width/height`，或从 slide XML 的 `ext` 算）
2. **算每张候选被裁掉多少**：
   ```python
   target = TW / TH
   if w / h > target:  keep = (h * target) / w      # 宽图裁两边
   else:               keep = (w / target) / h      # 高图裁上下
   lost = 1 - keep                                  # >40% 基本不能用
   ```
3. **只在\"裁切损失 <~30%\"的候选里比内容**（形式、有无落款印章、与另一张是否呼应）
4. 同分时**优先有署名/印章的那张**——竞选/答辩场景，作品上有自己的名字最有说服力

**反面教训**：vision 看联络图给\"推荐书法作品7\"是对的（只评了内容美观），
但**它不知道目标框比例**。视觉推荐必须叠加几何校验，两者都过才选。

#### 交付前必须确认「其余一律未动」

用 zip 逐字节对比新旧文件，把\"我只改了该改的\"变成可验证事实：

```python
a, b = zipfile.ZipFile(V5), zipfile.ZipFile(V6)
for m in ("ppt/media/image1.jpg", "ppt/media/image4.jpg"):
    assert a.read(m) == b.read(m), f"{m} should be untouched"
for i in range(1, 11):                                   # 文字必须逐页相同
    n = f"ppt/slides/slide{i}.xml"
    assert (re.findall(r"<a:t>([^<]*)</a:t>", a.read(n).decode("utf-8", "ignore"))
         == re.findall(r"<a:t>([^<]*)</a:t>", b.read(n).decode("utf-8", "ignore")))
assert all(a.read(n) == b.read(n) for n in a.namelist() if "notesSlide" in n)
```

**版式改动只改该改的、交付时说清\"其他字节级未变\"**，用户才敢直接用。



## 8c. PPT 不是你做的（别人/zcode 给的）→ 补图、修变形、嵌视频

用户拿一份外部 .pptx 回来说「这几页没配图」「图被拉变形了」「视频只有链接，下载下来嵌进去」时，
**没有 SVG 源，全部在 .pptx 上做**。完整方法见
**`references/fix-existing-pptx-media.md`**（量比例脚本、COM 导出 PNG、ffprobe 验证、
B 站/央视取片、`AddMediaObject2` 嵌视频）。

三条最容易翻车的：

1. **用户说的「变形」经常不成立**。先 `python-pptx` 算 native/display 比例 **且** 导出 PNG 用 vision
   逐页看，两样都过才动手。本会话 3 个"疑似变形"实测 0 个真变形——真问题全是**缺图**。
2. **下载完必须 `ffprobe` 量宽高**。`yt-dlp -F` 只报 480p 时，硬扒央视 1200.m3u8 母带
   **仍可能只有 480×270**——新闻片源本来就是标清，换接口救不了，只能换片源。
3. **嵌视频**：外部 deck 里塞视频优先 COM `Shapes.AddMediaObject2(path, False, True, ...)`；
   `LinkToFile=False` + `SaveWithDocument=True` 才是真嵌入。**python-pptx 也能用
   `slide.shapes.add_movie(mp4, ..., poster_frame_image=<jpg>, mime_type="video/mp4")`**，
   但 `poster_frame_image` **不接受 mp4 本身**（会 `UnidentifiedImageError`），
   必须先用 `ffmpeg -ss 2 -i x.mp4 -frames:v 1 poster.jpg` 抽一帧。
   视频塞完**标题会被吞**，见 references §6c。嵌完把「片源（点击打开）：…」文本框整块删掉。

4. **改完必须重导 PNG 逐页 vision 复查**。往外部 deck 补图的三大翻车：
   盖住原有正文（空框其实是文本框）、挪框后文字溢出压到下块、视频吞掉标题。
   详见 references §6。

5. **补完图用户还说「排版还是有问题 / 文字太多正文太少」→ 别再局部修补，整页重排**。
   见 **`references/pptx-page-redesign.md`**：四种版式模板（满版+遮罩 / 半页 bleed /
   视频页 / 竖图+时间线）、该删的元信息清单（图注、"点击播放"、"未修改未剪辑"）、
   主体文字加厚写法（判断→机制→一句话收束，每页 150-230 字）。

6. **「视频不完整」先分清是时长还是画面出界**——用户说「画面不在 PPT 里」时量
   `top + height` 是否超出页高，别去重剪片子。视频与页面同为 16:9 → 直接铺满整页
   （0,0,W,H）+ 给 `p14:media` 设 `fullScreen="1"`，标题让位、只留底部一行片源。
   两个 python-pptx 死坑：**删形状时 `sh is med` 永远为 False**（要 `sh._element is med_el`，
   否则连视频一起删掉）；**`find('.//{p}videoFile')` 找不到**（`a:videoFile` 在 a 命名空间，
   判视频用 `'.mp4' in sh.name`）。详见 references §7-§8。
7. **用户丢来自拍照片 → 先 vision 核内容再定页**（文件名常与画面不符），
   图注写「年月 + 地点 + 作者」；删图必须连图注一起删。详见 references §10。
8. **用户说「每页之间加动画过渡，高级一点」→ 直接给 .pptx 写 morph 转场**，
   不用 ppt-master 的 sidecar。要点：`p:transition` 插在 `<p:clrMapOvr>` 后 `<p:timing>` 前；
   morph 在 p159 命名空间且要带 `p14:animBg`；**`dur` 属性常被忽略，时长必须用 COM
   `SlideShowTransition.Duration` 兜底重写**；视频页用 fade 不用 morph；
   COM 读回 `3954`=morph、`3849`=fade 做断言验收（不能靠截图）。
   详见 `references/animations-sidecar-findings.md` 最后一段「直接给现有 .pptx 写转场」。
   ⚠️ **写 XML 只能用纯文本插入，绝不用 lxml 重新序列化**——会产出 PowerPoint
   打不开的文件（python-pptx 能读 + zip 完整**都不算通过**，必须真打开）。
   详见 `references/pptx-page-redesign.md` §12–§13。
9. **用户说「没点到十四五/十五五」「没扣住课程主题」→ 不是补一页，是三处咬合**
   （前段补上位表述 / 中段加规划期对比页 / 收尾推到下一个规划期）。
   量化指标查不到原文就**留白的定性写**，明说没编数字。
   接着说「**不只要一页，最好贯穿全文**」**别再补第二页专页**（=连续两页讲同一件事），
   改成**每页右上角加一行 9pt 标注**（`十四五 · 提法 ｜ 十五五 · 提法`），
   视频页和已以规划期为题的那页跳过；深色满版页的标注必须改**白字+深色描边**否则读不出。
   见 `references/pptx-page-redesign.md` §14–§15。

## 9. 工作流杂项
- 用 `todo` 工具让阶段对用户可见（读材料/选路由/写规范/画页/加动效/导出）。
- 素材不全时**先并行做不依赖用户输入的部分**（风格定调、视觉体系、动效方案），
  别干等——这与用户"按顺序来都完成"的风格一致。

## 参考文件

- `references/svg-authoring-checker-rules.md` — **画页前必读**：质检器 6 条硬规则、
  一次成型页头模板、字号标定表、报错精确定位命令、迭代收敛记录
- `references/images-and-page-roster-ops.md` — **加用户照片前必读**：`<image>` 三条独立契约
  （href 必须 `../images/`、lock 必须 `- key: value` 冒号格式、§VIII Status 合法枚举）、
  Pillow 压缩配方（41MB→2MB）、选图前先出联络图用 vision 看、删页/重编页码要同步的 5 处
- `references/animations-sidecar-findings.md` — **做动效前必读**：转场确定有效 vs
  对象动画未跑通的实测结论、字段单位坑（秒 vs 毫秒）、`trigger` 不是 `start`、
  已排除的 5 个失败假设、回退策略、解包 PPTX 验证动效的脚本
- `references/post-export-verification.md` — **导出后验证必读**：验证脚本自身的 5 个
  假警报陷阱（转场只读开标签 / ARCHIVE 条被页码正则误匹配 / 跨段正则 / `.lstrip("0")`
  / PS 正则吃内容）、固定断言骨架、ad-hoc 脚本与"测试套件"的区别、交付文件被占用的处理
- `references/pdf-text-extraction.md` — PDF 抽文本的两种走法 + PowerShell 调 Python 的编码坑
- `references/fix-existing-pptx-media.md` — **改别人做的 .pptx 必读**：图片变形先量后改（连 vision 目视）、
  COM 导出 PNG 做联络图、央视母带/ffprobe 验证的坑、B 站取中文纪录片、advance 嵌视频、
  官方图源抓原图、**§6 补图三铁律**（空框可能是文本框、挪框必溢出→改缩字号、视频吞标题、逐页大图验收）
- `references/pptx-page-redesign.md` — **用户说「排版还是不行/文字太多/正文太少」时必读**：
  四种版式模板 + 遮罩代码、该删的元信息清单、主体文字加厚写法、时间线分块、字数验收、
  **§7 视频「画面不在页面里」的坐标诊断 + 铺满整页/全屏属性**、
  **§8 python-pptx 删形状 `sh is med` 恒 False 的坑**、§9 页码页眉一次全清、
  §10 用户自拍照片按内容定页（含本会话三张的实际归属）、
  **§12 lxml 重序列化会把 pptx 写坏（必须纯文本插入 + 真打开验收）**、
  §13 转场时长必须 COM 兜底、**§14 「没点到 XX」= 补课程主题的三处咬合**
- 安装/升级/安全扫描误报识别 → `skill-collection-install`
- Windows PowerShell 调 Python 的通用编码坑 → `windows-wsl2-script-exec`、`china-university-web-research`
