# 给已有 .pptx 补图 / 修图 / 嵌视频（不改源、只改用户手上那份）

场景：PPT 不是你生成的（zcode / 豆包 / 别人给的），用户拿回来说
「这几页没配图」「图被拉变形了」「视频只有个链接，下载下来嵌进去」。
**这时没有 SVG 源可改，全部操作在 .pptx 上做**（与 SKILL.md §8b 同理）。

## 0. 先量，别信用户的口头诊断

用户说的「图片被拉伸变形了」**经常不成立**。本会话实测：

- 用 `python-pptx` 算出来 3 个「疑似变形」（第 1/4/8 页）
- 导出 PNG 用 vision 逐页看 → **一张都没变形**

**所以第一步永远是：解包量比例 + 导出 PNG 目视**，两样都过了才动手改。
改没坏的东西 = 制造新 bug。

### 量比例

```python
from pptx import Presentation
from PIL import Image
import io
prs = Presentation(path)
EMU = 360000.0   # 1 cm
for i, s in enumerate(prs.slides, 1):
    for sh in s.shapes:
        if sh.shape_type != 13:      # 13 = PICTURE
            continue
        im = Image.open(io.BytesIO(sh.image.blob))
        native = im.width / im.height
        shown  = sh.width / sh.height
        flag = "⚠️STRETCH" if abs(native - shown) / native > 0.03 else "ok"
        print(f"P{i} {native:.3f} vs {shown:.3f} {flag}  "
              f"[{sh.left/EMU:.2f},{sh.top/EMU:.2f} {sh.width/EMU:.2f}x{sh.height/EMU:.2f}cm]")
```

### 导出 PNG 目视（本机装了 Office 就用 COM，不用装 LibreOffice）

```python
import win32com.client, os
app = win32com.client.Dispatch("PowerPoint.Application")
pres = app.Presentations.Open(os.path.abspath(src), WithWindow=False)
pres.Export(os.path.abspath(outdir), "PNG", 1600, 900)   # 宽高按 16:9 给
pres.Close(); app.Quit()
# 文件名是「幻灯片1.PNG」，再用 PIL 拼 2 列联络图一次看完
```

跑法：`uv run --no-project --with python-pptx --with pillow --with pywin32 python x.py`

⚠️ 导出带中文名的 PNG 时 `Export` 第二个参数固定传 `"PNG"`。

## 1. 缺图页怎么补

先 `_dump` 每页文字（`sh.text_frame.text`），确定这页讲什么，再决定配什么图。
**不要按用户说的「后面很多页都没图」平均用力**——有的页（金句页、大数字页）
留白是设计，硬塞图反而毁版式。判断标准：**这页的信息是不是「一个具体地点/事件」**，
是就配实景图，不是就留白。

## 2. 图片变形：修的比例原则

真变形了才修，二选一：

| 做法 | 什么时候用 |
|---|---|
| **裁剪到框比例**（`crop_left/right/top/bottom`） | 构图主体居中、裁 30% 以内不伤内容 ← **首选** |
| 等比缩放后居中（改 width/height 保持 native 比） | 图比框小，裁了全是马赛克 |

python-pptx 直接改 `crop_*`（0~1 的相对值），**不要**去改 `width/height`——
后者会重新排版、可能压到文字。

## 3. 视频：从「一个链接」变成「能直接播」

### 3a. 先确认哪条源真的是高清——别信 `-F` 的输出

**本会话最大坑**：`yt-dlp -F` 对央视页面只列 `480x270`，
但我以为「肯定有 1080P 母带」，改走 `hls.cntv.lxdns.com/asp/hls/{450,850,1200,2000}/...`，
加 `Referer: https://tv.cctv.com/` 后**确实拿到了 1200.m3u8 并下完**——
`ffprobe` 一量还是 **480×270**。

> **规律：新闻短片的母带就是标清。** 想要高清只能换片源，不是换接口。
> **每次下载完必须 `ffprobe` 量宽高**，不量就等于没验证。

```powershell
ffprobe -v error -select_streams v:0 -show_entries stream=width,height `
  -show_entries format=duration -of default=nw=1 "视频素材\x.mp4"
```

### 3b. 央视网的坑（记录用，别再摸索一遍）

- `yt-dlp` 对 `tv.cctv.com` 走 CCTV 提取器，只给 `480x270`
- 视频页里 `pid` 用正则 `guid\s*[:=]\s*['"]([a-f0-9]{20,40})['"]` 抓
- `vdn.apps.cntv.cn/api/getHttpVideoInfo.do?pid=<pid>` 返回 `hls_url`（`maxbr=2048` 是**上限**参数，不代表有 720P）
- 高清母带路径 `/asp/hls/1200/0303000a/3/default/<guid>/1200.m3u8`，**必须带 Referer** 否则 403
- `yt-dlp -f <URL>` 是错的（`-f` 是格式选择器），直接给 URL 即可
- m3u8 下载后 yt-dlp 会自动 `FixupM3u8` 转 MP4，正常

### 3c. 中文纪录片首选 B 站（有台标、有中文字幕、能吃 1080P）

央视纪录片在 B 站的搬运版往往比官网清晰度高：
- 《美丽中国：自然》秦岭系列 → **1080P**（但英配，课堂不可用）
- 《律动的秦岭》（CCTV-10，**中文配音 + 中文字幕 + CCTV 台标**）→ 720P，24 集 × 5 分钟

`yt-dlp -F "https://www.bilibili.com/video/BVxxxx/"` 即可列格式；
`-F` 对合集默认只列最后一 P，正常。`--flat-playlist --print` 拿不到 `title`/`duration`
（合集分集数据是异步加载的，页面 HTML 里没有 `part`/`duration` 对），
**别在解析分集标题上耗时间**，直接抽第 1 集看内容更快。

> 选片素材的铁律：**中文配音 + 中文字幕**才算能用。英配版即使 1080P 60fps 也只能当封面背景。

### 3d. 剪辑与编码（只为嵌进 PPT，不做二次创作）

```powershell
ffmpeg -ss 00:00:14 -t 55 -i in.mp4 `
  -c:v libx264 -profile:v high -pix_fmt yuv420p -crf 21 -preset medium `
  -c:a aac -b:a 128k -movflags +faststart out.mp4
```

- `-ss` 放 `-i` **前面**（关键帧跳转，秒出）
- `-movflags +faststart` 必须加：PPT 内嵌播放要能流式起播
- `-pix_fmt yuv420p` 必须加：Mac/WPS 兼容
- 片头留 10~15 秒再切，避开制作人员名单
- 55 秒 / 720P / CRF 21 ≈ **17MB**，PPT 体积可接受

### 3e. 嵌进 PPT 用 COM，别用 python-pptx

python-pptx **不支持** add_movie。用 COM：

```python
shape = slide.Shapes.AddMediaObject2(
    os.path.abspath(mp4),   # 必须是绝对路径
    False,                  # LinkToFile: False = 真正嵌入，不是外链
    True,                   # SaveWithDocument: 必须 True
    left, top, width, height)
```

嵌入后原本那页的「片源（点击打开）：…」文本框要**整块删掉**，
否则页面同时有链接和视频，用户还是不知道点哪。

## 4. 官方图源（西安/秦岭这类题材）

- 原图比搜索引擎的缩略图靠谱得多：**进原报道页 `document.images` 抓 `naturalWidth>=400`**
- 澎湃这类站的原图 URL 形如 `http://image.thepaper.cn/www/image/5/366/335.jpg`，
  带 `-e referer` 用 `curl.exe` 能直接下
- 地方媒体（浙江新闻 `stc.zjol.com.cn`）的老图大量 **404**，别反复重试
- 政治人物照片优先选**官方发布渠道**（@西安发布）并保留原水印，页脚标出处
- 360 图搜 `image.so.com` 是懒加载，HTML 里抓不到 `src`；**改从原文页抓**

## 6. 补图/挪框的三条铁律（本会话连踩三次，逐页修了三轮才干净）

改了外部 deck 的版式后，**必须重新导出 PNG 逐页看**——`python-pptx` 不会告诉你
新加的图盖住了原有正文。本会话第一版"全部完成"其实引入了 4 个新 bug。

### 6a. 往任何空框里塞图前，先查这个 shape_id 是不是文本框

`_audit.py` 打出 `AUTO_SHAPE id=7` 看着像占位空框，实际可能**已有文字**。
`add_picture` 只是叠在它上面 → 正文被图盖住，且**导出 PNG 前完全无感**。

规则：**先看 `sh.has_text_frame and sh.text_frame.text.strip()` 非空就不许盖**。
图要放在已有文字框的**上方或下方**，然后把文字框 `top` 让开、必要时缩 `height`。

### 6b. 挪走/缩小文字框后，内容会溢出压到下一块

本会话 P12 把右侧文字框下移，结果它延长到和底部红字重叠。
**这个 deck 的文字框本来就装不下内容**（zcode 生成的常见状态），
所以"挪一下"必然溢出。

正确做法不是继续挪，而是 **缩字号让它回到框内**：

```python
def shrink(shape, factor):           # factor 0.7~0.8
    for p in shape.text_frame.paragraphs:
        for r in p.runs:
            if r.font.size:
                r.font.size = Pt(max(8, round(r.font.size.pt * factor, 1)))
```

挪框（改 top/height）和缩字号**二选一，别叠加**——叠加两轮后必然互相打脸。

### 6c. 视频页：标题框会被视频区吞掉

外部 deck 的视频页标题框 `top` 常在 3.8cm 左右，正好落在"视频上沿"里。
塞完视频先检查：**kicker（`视频 ① · 约 1 分 10 秒`）和标题要一起上移到 1.1/1.9cm**，
视频从 5.0cm 起，宽度按页宽减两边距算（16:9），否则只露"城墙"两个字。

### 6d. 交付前的目视验收顺序

1. 重新 `Export` PNG（别复用旧目录，新建 `_previewN`）
2. 逐张 `vision_analyze` 问**具体问题**：「X 段文字完整吗」「有重叠吗」「比例正常吗」
3. **别拿 14 页拼的小缩略图问 vision** —— 图太小页码会错位，
   本会话总览图把"秦岭"页说成第 10 页、把视频页说成第 5 页，全是幻觉。
   缩略图只用来给用户看，**判断必须逐页大图**
4. 拼版给用户时保留原始 PNG 路径，缩略图看不清要能点开大图

## 7. 顺手记：360 会弹验证码

子代理并发大量搜索后，`so.com` 会跳 `qcaptcha.so.com`
「同IP短时间内大量发送请求」。这不是被封，**等一会儿或换直连官网**即可。
所以「主 agent 查证 + 子代理找图」这种并行会互相踩，宁可串行。
