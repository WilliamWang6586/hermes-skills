# animations.json 动效 sidecar：实测结论（含未解决问题）

2026-09 实测。**读这一页能省掉 4 轮白试。** 本文件记录「什么确定有效、什么没试出来」，
不美化结论。

## 结论先行

| 动效层次 | 状态 | 证据 |
|---|---|---|
| **页面转场** | ✅ **完全有效**，每页可不同效果 + 各自时长 | 导出 PPTX 里 `p:transition` 带 `p14:dur`，10 种不同效果全部落盘 |
| **对象级动画（每块不同效果）** | ❌ **未跑通**，一律退化成 `entrance_fade` | 试了 4 轮，PPTX 里 `filter=` 只出现 `fade` |

**影响可控**：转场贡献了"华丽"的主要观感；对象动画统一淡入属于端庄不炫。
**但不要对用户承诺"逐条飞入"**——做不到就说做不到。

## 确定有效：转场

`animations.json` 顶层 + 每页 `transition` 块。**必须带 `"version": 1`**：

```json
{
  "version": 1,
  "defaults": {
    "transition": { "effect": "fade", "duration": 0.4, "sound": null }
  },
  "slides": {
    "01_cover": { "transition": { "effect": "drape", "duration": 0.9 } },
    "06_roles": { "transition": { "effect": "gallery", "duration": 0.8 } }
  }
}
```

验证（**唯一可信的验证方式是解包 PPTX 看 XML**，不是看 `validate` 通过）：

```python
import zipfile, re, collections, glob, os
f = sorted(glob.glob(P + r"\exports\*.pptx"), key=os.path.getmtime)[-1]
z = zipfile.ZipFile(f)
allf = collections.Counter()
for i in range(1, 12):
    x = z.read(f"ppt/slides/slide{i}.xml").decode("utf-8", "ignore")
    print(i, collections.Counter(re.findall(r'filter="([a-zA-Z0-9_]+)"', x)))
    allf.update(re.findall(r'filter="([a-zA-Z0-9_]+)"', x))
print(allf.most_common())          # 只出 fade → 对象动画没生效
```

转场用 `<p:transition ... p14:dur="900">`，`p14:dur` 是**毫秒**（sidecar 里写**秒** 0.9）。

### ⚠️ 读转场的两个陷阱（会误报"转场丢了"）

**陷阱 1：效果名在子元素里，不在 `<p:transition>` 开标签上。**
只 grep `r'<p:transition[^>]*'` 会把 push/cover/wipe/split/prism/gallery **全部折叠成同一个 key**，
看起来像"只剩 1 种转场"。正确读法是取 **`<p:transition>` 的第一个子元素**：

```python
def transition_key(x):
    m = re.search(r"<p:transition\b.*?</p:transition>|<p:transition\b[^>]*/>", x, re.S)
    if not m:
        return None
    kids = [k for k in re.findall(r"<((?:p|p14):\w+)\b", m.group(0)) if k != "p:transition"]
    return kids[0] if kids else "(p14-bare)"     # 部分效果无子元素，只能看 dur
```

本会话 10 页设了 8 种不同转场，**旧脚本判定"只有 4 种"→ 差点误报失败**；
用新读法得到 8 个不同 key，实际全部生效。

**陷阱 2：sidecar 效果名 ≠ OOXML 序列化名。** 已知映射：

| sidecar `transition.effect` | PPTX 里实际出现的元素 |
|---|---|
| `cube` | `p14:prism` |
| `drape` / `peel_off` | 无子元素的裸 `<p:transition>`（只能靠 `p14:dur` 区分） |
| `cover` / `push` / `wipe` / `split` / `dissolve` | 同名子元素 `p:cover` / `p:push` / … |
| `gallery` | `p14:gallery` |

**所以验证转场时不要断言"元素名 == sidecar 名"**，只断言
**「`distinct key 数 >= 5`」+「每页都有 `<p:transition`」+「`p14:dur` 各不相同」**。
`p14:dur` 是**逐页独立写入**的，是最可靠的存在性证据。

## ⚠️ 字段单位坑（会静默毁掉配置）

| 字段 | sidecar 单位 | 实际落盘 |
|---|---|---|
| `transition.duration` / `duration` | **秒**（0.9） | `p14:dur="900"` 毫秒 |
| `effects[].trigger` | `after-previous` / `with-previous` / `on-click` | — |

**写错会静默失效**，不报错。第一版我全写成毫秒（900），`validate` 照样通过。

## ⚠️ 字段名：`trigger` 不是 `start`

`effects[]` 行里触发方式字段是 **`trigger`**。写 `start` 会让 `animation_config.py validate` 报
一大片 `unknown field: start`：

```
Error: animations.json slides["08_x"].groups["page-title"].effects[0] has unknown field: start
```

## 没跑通的：对象级 `groups.effects[]`

写了 46 行、`validate` 通过、`list-groups` 也确认组 id 可动画，**但导出后全是 fade**。

已排除的可能（都实测过）：

| 试过的假设 | 结果 |
|---|---|
| 缺 `order` 字段 → 补上 46 行 | ❌ 仍全 fade |
| 缺 `"version": 1` → 按官方 scaffold 重建 | ❌ 仍全 fade |
| 缺 slide 级 `animation` 块 → 11 页都补上 | ❌ 仍全 fade |
| slide 级设 `animation.effect: "none"`（scaffold 默认） | ❌ **更差**：动画行从 27 掉到 15，3 页彻底没动画 |
| 组 id 不对 | ❌ 排除：`list-groups` 明确列出这些 id 可动画 |

从源码读到的事实（`builder.py`）：
- `groups_value = slide_cfg.get('groups', {})` —— 读的就是我们的结构，正确
- 对象动画写入条件：`not animation_hard_disabled and (slide_animation or explicit_animation_groups) and anim_targets`
- `anim_targets` 是**函数参数**（由上层传入），不是在这里生成 —— **嫌疑最大，没继续追**

**未验证的下一步**（下次可从这继续，别再从零试）：
```powershell
# 1) 用官方 scaffold 作基准，只改一个组，隔离最小可复现
python3.14 $SK\scripts\animation_config.py scaffold $P --force
# 2) 只保留一页一个组，写 effects[]，其余页删掉
# 3) 导出后解包看该组是否出现非 fade filter
# 4) 如果单组能生效 → 是规模/继承问题；如果单组也不生效 → anim_targets 没收录这些组
```

## 回退策略（重要）

对象动画试不通时，**不要再往"更精细"方向调**（本会话第 3 轮就是这样把 27 行搞成 15 行）。
正确做法：**退回到"每页 uniform fade + 保留全部多样转场"的已知good状态**。

```python
# 恢复：version:1 + slide 级 entrance_fade（每页都有完整对象 build）
d["defaults"]["animation"] = {"effect": "entrance_fade", "duration": 0.4,
                              "stagger": 0.5, "trigger": "after-previous"}
for s in d["slides"].values():
    s["animation"] = dict(d["defaults"]["animation"])
# 断言：转场多样性没被压平
assert len({v["transition"]["effect"] for v in d["slides"].values()}) >= 5
```

**原则**：动效的"华丽"由**转场**承担；对象动画失败不要连累转场。

## 官方示例形状（照抄这个，别自己发明）

`references/animations.md` §2 给的稀疏 sidecar（**没有 slide 级 `animation` 块**）：

```json
{
  "version": 1,
  "slides": {
    "03_threshold": {
      "groups": {
        "risk-marker": {
          "effects": [
            { "effect": "entrance_fade", "order": 1, "duration": 0.25 },
            { "effect": "path_right", "effect_options": { "relative": true }, "order": 2, "duration": 0.7 }
          ]
        }
      }
    }
  }
}
```

scaffold 生成的形状：`animation.effect: "none"` + `groups.<id>: {}` 空占位。
**两者都没能让我这册的对象动画生效** —— 问题不在形状。

## 命名空间与 chrome 排除

`animation_config.py list-groups <P>` 输出每页可动画组 + chrome 名单：

```
02_responsibility: archive-band, page-title, row-1, row-2, row-3, row-4
                   [chrome, animates only when named: table-header, page-number]
```

chrome 判定：id 含 `bg/background/header/footer/decor/decoration/chrome/nav/watermark/logo/`
`pagenumber/pagenum/slidenumber/slidenum/rule` 任一 token（`-`/`_` 分隔）。
命名空间**不要用 `xxx-rule`、`xxx-header`** 这类词给内容块命名，会被当装饰排除。

## 效果名（203 个，常用）

转场：`drape` `cube` `dissolve` `gallery` `peel_off` `checkerboard` `split` `cover` `push` `wipe`
`morph` `fade` `blinds` `clock` `ripple` `honeycomb` `glitter` `vortex` `flip` `doors` `box` `comb`

对象（entrance 系列）：`entrance_fade` `entrance_fly` `entrance_wipe` `entrance_zoom`
`entrance_rise_up` `entrance_dissolve` `entrance_bounce` `entrance_float` `entrance_unfold`
强调：`emphasis_grow_shrink` `emphasis_shimmer` `emphasis_teeter`

查全部：`python3.14 $SK\scripts\pptx_animations.py --list`
查参数：`python3.14 $SK\scripts\pptx_animations.py --describe <effect>`

## 每次改完 sidecar 的固定流程

```powershell
python3.14 $SK\scripts\animation_config.py validate $P      # 只保证语法
python3.14 $SK\scripts\svg_to_pptx.py $P                    # 重新导出
# 然后必须解包 PPTX 核对 filter= / p:transition，不要只看 POSTFLIGHT status=passed
```

**`validate` 通过 + `POSTFLIGHT status=passed` ≠ 动效生效。** 本会话 4 个版本全部
`validate` 通过、`status=passed`，而对象动画全是 fade。**只有解包看 XML 是可信的。**

---

# 没有 SVG 源时：直接给现有 .pptx 写转场（实测有效）

用户拿一份别人做的 / 自己手改过的 .pptx 说「每页之间加动画过渡，高级一点」时，
**不走 ppt-master 的 sidecar**，直接改 zip 内每个 `ppt/slides/slideN.xml`。

## 写入 morph（平滑切换）

`p:transition` 必须放在 `<p:cSld>`/`<p:clrMapOvr>` **之后、`<p:timing>` 之前**，
否则 PowerPoint 报文件损坏。morph 子元素在 p159 命名空间，还必须带空的可选 `p14:animBg`：

```python
import zipfile, shutil, re
from lxml import etree

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'p14': 'http://schemas.microsoft.com/office/powerpoint/2010/main',
      'p159': 'http://schemas.microsoft.com/office/powerpoint/2015/09/main'}

MORPH = ('<p:transition xmlns:p="%(p)s" xmlns:p14="%(p14)s" xmlns:p159="%(p159)s" '
         'spd="slow" dur="%(dur)d"><p159:morph option="byObject"/><p14:animBg/></p:transition>')
FADE  = '<p:transition xmlns:p="%(p)s" spd="med" dur="%(dur)d"><p:fade/></p:transition>'

root = etree.fromstring(orig_xml)
for el in root.findall('{%s}transition' % NS['p']):      # 先清掉旧的
    root.remove(el)
frag = etree.fromstring(xml)
timing = root.find('{%s}timing' % NS['p'])
(timing.addprevious if timing is not None else root.append)(frag)
```

`option="byObject"` 让同名对象之间位移；还有 `byWord` / `byChar`（只对文字生效）。

## ⚠️ `dur` 属性常被忽略 → 时长必须用 COM 兜底

手写 `dur="900"` + `spd="slow"` 后，COM 读回来是 **1.00s**，不是你写的 0.9。
**时长以 COM 为准**，写完再开一次由 PowerPoint 自己落盘：

```python
app = win32com.client.Dispatch('PowerPoint.Application')
p = app.Presentations.Open(os.path.abspath(f), WithWindow=False)
for i in range(1, p.Slides.Count + 1):
    t = p.Slides(i).SlideShowTransition
    t.Duration = 0.7 if t.EntryEffect == 3849 else 0.9    # 3849=fade, 3954=morph
p.Save(); p.Close(); app.Quit()
```

**效果 ID 对照（读回来验证用）**：`3954` = Morph 平滑，`3849` = Fade 淡化。
`ppEffectMorphByObject` 这类枚举名在 `win32com.constants` 里**不存在**，别去 getattr 查。

## 验收：COM 逐页读回 + 断言

```python
t = p.Slides(i).SlideShowTransition
assert round(t.Duration, 2) == want, (i, t.EntryEffect, t.Duration)
```

能打开 + 页码数对 + `EntryEffect`/`Duration` 全对 = 转场真生效。
**不要用截图验收**——转场是动态的，PNG 导出的静态图看不出来。

## 效果搭配（本会话定稿，中文汇报场景）

| 页型 | 效果 | 时长 |
|---|---|---|
| 满版大图页、章节页、同类版式相邻 | morph | 0.9s |
| 视频页进出（画面在动） | fade | 0.7s |
| 收尾、附页 | fade | 0.5–0.9s |

- **视频页必须 fade**：morph 会让动态画面同时位移，观感发晕。
- morph 出彩的前提是**相邻页有同名/同位元素**（相同版式的文字块、编号）。全册版式越统一，
  morph 越像剪片；版式各页不同时，它退化成\"整页推\"，和普通切换差不多。
- 别超 1.2s，讲到后面会嫌慢。

## 兼容性风险（必须告知用户）

morph 需要 **PowerPoint 2019+ / Microsoft 365**。WPS 或旧版 PowerPoint 会降级成淡入，
**不会报错**，只是没那么好看。要拿教室电脑放映时提前提醒用户先试一次。
