# SVG 页面编写：质检器硬规则与一次成型模板

`svg_quality_checker.py` 是 ppt-master 的强制门（早期门 + 最终门），**报错会直接阻塞导出**。
本文件是 2026-09 实测把 11 个阻塞错误收敛到 0 的完整规则集。

**为什么必须一次到位**：早期门（第 5 页后）的作用就是「抓方法级偏差」——同一个错误会在
后面的每一页复制。本会话 4 页报 11 错，逐条修完后 **0 错**，后面 7 页直接套标准不返工。
所以**先画 4-5 页跑早期门，把方法修对，再往下画**，不要一口气画完 11 页再质检。

## 一次成型的页头模板（直接复制）

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720"
     font-family="Microsoft YaHei, Arial, sans-serif"
     data-pptx-page-role="content">
  <title>页面名</title>
  <desc>版式说明</desc>

  <rect id="page-bg" data-pptx-role="background" x="0" y="0" width="1280" height="720" fill="#FAF8F5"/>

  <!-- 全屏框线：直挂 rect + decoration 角色，绝不包 <g> -->
  <rect id="frame-outer" data-pptx-role="decoration" x="56" y="56" width="1168" height="608"
        fill="none" stroke="#D8D2C8" stroke-width="1"/>

  <!-- 每个内容块：唯一 id + name + bounds，bounds 互不重叠 -->
  <g id="archive-band" data-pptx-name="archive-band" data-pptx-bounds="80 74 1120 46">
    <text x="88" y="96" font-size="15" fill="#8B6914">档案 001</text>
    <line x1="88" y1="110" x2="1192" y2="110" stroke="#1A2332" stroke-width="1"/>
  </g>

  <g id="content-main" data-pptx-name="content-main" data-pptx-bounds="80 150 1104 500">
    <text x="88" y="196" font-family="SimSun, Times New Roman, serif" font-size="42" fill="#1A2332">页面标题</text>
  </g>
</svg>
```

`data-pptx-page-role` 取值：`cover` / `toc` / `section` / `content` / `ending`（每页恰好一个）。

## 六条硬规则

### 1. bounds 必须互不重叠

```
[ERROR] <g id="A"> data-pptx-bounds overlaps <g id="B"> data-pptx-bounds by Xpx x Ypx
```

根级 `<g>` 的 bounds 是「模块区」，**彼此不能重叠**（容差 1px）。

- 全屏装饰框若包在 `<g>` 里，它的 bounds 会覆盖整个画布 → 与所有块重叠。
  **拆成直挂 `<rect>` + `data-pptx-role="decoration"`**，不要包 `<g>`。
  同理整页底图用 `<rect data-pptx-role="background">` 直挂。
- 相邻块的 bounds 要留缝。`bounds_y + bounds_h ≤ 下一块 bounds_y`。

**测算法**：块的实际渲染范围比字面 y 高。**无 transform 的 line/text 垂直占位 = `y − 0.85×font_size` 到 `y + 0.35×font_size`**。

```
字号 42 的文本在 y=170  →  上沿 170 − 35.7 = 134.3
放它的块必须 bounds_y ≤ 134，否则报「exceeds bounds on the vertical axis」
```

### 1b. 块间「差几个像素」的重叠：一次性对齐像素等级

本会话删页重排后，相邻块下沿/上沿只差 **2px、4px、12px** 就报重叠。**逐条试错极费事**——
正确做法是**把所有相邻块对齐到同一个像素等级**，一次改完：

```
① 先算出每块「内容实际底 = 最后一行 baseline + 0.35×字号」
② 让块 bounds 底 = 下一个块的 bounds 顶（留 1-2px 缝）
③ 一页里所有相邻边界用同一套数值，别一块一块凑
```

```xml
<!-- ✗ 差 2px：title 底 414，content 顶 412 → 报重叠 1120x2 -->
<g id="page-title"    data-pptx-bounds="80 296 1120 118"/>   <!-- 底 414 -->
<g id="content-main"  data-pptx-bounds="80 412 1120 240"/>   <!-- 顶 412 -->

<!-- ✓ title 收到 114 → 底 410，留 2px 缝 -->
<g id="page-title"    data-pptx-bounds="80 296 1120 114"/>
<g id="content-main"  data-pptx-bounds="80 412 1120 240"/>
```

**同理「内容超出 bounds 5.5%」这类差 3px 的错**：直接给 bounds 加高 6px
（如 60→66），别去动文本位置——动文本会连锁引发别的重叠。
`5.5%` 只比阈值 `5%` 超一点点，说明**只差几个像素**，不是你算错了方向。

**判断超限是「差一点」还是「差很多」**：看报错里的百分比。
个位数百分比 = 加几像素就过；两位数 = bounds 结构写错了，要重排。

### 2. bounds 必须包住实际内容（含余量）

```
[ERROR] <text> (x=88, y=170; ...) exceeds <g id="page-title"> data-pptx-bounds
        on the vertical axis: content (88.0, 134.3)-(699.5, 184.7),
        container (80.0, 140.0)-(1200.0, 220.0), overflow vertical 7.1% (error above 5%)
```

超限 **> 5% 报 ERROR，≤5% 报 WARN**。报错信息里直接给了 `content (x1,y1)-(x2,y2)` 与
`container (...)`，**照抄数值改 bounds 即可**，不用猜。

* 垂直：顶部留 `0.85×字号`，底部留 `0.35×字号`
* 水平：用标定表算宽度，见第 4 条。报错会提示 `≈N px per char at Spx; ≈M chars fit in Wpx`

### 3. 禁用内嵌 `<tspan>` 做行内上色

```
[ERROR] Unsupported visual SVG element(s) for native PPTX export: /svg[8]/g[2]/text[1]/span
```

技能文档（`executor-base.md`）**说** `<text>` 内嵌 `<tspan>` 是支持的行内强调，
但**实测质检器判阻塞**（PPTX 原生导出不支持）。

**做法**：拆成同 baseline 的多个独立 `<text>`，按宽度手工定位 x：

```xml
<!-- ✗ 报错 -->
<text x="88" y="564" font-size="26" fill="#2B2B2B">我是来交一份<span fill="#C41E3A">已经做过的事</span>的答卷。</text>

<!-- ✓ 拆三段，y 相同 -->
<text x="88"  y="564" font-size="26" fill="#2B2B2B">我是来交一份</text>
<text x="244" y="564" font-size="26" fill="#C41E3A">已经做过的事</text>
<text x="400" y="564" font-size="26" fill="#2B2B2B">的答卷。</text>
```

x 位置 = 前段起点 + 前段字数 ÷ 该字号 chars-per-100px × 100。拆完记得**加进某块的 bounds**。

### 4. 字号必须命中已声明角色

```
[ERROR] spec_lock typography-size recurrence: undeclared font-size 22 (3 occurrences),
        23 (6 occurrences) exceeds the sparse-display limit of 2 occurrences.
```

- 所有结构性文字必须映射到 `spec_lock.md typography` 里**已声明的角色**，允许 `±2px`。
- **未声明字号全册最多出现 2 次**（稀疏显示例外），第 3 次即报 ERROR。
- 所以：画页前先在 lock 里把要用的字号**全部声明成具名角色**。本会话补了：

```markdown
- body: 26          # 主正文
- body_sm: 23       # 分栏正文
- annotation: 22    # 紧凑条目
- annotation_sm: 18 # 小字注释
- display: 96       # 编号大数字
- display_lg: 180   # 超大编号
- display_md: 38    # 页内二级标题
- cover_title: 72   # 封面巨字
- title: 42
- subtitle: 32
- lead: 30
- footnote: 15
```

**先声明再画** = 后面所有页直接按声明值写，永不返工。

### 5. 根 `<svg>` 设默认字体

```
[WARN] Noncanonical compact authoring: Visible text requires one direct root font-family default
```

根 `<svg>` 上加 `font-family="..."`，子元素**只写覆盖**（宋体标题才写 `font-family`，
雅黑正文不写）。这是 WARN 不是 ERROR，但一次做对能少 20+ 条警告。

### 6. 视觉根组必须有 `id`

```
[WARN] Top-level visible <g> #2 has no id; object-level animation config cannot reference it
```

每个 `data-pptx-name` 的根 `<g>` **必须带唯一 `id`**。

**⚠️ 但 `id` 是必要不充分条件**：2026-09 实测，11 页全部组都补了唯一 `id`、`list-groups`
也确认这些 id 可动画，**对象级动画仍然全是 fade**。别以为加了 id "华丽动效"就做出来了——
见 `animations-sidecar-findings.md`。**用户要动效，靠转场兑现，对象动画先做后验。**

## 字号标定表（画页前必跑）

```powershell
python3.14 $SK\scripts\text_measure.py calibrate $P --outline
# 输出写到 $P\validation\text_calibration.json
```

`ppt169` + 正文 26px 实测样例：

| 角色 | 字号 | CJK chars/100px | Latin chars/100px | 说明 |
|---|---:|---:|---:|---|
| body | 26 | 3.6 | 7.5 | **1104px 宽 → 每行 ≈39 个中文字** |
| title | 42 | 2.1 | 4.2 | 标题超 30 字就要拆行 |
| subtitle | 32 | 2.8 | 5.6 | |
| annotation | 22 | 4.2 | 8.4 | |
| footnote | 15 | 6.3 | 13.0 | |

**宽度推算**：`宽度 px = (CJK字数 ÷ CJK费率 + 其他字符数 ÷ Latin费率) × 100`。
混合串两部分相加；数字用 DIGITS 费率、全大写用 CAPS 费率。
**留 5% 余量**（费率是样本均值，质检器逐字形实测）。

文本放不下时的处理**顺序**：先扩块（用闲置空间）→ 再重排/改写法（长句→分行）→ **最后才删限定词**。
**永远不要靠缩小字号来塞内容**，也不要为了塞进框而砍掉信息。

## 报错精确定位（别逐条猜）

`--json` 会把完整报告写到 `validation/svg_quality_early_report.json`（早期门）或
`svg_quality_report.json`（最终门）。stdout 是给人看的，**不要解析 stdout**。

只取阻塞项，一条命令看完：

```powershell
python3.14 -c "
import json,io
d=json.load(io.open(r'$P\validation\svg_quality_early_report.json',encoding='utf-8'))
for c in d.get('categories',{}).get('blocking',{}).get('issues',[]):
    print('*', c.get('file')); print('  ', str(c.get('message'))[:340]); print()
"
```

## 迭代收敛记录（本会话实测，可作预期参考）

| 轮次 | 阻塞错误 | 修了什么 |
|---|---:|---|
| 1 | 3 | `<tspan>` 上色 ×2；字号 22/23 未声明 |
| 2 | 11 | 加 bounds 后暴露：全屏框与全部块重叠 ×6；bounds 高度不足 ×3；块间重叠 ×1；文字超宽 ×1 |
| 3 | 4 | 全屏框改 decoration；标题块加高；编号块加宽；正文右移避让 |
| 4 | 3 | 全屏框改**直挂 rect**（包 `<g>` 仍报错）；标题块收窄避让图标块；图标块文字缩短 |
| 5 | **0** | ✅ 早期门通过 |

**教训**：加 bounds 会让原本"看起来没问题"的页暴露出所有重叠/超限问题。
**第一轮就把 bounds 写对**（按第 1、2 条预留 `0.85×字号` 上沿 + 块间留缝），能省掉第 2-4 轮。

## 命令速查

```powershell
$SK = "...\skills\ppt-master"
$P  = "...\hermes-home\projects\<name>_<YYYYMMDD>"   # 带日期后缀！

# 校验项目结构 + lock 语法（画页前跑）
python3.14 $SK\scripts\project_manager.py validate $P

# 同步图标（画页前，缺失即 ERROR）
python3.14 $SK\scripts\icon_sync.py $P tabler-outline/folder tabler-outline/database ...

# 字号标定（画页前）
python3.14 $SK\scripts\text_measure.py calibrate $P --outline

# 早期门（第 5 页后，只画了 ≤5 页时跳过）
python3.14 $SK\scripts\svg_quality_checker.py $P --canonical-authoring --stage early --json

# 最终门（全部页画完后）
python3.14 $SK\scripts\svg_quality_checker.py $P --canonical-authoring --stage final --json
```

`--json` **必须加**——不加导出会被拒（exporter 要匹配的 final 报告）。
