# PDF 抽文本 & 管道理编码坑（实测）

## 1. 症状：`read_file` 一个 PDF 只看到二进制

PDF 内容流是 Flate 压缩的，`read_file` 会输出 `%PDF-1.7` + 一堆 `x��Z۪...` 乱码，
并在 100KB 处截断。**这不是文件损坏**，是需要解压。

## 2. 首选：用 ppt-master 自带转换器

```powershell
$SK = "...\skills\ppt-master"
python3.14 $SK\scripts\source_to_md.py <file.pdf> -o $P\sources
# 产物：<stem>.md + <stem>.conversion_profile.json（sidecar）
```

优点：产出 Markdown（保留标题层级、表格）+ sidecar 供 `import-sources` 识别，
且**避免重复转换**（md 与原件同时传入时自动跳过）。
缺点：要装 PyMuPDF（AGPL-3.0）。

## 3. 备选：PyMuPDF 直抽（只想要文本、不想落文件时）

```powershell
python3.14 -c "
import fitz, sys
sys.stdout.reconfigure(encoding='utf-8')   # ← 必须，否则中文 print 崩
d = fitz.open(r'D:\path\file.pdf')
print('pages:', d.page_count)
for i,p in enumerate(d):
    print(f'===== PAGE {i+1} =====')
    print(p.get_text().strip())
"
```

关键点：

- **`sys.stdout.reconfigure(encoding='utf-8')` 不能省**——Windows 终端默认 GBK，
  中文/emoji `print` 会 `UnicodeEncodeError` 或输出乱码。
- 路径用 `r'...'` 原始字符串。在 PS 里**别把 `r'D:\...'` 塞进双引号内联脚本**，
  反斜杠会被 PS 吃掉 → 报找不到文件。要么整段用单引号，要么写进 `.py` 用 `write_file`。
- 页面分隔符用 `===== PAGE n =====`，方便后续按页引用（做 PPT 时"第几页说了什么"很常用）。

## 4. 管道理编码坑（PowerShell ↔ Python）

| 症状 | 原因 | 修法 |
|---|---|---|
| `json.load` 报 `Unexpected UTF-8 BOM` | PS 管道/重定向中转后带了 BOM | 读时用 `encoding='utf-8-sig'` |
| `UnicodeDecodeError: invalid start byte 0xff`（位置 0） | `*>` 重定向把输出转成了 **UTF-16**(LE, 带 BOM) | 用工具自带的 `--output` 参数；万一手上有 UTF-16 残留，读时 `encoding='utf-16'` |
| `NativeCommandError` 但内容看起来正常 | **python 的 stderr 经 PS 会被包成错误**，`[OK]`/`note:` 都在 stderr 上 | 别只看 `exit_code`，**看输出内容判断**是否真失败 |
| 中文 print 崩 / 乱码 | PS 控制台是 GBK | `python -c` 里先 `sys.stdout.reconfigure(encoding='utf-8')`；或设 `$env:PYTHONUTF8=1` |
| 传中文参数给 python 时被吞字符 | PS 调 python 的编码转换 | 见 `windows-wsl2-script-exec` 技能（有完整细节） |

## 5. 铁律

改 `.py` / `.md` 脚本**只用 `patch` / `write_file`**。
**禁用 `Get-Content` / `Set-Content`** ——它们会按 GBK 解码 UTF-8 再写回，
对含中文的脚本是**不可逆损毁**。
