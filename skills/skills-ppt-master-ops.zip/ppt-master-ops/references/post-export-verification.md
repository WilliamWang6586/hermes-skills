# 导出后验证：别让自己的断言说谎

2026-09 实测。本会话为了验证「页码跟随页序」这件事，我的核验脚本报了 **6 次 FAIL，其中 5 次是脚本自己的 bug**，
每次都让我回头怀疑文件错了、去改本来正确的产物。**验证脚本必须先被验证。**

核心原则：**先确认脚本量到的是"文件真的错了"，还是"我的正则/断言写错了"。**
判据很简单 —— **把量到的原始值打印出来**，肉眼对一遍再决定动不动文件。

---

## 一、最省事的排错动作：先 dump 原始文本

不要一上来就写断言。**先看文件里到底有什么**：

```python
# dump_text.py —— 逐页打印所有可见文本 + 字号
import xml.etree.ElementTree as ET, os
for f in sorted(os.listdir(SVG)):
    if not f.endswith(".svg"):
        continue
    print(f"\n===== {f} =====")
    for el in ET.parse(os.path.join(SVG, f)).getroot().iter():
        if el.tag.endswith("text"):
            t = "".join(el.itertext()).strip()
            if t:
                print(f"  [{el.get('font-size','?'):>3}] {t}")
```

> ⚠️ `el.itertext()` 返回**迭代器**不是字符串元组。
> `"".join(e.itertext() for e in root.iter() if ...)` 会 `TypeError: sequence item 0:
> expected str instance, _elementtree._element_iterator found`。
> 正确写法：`"".join(el.itertext())`（对单个元素调用）。

这个 dump 一步就定位了本会话的真相：**SVG 里的页码其实全对**，错的是我导出后没重导。

---

## 二、五个真实踩过的假警报

### 1. PowerShell 正则吃内容 → 用 Python 打印

```powershell
# ✗ 输出全是空行，看不出内容
Select-String -Path "$P\*.svg" -Pattern "<text" | ForEach-Object { $_.Line.Trim() -replace '.*>','' }
```

PS 的 `-replace` + 引号嵌套很容易把捕获组搞丢。**看内容一律用 Python 脚本文件**
（`write_file` 落盘再跑），不要塞进 `python3.14 -c "..."`——PS 会把内层双引号转义掉，
报 `SyntaxError: unterminated string literal`。

### 2. 只读 `<p:transition` 开标签 → 转场全被算成同一种

```python
# ✗ 8 种转场被算成 4 种/1 种
set(re.search(r'<p:transition[^>]*', x).group(0) for x in slides)
```

**原因**：效果名在**子元素**里，不在开标签上；且 `p14:` 命名空间的效果（drape / peel_off）
压根**没有子元素**，是 `p14:dur` 属性形态。

```python
# ✓ 读整个 p:transition 块，取第一个子元素名
def transition_key(x):
    m = re.search(r"<p:transition\b.*?</p:transition>|<p:transition\b[^>]*/>", x, re.S)
    if not m:
        return None
    k = [e for e in re.findall(r"<((?:p|p14):\w+)\b", m.group(0)) if e != "p:transition"]
    return k[0] if k else "(p14-bare)"
```

实测结果：`{p14-bare, p14:gallery, p14:prism, p:cover, p:dissolve, p:push, p:split, p:wipe}`
= 8 种，**转场本来就是好的**。`cube` 序列化后的名字是 **`p14:prism`**。

### 3. `ARCHIVE 001 / 010` 被页码正则抢先匹配

文本 `ARCHIVE 001 / 010` 里**含子串 `01 / 010`**，所以裸正则 `(\d{2})\s*/\s*(\d{2,3})`
会把封面读成页码 `01 / 010`。

```python
# ✓ 取最后一个匹配（页码框在阅读顺序上总在编号条之后）
marks = re.findall(r"(\d{2,3})\s*/\s*(\d{2,3})", joined)
label = f"{marks[-1][0]} / {marks[-1][1]}" if marks else "-"
```

反面教材：`(?<!ARCHIVE )` 这种负向后顾**更糟**——它会把正常的 `05 / 10` 一起挡掉。

### 4. 三格式标签 `.lstrip("0")` 断言写错

封面用 3 位 `001`、正文用 2 位 `02`。断言写成 `label == f"{idx:02d}"` 时，
`"001".lstrip("0")` = `"1"` ≠ `"01"`。
**比较用整数**：`int(label) == idx`。

### 5. 跨段正则把别的段吃进来

`re.findall(r"- P(\d{2}): (\w+)", spec_lock)` 会把 `page_visualizations` 段的
`- P05: none` 也算进来 → 报"11 行，P05 重复"。
**先切段再匹配**：

```python
sec = re.search(r"## page_rhythm\n(.*?)(?=\n## )", lock, re.S).group(1)
rhythm = re.findall(r"- P(\d{2}): (\w+)", sec)
```

---

## 三、验证脚本的固定骨架

```python
fails = []
def ck(label, cond, detail=""):
    print(("  OK   " if cond else "  FAIL ") + label + (f"  [{detail}]" if detail else ""))
    if not cond:
        fails.append(label)

# ...检查项，每项都把量到的值放进 detail...

if fails:
    print(f"RESULT: {len(fails)} FAILURE(S)")
    for f in fails: print("  -", f)
    raise SystemExit(1)          # 非 0 退出码，能被调用方看见
print("RESULT: ad-hoc verification passed")
```

**必带 detail**：每个 `ck()` 都把**实测值**打出来。
本会话 5 个假警报全靠 detail 里的 `[got '010' vs '10']` 一眼看穿是断言问题。

---

## 四、验证边界：ad-hoc 脚本 ≠ 测试套件

- ppt-master 项目目录**没有 test / lint / build 命令**。核验脚本是**一次性的 ad-hoc 探针**，
  **不要说成"测试通过"**。
- 说清它**证明什么**（文件结构、嵌入的媒体、序列化后的 XML 事实）与
  **证明不了什么**（放映观感：字体渲染、照片裁切、动效是否顺滑——只能靠用户 F5 看）。
- 用户明确表达过这类区分（"这属于视觉创作工作，测试该压后；但产物完整性该验"）。

## 五、临时脚本用完就删

```powershell
Remove-Item "$env:TEMP\hermes-verify-*.py" -Force -ErrorAction SilentlyContinue
$left = Get-ChildItem "$env:TEMP\hermes-*.py" -ErrorAction SilentlyContinue
if($left){ $left.Name } else { "cleaned" }
```

## 六、交付文件被占用

拷到交付目录时若用户**正开着那个 PPT**，`Copy-Item` 报
`PermissionError: [Errno 13] Permission denied`。
**别重试同一个目标名**——那是 PowerPoint 的文件锁，直接换个文件名交付
（`_v2` / `_v3`），并在回复里说明旧文件可删。
