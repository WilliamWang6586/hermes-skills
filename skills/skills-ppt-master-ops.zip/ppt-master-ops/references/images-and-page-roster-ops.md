# 把用户照片放进 PPT：三条必过的门

2026-09 实测（竞选 PPT 加 5 张用户照片）。加图不是"写个 `<image>` 就行"——**质检器有三条独立契约，
各自会报一个看起来完全无关的错**。三条全过才算通。

## 快速通关模板

**SVG（`svg_output/NN_x.svg`）** —— href **相对 SVG 自己**：

```xml
<defs>
  <clipPath id="photoClip"><rect x="88" y="196" width="536" height="324"/></clipPath>
</defs>
<image x="88" y="196" width="536" height="324"
       preserveAspectRatio="xMidYMid slice"
       clip-path="url(#photoClip)"
       href="../images/photo.jpg"/>
```

**`spec_lock.md`** —— 必须是 `- key: value`（**冒号**）：

```markdown
## images
- photo.jpg: images/photo.jpg | source=user | crop=adaptive
```

**`design_spec.md` §VIII** —— `Status` 用合法枚举值：

```markdown
| images/photo.jpg | 1900x1267 | 1.50 | 封面人像 | photo | framed-pair | adaptive | user | existing | 用户提供 人像.JPG | none | decoration |
```

## 三条契约（报错 → 真因）

### 1. `invalid image source: External image not found: images/x.jpg`

**真因**：`elements.py::_resolve_external_image` 的注释写得非常明确——

> The href is interpreted **exactly relative to the owning SVG** and must remain
> inside the project. **No root, `images/`, or template-path guessing occurs.**

SVG 住在 `svg_output/`，所以 `images/x.jpg` 被解析成 `svg_output/images/x.jpg` → 不存在。
**正确写法 `../images/x.jpg`**。

### 2. `design_spec.md 里有这一行，但 spec_lock.md images 里找不到`

**真因**：`spec_lock.md` 的解析器 `_MARKDOWN_DATA_LINE_RE` 要求 **`- key: value`（冒号）**：

```python
r"^[ \t]*-[ \t]+(?:\*\*)?([^:\n*]+?)(?:\*\*)?[ \t]*:[ \t]*(.*)$"
```

写成 `- images/x.jpg | source=user | crop=adaptive`（竖线开头、无冒号）→ **整段 fields 解析出 0 行**，
静默失效。加冒号前缀后正常：

```
- photo.jpg: images/photo.jpg | source=user | crop=adaptive
                 ↑ 冒号隔开 key 和 value
```

自查命令（不跑质检器，直接问解析器）：

```python
import sys; sys.path.insert(0, r"<SK>\scripts")
from pathlib import Path
from project_management.project_specs import parse_markdown_artifact, parse_spec_lock_image_value
secs = parse_markdown_artifact(Path(P) / "spec_lock.md")
img = [s for s in secs if s["heading"].strip().lower() == "images"]
print("rows:", len(img[0]["fields"]))   # 0 = 格式错
```

### 3. `has invalid Status 'placed'`

**真因**：§VIII 的 `Status` 列是**闭集**，合法值只有
`pending / failed / generated / sourced / rendered / needs-manual / existing / placeholder`。

**用户已经提供、已经放进页面的现成图 → 用 `existing`**。
`placed`、`done`、`ready` 这类"看起来对"的词全部阻塞。

> `Type: Source` 是特殊值：标记"只喂衍生图的原始素材"，**永不进入 lock 也不进入页面**。
> 正常放上页面的图不要用 `Source`。

## `source=` 与 `crop=` 的合法值

- `source` ∈ `ai / web / user / formula / placeholder / slice`
- `crop` ∈ `adaptive / no-crop`

## 删页 / 重编页码时要一起改的东西

本会话删了 3 页、把 11 页重编成 10 页。**不是改文件名就完事**——质检器有一致性校验，
漏一个就阻塞：

| 要同步改 | 报错 |
|---|---|
| `animations.json` 的 `slides` keys | `references missing slide: <旧 stem>` |
| `design_spec.md §IX` 的 Slide 编号与页数 | `§IX names N slide(s) but svg_output/ holds M` |
| `spec_lock.md` 的 `page_rhythm` P 编号 | 与 §IX 对不上时报页数不符 |
| `notes/*.md`（讲稿） | 陈旧 filenames 会出 advisory，可删 |
| 每页内的页码文本 `NN / MM` | 无报错，但**用户会看到错页码**（本会话就差点漏） |

**重编页码的正则陷阱**：`re.sub(r'>(\d{2}) / 10</text>', ...)` 匹配不到 `>02 / 11</text>`
（因为数字变了）。用宽松式：

```python
re.sub(r">\s*\d{2}\s*/\s*\d{2,3}\s*</text>", f">{label}</text>", s, count=1)
```

**注意 `count=1`**：一页里可能同时有档案编号条和页码，只改第一个出现的页码文本要确认顺序。

## 插页 / 重排：两阶段重命名（避免文件名撞车）

用户中途要求"在最前面加一页自我介绍"时，不是新建一页就完事——**后续所有页要顺移**，
而 `02_responsibility` → `03_responsibility` 这类改动会**撞上已存在的目标名**。

**正确走法：先全部改成临时名，再改成最终名**（两阶段，永不撞车）：

```python
ORDER = ["01_cover.svg", "02_intro.svg", "02_responsibility.svg", ...]  # 期望顺序 → 现有文件名
# phase 1: 现有名 → __tmpNN.svg
for i, f in enumerate(ORDER, 1):
    os.rename(SVG/f, SVG/f"__tmp{i:02d}.svg")
# phase 2: __tmpNN.svg → NN_<去掉旧前缀的原名>.svg
body = re.sub(r"^\d+_", "", old_stem)      # 丢掉旧 NN_ 前缀，保留语义后缀
os.rename(SVG/f"__tmp{i:02d}.svg", SVG/f"{i:02d}_{body}.svg")
```

然后按新顺序重刷页码 `NN / MM` 与档案编号条（正则见上一节）。

**插页后必查**：档案编号/装饰编号会不会**重复**。本会话把自我介绍也标成"档案 002"，
和原有的竞赛材料页撞号，页面上出现两个"档案 002"。
修法是**只让真正的档案条目保留数字编号**，其余页改成功能性标签：

| 页 | 编号 |
|---|---|
| 04 数据库 / 05 竞赛材料（真·做过的事） | `档案 001` / `档案 002` |
| 02 自我介绍 / 03 岗位职责 | `自我介绍` / `岗位职责`（不用数字） |

自查：`re.findall(r"档案 (\d+)</text>", 全册)` 后断言 `len(x) == len(set(x))`。

**重排会让转场配置丢失**：`animation_config.py scaffold --force` 重建后只会保留
**stem 未变**的页的转场，重命名过的页全退回默认 `fade`。所以重排后要**显式重设每页转场**，
并断言没有页停在 `fade`（见下一节）。

## 图片压缩配方（必做）

用户手机/相机原图动辄 10-17MB，20 张直接超 200MB，放映卡。Pillow 压到长边 1700-1900px：

```python
from PIL import Image, ImageOps
Image.MAX_IMAGE_PIXELS = None          # 6000x4000 会触发 DecompressionBombWarning
im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")   # 必须转，否则手机会转90度
im.thumbnail((1900, 1900), Image.LANCZOS)
im.save(dst, "JPEG", quality=88, optimize=True, progressive=True)
```

实测 **41.2MB → 2.03MB**（4.9%），投影画质无损感。

**选图前必须真的看**：生成联络图（contact sheet）后用 `vision_analyze` 逐张看内容与构图。
本会话靠这步发现了关键细节——人像照里用户**正举着相机在活动现场**，人物在右、左侧大片留白，
于是"照片在右 + 文字在左"的封面版式既好看又天然展示了他"在做的事"。
**不看图只看文件名 = 蒙。**

## 注意

- `<image>` 不要写 `xlink:href`。根 `<svg>` 没声明 `xmlns:xlink` 会
  `ParseError: unbound prefix` 直接阻塞。**只用 `href`**（SVG2，技能示例本身也用这个）。
- 图放 `<g id>` 外、标 `data-pptx-role="decoration"` 可避开 bounds 重叠判定（封面全幅人像即如此）。
  放进内容组内则 bounds 要包住它。
